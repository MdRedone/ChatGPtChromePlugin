"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
    get: (a3, b3) => (typeof require !== "undefined" ? require : a3)[b3]
  }) : x)(function(x) {
    if (typeof require !== "undefined")
      return require.apply(this, arguments);
    throw new Error('Dynamic require of "' + x + '" is not supported');
  });
  var __commonJS = (cb, mod) => function __require2() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key2 of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key2) && key2 !== except)
          __defProp(to, key2, { get: () => from[key2], enumerable: !(desc = __getOwnPropDesc(from, key2)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports2, module2) {
      (function(global2, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports2 !== "undefined") {
          factory(module2);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global2.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports2, function(module3) {
        "use strict";
        if (!globalThis.chrome?.runtime?.id) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (typeof globalThis.browser === "undefined" || Object.getPrototypeOf(globalThis.browser) !== Object.prototype) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key2) {
                if (!this.has(key2)) {
                  this.set(key2, this.createItem(key2));
                }
                return super.get(key2);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty7 = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop3) {
                  return prop3 in target || prop3 in cache;
                },
                get(proxyTarget2, prop3, receiver) {
                  if (prop3 in cache) {
                    return cache[prop3];
                  }
                  if (!(prop3 in target)) {
                    return void 0;
                  }
                  let value = target[prop3];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop3] === "function") {
                      value = wrapMethod(target, target[prop3], wrappers[prop3]);
                    } else if (hasOwnProperty7(metadata, prop3)) {
                      let wrapper = wrapAsyncFunction(prop3, metadata[prop3]);
                      value = wrapMethod(target, target[prop3], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty7(wrappers, prop3) || hasOwnProperty7(metadata, prop3))) {
                    value = wrapObject(value, wrappers[prop3], metadata[prop3]);
                  } else if (hasOwnProperty7(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop3], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop3, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop3];
                      },
                      set(value2) {
                        target[prop3] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop3] = value;
                  return value;
                },
                set(proxyTarget2, prop3, value, receiver) {
                  if (prop3 in cache) {
                    cache[prop3] = value;
                  } else {
                    target[prop3] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop3, desc) {
                  return Reflect.defineProperty(cache, prop3, desc);
                },
                deleteProperty(proxyTarget2, prop3) {
                  return Reflect.deleteProperty(cache, prop3);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(
                  req,
                  {},
                  {
                    getContent: {
                      minArgs: 0,
                      maxArgs: 0
                    }
                  }
                );
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module3.exports = wrapAPIs(chrome);
        } else {
          module3.exports = globalThis.browser;
        }
      });
    }
  });

  // node_modules/boolbase/index.js
  var require_boolbase = __commonJS({
    "node_modules/boolbase/index.js"(exports2, module2) {
      module2.exports = {
        trueFunc: function trueFunc2() {
          return true;
        },
        falseFunc: function falseFunc() {
          return false;
        }
      };
    }
  });

  // node_modules/@mozilla/readability/Readability.js
  var require_Readability = __commonJS({
    "node_modules/@mozilla/readability/Readability.js"(exports2, module2) {
      function Readability2(doc, options2) {
        if (options2 && options2.documentElement) {
          doc = options2;
          options2 = arguments[2];
        } else if (!doc || !doc.documentElement) {
          throw new Error("First argument to Readability constructor should be a document object.");
        }
        options2 = options2 || {};
        this._doc = doc;
        this._docJSDOMParser = this._doc.firstChild.__JSDOMParser__;
        this._articleTitle = null;
        this._articleByline = null;
        this._articleDir = null;
        this._articleSiteName = null;
        this._attempts = [];
        this._debug = !!options2.debug;
        this._maxElemsToParse = options2.maxElemsToParse || this.DEFAULT_MAX_ELEMS_TO_PARSE;
        this._nbTopCandidates = options2.nbTopCandidates || this.DEFAULT_N_TOP_CANDIDATES;
        this._charThreshold = options2.charThreshold || this.DEFAULT_CHAR_THRESHOLD;
        this._classesToPreserve = this.CLASSES_TO_PRESERVE.concat(options2.classesToPreserve || []);
        this._keepClasses = !!options2.keepClasses;
        this._serializer = options2.serializer || function(el) {
          return el.innerHTML;
        };
        this._disableJSONLD = !!options2.disableJSONLD;
        this._flags = this.FLAG_STRIP_UNLIKELYS | this.FLAG_WEIGHT_CLASSES | this.FLAG_CLEAN_CONDITIONALLY;
        if (this._debug) {
          let logNode = function(node) {
            if (node.nodeType == node.TEXT_NODE) {
              return `${node.nodeName} ("${node.textContent}")`;
            }
            let attrPairs = Array.from(node.attributes || [], function(attr2) {
              return `${attr2.name}="${attr2.value}"`;
            }).join(" ");
            return `<${node.localName} ${attrPairs}>`;
          };
          this.log = function() {
            if (typeof dump !== "undefined") {
              var msg = Array.prototype.map.call(arguments, function(x) {
                return x && x.nodeName ? logNode(x) : x;
              }).join(" ");
              dump("Reader: (Readability) " + msg + "\n");
            } else if (typeof console !== "undefined") {
              let args = Array.from(arguments, (arg) => {
                if (arg && arg.nodeType == this.ELEMENT_NODE) {
                  return logNode(arg);
                }
                return arg;
              });
              args.unshift("Reader: (Readability)");
              console.log.apply(console, args);
            }
          };
        } else {
          this.log = function() {
          };
        }
      }
      Readability2.prototype = {
        FLAG_STRIP_UNLIKELYS: 1,
        FLAG_WEIGHT_CLASSES: 2,
        FLAG_CLEAN_CONDITIONALLY: 4,
        // https://developer.mozilla.org/en-US/docs/Web/API/Node/nodeType
        ELEMENT_NODE: 1,
        TEXT_NODE: 3,
        // Max number of nodes supported by this parser. Default: 0 (no limit)
        DEFAULT_MAX_ELEMS_TO_PARSE: 0,
        // The number of top candidates to consider when analysing how
        // tight the competition is among candidates.
        DEFAULT_N_TOP_CANDIDATES: 5,
        // Element tags to score by default.
        DEFAULT_TAGS_TO_SCORE: "section,h2,h3,h4,h5,h6,p,td,pre".toUpperCase().split(","),
        // The default number of chars an article must have in order to return a result
        DEFAULT_CHAR_THRESHOLD: 500,
        // All of the regular expressions in use within readability.
        // Defined up here so we don't instantiate them repeatedly in loops.
        REGEXPS: {
          // NOTE: These two regular expressions are duplicated in
          // Readability-readerable.js. Please keep both copies in sync.
          unlikelyCandidates: /-ad-|ai2html|banner|breadcrumbs|combx|comment|community|cover-wrap|disqus|extra|footer|gdpr|header|legends|menu|related|remark|replies|rss|shoutbox|sidebar|skyscraper|social|sponsor|supplemental|ad-break|agegate|pagination|pager|popup|yom-remote/i,
          okMaybeItsACandidate: /and|article|body|column|content|main|shadow/i,
          positive: /article|body|content|entry|hentry|h-entry|main|page|pagination|post|text|blog|story/i,
          negative: /-ad-|hidden|^hid$| hid$| hid |^hid |banner|combx|comment|com-|contact|foot|footer|footnote|gdpr|masthead|media|meta|outbrain|promo|related|scroll|share|shoutbox|sidebar|skyscraper|sponsor|shopping|tags|tool|widget/i,
          extraneous: /print|archive|comment|discuss|e[\-]?mail|share|reply|all|login|sign|single|utility/i,
          byline: /byline|author|dateline|writtenby|p-author/i,
          replaceFonts: /<(\/?)font[^>]*>/gi,
          normalize: /\s{2,}/g,
          videos: /\/\/(www\.)?((dailymotion|youtube|youtube-nocookie|player\.vimeo|v\.qq)\.com|(archive|upload\.wikimedia)\.org|player\.twitch\.tv)/i,
          shareElements: /(\b|_)(share|sharedaddy)(\b|_)/i,
          nextLink: /(next|weiter|continue|>([^\|]|$)|»([^\|]|$))/i,
          prevLink: /(prev|earl|old|new|<|«)/i,
          tokenize: /\W+/g,
          whitespace: /^\s*$/,
          hasContent: /\S$/,
          hashUrl: /^#.+/,
          srcsetUrl: /(\S+)(\s+[\d.]+[xw])?(\s*(?:,|$))/g,
          b64DataUrl: /^data:\s*([^\s;,]+)\s*;\s*base64\s*,/i,
          // See: https://schema.org/Article
          jsonLdArticleTypes: /^Article|AdvertiserContentArticle|NewsArticle|AnalysisNewsArticle|AskPublicNewsArticle|BackgroundNewsArticle|OpinionNewsArticle|ReportageNewsArticle|ReviewNewsArticle|Report|SatiricalArticle|ScholarlyArticle|MedicalScholarlyArticle|SocialMediaPosting|BlogPosting|LiveBlogPosting|DiscussionForumPosting|TechArticle|APIReference$/
        },
        UNLIKELY_ROLES: ["menu", "menubar", "complementary", "navigation", "alert", "alertdialog", "dialog"],
        DIV_TO_P_ELEMS: /* @__PURE__ */ new Set(["BLOCKQUOTE", "DL", "DIV", "IMG", "OL", "P", "PRE", "TABLE", "UL"]),
        ALTER_TO_DIV_EXCEPTIONS: ["DIV", "ARTICLE", "SECTION", "P"],
        PRESENTATIONAL_ATTRIBUTES: ["align", "background", "bgcolor", "border", "cellpadding", "cellspacing", "frame", "hspace", "rules", "style", "valign", "vspace"],
        DEPRECATED_SIZE_ATTRIBUTE_ELEMS: ["TABLE", "TH", "TD", "HR", "PRE"],
        // The commented out elements qualify as phrasing content but tend to be
        // removed by readability when put into paragraphs, so we ignore them here.
        PHRASING_ELEMS: [
          // "CANVAS", "IFRAME", "SVG", "VIDEO",
          "ABBR",
          "AUDIO",
          "B",
          "BDO",
          "BR",
          "BUTTON",
          "CITE",
          "CODE",
          "DATA",
          "DATALIST",
          "DFN",
          "EM",
          "EMBED",
          "I",
          "IMG",
          "INPUT",
          "KBD",
          "LABEL",
          "MARK",
          "MATH",
          "METER",
          "NOSCRIPT",
          "OBJECT",
          "OUTPUT",
          "PROGRESS",
          "Q",
          "RUBY",
          "SAMP",
          "SCRIPT",
          "SELECT",
          "SMALL",
          "SPAN",
          "STRONG",
          "SUB",
          "SUP",
          "TEXTAREA",
          "TIME",
          "VAR",
          "WBR"
        ],
        // These are the classes that readability sets itself.
        CLASSES_TO_PRESERVE: ["page"],
        // These are the list of HTML entities that need to be escaped.
        HTML_ESCAPE_MAP: {
          "lt": "<",
          "gt": ">",
          "amp": "&",
          "quot": '"',
          "apos": "'"
        },
        /**
         * Run any post-process modifications to article content as necessary.
         *
         * @param Element
         * @return void
        **/
        _postProcessContent: function(articleContent) {
          this._fixRelativeUris(articleContent);
          this._simplifyNestedElements(articleContent);
          if (!this._keepClasses) {
            this._cleanClasses(articleContent);
          }
        },
        /**
         * Iterates over a NodeList, calls `filterFn` for each node and removes node
         * if function returned `true`.
         *
         * If function is not passed, removes all the nodes in node list.
         *
         * @param NodeList nodeList The nodes to operate on
         * @param Function filterFn the function to use as a filter
         * @return void
         */
        _removeNodes: function(nodeList, filterFn) {
          if (this._docJSDOMParser && nodeList._isLiveNodeList) {
            throw new Error("Do not pass live node lists to _removeNodes");
          }
          for (var i3 = nodeList.length - 1; i3 >= 0; i3--) {
            var node = nodeList[i3];
            var parentNode = node.parentNode;
            if (parentNode) {
              if (!filterFn || filterFn.call(this, node, i3, nodeList)) {
                parentNode.removeChild(node);
              }
            }
          }
        },
        /**
         * Iterates over a NodeList, and calls _setNodeTag for each node.
         *
         * @param NodeList nodeList The nodes to operate on
         * @param String newTagName the new tag name to use
         * @return void
         */
        _replaceNodeTags: function(nodeList, newTagName) {
          if (this._docJSDOMParser && nodeList._isLiveNodeList) {
            throw new Error("Do not pass live node lists to _replaceNodeTags");
          }
          for (const node of nodeList) {
            this._setNodeTag(node, newTagName);
          }
        },
        /**
         * Iterate over a NodeList, which doesn't natively fully implement the Array
         * interface.
         *
         * For convenience, the current object context is applied to the provided
         * iterate function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The iterate function.
         * @return void
         */
        _forEachNode: function(nodeList, fn) {
          Array.prototype.forEach.call(nodeList, fn, this);
        },
        /**
         * Iterate over a NodeList, and return the first node that passes
         * the supplied test function
         *
         * For convenience, the current object context is applied to the provided
         * test function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The test function.
         * @return void
         */
        _findNode: function(nodeList, fn) {
          return Array.prototype.find.call(nodeList, fn, this);
        },
        /**
         * Iterate over a NodeList, return true if any of the provided iterate
         * function calls returns true, false otherwise.
         *
         * For convenience, the current object context is applied to the
         * provided iterate function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The iterate function.
         * @return Boolean
         */
        _someNode: function(nodeList, fn) {
          return Array.prototype.some.call(nodeList, fn, this);
        },
        /**
         * Iterate over a NodeList, return true if all of the provided iterate
         * function calls return true, false otherwise.
         *
         * For convenience, the current object context is applied to the
         * provided iterate function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The iterate function.
         * @return Boolean
         */
        _everyNode: function(nodeList, fn) {
          return Array.prototype.every.call(nodeList, fn, this);
        },
        /**
         * Concat all nodelists passed as arguments.
         *
         * @return ...NodeList
         * @return Array
         */
        _concatNodeLists: function() {
          var slice2 = Array.prototype.slice;
          var args = slice2.call(arguments);
          var nodeLists = args.map(function(list) {
            return slice2.call(list);
          });
          return Array.prototype.concat.apply([], nodeLists);
        },
        _getAllNodesWithTag: function(node, tagNames) {
          if (node.querySelectorAll) {
            return node.querySelectorAll(tagNames.join(","));
          }
          return [].concat.apply([], tagNames.map(function(tag) {
            var collection = node.getElementsByTagName(tag);
            return Array.isArray(collection) ? collection : Array.from(collection);
          }));
        },
        /**
         * Removes the class="" attribute from every element in the given
         * subtree, except those that match CLASSES_TO_PRESERVE and
         * the classesToPreserve array from the options object.
         *
         * @param Element
         * @return void
         */
        _cleanClasses: function(node) {
          var classesToPreserve = this._classesToPreserve;
          var className = (node.getAttribute("class") || "").split(/\s+/).filter(function(cls) {
            return classesToPreserve.indexOf(cls) != -1;
          }).join(" ");
          if (className) {
            node.setAttribute("class", className);
          } else {
            node.removeAttribute("class");
          }
          for (node = node.firstElementChild; node; node = node.nextElementSibling) {
            this._cleanClasses(node);
          }
        },
        /**
         * Converts each <a> and <img> uri in the given element to an absolute URI,
         * ignoring #ref URIs.
         *
         * @param Element
         * @return void
         */
        _fixRelativeUris: function(articleContent) {
          var baseURI = this._doc.baseURI;
          var documentURI = this._doc.documentURI;
          function toAbsoluteURI(uri) {
            if (baseURI == documentURI && uri.charAt(0) == "#") {
              return uri;
            }
            try {
              return new URL(uri, baseURI).href;
            } catch (ex) {
            }
            return uri;
          }
          var links = this._getAllNodesWithTag(articleContent, ["a"]);
          this._forEachNode(links, function(link) {
            var href = link.getAttribute("href");
            if (href) {
              if (href.indexOf("javascript:") === 0) {
                if (link.childNodes.length === 1 && link.childNodes[0].nodeType === this.TEXT_NODE) {
                  var text3 = this._doc.createTextNode(link.textContent);
                  link.parentNode.replaceChild(text3, link);
                } else {
                  var container = this._doc.createElement("span");
                  while (link.firstChild) {
                    container.appendChild(link.firstChild);
                  }
                  link.parentNode.replaceChild(container, link);
                }
              } else {
                link.setAttribute("href", toAbsoluteURI(href));
              }
            }
          });
          var medias = this._getAllNodesWithTag(articleContent, [
            "img",
            "picture",
            "figure",
            "video",
            "audio",
            "source"
          ]);
          this._forEachNode(medias, function(media) {
            var src = media.getAttribute("src");
            var poster = media.getAttribute("poster");
            var srcset = media.getAttribute("srcset");
            if (src) {
              media.setAttribute("src", toAbsoluteURI(src));
            }
            if (poster) {
              media.setAttribute("poster", toAbsoluteURI(poster));
            }
            if (srcset) {
              var newSrcset = srcset.replace(this.REGEXPS.srcsetUrl, function(_2, p1, p22, p3) {
                return toAbsoluteURI(p1) + (p22 || "") + p3;
              });
              media.setAttribute("srcset", newSrcset);
            }
          });
        },
        _simplifyNestedElements: function(articleContent) {
          var node = articleContent;
          while (node) {
            if (node.parentNode && ["DIV", "SECTION"].includes(node.tagName) && !(node.id && node.id.startsWith("readability"))) {
              if (this._isElementWithoutContent(node)) {
                node = this._removeAndGetNext(node);
                continue;
              } else if (this._hasSingleTagInsideElement(node, "DIV") || this._hasSingleTagInsideElement(node, "SECTION")) {
                var child = node.children[0];
                for (var i3 = 0; i3 < node.attributes.length; i3++) {
                  child.setAttribute(node.attributes[i3].name, node.attributes[i3].value);
                }
                node.parentNode.replaceChild(child, node);
                node = child;
                continue;
              }
            }
            node = this._getNextNode(node);
          }
        },
        /**
         * Get the article title as an H1.
         *
         * @return string
         **/
        _getArticleTitle: function() {
          var doc = this._doc;
          var curTitle = "";
          var origTitle = "";
          try {
            curTitle = origTitle = doc.title.trim();
            if (typeof curTitle !== "string")
              curTitle = origTitle = this._getInnerText(doc.getElementsByTagName("title")[0]);
          } catch (e3) {
          }
          var titleHadHierarchicalSeparators = false;
          function wordCount(str) {
            return str.split(/\s+/).length;
          }
          if (/ [\|\-\\\/>»] /.test(curTitle)) {
            titleHadHierarchicalSeparators = / [\\\/>»] /.test(curTitle);
            curTitle = origTitle.replace(/(.*)[\|\-\\\/>»] .*/gi, "$1");
            if (wordCount(curTitle) < 3)
              curTitle = origTitle.replace(/[^\|\-\\\/>»]*[\|\-\\\/>»](.*)/gi, "$1");
          } else if (curTitle.indexOf(": ") !== -1) {
            var headings = this._concatNodeLists(
              doc.getElementsByTagName("h1"),
              doc.getElementsByTagName("h2")
            );
            var trimmedTitle = curTitle.trim();
            var match = this._someNode(headings, function(heading) {
              return heading.textContent.trim() === trimmedTitle;
            });
            if (!match) {
              curTitle = origTitle.substring(origTitle.lastIndexOf(":") + 1);
              if (wordCount(curTitle) < 3) {
                curTitle = origTitle.substring(origTitle.indexOf(":") + 1);
              } else if (wordCount(origTitle.substr(0, origTitle.indexOf(":"))) > 5) {
                curTitle = origTitle;
              }
            }
          } else if (curTitle.length > 150 || curTitle.length < 15) {
            var hOnes = doc.getElementsByTagName("h1");
            if (hOnes.length === 1)
              curTitle = this._getInnerText(hOnes[0]);
          }
          curTitle = curTitle.trim().replace(this.REGEXPS.normalize, " ");
          var curTitleWordCount = wordCount(curTitle);
          if (curTitleWordCount <= 4 && (!titleHadHierarchicalSeparators || curTitleWordCount != wordCount(origTitle.replace(/[\|\-\\\/>»]+/g, "")) - 1)) {
            curTitle = origTitle;
          }
          return curTitle;
        },
        /**
         * Prepare the HTML document for readability to scrape it.
         * This includes things like stripping javascript, CSS, and handling terrible markup.
         *
         * @return void
         **/
        _prepDocument: function() {
          var doc = this._doc;
          this._removeNodes(this._getAllNodesWithTag(doc, ["style"]));
          if (doc.body) {
            this._replaceBrs(doc.body);
          }
          this._replaceNodeTags(this._getAllNodesWithTag(doc, ["font"]), "SPAN");
        },
        /**
         * Finds the next node, starting from the given node, and ignoring
         * whitespace in between. If the given node is an element, the same node is
         * returned.
         */
        _nextNode: function(node) {
          var next2 = node;
          while (next2 && next2.nodeType != this.ELEMENT_NODE && this.REGEXPS.whitespace.test(next2.textContent)) {
            next2 = next2.nextSibling;
          }
          return next2;
        },
        /**
         * Replaces 2 or more successive <br> elements with a single <p>.
         * Whitespace between <br> elements are ignored. For example:
         *   <div>foo<br>bar<br> <br><br>abc</div>
         * will become:
         *   <div>foo<br>bar<p>abc</p></div>
         */
        _replaceBrs: function(elem) {
          this._forEachNode(this._getAllNodesWithTag(elem, ["br"]), function(br) {
            var next2 = br.nextSibling;
            var replaced = false;
            while ((next2 = this._nextNode(next2)) && next2.tagName == "BR") {
              replaced = true;
              var brSibling = next2.nextSibling;
              next2.parentNode.removeChild(next2);
              next2 = brSibling;
            }
            if (replaced) {
              var p3 = this._doc.createElement("p");
              br.parentNode.replaceChild(p3, br);
              next2 = p3.nextSibling;
              while (next2) {
                if (next2.tagName == "BR") {
                  var nextElem = this._nextNode(next2.nextSibling);
                  if (nextElem && nextElem.tagName == "BR")
                    break;
                }
                if (!this._isPhrasingContent(next2))
                  break;
                var sibling = next2.nextSibling;
                p3.appendChild(next2);
                next2 = sibling;
              }
              while (p3.lastChild && this._isWhitespace(p3.lastChild)) {
                p3.removeChild(p3.lastChild);
              }
              if (p3.parentNode.tagName === "P")
                this._setNodeTag(p3.parentNode, "DIV");
            }
          });
        },
        _setNodeTag: function(node, tag) {
          this.log("_setNodeTag", node, tag);
          if (this._docJSDOMParser) {
            node.localName = tag.toLowerCase();
            node.tagName = tag.toUpperCase();
            return node;
          }
          var replacement = node.ownerDocument.createElement(tag);
          while (node.firstChild) {
            replacement.appendChild(node.firstChild);
          }
          node.parentNode.replaceChild(replacement, node);
          if (node.readability)
            replacement.readability = node.readability;
          for (var i3 = 0; i3 < node.attributes.length; i3++) {
            try {
              replacement.setAttribute(node.attributes[i3].name, node.attributes[i3].value);
            } catch (ex) {
            }
          }
          return replacement;
        },
        /**
         * Prepare the article node for display. Clean out any inline styles,
         * iframes, forms, strip extraneous <p> tags, etc.
         *
         * @param Element
         * @return void
         **/
        _prepArticle: function(articleContent) {
          this._cleanStyles(articleContent);
          this._markDataTables(articleContent);
          this._fixLazyImages(articleContent);
          this._cleanConditionally(articleContent, "form");
          this._cleanConditionally(articleContent, "fieldset");
          this._clean(articleContent, "object");
          this._clean(articleContent, "embed");
          this._clean(articleContent, "footer");
          this._clean(articleContent, "link");
          this._clean(articleContent, "aside");
          var shareElementThreshold = this.DEFAULT_CHAR_THRESHOLD;
          this._forEachNode(articleContent.children, function(topCandidate) {
            this._cleanMatchedNodes(topCandidate, function(node, matchString) {
              return this.REGEXPS.shareElements.test(matchString) && node.textContent.length < shareElementThreshold;
            });
          });
          this._clean(articleContent, "iframe");
          this._clean(articleContent, "input");
          this._clean(articleContent, "textarea");
          this._clean(articleContent, "select");
          this._clean(articleContent, "button");
          this._cleanHeaders(articleContent);
          this._cleanConditionally(articleContent, "table");
          this._cleanConditionally(articleContent, "ul");
          this._cleanConditionally(articleContent, "div");
          this._replaceNodeTags(this._getAllNodesWithTag(articleContent, ["h1"]), "h2");
          this._removeNodes(this._getAllNodesWithTag(articleContent, ["p"]), function(paragraph) {
            var imgCount = paragraph.getElementsByTagName("img").length;
            var embedCount = paragraph.getElementsByTagName("embed").length;
            var objectCount = paragraph.getElementsByTagName("object").length;
            var iframeCount = paragraph.getElementsByTagName("iframe").length;
            var totalCount = imgCount + embedCount + objectCount + iframeCount;
            return totalCount === 0 && !this._getInnerText(paragraph, false);
          });
          this._forEachNode(this._getAllNodesWithTag(articleContent, ["br"]), function(br) {
            var next2 = this._nextNode(br.nextSibling);
            if (next2 && next2.tagName == "P")
              br.parentNode.removeChild(br);
          });
          this._forEachNode(this._getAllNodesWithTag(articleContent, ["table"]), function(table) {
            var tbody = this._hasSingleTagInsideElement(table, "TBODY") ? table.firstElementChild : table;
            if (this._hasSingleTagInsideElement(tbody, "TR")) {
              var row = tbody.firstElementChild;
              if (this._hasSingleTagInsideElement(row, "TD")) {
                var cell = row.firstElementChild;
                cell = this._setNodeTag(cell, this._everyNode(cell.childNodes, this._isPhrasingContent) ? "P" : "DIV");
                table.parentNode.replaceChild(cell, table);
              }
            }
          });
        },
        /**
         * Initialize a node with the readability object. Also checks the
         * className/id for special names to add to its score.
         *
         * @param Element
         * @return void
        **/
        _initializeNode: function(node) {
          node.readability = { "contentScore": 0 };
          switch (node.tagName) {
            case "DIV":
              node.readability.contentScore += 5;
              break;
            case "PRE":
            case "TD":
            case "BLOCKQUOTE":
              node.readability.contentScore += 3;
              break;
            case "ADDRESS":
            case "OL":
            case "UL":
            case "DL":
            case "DD":
            case "DT":
            case "LI":
            case "FORM":
              node.readability.contentScore -= 3;
              break;
            case "H1":
            case "H2":
            case "H3":
            case "H4":
            case "H5":
            case "H6":
            case "TH":
              node.readability.contentScore -= 5;
              break;
          }
          node.readability.contentScore += this._getClassWeight(node);
        },
        _removeAndGetNext: function(node) {
          var nextNode = this._getNextNode(node, true);
          node.parentNode.removeChild(node);
          return nextNode;
        },
        /**
         * Traverse the DOM from node to node, starting at the node passed in.
         * Pass true for the second parameter to indicate this node itself
         * (and its kids) are going away, and we want the next node over.
         *
         * Calling this in a loop will traverse the DOM depth-first.
         */
        _getNextNode: function(node, ignoreSelfAndKids) {
          if (!ignoreSelfAndKids && node.firstElementChild) {
            return node.firstElementChild;
          }
          if (node.nextElementSibling) {
            return node.nextElementSibling;
          }
          do {
            node = node.parentNode;
          } while (node && !node.nextElementSibling);
          return node && node.nextElementSibling;
        },
        // compares second text to first one
        // 1 = same text, 0 = completely different text
        // works the way that it splits both texts into words and then finds words that are unique in second text
        // the result is given by the lower length of unique parts
        _textSimilarity: function(textA, textB) {
          var tokensA = textA.toLowerCase().split(this.REGEXPS.tokenize).filter(Boolean);
          var tokensB = textB.toLowerCase().split(this.REGEXPS.tokenize).filter(Boolean);
          if (!tokensA.length || !tokensB.length) {
            return 0;
          }
          var uniqTokensB = tokensB.filter((token) => !tokensA.includes(token));
          var distanceB = uniqTokensB.join(" ").length / tokensB.join(" ").length;
          return 1 - distanceB;
        },
        _checkByline: function(node, matchString) {
          if (this._articleByline) {
            return false;
          }
          if (node.getAttribute !== void 0) {
            var rel = node.getAttribute("rel");
            var itemprop = node.getAttribute("itemprop");
          }
          if ((rel === "author" || itemprop && itemprop.indexOf("author") !== -1 || this.REGEXPS.byline.test(matchString)) && this._isValidByline(node.textContent)) {
            this._articleByline = node.textContent.trim();
            return true;
          }
          return false;
        },
        _getNodeAncestors: function(node, maxDepth) {
          maxDepth = maxDepth || 0;
          var i3 = 0, ancestors = [];
          while (node.parentNode) {
            ancestors.push(node.parentNode);
            if (maxDepth && ++i3 === maxDepth)
              break;
            node = node.parentNode;
          }
          return ancestors;
        },
        /***
         * grabArticle - Using a variety of metrics (content score, classname, element types), find the content that is
         *         most likely to be the stuff a user wants to read. Then return it wrapped up in a div.
         *
         * @param page a document to run upon. Needs to be a full document, complete with body.
         * @return Element
        **/
        _grabArticle: function(page) {
          this.log("**** grabArticle ****");
          var doc = this._doc;
          var isPaging = page !== null;
          page = page ? page : this._doc.body;
          if (!page) {
            this.log("No body found in document. Abort.");
            return null;
          }
          var pageCacheHtml = page.innerHTML;
          while (true) {
            this.log("Starting grabArticle loop");
            var stripUnlikelyCandidates = this._flagIsActive(this.FLAG_STRIP_UNLIKELYS);
            var elementsToScore = [];
            var node = this._doc.documentElement;
            let shouldRemoveTitleHeader = true;
            while (node) {
              if (node.tagName === "HTML") {
                this._articleLang = node.getAttribute("lang");
              }
              var matchString = node.className + " " + node.id;
              if (!this._isProbablyVisible(node)) {
                this.log("Removing hidden node - " + matchString);
                node = this._removeAndGetNext(node);
                continue;
              }
              if (this._checkByline(node, matchString)) {
                node = this._removeAndGetNext(node);
                continue;
              }
              if (shouldRemoveTitleHeader && this._headerDuplicatesTitle(node)) {
                this.log("Removing header: ", node.textContent.trim(), this._articleTitle.trim());
                shouldRemoveTitleHeader = false;
                node = this._removeAndGetNext(node);
                continue;
              }
              if (stripUnlikelyCandidates) {
                if (this.REGEXPS.unlikelyCandidates.test(matchString) && !this.REGEXPS.okMaybeItsACandidate.test(matchString) && !this._hasAncestorTag(node, "table") && !this._hasAncestorTag(node, "code") && node.tagName !== "BODY" && node.tagName !== "A") {
                  this.log("Removing unlikely candidate - " + matchString);
                  node = this._removeAndGetNext(node);
                  continue;
                }
                if (this.UNLIKELY_ROLES.includes(node.getAttribute("role"))) {
                  this.log("Removing content with role " + node.getAttribute("role") + " - " + matchString);
                  node = this._removeAndGetNext(node);
                  continue;
                }
              }
              if ((node.tagName === "DIV" || node.tagName === "SECTION" || node.tagName === "HEADER" || node.tagName === "H1" || node.tagName === "H2" || node.tagName === "H3" || node.tagName === "H4" || node.tagName === "H5" || node.tagName === "H6") && this._isElementWithoutContent(node)) {
                node = this._removeAndGetNext(node);
                continue;
              }
              if (this.DEFAULT_TAGS_TO_SCORE.indexOf(node.tagName) !== -1) {
                elementsToScore.push(node);
              }
              if (node.tagName === "DIV") {
                var p3 = null;
                var childNode = node.firstChild;
                while (childNode) {
                  var nextSibling2 = childNode.nextSibling;
                  if (this._isPhrasingContent(childNode)) {
                    if (p3 !== null) {
                      p3.appendChild(childNode);
                    } else if (!this._isWhitespace(childNode)) {
                      p3 = doc.createElement("p");
                      node.replaceChild(p3, childNode);
                      p3.appendChild(childNode);
                    }
                  } else if (p3 !== null) {
                    while (p3.lastChild && this._isWhitespace(p3.lastChild)) {
                      p3.removeChild(p3.lastChild);
                    }
                    p3 = null;
                  }
                  childNode = nextSibling2;
                }
                if (this._hasSingleTagInsideElement(node, "P") && this._getLinkDensity(node) < 0.25) {
                  var newNode = node.children[0];
                  node.parentNode.replaceChild(newNode, node);
                  node = newNode;
                  elementsToScore.push(node);
                } else if (!this._hasChildBlockElement(node)) {
                  node = this._setNodeTag(node, "P");
                  elementsToScore.push(node);
                }
              }
              node = this._getNextNode(node);
            }
            var candidates = [];
            this._forEachNode(elementsToScore, function(elementToScore) {
              if (!elementToScore.parentNode || typeof elementToScore.parentNode.tagName === "undefined")
                return;
              var innerText2 = this._getInnerText(elementToScore);
              if (innerText2.length < 25)
                return;
              var ancestors2 = this._getNodeAncestors(elementToScore, 5);
              if (ancestors2.length === 0)
                return;
              var contentScore = 0;
              contentScore += 1;
              contentScore += innerText2.split(",").length;
              contentScore += Math.min(Math.floor(innerText2.length / 100), 3);
              this._forEachNode(ancestors2, function(ancestor, level) {
                if (!ancestor.tagName || !ancestor.parentNode || typeof ancestor.parentNode.tagName === "undefined")
                  return;
                if (typeof ancestor.readability === "undefined") {
                  this._initializeNode(ancestor);
                  candidates.push(ancestor);
                }
                if (level === 0)
                  var scoreDivider = 1;
                else if (level === 1)
                  scoreDivider = 2;
                else
                  scoreDivider = level * 3;
                ancestor.readability.contentScore += contentScore / scoreDivider;
              });
            });
            var topCandidates = [];
            for (var c3 = 0, cl = candidates.length; c3 < cl; c3 += 1) {
              var candidate = candidates[c3];
              var candidateScore = candidate.readability.contentScore * (1 - this._getLinkDensity(candidate));
              candidate.readability.contentScore = candidateScore;
              this.log("Candidate:", candidate, "with score " + candidateScore);
              for (var t3 = 0; t3 < this._nbTopCandidates; t3++) {
                var aTopCandidate = topCandidates[t3];
                if (!aTopCandidate || candidateScore > aTopCandidate.readability.contentScore) {
                  topCandidates.splice(t3, 0, candidate);
                  if (topCandidates.length > this._nbTopCandidates)
                    topCandidates.pop();
                  break;
                }
              }
            }
            var topCandidate = topCandidates[0] || null;
            var neededToCreateTopCandidate = false;
            var parentOfTopCandidate;
            if (topCandidate === null || topCandidate.tagName === "BODY") {
              topCandidate = doc.createElement("DIV");
              neededToCreateTopCandidate = true;
              while (page.firstChild) {
                this.log("Moving child out:", page.firstChild);
                topCandidate.appendChild(page.firstChild);
              }
              page.appendChild(topCandidate);
              this._initializeNode(topCandidate);
            } else if (topCandidate) {
              var alternativeCandidateAncestors = [];
              for (var i3 = 1; i3 < topCandidates.length; i3++) {
                if (topCandidates[i3].readability.contentScore / topCandidate.readability.contentScore >= 0.75) {
                  alternativeCandidateAncestors.push(this._getNodeAncestors(topCandidates[i3]));
                }
              }
              var MINIMUM_TOPCANDIDATES = 3;
              if (alternativeCandidateAncestors.length >= MINIMUM_TOPCANDIDATES) {
                parentOfTopCandidate = topCandidate.parentNode;
                while (parentOfTopCandidate.tagName !== "BODY") {
                  var listsContainingThisAncestor = 0;
                  for (var ancestorIndex = 0; ancestorIndex < alternativeCandidateAncestors.length && listsContainingThisAncestor < MINIMUM_TOPCANDIDATES; ancestorIndex++) {
                    listsContainingThisAncestor += Number(alternativeCandidateAncestors[ancestorIndex].includes(parentOfTopCandidate));
                  }
                  if (listsContainingThisAncestor >= MINIMUM_TOPCANDIDATES) {
                    topCandidate = parentOfTopCandidate;
                    break;
                  }
                  parentOfTopCandidate = parentOfTopCandidate.parentNode;
                }
              }
              if (!topCandidate.readability) {
                this._initializeNode(topCandidate);
              }
              parentOfTopCandidate = topCandidate.parentNode;
              var lastScore = topCandidate.readability.contentScore;
              var scoreThreshold = lastScore / 3;
              while (parentOfTopCandidate.tagName !== "BODY") {
                if (!parentOfTopCandidate.readability) {
                  parentOfTopCandidate = parentOfTopCandidate.parentNode;
                  continue;
                }
                var parentScore = parentOfTopCandidate.readability.contentScore;
                if (parentScore < scoreThreshold)
                  break;
                if (parentScore > lastScore) {
                  topCandidate = parentOfTopCandidate;
                  break;
                }
                lastScore = parentOfTopCandidate.readability.contentScore;
                parentOfTopCandidate = parentOfTopCandidate.parentNode;
              }
              parentOfTopCandidate = topCandidate.parentNode;
              while (parentOfTopCandidate.tagName != "BODY" && parentOfTopCandidate.children.length == 1) {
                topCandidate = parentOfTopCandidate;
                parentOfTopCandidate = topCandidate.parentNode;
              }
              if (!topCandidate.readability) {
                this._initializeNode(topCandidate);
              }
            }
            var articleContent = doc.createElement("DIV");
            if (isPaging)
              articleContent.id = "readability-content";
            var siblingScoreThreshold = Math.max(10, topCandidate.readability.contentScore * 0.2);
            parentOfTopCandidate = topCandidate.parentNode;
            var siblings2 = parentOfTopCandidate.children;
            for (var s2 = 0, sl = siblings2.length; s2 < sl; s2++) {
              var sibling = siblings2[s2];
              var append4 = false;
              this.log("Looking at sibling node:", sibling, sibling.readability ? "with score " + sibling.readability.contentScore : "");
              this.log("Sibling has score", sibling.readability ? sibling.readability.contentScore : "Unknown");
              if (sibling === topCandidate) {
                append4 = true;
              } else {
                var contentBonus = 0;
                if (sibling.className === topCandidate.className && topCandidate.className !== "")
                  contentBonus += topCandidate.readability.contentScore * 0.2;
                if (sibling.readability && sibling.readability.contentScore + contentBonus >= siblingScoreThreshold) {
                  append4 = true;
                } else if (sibling.nodeName === "P") {
                  var linkDensity = this._getLinkDensity(sibling);
                  var nodeContent = this._getInnerText(sibling);
                  var nodeLength = nodeContent.length;
                  if (nodeLength > 80 && linkDensity < 0.25) {
                    append4 = true;
                  } else if (nodeLength < 80 && nodeLength > 0 && linkDensity === 0 && nodeContent.search(/\.( |$)/) !== -1) {
                    append4 = true;
                  }
                }
              }
              if (append4) {
                this.log("Appending node:", sibling);
                if (this.ALTER_TO_DIV_EXCEPTIONS.indexOf(sibling.nodeName) === -1) {
                  this.log("Altering sibling:", sibling, "to div.");
                  sibling = this._setNodeTag(sibling, "DIV");
                }
                articleContent.appendChild(sibling);
                siblings2 = parentOfTopCandidate.children;
                s2 -= 1;
                sl -= 1;
              }
            }
            if (this._debug)
              this.log("Article content pre-prep: " + articleContent.innerHTML);
            this._prepArticle(articleContent);
            if (this._debug)
              this.log("Article content post-prep: " + articleContent.innerHTML);
            if (neededToCreateTopCandidate) {
              topCandidate.id = "readability-page-1";
              topCandidate.className = "page";
            } else {
              var div = doc.createElement("DIV");
              div.id = "readability-page-1";
              div.className = "page";
              while (articleContent.firstChild) {
                div.appendChild(articleContent.firstChild);
              }
              articleContent.appendChild(div);
            }
            if (this._debug)
              this.log("Article content after paging: " + articleContent.innerHTML);
            var parseSuccessful = true;
            var textLength = this._getInnerText(articleContent, true).length;
            if (textLength < this._charThreshold) {
              parseSuccessful = false;
              page.innerHTML = pageCacheHtml;
              if (this._flagIsActive(this.FLAG_STRIP_UNLIKELYS)) {
                this._removeFlag(this.FLAG_STRIP_UNLIKELYS);
                this._attempts.push({ articleContent, textLength });
              } else if (this._flagIsActive(this.FLAG_WEIGHT_CLASSES)) {
                this._removeFlag(this.FLAG_WEIGHT_CLASSES);
                this._attempts.push({ articleContent, textLength });
              } else if (this._flagIsActive(this.FLAG_CLEAN_CONDITIONALLY)) {
                this._removeFlag(this.FLAG_CLEAN_CONDITIONALLY);
                this._attempts.push({ articleContent, textLength });
              } else {
                this._attempts.push({ articleContent, textLength });
                this._attempts.sort(function(a3, b3) {
                  return b3.textLength - a3.textLength;
                });
                if (!this._attempts[0].textLength) {
                  return null;
                }
                articleContent = this._attempts[0].articleContent;
                parseSuccessful = true;
              }
            }
            if (parseSuccessful) {
              var ancestors = [parentOfTopCandidate, topCandidate].concat(this._getNodeAncestors(parentOfTopCandidate));
              this._someNode(ancestors, function(ancestor) {
                if (!ancestor.tagName)
                  return false;
                var articleDir = ancestor.getAttribute("dir");
                if (articleDir) {
                  this._articleDir = articleDir;
                  return true;
                }
                return false;
              });
              return articleContent;
            }
          }
        },
        /**
         * Check whether the input string could be a byline.
         * This verifies that the input is a string, and that the length
         * is less than 100 chars.
         *
         * @param possibleByline {string} - a string to check whether its a byline.
         * @return Boolean - whether the input string is a byline.
         */
        _isValidByline: function(byline) {
          if (typeof byline == "string" || byline instanceof String) {
            byline = byline.trim();
            return byline.length > 0 && byline.length < 100;
          }
          return false;
        },
        /**
         * Converts some of the common HTML entities in string to their corresponding characters.
         *
         * @param str {string} - a string to unescape.
         * @return string without HTML entity.
         */
        _unescapeHtmlEntities: function(str) {
          if (!str) {
            return str;
          }
          var htmlEscapeMap = this.HTML_ESCAPE_MAP;
          return str.replace(/&(quot|amp|apos|lt|gt);/g, function(_2, tag) {
            return htmlEscapeMap[tag];
          }).replace(/&#(?:x([0-9a-z]{1,4})|([0-9]{1,4}));/gi, function(_2, hex, numStr) {
            var num = parseInt(hex || numStr, hex ? 16 : 10);
            return String.fromCharCode(num);
          });
        },
        /**
         * Try to extract metadata from JSON-LD object.
         * For now, only Schema.org objects of type Article or its subtypes are supported.
         * @return Object with any metadata that could be extracted (possibly none)
         */
        _getJSONLD: function(doc) {
          var scripts = this._getAllNodesWithTag(doc, ["script"]);
          var metadata;
          this._forEachNode(scripts, function(jsonLdElement) {
            if (!metadata && jsonLdElement.getAttribute("type") === "application/ld+json") {
              try {
                var content = jsonLdElement.textContent.replace(/^\s*<!\[CDATA\[|\]\]>\s*$/g, "");
                var parsed = JSON.parse(content);
                if (!parsed["@context"] || !parsed["@context"].match(/^https?\:\/\/schema\.org$/)) {
                  return;
                }
                if (!parsed["@type"] && Array.isArray(parsed["@graph"])) {
                  parsed = parsed["@graph"].find(function(it) {
                    return (it["@type"] || "").match(
                      this.REGEXPS.jsonLdArticleTypes
                    );
                  });
                }
                if (!parsed || !parsed["@type"] || !parsed["@type"].match(this.REGEXPS.jsonLdArticleTypes)) {
                  return;
                }
                metadata = {};
                if (typeof parsed.name === "string" && typeof parsed.headline === "string" && parsed.name !== parsed.headline) {
                  var title = this._getArticleTitle();
                  var nameMatches = this._textSimilarity(parsed.name, title) > 0.75;
                  var headlineMatches = this._textSimilarity(parsed.headline, title) > 0.75;
                  if (headlineMatches && !nameMatches) {
                    metadata.title = parsed.headline;
                  } else {
                    metadata.title = parsed.name;
                  }
                } else if (typeof parsed.name === "string") {
                  metadata.title = parsed.name.trim();
                } else if (typeof parsed.headline === "string") {
                  metadata.title = parsed.headline.trim();
                }
                if (parsed.author) {
                  if (typeof parsed.author.name === "string") {
                    metadata.byline = parsed.author.name.trim();
                  } else if (Array.isArray(parsed.author) && parsed.author[0] && typeof parsed.author[0].name === "string") {
                    metadata.byline = parsed.author.filter(function(author) {
                      return author && typeof author.name === "string";
                    }).map(function(author) {
                      return author.name.trim();
                    }).join(", ");
                  }
                }
                if (typeof parsed.description === "string") {
                  metadata.excerpt = parsed.description.trim();
                }
                if (parsed.publisher && typeof parsed.publisher.name === "string") {
                  metadata.siteName = parsed.publisher.name.trim();
                }
                return;
              } catch (err) {
                this.log(err.message);
              }
            }
          });
          return metadata ? metadata : {};
        },
        /**
         * Attempts to get excerpt and byline metadata for the article.
         *
         * @param {Object} jsonld — object containing any metadata that
         * could be extracted from JSON-LD object.
         *
         * @return Object with optional "excerpt" and "byline" properties
         */
        _getArticleMetadata: function(jsonld) {
          var metadata = {};
          var values = {};
          var metaElements = this._doc.getElementsByTagName("meta");
          var propertyPattern = /\s*(dc|dcterm|og|twitter)\s*:\s*(author|creator|description|title|site_name)\s*/gi;
          var namePattern = /^\s*(?:(dc|dcterm|og|twitter|weibo:(article|webpage))\s*[\.:]\s*)?(author|creator|description|title|site_name)\s*$/i;
          this._forEachNode(metaElements, function(element) {
            var elementName = element.getAttribute("name");
            var elementProperty = element.getAttribute("property");
            var content = element.getAttribute("content");
            if (!content) {
              return;
            }
            var matches2 = null;
            var name = null;
            if (elementProperty) {
              matches2 = elementProperty.match(propertyPattern);
              if (matches2) {
                name = matches2[0].toLowerCase().replace(/\s/g, "");
                values[name] = content.trim();
              }
            }
            if (!matches2 && elementName && namePattern.test(elementName)) {
              name = elementName;
              if (content) {
                name = name.toLowerCase().replace(/\s/g, "").replace(/\./g, ":");
                values[name] = content.trim();
              }
            }
          });
          metadata.title = jsonld.title || values["dc:title"] || values["dcterm:title"] || values["og:title"] || values["weibo:article:title"] || values["weibo:webpage:title"] || values["title"] || values["twitter:title"];
          if (!metadata.title) {
            metadata.title = this._getArticleTitle();
          }
          metadata.byline = jsonld.byline || values["dc:creator"] || values["dcterm:creator"] || values["author"];
          metadata.excerpt = jsonld.excerpt || values["dc:description"] || values["dcterm:description"] || values["og:description"] || values["weibo:article:description"] || values["weibo:webpage:description"] || values["description"] || values["twitter:description"];
          metadata.siteName = jsonld.siteName || values["og:site_name"];
          metadata.title = this._unescapeHtmlEntities(metadata.title);
          metadata.byline = this._unescapeHtmlEntities(metadata.byline);
          metadata.excerpt = this._unescapeHtmlEntities(metadata.excerpt);
          metadata.siteName = this._unescapeHtmlEntities(metadata.siteName);
          return metadata;
        },
        /**
         * Check if node is image, or if node contains exactly only one image
         * whether as a direct child or as its descendants.
         *
         * @param Element
        **/
        _isSingleImage: function(node) {
          if (node.tagName === "IMG") {
            return true;
          }
          if (node.children.length !== 1 || node.textContent.trim() !== "") {
            return false;
          }
          return this._isSingleImage(node.children[0]);
        },
        /**
         * Find all <noscript> that are located after <img> nodes, and which contain only one
         * <img> element. Replace the first image with the image from inside the <noscript> tag,
         * and remove the <noscript> tag. This improves the quality of the images we use on
         * some sites (e.g. Medium).
         *
         * @param Element
        **/
        _unwrapNoscriptImages: function(doc) {
          var imgs = Array.from(doc.getElementsByTagName("img"));
          this._forEachNode(imgs, function(img) {
            for (var i3 = 0; i3 < img.attributes.length; i3++) {
              var attr2 = img.attributes[i3];
              switch (attr2.name) {
                case "src":
                case "srcset":
                case "data-src":
                case "data-srcset":
                  return;
              }
              if (/\.(jpg|jpeg|png|webp)/i.test(attr2.value)) {
                return;
              }
            }
            img.parentNode.removeChild(img);
          });
          var noscripts = Array.from(doc.getElementsByTagName("noscript"));
          this._forEachNode(noscripts, function(noscript) {
            var tmp = doc.createElement("div");
            tmp.innerHTML = noscript.innerHTML;
            if (!this._isSingleImage(tmp)) {
              return;
            }
            var prevElement = noscript.previousElementSibling;
            if (prevElement && this._isSingleImage(prevElement)) {
              var prevImg = prevElement;
              if (prevImg.tagName !== "IMG") {
                prevImg = prevElement.getElementsByTagName("img")[0];
              }
              var newImg = tmp.getElementsByTagName("img")[0];
              for (var i3 = 0; i3 < prevImg.attributes.length; i3++) {
                var attr2 = prevImg.attributes[i3];
                if (attr2.value === "") {
                  continue;
                }
                if (attr2.name === "src" || attr2.name === "srcset" || /\.(jpg|jpeg|png|webp)/i.test(attr2.value)) {
                  if (newImg.getAttribute(attr2.name) === attr2.value) {
                    continue;
                  }
                  var attrName = attr2.name;
                  if (newImg.hasAttribute(attrName)) {
                    attrName = "data-old-" + attrName;
                  }
                  newImg.setAttribute(attrName, attr2.value);
                }
              }
              noscript.parentNode.replaceChild(tmp.firstElementChild, prevElement);
            }
          });
        },
        /**
         * Removes script tags from the document.
         *
         * @param Element
        **/
        _removeScripts: function(doc) {
          this._removeNodes(this._getAllNodesWithTag(doc, ["script"]), function(scriptNode) {
            scriptNode.nodeValue = "";
            scriptNode.removeAttribute("src");
            return true;
          });
          this._removeNodes(this._getAllNodesWithTag(doc, ["noscript"]));
        },
        /**
         * Check if this node has only whitespace and a single element with given tag
         * Returns false if the DIV node contains non-empty text nodes
         * or if it contains no element with given tag or more than 1 element.
         *
         * @param Element
         * @param string tag of child element
        **/
        _hasSingleTagInsideElement: function(element, tag) {
          if (element.children.length != 1 || element.children[0].tagName !== tag) {
            return false;
          }
          return !this._someNode(element.childNodes, function(node) {
            return node.nodeType === this.TEXT_NODE && this.REGEXPS.hasContent.test(node.textContent);
          });
        },
        _isElementWithoutContent: function(node) {
          return node.nodeType === this.ELEMENT_NODE && node.textContent.trim().length == 0 && (node.children.length == 0 || node.children.length == node.getElementsByTagName("br").length + node.getElementsByTagName("hr").length);
        },
        /**
         * Determine whether element has any children block level elements.
         *
         * @param Element
         */
        _hasChildBlockElement: function(element) {
          return this._someNode(element.childNodes, function(node) {
            return this.DIV_TO_P_ELEMS.has(node.tagName) || this._hasChildBlockElement(node);
          });
        },
        /***
         * Determine if a node qualifies as phrasing content.
         * https://developer.mozilla.org/en-US/docs/Web/Guide/HTML/Content_categories#Phrasing_content
        **/
        _isPhrasingContent: function(node) {
          return node.nodeType === this.TEXT_NODE || this.PHRASING_ELEMS.indexOf(node.tagName) !== -1 || (node.tagName === "A" || node.tagName === "DEL" || node.tagName === "INS") && this._everyNode(node.childNodes, this._isPhrasingContent);
        },
        _isWhitespace: function(node) {
          return node.nodeType === this.TEXT_NODE && node.textContent.trim().length === 0 || node.nodeType === this.ELEMENT_NODE && node.tagName === "BR";
        },
        /**
         * Get the inner text of a node - cross browser compatibly.
         * This also strips out any excess whitespace to be found.
         *
         * @param Element
         * @param Boolean normalizeSpaces (default: true)
         * @return string
        **/
        _getInnerText: function(e3, normalizeSpaces) {
          normalizeSpaces = typeof normalizeSpaces === "undefined" ? true : normalizeSpaces;
          var textContent2 = e3.textContent.trim();
          if (normalizeSpaces) {
            return textContent2.replace(this.REGEXPS.normalize, " ");
          }
          return textContent2;
        },
        /**
         * Get the number of times a string s appears in the node e.
         *
         * @param Element
         * @param string - what to split on. Default is ","
         * @return number (integer)
        **/
        _getCharCount: function(e3, s2) {
          s2 = s2 || ",";
          return this._getInnerText(e3).split(s2).length - 1;
        },
        /**
         * Remove the style attribute on every e and under.
         * TODO: Test if getElementsByTagName(*) is faster.
         *
         * @param Element
         * @return void
        **/
        _cleanStyles: function(e3) {
          if (!e3 || e3.tagName.toLowerCase() === "svg")
            return;
          for (var i3 = 0; i3 < this.PRESENTATIONAL_ATTRIBUTES.length; i3++) {
            e3.removeAttribute(this.PRESENTATIONAL_ATTRIBUTES[i3]);
          }
          if (this.DEPRECATED_SIZE_ATTRIBUTE_ELEMS.indexOf(e3.tagName) !== -1) {
            e3.removeAttribute("width");
            e3.removeAttribute("height");
          }
          var cur = e3.firstElementChild;
          while (cur !== null) {
            this._cleanStyles(cur);
            cur = cur.nextElementSibling;
          }
        },
        /**
         * Get the density of links as a percentage of the content
         * This is the amount of text that is inside a link divided by the total text in the node.
         *
         * @param Element
         * @return number (float)
        **/
        _getLinkDensity: function(element) {
          var textLength = this._getInnerText(element).length;
          if (textLength === 0)
            return 0;
          var linkLength = 0;
          this._forEachNode(element.getElementsByTagName("a"), function(linkNode) {
            var href = linkNode.getAttribute("href");
            var coefficient = href && this.REGEXPS.hashUrl.test(href) ? 0.3 : 1;
            linkLength += this._getInnerText(linkNode).length * coefficient;
          });
          return linkLength / textLength;
        },
        /**
         * Get an elements class/id weight. Uses regular expressions to tell if this
         * element looks good or bad.
         *
         * @param Element
         * @return number (Integer)
        **/
        _getClassWeight: function(e3) {
          if (!this._flagIsActive(this.FLAG_WEIGHT_CLASSES))
            return 0;
          var weight = 0;
          if (typeof e3.className === "string" && e3.className !== "") {
            if (this.REGEXPS.negative.test(e3.className))
              weight -= 25;
            if (this.REGEXPS.positive.test(e3.className))
              weight += 25;
          }
          if (typeof e3.id === "string" && e3.id !== "") {
            if (this.REGEXPS.negative.test(e3.id))
              weight -= 25;
            if (this.REGEXPS.positive.test(e3.id))
              weight += 25;
          }
          return weight;
        },
        /**
         * Clean a node of all elements of type "tag".
         * (Unless it's a youtube/vimeo video. People love movies.)
         *
         * @param Element
         * @param string tag to clean
         * @return void
         **/
        _clean: function(e3, tag) {
          var isEmbed = ["object", "embed", "iframe"].indexOf(tag) !== -1;
          this._removeNodes(this._getAllNodesWithTag(e3, [tag]), function(element) {
            if (isEmbed) {
              for (var i3 = 0; i3 < element.attributes.length; i3++) {
                if (this.REGEXPS.videos.test(element.attributes[i3].value)) {
                  return false;
                }
              }
              if (element.tagName === "object" && this.REGEXPS.videos.test(element.innerHTML)) {
                return false;
              }
            }
            return true;
          });
        },
        /**
         * Check if a given node has one of its ancestor tag name matching the
         * provided one.
         * @param  HTMLElement node
         * @param  String      tagName
         * @param  Number      maxDepth
         * @param  Function    filterFn a filter to invoke to determine whether this node 'counts'
         * @return Boolean
         */
        _hasAncestorTag: function(node, tagName18, maxDepth, filterFn) {
          maxDepth = maxDepth || 3;
          tagName18 = tagName18.toUpperCase();
          var depth = 0;
          while (node.parentNode) {
            if (maxDepth > 0 && depth > maxDepth)
              return false;
            if (node.parentNode.tagName === tagName18 && (!filterFn || filterFn(node.parentNode)))
              return true;
            node = node.parentNode;
            depth++;
          }
          return false;
        },
        /**
         * Return an object indicating how many rows and columns this table has.
         */
        _getRowAndColumnCount: function(table) {
          var rows = 0;
          var columns = 0;
          var trs = table.getElementsByTagName("tr");
          for (var i3 = 0; i3 < trs.length; i3++) {
            var rowspan = trs[i3].getAttribute("rowspan") || 0;
            if (rowspan) {
              rowspan = parseInt(rowspan, 10);
            }
            rows += rowspan || 1;
            var columnsInThisRow = 0;
            var cells = trs[i3].getElementsByTagName("td");
            for (var j3 = 0; j3 < cells.length; j3++) {
              var colspan = cells[j3].getAttribute("colspan") || 0;
              if (colspan) {
                colspan = parseInt(colspan, 10);
              }
              columnsInThisRow += colspan || 1;
            }
            columns = Math.max(columns, columnsInThisRow);
          }
          return { rows, columns };
        },
        /**
         * Look for 'data' (as opposed to 'layout') tables, for which we use
         * similar checks as
         * https://searchfox.org/mozilla-central/rev/f82d5c549f046cb64ce5602bfd894b7ae807c8f8/accessible/generic/TableAccessible.cpp#19
         */
        _markDataTables: function(root4) {
          var tables = root4.getElementsByTagName("table");
          for (var i3 = 0; i3 < tables.length; i3++) {
            var table = tables[i3];
            var role = table.getAttribute("role");
            if (role == "presentation") {
              table._readabilityDataTable = false;
              continue;
            }
            var datatable = table.getAttribute("datatable");
            if (datatable == "0") {
              table._readabilityDataTable = false;
              continue;
            }
            var summary = table.getAttribute("summary");
            if (summary) {
              table._readabilityDataTable = true;
              continue;
            }
            var caption = table.getElementsByTagName("caption")[0];
            if (caption && caption.childNodes.length > 0) {
              table._readabilityDataTable = true;
              continue;
            }
            var dataTableDescendants = ["col", "colgroup", "tfoot", "thead", "th"];
            var descendantExists = function(tag) {
              return !!table.getElementsByTagName(tag)[0];
            };
            if (dataTableDescendants.some(descendantExists)) {
              this.log("Data table because found data-y descendant");
              table._readabilityDataTable = true;
              continue;
            }
            if (table.getElementsByTagName("table")[0]) {
              table._readabilityDataTable = false;
              continue;
            }
            var sizeInfo = this._getRowAndColumnCount(table);
            if (sizeInfo.rows >= 10 || sizeInfo.columns > 4) {
              table._readabilityDataTable = true;
              continue;
            }
            table._readabilityDataTable = sizeInfo.rows * sizeInfo.columns > 10;
          }
        },
        /* convert images and figures that have properties like data-src into images that can be loaded without JS */
        _fixLazyImages: function(root4) {
          this._forEachNode(this._getAllNodesWithTag(root4, ["img", "picture", "figure"]), function(elem) {
            if (elem.src && this.REGEXPS.b64DataUrl.test(elem.src)) {
              var parts = this.REGEXPS.b64DataUrl.exec(elem.src);
              if (parts[1] === "image/svg+xml") {
                return;
              }
              var srcCouldBeRemoved = false;
              for (var i3 = 0; i3 < elem.attributes.length; i3++) {
                var attr2 = elem.attributes[i3];
                if (attr2.name === "src") {
                  continue;
                }
                if (/\.(jpg|jpeg|png|webp)/i.test(attr2.value)) {
                  srcCouldBeRemoved = true;
                  break;
                }
              }
              if (srcCouldBeRemoved) {
                var b64starts = elem.src.search(/base64\s*/i) + 7;
                var b64length = elem.src.length - b64starts;
                if (b64length < 133) {
                  elem.removeAttribute("src");
                }
              }
            }
            if ((elem.src || elem.srcset && elem.srcset != "null") && elem.className.toLowerCase().indexOf("lazy") === -1) {
              return;
            }
            for (var j3 = 0; j3 < elem.attributes.length; j3++) {
              attr2 = elem.attributes[j3];
              if (attr2.name === "src" || attr2.name === "srcset" || attr2.name === "alt") {
                continue;
              }
              var copyTo = null;
              if (/\.(jpg|jpeg|png|webp)\s+\d/.test(attr2.value)) {
                copyTo = "srcset";
              } else if (/^\s*\S+\.(jpg|jpeg|png|webp)\S*\s*$/.test(attr2.value)) {
                copyTo = "src";
              }
              if (copyTo) {
                if (elem.tagName === "IMG" || elem.tagName === "PICTURE") {
                  elem.setAttribute(copyTo, attr2.value);
                } else if (elem.tagName === "FIGURE" && !this._getAllNodesWithTag(elem, ["img", "picture"]).length) {
                  var img = this._doc.createElement("img");
                  img.setAttribute(copyTo, attr2.value);
                  elem.appendChild(img);
                }
              }
            }
          });
        },
        _getTextDensity: function(e3, tags) {
          var textLength = this._getInnerText(e3, true).length;
          if (textLength === 0) {
            return 0;
          }
          var childrenLength = 0;
          var children2 = this._getAllNodesWithTag(e3, tags);
          this._forEachNode(children2, (child) => childrenLength += this._getInnerText(child, true).length);
          return childrenLength / textLength;
        },
        /**
         * Clean an element of all tags of type "tag" if they look fishy.
         * "Fishy" is an algorithm based on content length, classnames, link density, number of images & embeds, etc.
         *
         * @return void
         **/
        _cleanConditionally: function(e3, tag) {
          if (!this._flagIsActive(this.FLAG_CLEAN_CONDITIONALLY))
            return;
          this._removeNodes(this._getAllNodesWithTag(e3, [tag]), function(node) {
            var isDataTable = function(t3) {
              return t3._readabilityDataTable;
            };
            var isList = tag === "ul" || tag === "ol";
            if (!isList) {
              var listLength = 0;
              var listNodes = this._getAllNodesWithTag(node, ["ul", "ol"]);
              this._forEachNode(listNodes, (list) => listLength += this._getInnerText(list).length);
              isList = listLength / this._getInnerText(node).length > 0.9;
            }
            if (tag === "table" && isDataTable(node)) {
              return false;
            }
            if (this._hasAncestorTag(node, "table", -1, isDataTable)) {
              return false;
            }
            if (this._hasAncestorTag(node, "code")) {
              return false;
            }
            var weight = this._getClassWeight(node);
            this.log("Cleaning Conditionally", node);
            var contentScore = 0;
            if (weight + contentScore < 0) {
              return true;
            }
            if (this._getCharCount(node, ",") < 10) {
              var p3 = node.getElementsByTagName("p").length;
              var img = node.getElementsByTagName("img").length;
              var li = node.getElementsByTagName("li").length - 100;
              var input = node.getElementsByTagName("input").length;
              var headingDensity = this._getTextDensity(node, ["h1", "h2", "h3", "h4", "h5", "h6"]);
              var embedCount = 0;
              var embeds = this._getAllNodesWithTag(node, ["object", "embed", "iframe"]);
              for (var i3 = 0; i3 < embeds.length; i3++) {
                for (var j3 = 0; j3 < embeds[i3].attributes.length; j3++) {
                  if (this.REGEXPS.videos.test(embeds[i3].attributes[j3].value)) {
                    return false;
                  }
                }
                if (embeds[i3].tagName === "object" && this.REGEXPS.videos.test(embeds[i3].innerHTML)) {
                  return false;
                }
                embedCount++;
              }
              var linkDensity = this._getLinkDensity(node);
              var contentLength = this._getInnerText(node).length;
              var haveToRemove = img > 1 && p3 / img < 0.5 && !this._hasAncestorTag(node, "figure") || !isList && li > p3 || input > Math.floor(p3 / 3) || !isList && headingDensity < 0.9 && contentLength < 25 && (img === 0 || img > 2) && !this._hasAncestorTag(node, "figure") || !isList && weight < 25 && linkDensity > 0.2 || weight >= 25 && linkDensity > 0.5 || (embedCount === 1 && contentLength < 75 || embedCount > 1);
              return haveToRemove;
            }
            return false;
          });
        },
        /**
         * Clean out elements that match the specified conditions
         *
         * @param Element
         * @param Function determines whether a node should be removed
         * @return void
         **/
        _cleanMatchedNodes: function(e3, filter4) {
          var endOfSearchMarkerNode = this._getNextNode(e3, true);
          var next2 = this._getNextNode(e3);
          while (next2 && next2 != endOfSearchMarkerNode) {
            if (filter4.call(this, next2, next2.className + " " + next2.id)) {
              next2 = this._removeAndGetNext(next2);
            } else {
              next2 = this._getNextNode(next2);
            }
          }
        },
        /**
         * Clean out spurious headers from an Element.
         *
         * @param Element
         * @return void
        **/
        _cleanHeaders: function(e3) {
          let headingNodes = this._getAllNodesWithTag(e3, ["h1", "h2"]);
          this._removeNodes(headingNodes, function(node) {
            let shouldRemove = this._getClassWeight(node) < 0;
            if (shouldRemove) {
              this.log("Removing header with low class weight:", node);
            }
            return shouldRemove;
          });
        },
        /**
         * Check if this node is an H1 or H2 element whose content is mostly
         * the same as the article title.
         *
         * @param Element  the node to check.
         * @return boolean indicating whether this is a title-like header.
         */
        _headerDuplicatesTitle: function(node) {
          if (node.tagName != "H1" && node.tagName != "H2") {
            return false;
          }
          var heading = this._getInnerText(node, false);
          this.log("Evaluating similarity of header:", heading, this._articleTitle);
          return this._textSimilarity(this._articleTitle, heading) > 0.75;
        },
        _flagIsActive: function(flag) {
          return (this._flags & flag) > 0;
        },
        _removeFlag: function(flag) {
          this._flags = this._flags & ~flag;
        },
        _isProbablyVisible: function(node) {
          return (!node.style || node.style.display != "none") && !node.hasAttribute("hidden") && (!node.hasAttribute("aria-hidden") || node.getAttribute("aria-hidden") != "true" || node.className && node.className.indexOf && node.className.indexOf("fallback-image") !== -1);
        },
        /**
         * Runs readability.
         *
         * Workflow:
         *  1. Prep the document by removing script tags, css, etc.
         *  2. Build readability's DOM tree.
         *  3. Grab the article content from the current dom tree.
         *  4. Replace the current DOM tree with the new one.
         *  5. Read peacefully.
         *
         * @return void
         **/
        parse: function() {
          if (this._maxElemsToParse > 0) {
            var numTags = this._doc.getElementsByTagName("*").length;
            if (numTags > this._maxElemsToParse) {
              throw new Error("Aborting parsing document; " + numTags + " elements found");
            }
          }
          this._unwrapNoscriptImages(this._doc);
          var jsonLd = this._disableJSONLD ? {} : this._getJSONLD(this._doc);
          this._removeScripts(this._doc);
          this._prepDocument();
          var metadata = this._getArticleMetadata(jsonLd);
          this._articleTitle = metadata.title;
          var articleContent = this._grabArticle();
          if (!articleContent)
            return null;
          this.log("Grabbed: " + articleContent.innerHTML);
          this._postProcessContent(articleContent);
          if (!metadata.excerpt) {
            var paragraphs = articleContent.getElementsByTagName("p");
            if (paragraphs.length > 0) {
              metadata.excerpt = paragraphs[0].textContent.trim();
            }
          }
          var textContent2 = articleContent.textContent;
          return {
            title: this._articleTitle,
            byline: metadata.byline || this._articleByline,
            dir: this._articleDir,
            lang: this._articleLang,
            content: this._serializer(articleContent),
            textContent: textContent2,
            length: textContent2.length,
            excerpt: metadata.excerpt,
            siteName: metadata.siteName || this._articleSiteName
          };
        }
      };
      if (typeof module2 === "object") {
        module2.exports = Readability2;
      }
    }
  });

  // node_modules/@mozilla/readability/Readability-readerable.js
  var require_Readability_readerable = __commonJS({
    "node_modules/@mozilla/readability/Readability-readerable.js"(exports2, module2) {
      var REGEXPS = {
        // NOTE: These two regular expressions are duplicated in
        // Readability.js. Please keep both copies in sync.
        unlikelyCandidates: /-ad-|ai2html|banner|breadcrumbs|combx|comment|community|cover-wrap|disqus|extra|footer|gdpr|header|legends|menu|related|remark|replies|rss|shoutbox|sidebar|skyscraper|social|sponsor|supplemental|ad-break|agegate|pagination|pager|popup|yom-remote/i,
        okMaybeItsACandidate: /and|article|body|column|content|main|shadow/i
      };
      function isNodeVisible(node) {
        return (!node.style || node.style.display != "none") && !node.hasAttribute("hidden") && (!node.hasAttribute("aria-hidden") || node.getAttribute("aria-hidden") != "true" || node.className && node.className.indexOf && node.className.indexOf("fallback-image") !== -1);
      }
      function isProbablyReaderable(doc, options2 = {}) {
        if (typeof options2 == "function") {
          options2 = { visibilityChecker: options2 };
        }
        var defaultOptions2 = { minScore: 20, minContentLength: 140, visibilityChecker: isNodeVisible };
        options2 = Object.assign(defaultOptions2, options2);
        var nodes = doc.querySelectorAll("p, pre, article");
        var brNodes = doc.querySelectorAll("div > br");
        if (brNodes.length) {
          var set = new Set(nodes);
          [].forEach.call(brNodes, function(node) {
            set.add(node.parentNode);
          });
          nodes = Array.from(set);
        }
        var score = 0;
        return [].some.call(nodes, function(node) {
          if (!options2.visibilityChecker(node)) {
            return false;
          }
          var matchString = node.className + " " + node.id;
          if (REGEXPS.unlikelyCandidates.test(matchString) && !REGEXPS.okMaybeItsACandidate.test(matchString)) {
            return false;
          }
          if (node.matches("li p")) {
            return false;
          }
          var textContentLength = node.textContent.trim().length;
          if (textContentLength < options2.minContentLength) {
            return false;
          }
          score += Math.sqrt(textContentLength - options2.minContentLength);
          if (score > options2.minScore) {
            return true;
          }
          return false;
        });
      }
      if (typeof module2 === "object") {
        module2.exports = isProbablyReaderable;
      }
    }
  });

  // node_modules/@mozilla/readability/index.js
  var require_readability = __commonJS({
    "node_modules/@mozilla/readability/index.js"(exports2, module2) {
      var Readability2 = require_Readability();
      var isProbablyReaderable = require_Readability_readerable();
      module2.exports = {
        Readability: Readability2,
        isProbablyReaderable
      };
    }
  });

  // node_modules/linkedom/commonjs/perf_hooks.cjs
  var require_perf_hooks = __commonJS({
    "node_modules/linkedom/commonjs/perf_hooks.cjs"(exports2) {
      try {
        const { performance: performance2 } = __require("perf_hooks");
        exports2.performance = performance2;
      } catch (fallback) {
        exports2.performance = { now() {
          return +new Date();
        } };
      }
    }
  });

  // node_modules/cssom/lib/StyleSheet.js
  var require_StyleSheet = __commonJS({
    "node_modules/cssom/lib/StyleSheet.js"(exports2) {
      var CSSOM = {};
      CSSOM.StyleSheet = function StyleSheet() {
        this.parentStyleSheet = null;
      };
      exports2.StyleSheet = CSSOM.StyleSheet;
    }
  });

  // node_modules/cssom/lib/CSSRule.js
  var require_CSSRule = __commonJS({
    "node_modules/cssom/lib/CSSRule.js"(exports2) {
      var CSSOM = {};
      CSSOM.CSSRule = function CSSRule() {
        this.parentRule = null;
        this.parentStyleSheet = null;
      };
      CSSOM.CSSRule.UNKNOWN_RULE = 0;
      CSSOM.CSSRule.STYLE_RULE = 1;
      CSSOM.CSSRule.CHARSET_RULE = 2;
      CSSOM.CSSRule.IMPORT_RULE = 3;
      CSSOM.CSSRule.MEDIA_RULE = 4;
      CSSOM.CSSRule.FONT_FACE_RULE = 5;
      CSSOM.CSSRule.PAGE_RULE = 6;
      CSSOM.CSSRule.KEYFRAMES_RULE = 7;
      CSSOM.CSSRule.KEYFRAME_RULE = 8;
      CSSOM.CSSRule.MARGIN_RULE = 9;
      CSSOM.CSSRule.NAMESPACE_RULE = 10;
      CSSOM.CSSRule.COUNTER_STYLE_RULE = 11;
      CSSOM.CSSRule.SUPPORTS_RULE = 12;
      CSSOM.CSSRule.DOCUMENT_RULE = 13;
      CSSOM.CSSRule.FONT_FEATURE_VALUES_RULE = 14;
      CSSOM.CSSRule.VIEWPORT_RULE = 15;
      CSSOM.CSSRule.REGION_STYLE_RULE = 16;
      CSSOM.CSSRule.prototype = {
        constructor: CSSOM.CSSRule
        //FIXME
      };
      exports2.CSSRule = CSSOM.CSSRule;
    }
  });

  // node_modules/cssom/lib/CSSStyleRule.js
  var require_CSSStyleRule = __commonJS({
    "node_modules/cssom/lib/CSSStyleRule.js"(exports2) {
      var CSSOM = {
        CSSStyleDeclaration: require_CSSStyleDeclaration().CSSStyleDeclaration,
        CSSRule: require_CSSRule().CSSRule
      };
      CSSOM.CSSStyleRule = function CSSStyleRule() {
        CSSOM.CSSRule.call(this);
        this.selectorText = "";
        this.style = new CSSOM.CSSStyleDeclaration();
        this.style.parentRule = this;
      };
      CSSOM.CSSStyleRule.prototype = new CSSOM.CSSRule();
      CSSOM.CSSStyleRule.prototype.constructor = CSSOM.CSSStyleRule;
      CSSOM.CSSStyleRule.prototype.type = 1;
      Object.defineProperty(CSSOM.CSSStyleRule.prototype, "cssText", {
        get: function() {
          var text3;
          if (this.selectorText) {
            text3 = this.selectorText + " {" + this.style.cssText + "}";
          } else {
            text3 = "";
          }
          return text3;
        },
        set: function(cssText) {
          var rule = CSSOM.CSSStyleRule.parse(cssText);
          this.style = rule.style;
          this.selectorText = rule.selectorText;
        }
      });
      CSSOM.CSSStyleRule.parse = function(ruleText) {
        var i3 = 0;
        var state = "selector";
        var index2;
        var j3 = i3;
        var buffer = "";
        var SIGNIFICANT_WHITESPACE = {
          "selector": true,
          "value": true
        };
        var styleRule = new CSSOM.CSSStyleRule();
        var name, priority = "";
        for (var character; character = ruleText.charAt(i3); i3++) {
          switch (character) {
            case " ":
            case "	":
            case "\r":
            case "\n":
            case "\f":
              if (SIGNIFICANT_WHITESPACE[state]) {
                switch (ruleText.charAt(i3 - 1)) {
                  case " ":
                  case "	":
                  case "\r":
                  case "\n":
                  case "\f":
                    break;
                  default:
                    buffer += " ";
                    break;
                }
              }
              break;
            case '"':
              j3 = i3 + 1;
              index2 = ruleText.indexOf('"', j3) + 1;
              if (!index2) {
                throw '" is missing';
              }
              buffer += ruleText.slice(i3, index2);
              i3 = index2 - 1;
              break;
            case "'":
              j3 = i3 + 1;
              index2 = ruleText.indexOf("'", j3) + 1;
              if (!index2) {
                throw "' is missing";
              }
              buffer += ruleText.slice(i3, index2);
              i3 = index2 - 1;
              break;
            case "/":
              if (ruleText.charAt(i3 + 1) === "*") {
                i3 += 2;
                index2 = ruleText.indexOf("*/", i3);
                if (index2 === -1) {
                  throw new SyntaxError("Missing */");
                } else {
                  i3 = index2 + 1;
                }
              } else {
                buffer += character;
              }
              break;
            case "{":
              if (state === "selector") {
                styleRule.selectorText = buffer.trim();
                buffer = "";
                state = "name";
              }
              break;
            case ":":
              if (state === "name") {
                name = buffer.trim();
                buffer = "";
                state = "value";
              } else {
                buffer += character;
              }
              break;
            case "!":
              if (state === "value" && ruleText.indexOf("!important", i3) === i3) {
                priority = "important";
                i3 += "important".length;
              } else {
                buffer += character;
              }
              break;
            case ";":
              if (state === "value") {
                styleRule.style.setProperty(name, buffer.trim(), priority);
                priority = "";
                buffer = "";
                state = "name";
              } else {
                buffer += character;
              }
              break;
            case "}":
              if (state === "value") {
                styleRule.style.setProperty(name, buffer.trim(), priority);
                priority = "";
                buffer = "";
              } else if (state === "name") {
                break;
              } else {
                buffer += character;
              }
              state = "selector";
              break;
            default:
              buffer += character;
              break;
          }
        }
        return styleRule;
      };
      exports2.CSSStyleRule = CSSOM.CSSStyleRule;
    }
  });

  // node_modules/cssom/lib/CSSStyleSheet.js
  var require_CSSStyleSheet = __commonJS({
    "node_modules/cssom/lib/CSSStyleSheet.js"(exports2) {
      var CSSOM = {
        StyleSheet: require_StyleSheet().StyleSheet,
        CSSStyleRule: require_CSSStyleRule().CSSStyleRule
      };
      CSSOM.CSSStyleSheet = function CSSStyleSheet() {
        CSSOM.StyleSheet.call(this);
        this.cssRules = [];
      };
      CSSOM.CSSStyleSheet.prototype = new CSSOM.StyleSheet();
      CSSOM.CSSStyleSheet.prototype.constructor = CSSOM.CSSStyleSheet;
      CSSOM.CSSStyleSheet.prototype.insertRule = function(rule, index2) {
        if (index2 < 0 || index2 > this.cssRules.length) {
          throw new RangeError("INDEX_SIZE_ERR");
        }
        var cssRule = CSSOM.parse(rule).cssRules[0];
        cssRule.parentStyleSheet = this;
        this.cssRules.splice(index2, 0, cssRule);
        return index2;
      };
      CSSOM.CSSStyleSheet.prototype.deleteRule = function(index2) {
        if (index2 < 0 || index2 >= this.cssRules.length) {
          throw new RangeError("INDEX_SIZE_ERR");
        }
        this.cssRules.splice(index2, 1);
      };
      CSSOM.CSSStyleSheet.prototype.toString = function() {
        var result = "";
        var rules = this.cssRules;
        for (var i3 = 0; i3 < rules.length; i3++) {
          result += rules[i3].cssText + "\n";
        }
        return result;
      };
      exports2.CSSStyleSheet = CSSOM.CSSStyleSheet;
      CSSOM.parse = require_parse().parse;
    }
  });

  // node_modules/cssom/lib/MediaList.js
  var require_MediaList = __commonJS({
    "node_modules/cssom/lib/MediaList.js"(exports2) {
      var CSSOM = {};
      CSSOM.MediaList = function MediaList() {
        this.length = 0;
      };
      CSSOM.MediaList.prototype = {
        constructor: CSSOM.MediaList,
        /**
         * @return {string}
         */
        get mediaText() {
          return Array.prototype.join.call(this, ", ");
        },
        /**
         * @param {string} value
         */
        set mediaText(value) {
          var values = value.split(",");
          var length = this.length = values.length;
          for (var i3 = 0; i3 < length; i3++) {
            this[i3] = values[i3].trim();
          }
        },
        /**
         * @param {string} medium
         */
        appendMedium: function(medium) {
          if (Array.prototype.indexOf.call(this, medium) === -1) {
            this[this.length] = medium;
            this.length++;
          }
        },
        /**
         * @param {string} medium
         */
        deleteMedium: function(medium) {
          var index2 = Array.prototype.indexOf.call(this, medium);
          if (index2 !== -1) {
            Array.prototype.splice.call(this, index2, 1);
          }
        }
      };
      exports2.MediaList = CSSOM.MediaList;
    }
  });

  // node_modules/cssom/lib/CSSImportRule.js
  var require_CSSImportRule = __commonJS({
    "node_modules/cssom/lib/CSSImportRule.js"(exports2) {
      var CSSOM = {
        CSSRule: require_CSSRule().CSSRule,
        CSSStyleSheet: require_CSSStyleSheet().CSSStyleSheet,
        MediaList: require_MediaList().MediaList
      };
      CSSOM.CSSImportRule = function CSSImportRule() {
        CSSOM.CSSRule.call(this);
        this.href = "";
        this.media = new CSSOM.MediaList();
        this.styleSheet = new CSSOM.CSSStyleSheet();
      };
      CSSOM.CSSImportRule.prototype = new CSSOM.CSSRule();
      CSSOM.CSSImportRule.prototype.constructor = CSSOM.CSSImportRule;
      CSSOM.CSSImportRule.prototype.type = 3;
      Object.defineProperty(CSSOM.CSSImportRule.prototype, "cssText", {
        get: function() {
          var mediaText = this.media.mediaText;
          return "@import url(" + this.href + ")" + (mediaText ? " " + mediaText : "") + ";";
        },
        set: function(cssText) {
          var i3 = 0;
          var state = "";
          var buffer = "";
          var index2;
          for (var character; character = cssText.charAt(i3); i3++) {
            switch (character) {
              case " ":
              case "	":
              case "\r":
              case "\n":
              case "\f":
                if (state === "after-import") {
                  state = "url";
                } else {
                  buffer += character;
                }
                break;
              case "@":
                if (!state && cssText.indexOf("@import", i3) === i3) {
                  state = "after-import";
                  i3 += "import".length;
                  buffer = "";
                }
                break;
              case "u":
                if (state === "url" && cssText.indexOf("url(", i3) === i3) {
                  index2 = cssText.indexOf(")", i3 + 1);
                  if (index2 === -1) {
                    throw i3 + ': ")" not found';
                  }
                  i3 += "url(".length;
                  var url = cssText.slice(i3, index2);
                  if (url[0] === url[url.length - 1]) {
                    if (url[0] === '"' || url[0] === "'") {
                      url = url.slice(1, -1);
                    }
                  }
                  this.href = url;
                  i3 = index2;
                  state = "media";
                }
                break;
              case '"':
                if (state === "url") {
                  index2 = cssText.indexOf('"', i3 + 1);
                  if (!index2) {
                    throw i3 + `: '"' not found`;
                  }
                  this.href = cssText.slice(i3 + 1, index2);
                  i3 = index2;
                  state = "media";
                }
                break;
              case "'":
                if (state === "url") {
                  index2 = cssText.indexOf("'", i3 + 1);
                  if (!index2) {
                    throw i3 + `: "'" not found`;
                  }
                  this.href = cssText.slice(i3 + 1, index2);
                  i3 = index2;
                  state = "media";
                }
                break;
              case ";":
                if (state === "media") {
                  if (buffer) {
                    this.media.mediaText = buffer.trim();
                  }
                }
                break;
              default:
                if (state === "media") {
                  buffer += character;
                }
                break;
            }
          }
        }
      });
      exports2.CSSImportRule = CSSOM.CSSImportRule;
    }
  });

  // node_modules/cssom/lib/CSSGroupingRule.js
  var require_CSSGroupingRule = __commonJS({
    "node_modules/cssom/lib/CSSGroupingRule.js"(exports2) {
      var CSSOM = {
        CSSRule: require_CSSRule().CSSRule
      };
      CSSOM.CSSGroupingRule = function CSSGroupingRule() {
        CSSOM.CSSRule.call(this);
        this.cssRules = [];
      };
      CSSOM.CSSGroupingRule.prototype = new CSSOM.CSSRule();
      CSSOM.CSSGroupingRule.prototype.constructor = CSSOM.CSSGroupingRule;
      CSSOM.CSSGroupingRule.prototype.insertRule = function insertRule(rule, index2) {
        if (index2 < 0 || index2 > this.cssRules.length) {
          throw new RangeError("INDEX_SIZE_ERR");
        }
        var cssRule = CSSOM.parse(rule).cssRules[0];
        cssRule.parentRule = this;
        this.cssRules.splice(index2, 0, cssRule);
        return index2;
      };
      CSSOM.CSSGroupingRule.prototype.deleteRule = function deleteRule(index2) {
        if (index2 < 0 || index2 >= this.cssRules.length) {
          throw new RangeError("INDEX_SIZE_ERR");
        }
        this.cssRules.splice(index2, 1)[0].parentRule = null;
      };
      exports2.CSSGroupingRule = CSSOM.CSSGroupingRule;
    }
  });

  // node_modules/cssom/lib/CSSConditionRule.js
  var require_CSSConditionRule = __commonJS({
    "node_modules/cssom/lib/CSSConditionRule.js"(exports2) {
      var CSSOM = {
        CSSRule: require_CSSRule().CSSRule,
        CSSGroupingRule: require_CSSGroupingRule().CSSGroupingRule
      };
      CSSOM.CSSConditionRule = function CSSConditionRule() {
        CSSOM.CSSGroupingRule.call(this);
        this.cssRules = [];
      };
      CSSOM.CSSConditionRule.prototype = new CSSOM.CSSGroupingRule();
      CSSOM.CSSConditionRule.prototype.constructor = CSSOM.CSSConditionRule;
      CSSOM.CSSConditionRule.prototype.conditionText = "";
      CSSOM.CSSConditionRule.prototype.cssText = "";
      exports2.CSSConditionRule = CSSOM.CSSConditionRule;
    }
  });

  // node_modules/cssom/lib/CSSMediaRule.js
  var require_CSSMediaRule = __commonJS({
    "node_modules/cssom/lib/CSSMediaRule.js"(exports2) {
      var CSSOM = {
        CSSRule: require_CSSRule().CSSRule,
        CSSGroupingRule: require_CSSGroupingRule().CSSGroupingRule,
        CSSConditionRule: require_CSSConditionRule().CSSConditionRule,
        MediaList: require_MediaList().MediaList
      };
      CSSOM.CSSMediaRule = function CSSMediaRule() {
        CSSOM.CSSConditionRule.call(this);
        this.media = new CSSOM.MediaList();
      };
      CSSOM.CSSMediaRule.prototype = new CSSOM.CSSConditionRule();
      CSSOM.CSSMediaRule.prototype.constructor = CSSOM.CSSMediaRule;
      CSSOM.CSSMediaRule.prototype.type = 4;
      Object.defineProperties(CSSOM.CSSMediaRule.prototype, {
        "conditionText": {
          get: function() {
            return this.media.mediaText;
          },
          set: function(value) {
            this.media.mediaText = value;
          },
          configurable: true,
          enumerable: true
        },
        "cssText": {
          get: function() {
            var cssTexts = [];
            for (var i3 = 0, length = this.cssRules.length; i3 < length; i3++) {
              cssTexts.push(this.cssRules[i3].cssText);
            }
            return "@media " + this.media.mediaText + " {" + cssTexts.join("") + "}";
          },
          configurable: true,
          enumerable: true
        }
      });
      exports2.CSSMediaRule = CSSOM.CSSMediaRule;
    }
  });

  // node_modules/cssom/lib/CSSSupportsRule.js
  var require_CSSSupportsRule = __commonJS({
    "node_modules/cssom/lib/CSSSupportsRule.js"(exports2) {
      var CSSOM = {
        CSSRule: require_CSSRule().CSSRule,
        CSSGroupingRule: require_CSSGroupingRule().CSSGroupingRule,
        CSSConditionRule: require_CSSConditionRule().CSSConditionRule
      };
      CSSOM.CSSSupportsRule = function CSSSupportsRule() {
        CSSOM.CSSConditionRule.call(this);
      };
      CSSOM.CSSSupportsRule.prototype = new CSSOM.CSSConditionRule();
      CSSOM.CSSSupportsRule.prototype.constructor = CSSOM.CSSSupportsRule;
      CSSOM.CSSSupportsRule.prototype.type = 12;
      Object.defineProperty(CSSOM.CSSSupportsRule.prototype, "cssText", {
        get: function() {
          var cssTexts = [];
          for (var i3 = 0, length = this.cssRules.length; i3 < length; i3++) {
            cssTexts.push(this.cssRules[i3].cssText);
          }
          return "@supports " + this.conditionText + " {" + cssTexts.join("") + "}";
        }
      });
      exports2.CSSSupportsRule = CSSOM.CSSSupportsRule;
    }
  });

  // node_modules/cssom/lib/CSSFontFaceRule.js
  var require_CSSFontFaceRule = __commonJS({
    "node_modules/cssom/lib/CSSFontFaceRule.js"(exports2) {
      var CSSOM = {
        CSSStyleDeclaration: require_CSSStyleDeclaration().CSSStyleDeclaration,
        CSSRule: require_CSSRule().CSSRule
      };
      CSSOM.CSSFontFaceRule = function CSSFontFaceRule() {
        CSSOM.CSSRule.call(this);
        this.style = new CSSOM.CSSStyleDeclaration();
        this.style.parentRule = this;
      };
      CSSOM.CSSFontFaceRule.prototype = new CSSOM.CSSRule();
      CSSOM.CSSFontFaceRule.prototype.constructor = CSSOM.CSSFontFaceRule;
      CSSOM.CSSFontFaceRule.prototype.type = 5;
      Object.defineProperty(CSSOM.CSSFontFaceRule.prototype, "cssText", {
        get: function() {
          return "@font-face {" + this.style.cssText + "}";
        }
      });
      exports2.CSSFontFaceRule = CSSOM.CSSFontFaceRule;
    }
  });

  // node_modules/cssom/lib/CSSHostRule.js
  var require_CSSHostRule = __commonJS({
    "node_modules/cssom/lib/CSSHostRule.js"(exports2) {
      var CSSOM = {
        CSSRule: require_CSSRule().CSSRule
      };
      CSSOM.CSSHostRule = function CSSHostRule() {
        CSSOM.CSSRule.call(this);
        this.cssRules = [];
      };
      CSSOM.CSSHostRule.prototype = new CSSOM.CSSRule();
      CSSOM.CSSHostRule.prototype.constructor = CSSOM.CSSHostRule;
      CSSOM.CSSHostRule.prototype.type = 1001;
      Object.defineProperty(CSSOM.CSSHostRule.prototype, "cssText", {
        get: function() {
          var cssTexts = [];
          for (var i3 = 0, length = this.cssRules.length; i3 < length; i3++) {
            cssTexts.push(this.cssRules[i3].cssText);
          }
          return "@host {" + cssTexts.join("") + "}";
        }
      });
      exports2.CSSHostRule = CSSOM.CSSHostRule;
    }
  });

  // node_modules/cssom/lib/CSSKeyframeRule.js
  var require_CSSKeyframeRule = __commonJS({
    "node_modules/cssom/lib/CSSKeyframeRule.js"(exports2) {
      var CSSOM = {
        CSSRule: require_CSSRule().CSSRule,
        CSSStyleDeclaration: require_CSSStyleDeclaration().CSSStyleDeclaration
      };
      CSSOM.CSSKeyframeRule = function CSSKeyframeRule() {
        CSSOM.CSSRule.call(this);
        this.keyText = "";
        this.style = new CSSOM.CSSStyleDeclaration();
        this.style.parentRule = this;
      };
      CSSOM.CSSKeyframeRule.prototype = new CSSOM.CSSRule();
      CSSOM.CSSKeyframeRule.prototype.constructor = CSSOM.CSSKeyframeRule;
      CSSOM.CSSKeyframeRule.prototype.type = 8;
      Object.defineProperty(CSSOM.CSSKeyframeRule.prototype, "cssText", {
        get: function() {
          return this.keyText + " {" + this.style.cssText + "} ";
        }
      });
      exports2.CSSKeyframeRule = CSSOM.CSSKeyframeRule;
    }
  });

  // node_modules/cssom/lib/CSSKeyframesRule.js
  var require_CSSKeyframesRule = __commonJS({
    "node_modules/cssom/lib/CSSKeyframesRule.js"(exports2) {
      var CSSOM = {
        CSSRule: require_CSSRule().CSSRule
      };
      CSSOM.CSSKeyframesRule = function CSSKeyframesRule() {
        CSSOM.CSSRule.call(this);
        this.name = "";
        this.cssRules = [];
      };
      CSSOM.CSSKeyframesRule.prototype = new CSSOM.CSSRule();
      CSSOM.CSSKeyframesRule.prototype.constructor = CSSOM.CSSKeyframesRule;
      CSSOM.CSSKeyframesRule.prototype.type = 7;
      Object.defineProperty(CSSOM.CSSKeyframesRule.prototype, "cssText", {
        get: function() {
          var cssTexts = [];
          for (var i3 = 0, length = this.cssRules.length; i3 < length; i3++) {
            cssTexts.push("  " + this.cssRules[i3].cssText);
          }
          return "@" + (this._vendorPrefix || "") + "keyframes " + this.name + " { \n" + cssTexts.join("\n") + "\n}";
        }
      });
      exports2.CSSKeyframesRule = CSSOM.CSSKeyframesRule;
    }
  });

  // node_modules/cssom/lib/CSSValue.js
  var require_CSSValue = __commonJS({
    "node_modules/cssom/lib/CSSValue.js"(exports2) {
      var CSSOM = {};
      CSSOM.CSSValue = function CSSValue() {
      };
      CSSOM.CSSValue.prototype = {
        constructor: CSSOM.CSSValue,
        // @see: http://www.w3.org/TR/DOM-Level-2-Style/css.html#CSS-CSSValue
        set cssText(text3) {
          var name = this._getConstructorName();
          throw new Error('DOMException: property "cssText" of "' + name + '" is readonly and can not be replaced with "' + text3 + '"!');
        },
        get cssText() {
          var name = this._getConstructorName();
          throw new Error('getter "cssText" of "' + name + '" is not implemented!');
        },
        _getConstructorName: function() {
          var s2 = this.constructor.toString(), c3 = s2.match(/function\s([^\(]+)/), name = c3[1];
          return name;
        }
      };
      exports2.CSSValue = CSSOM.CSSValue;
    }
  });

  // node_modules/cssom/lib/CSSValueExpression.js
  var require_CSSValueExpression = __commonJS({
    "node_modules/cssom/lib/CSSValueExpression.js"(exports2) {
      var CSSOM = {
        CSSValue: require_CSSValue().CSSValue
      };
      CSSOM.CSSValueExpression = function CSSValueExpression(token, idx) {
        this._token = token;
        this._idx = idx;
      };
      CSSOM.CSSValueExpression.prototype = new CSSOM.CSSValue();
      CSSOM.CSSValueExpression.prototype.constructor = CSSOM.CSSValueExpression;
      CSSOM.CSSValueExpression.prototype.parse = function() {
        var token = this._token, idx = this._idx;
        var character = "", expression = "", error = "", info, paren = [];
        for (; ; ++idx) {
          character = token.charAt(idx);
          if (character === "") {
            error = "css expression error: unfinished expression!";
            break;
          }
          switch (character) {
            case "(":
              paren.push(character);
              expression += character;
              break;
            case ")":
              paren.pop(character);
              expression += character;
              break;
            case "/":
              if (info = this._parseJSComment(token, idx)) {
                if (info.error) {
                  error = "css expression error: unfinished comment in expression!";
                } else {
                  idx = info.idx;
                }
              } else if (info = this._parseJSRexExp(token, idx)) {
                idx = info.idx;
                expression += info.text;
              } else {
                expression += character;
              }
              break;
            case "'":
            case '"':
              info = this._parseJSString(token, idx, character);
              if (info) {
                idx = info.idx;
                expression += info.text;
              } else {
                expression += character;
              }
              break;
            default:
              expression += character;
              break;
          }
          if (error) {
            break;
          }
          if (paren.length === 0) {
            break;
          }
        }
        var ret;
        if (error) {
          ret = {
            error
          };
        } else {
          ret = {
            idx,
            expression
          };
        }
        return ret;
      };
      CSSOM.CSSValueExpression.prototype._parseJSComment = function(token, idx) {
        var nextChar = token.charAt(idx + 1), text3;
        if (nextChar === "/" || nextChar === "*") {
          var startIdx = idx, endIdx, commentEndChar;
          if (nextChar === "/") {
            commentEndChar = "\n";
          } else if (nextChar === "*") {
            commentEndChar = "*/";
          }
          endIdx = token.indexOf(commentEndChar, startIdx + 1 + 1);
          if (endIdx !== -1) {
            endIdx = endIdx + commentEndChar.length - 1;
            text3 = token.substring(idx, endIdx + 1);
            return {
              idx: endIdx,
              text: text3
            };
          } else {
            var error = "css expression error: unfinished comment in expression!";
            return {
              error
            };
          }
        } else {
          return false;
        }
      };
      CSSOM.CSSValueExpression.prototype._parseJSString = function(token, idx, sep) {
        var endIdx = this._findMatchedIdx(token, idx, sep), text3;
        if (endIdx === -1) {
          return false;
        } else {
          text3 = token.substring(idx, endIdx + sep.length);
          return {
            idx: endIdx,
            text: text3
          };
        }
      };
      CSSOM.CSSValueExpression.prototype._parseJSRexExp = function(token, idx) {
        var before3 = token.substring(0, idx).replace(/\s+$/, ""), legalRegx = [
          /^$/,
          /\($/,
          /\[$/,
          /\!$/,
          /\+$/,
          /\-$/,
          /\*$/,
          /\/\s+/,
          /\%$/,
          /\=$/,
          /\>$/,
          /<$/,
          /\&$/,
          /\|$/,
          /\^$/,
          /\~$/,
          /\?$/,
          /\,$/,
          /delete$/,
          /in$/,
          /instanceof$/,
          /new$/,
          /typeof$/,
          /void$/
        ];
        var isLegal = legalRegx.some(function(reg) {
          return reg.test(before3);
        });
        if (!isLegal) {
          return false;
        } else {
          var sep = "/";
          return this._parseJSString(token, idx, sep);
        }
      };
      CSSOM.CSSValueExpression.prototype._findMatchedIdx = function(token, idx, sep) {
        var startIdx = idx, endIdx;
        var NOT_FOUND = -1;
        while (true) {
          endIdx = token.indexOf(sep, startIdx + 1);
          if (endIdx === -1) {
            endIdx = NOT_FOUND;
            break;
          } else {
            var text3 = token.substring(idx + 1, endIdx), matched = text3.match(/\\+$/);
            if (!matched || matched[0] % 2 === 0) {
              break;
            } else {
              startIdx = endIdx;
            }
          }
        }
        var nextNewLineIdx = token.indexOf("\n", idx + 1);
        if (nextNewLineIdx < endIdx) {
          endIdx = NOT_FOUND;
        }
        return endIdx;
      };
      exports2.CSSValueExpression = CSSOM.CSSValueExpression;
    }
  });

  // node_modules/cssom/lib/MatcherList.js
  var require_MatcherList = __commonJS({
    "node_modules/cssom/lib/MatcherList.js"(exports2) {
      var CSSOM = {};
      CSSOM.MatcherList = function MatcherList() {
        this.length = 0;
      };
      CSSOM.MatcherList.prototype = {
        constructor: CSSOM.MatcherList,
        /**
         * @return {string}
         */
        get matcherText() {
          return Array.prototype.join.call(this, ", ");
        },
        /**
         * @param {string} value
         */
        set matcherText(value) {
          var values = value.split(",");
          var length = this.length = values.length;
          for (var i3 = 0; i3 < length; i3++) {
            this[i3] = values[i3].trim();
          }
        },
        /**
         * @param {string} matcher
         */
        appendMatcher: function(matcher) {
          if (Array.prototype.indexOf.call(this, matcher) === -1) {
            this[this.length] = matcher;
            this.length++;
          }
        },
        /**
         * @param {string} matcher
         */
        deleteMatcher: function(matcher) {
          var index2 = Array.prototype.indexOf.call(this, matcher);
          if (index2 !== -1) {
            Array.prototype.splice.call(this, index2, 1);
          }
        }
      };
      exports2.MatcherList = CSSOM.MatcherList;
    }
  });

  // node_modules/cssom/lib/CSSDocumentRule.js
  var require_CSSDocumentRule = __commonJS({
    "node_modules/cssom/lib/CSSDocumentRule.js"(exports2) {
      var CSSOM = {
        CSSRule: require_CSSRule().CSSRule,
        MatcherList: require_MatcherList().MatcherList
      };
      CSSOM.CSSDocumentRule = function CSSDocumentRule() {
        CSSOM.CSSRule.call(this);
        this.matcher = new CSSOM.MatcherList();
        this.cssRules = [];
      };
      CSSOM.CSSDocumentRule.prototype = new CSSOM.CSSRule();
      CSSOM.CSSDocumentRule.prototype.constructor = CSSOM.CSSDocumentRule;
      CSSOM.CSSDocumentRule.prototype.type = 10;
      Object.defineProperty(CSSOM.CSSDocumentRule.prototype, "cssText", {
        get: function() {
          var cssTexts = [];
          for (var i3 = 0, length = this.cssRules.length; i3 < length; i3++) {
            cssTexts.push(this.cssRules[i3].cssText);
          }
          return "@-moz-document " + this.matcher.matcherText + " {" + cssTexts.join("") + "}";
        }
      });
      exports2.CSSDocumentRule = CSSOM.CSSDocumentRule;
    }
  });

  // node_modules/cssom/lib/parse.js
  var require_parse = __commonJS({
    "node_modules/cssom/lib/parse.js"(exports2) {
      var CSSOM = {};
      CSSOM.parse = function parse8(token) {
        var i3 = 0;
        var state = "before-selector";
        var index2;
        var buffer = "";
        var valueParenthesisDepth = 0;
        var SIGNIFICANT_WHITESPACE = {
          "selector": true,
          "value": true,
          "value-parenthesis": true,
          "atRule": true,
          "importRule-begin": true,
          "importRule": true,
          "atBlock": true,
          "conditionBlock": true,
          "documentRule-begin": true
        };
        var styleSheet = new CSSOM.CSSStyleSheet();
        var currentScope = styleSheet;
        var parentRule;
        var ancestorRules = [];
        var hasAncestors = false;
        var prevScope;
        var name, priority = "", styleRule, mediaRule, supportsRule, importRule, fontFaceRule, keyframesRule, documentRule, hostRule;
        var atKeyframesRegExp = /@(-(?:\w+-)+)?keyframes/g;
        var parseError = function(message) {
          var lines = token.substring(0, i3).split("\n");
          var lineCount = lines.length;
          var charCount = lines.pop().length + 1;
          var error = new Error(message + " (line " + lineCount + ", char " + charCount + ")");
          error.line = lineCount;
          error["char"] = charCount;
          error.styleSheet = styleSheet;
          throw error;
        };
        for (var character; character = token.charAt(i3); i3++) {
          switch (character) {
            case " ":
            case "	":
            case "\r":
            case "\n":
            case "\f":
              if (SIGNIFICANT_WHITESPACE[state]) {
                buffer += character;
              }
              break;
            case '"':
              index2 = i3 + 1;
              do {
                index2 = token.indexOf('"', index2) + 1;
                if (!index2) {
                  parseError('Unmatched "');
                }
              } while (token[index2 - 2] === "\\");
              buffer += token.slice(i3, index2);
              i3 = index2 - 1;
              switch (state) {
                case "before-value":
                  state = "value";
                  break;
                case "importRule-begin":
                  state = "importRule";
                  break;
              }
              break;
            case "'":
              index2 = i3 + 1;
              do {
                index2 = token.indexOf("'", index2) + 1;
                if (!index2) {
                  parseError("Unmatched '");
                }
              } while (token[index2 - 2] === "\\");
              buffer += token.slice(i3, index2);
              i3 = index2 - 1;
              switch (state) {
                case "before-value":
                  state = "value";
                  break;
                case "importRule-begin":
                  state = "importRule";
                  break;
              }
              break;
            case "/":
              if (token.charAt(i3 + 1) === "*") {
                i3 += 2;
                index2 = token.indexOf("*/", i3);
                if (index2 === -1) {
                  parseError("Missing */");
                } else {
                  i3 = index2 + 1;
                }
              } else {
                buffer += character;
              }
              if (state === "importRule-begin") {
                buffer += " ";
                state = "importRule";
              }
              break;
            case "@":
              if (token.indexOf("@-moz-document", i3) === i3) {
                state = "documentRule-begin";
                documentRule = new CSSOM.CSSDocumentRule();
                documentRule.__starts = i3;
                i3 += "-moz-document".length;
                buffer = "";
                break;
              } else if (token.indexOf("@media", i3) === i3) {
                state = "atBlock";
                mediaRule = new CSSOM.CSSMediaRule();
                mediaRule.__starts = i3;
                i3 += "media".length;
                buffer = "";
                break;
              } else if (token.indexOf("@supports", i3) === i3) {
                state = "conditionBlock";
                supportsRule = new CSSOM.CSSSupportsRule();
                supportsRule.__starts = i3;
                i3 += "supports".length;
                buffer = "";
                break;
              } else if (token.indexOf("@host", i3) === i3) {
                state = "hostRule-begin";
                i3 += "host".length;
                hostRule = new CSSOM.CSSHostRule();
                hostRule.__starts = i3;
                buffer = "";
                break;
              } else if (token.indexOf("@import", i3) === i3) {
                state = "importRule-begin";
                i3 += "import".length;
                buffer += "@import";
                break;
              } else if (token.indexOf("@font-face", i3) === i3) {
                state = "fontFaceRule-begin";
                i3 += "font-face".length;
                fontFaceRule = new CSSOM.CSSFontFaceRule();
                fontFaceRule.__starts = i3;
                buffer = "";
                break;
              } else {
                atKeyframesRegExp.lastIndex = i3;
                var matchKeyframes = atKeyframesRegExp.exec(token);
                if (matchKeyframes && matchKeyframes.index === i3) {
                  state = "keyframesRule-begin";
                  keyframesRule = new CSSOM.CSSKeyframesRule();
                  keyframesRule.__starts = i3;
                  keyframesRule._vendorPrefix = matchKeyframes[1];
                  i3 += matchKeyframes[0].length - 1;
                  buffer = "";
                  break;
                } else if (state === "selector") {
                  state = "atRule";
                }
              }
              buffer += character;
              break;
            case "{":
              if (state === "selector" || state === "atRule") {
                styleRule.selectorText = buffer.trim();
                styleRule.style.__starts = i3;
                buffer = "";
                state = "before-name";
              } else if (state === "atBlock") {
                mediaRule.media.mediaText = buffer.trim();
                if (parentRule) {
                  ancestorRules.push(parentRule);
                }
                currentScope = parentRule = mediaRule;
                mediaRule.parentStyleSheet = styleSheet;
                buffer = "";
                state = "before-selector";
              } else if (state === "conditionBlock") {
                supportsRule.conditionText = buffer.trim();
                if (parentRule) {
                  ancestorRules.push(parentRule);
                }
                currentScope = parentRule = supportsRule;
                supportsRule.parentStyleSheet = styleSheet;
                buffer = "";
                state = "before-selector";
              } else if (state === "hostRule-begin") {
                if (parentRule) {
                  ancestorRules.push(parentRule);
                }
                currentScope = parentRule = hostRule;
                hostRule.parentStyleSheet = styleSheet;
                buffer = "";
                state = "before-selector";
              } else if (state === "fontFaceRule-begin") {
                if (parentRule) {
                  fontFaceRule.parentRule = parentRule;
                }
                fontFaceRule.parentStyleSheet = styleSheet;
                styleRule = fontFaceRule;
                buffer = "";
                state = "before-name";
              } else if (state === "keyframesRule-begin") {
                keyframesRule.name = buffer.trim();
                if (parentRule) {
                  ancestorRules.push(parentRule);
                  keyframesRule.parentRule = parentRule;
                }
                keyframesRule.parentStyleSheet = styleSheet;
                currentScope = parentRule = keyframesRule;
                buffer = "";
                state = "keyframeRule-begin";
              } else if (state === "keyframeRule-begin") {
                styleRule = new CSSOM.CSSKeyframeRule();
                styleRule.keyText = buffer.trim();
                styleRule.__starts = i3;
                buffer = "";
                state = "before-name";
              } else if (state === "documentRule-begin") {
                documentRule.matcher.matcherText = buffer.trim();
                if (parentRule) {
                  ancestorRules.push(parentRule);
                  documentRule.parentRule = parentRule;
                }
                currentScope = parentRule = documentRule;
                documentRule.parentStyleSheet = styleSheet;
                buffer = "";
                state = "before-selector";
              }
              break;
            case ":":
              if (state === "name") {
                name = buffer.trim();
                buffer = "";
                state = "before-value";
              } else {
                buffer += character;
              }
              break;
            case "(":
              if (state === "value") {
                if (buffer.trim() === "expression") {
                  var info = new CSSOM.CSSValueExpression(token, i3).parse();
                  if (info.error) {
                    parseError(info.error);
                  } else {
                    buffer += info.expression;
                    i3 = info.idx;
                  }
                } else {
                  state = "value-parenthesis";
                  valueParenthesisDepth = 1;
                  buffer += character;
                }
              } else if (state === "value-parenthesis") {
                valueParenthesisDepth++;
                buffer += character;
              } else {
                buffer += character;
              }
              break;
            case ")":
              if (state === "value-parenthesis") {
                valueParenthesisDepth--;
                if (valueParenthesisDepth === 0)
                  state = "value";
              }
              buffer += character;
              break;
            case "!":
              if (state === "value" && token.indexOf("!important", i3) === i3) {
                priority = "important";
                i3 += "important".length;
              } else {
                buffer += character;
              }
              break;
            case ";":
              switch (state) {
                case "value":
                  styleRule.style.setProperty(name, buffer.trim(), priority);
                  priority = "";
                  buffer = "";
                  state = "before-name";
                  break;
                case "atRule":
                  buffer = "";
                  state = "before-selector";
                  break;
                case "importRule":
                  importRule = new CSSOM.CSSImportRule();
                  importRule.parentStyleSheet = importRule.styleSheet.parentStyleSheet = styleSheet;
                  importRule.cssText = buffer + character;
                  styleSheet.cssRules.push(importRule);
                  buffer = "";
                  state = "before-selector";
                  break;
                default:
                  buffer += character;
                  break;
              }
              break;
            case "}":
              switch (state) {
                case "value":
                  styleRule.style.setProperty(name, buffer.trim(), priority);
                  priority = "";
                case "before-name":
                case "name":
                  styleRule.__ends = i3 + 1;
                  if (parentRule) {
                    styleRule.parentRule = parentRule;
                  }
                  styleRule.parentStyleSheet = styleSheet;
                  currentScope.cssRules.push(styleRule);
                  buffer = "";
                  if (currentScope.constructor === CSSOM.CSSKeyframesRule) {
                    state = "keyframeRule-begin";
                  } else {
                    state = "before-selector";
                  }
                  break;
                case "keyframeRule-begin":
                case "before-selector":
                case "selector":
                  if (!parentRule) {
                    parseError("Unexpected }");
                  }
                  hasAncestors = ancestorRules.length > 0;
                  while (ancestorRules.length > 0) {
                    parentRule = ancestorRules.pop();
                    if (parentRule.constructor.name === "CSSMediaRule" || parentRule.constructor.name === "CSSSupportsRule") {
                      prevScope = currentScope;
                      currentScope = parentRule;
                      currentScope.cssRules.push(prevScope);
                      break;
                    }
                    if (ancestorRules.length === 0) {
                      hasAncestors = false;
                    }
                  }
                  if (!hasAncestors) {
                    currentScope.__ends = i3 + 1;
                    styleSheet.cssRules.push(currentScope);
                    currentScope = styleSheet;
                    parentRule = null;
                  }
                  buffer = "";
                  state = "before-selector";
                  break;
              }
              break;
            default:
              switch (state) {
                case "before-selector":
                  state = "selector";
                  styleRule = new CSSOM.CSSStyleRule();
                  styleRule.__starts = i3;
                  break;
                case "before-name":
                  state = "name";
                  break;
                case "before-value":
                  state = "value";
                  break;
                case "importRule-begin":
                  state = "importRule";
                  break;
              }
              buffer += character;
              break;
          }
        }
        return styleSheet;
      };
      exports2.parse = CSSOM.parse;
      CSSOM.CSSStyleSheet = require_CSSStyleSheet().CSSStyleSheet;
      CSSOM.CSSStyleRule = require_CSSStyleRule().CSSStyleRule;
      CSSOM.CSSImportRule = require_CSSImportRule().CSSImportRule;
      CSSOM.CSSGroupingRule = require_CSSGroupingRule().CSSGroupingRule;
      CSSOM.CSSMediaRule = require_CSSMediaRule().CSSMediaRule;
      CSSOM.CSSConditionRule = require_CSSConditionRule().CSSConditionRule;
      CSSOM.CSSSupportsRule = require_CSSSupportsRule().CSSSupportsRule;
      CSSOM.CSSFontFaceRule = require_CSSFontFaceRule().CSSFontFaceRule;
      CSSOM.CSSHostRule = require_CSSHostRule().CSSHostRule;
      CSSOM.CSSStyleDeclaration = require_CSSStyleDeclaration().CSSStyleDeclaration;
      CSSOM.CSSKeyframeRule = require_CSSKeyframeRule().CSSKeyframeRule;
      CSSOM.CSSKeyframesRule = require_CSSKeyframesRule().CSSKeyframesRule;
      CSSOM.CSSValueExpression = require_CSSValueExpression().CSSValueExpression;
      CSSOM.CSSDocumentRule = require_CSSDocumentRule().CSSDocumentRule;
    }
  });

  // node_modules/cssom/lib/CSSStyleDeclaration.js
  var require_CSSStyleDeclaration = __commonJS({
    "node_modules/cssom/lib/CSSStyleDeclaration.js"(exports2) {
      var CSSOM = {};
      CSSOM.CSSStyleDeclaration = function CSSStyleDeclaration2() {
        this.length = 0;
        this.parentRule = null;
        this._importants = {};
      };
      CSSOM.CSSStyleDeclaration.prototype = {
        constructor: CSSOM.CSSStyleDeclaration,
        /**
         *
         * @param {string} name
         * @see http://www.w3.org/TR/DOM-Level-2-Style/css.html#CSS-CSSStyleDeclaration-getPropertyValue
         * @return {string} the value of the property if it has been explicitly set for this declaration block.
         * Returns the empty string if the property has not been set.
         */
        getPropertyValue: function(name) {
          return this[name] || "";
        },
        /**
         *
         * @param {string} name
         * @param {string} value
         * @param {string} [priority=null] "important" or null
         * @see http://www.w3.org/TR/DOM-Level-2-Style/css.html#CSS-CSSStyleDeclaration-setProperty
         */
        setProperty: function(name, value, priority) {
          if (this[name]) {
            var index2 = Array.prototype.indexOf.call(this, name);
            if (index2 < 0) {
              this[this.length] = name;
              this.length++;
            }
          } else {
            this[this.length] = name;
            this.length++;
          }
          this[name] = value + "";
          this._importants[name] = priority;
        },
        /**
         *
         * @param {string} name
         * @see http://www.w3.org/TR/DOM-Level-2-Style/css.html#CSS-CSSStyleDeclaration-removeProperty
         * @return {string} the value of the property if it has been explicitly set for this declaration block.
         * Returns the empty string if the property has not been set or the property name does not correspond to a known CSS property.
         */
        removeProperty: function(name) {
          if (!(name in this)) {
            return "";
          }
          var index2 = Array.prototype.indexOf.call(this, name);
          if (index2 < 0) {
            return "";
          }
          var prevValue = this[name];
          this[name] = "";
          Array.prototype.splice.call(this, index2, 1);
          return prevValue;
        },
        getPropertyCSSValue: function() {
        },
        /**
         *
         * @param {String} name
         */
        getPropertyPriority: function(name) {
          return this._importants[name] || "";
        },
        /**
         *   element.style.overflow = "auto"
         *   element.style.getPropertyShorthand("overflow-x")
         *   -> "overflow"
         */
        getPropertyShorthand: function() {
        },
        isPropertyImplicit: function() {
        },
        // Doesn't work in IE < 9
        get cssText() {
          var properties = [];
          for (var i3 = 0, length = this.length; i3 < length; ++i3) {
            var name = this[i3];
            var value = this.getPropertyValue(name);
            var priority = this.getPropertyPriority(name);
            if (priority) {
              priority = " !" + priority;
            }
            properties[i3] = name + ": " + value + priority + ";";
          }
          return properties.join(" ");
        },
        set cssText(text3) {
          var i3, name;
          for (i3 = this.length; i3--; ) {
            name = this[i3];
            this[name] = "";
          }
          Array.prototype.splice.call(this, 0, this.length);
          this._importants = {};
          var dummyRule = CSSOM.parse("#bogus{" + text3 + "}").cssRules[0].style;
          var length = dummyRule.length;
          for (i3 = 0; i3 < length; ++i3) {
            name = dummyRule[i3];
            this.setProperty(dummyRule[i3], dummyRule.getPropertyValue(name), dummyRule.getPropertyPriority(name));
          }
        }
      };
      exports2.CSSStyleDeclaration = CSSOM.CSSStyleDeclaration;
      CSSOM.parse = require_parse().parse;
    }
  });

  // node_modules/cssom/lib/clone.js
  var require_clone = __commonJS({
    "node_modules/cssom/lib/clone.js"(exports2) {
      var CSSOM = {
        CSSStyleSheet: require_CSSStyleSheet().CSSStyleSheet,
        CSSRule: require_CSSRule().CSSRule,
        CSSStyleRule: require_CSSStyleRule().CSSStyleRule,
        CSSGroupingRule: require_CSSGroupingRule().CSSGroupingRule,
        CSSConditionRule: require_CSSConditionRule().CSSConditionRule,
        CSSMediaRule: require_CSSMediaRule().CSSMediaRule,
        CSSSupportsRule: require_CSSSupportsRule().CSSSupportsRule,
        CSSStyleDeclaration: require_CSSStyleDeclaration().CSSStyleDeclaration,
        CSSKeyframeRule: require_CSSKeyframeRule().CSSKeyframeRule,
        CSSKeyframesRule: require_CSSKeyframesRule().CSSKeyframesRule
      };
      CSSOM.clone = function clone2(stylesheet) {
        var cloned = new CSSOM.CSSStyleSheet();
        var rules = stylesheet.cssRules;
        if (!rules) {
          return cloned;
        }
        for (var i3 = 0, rulesLength = rules.length; i3 < rulesLength; i3++) {
          var rule = rules[i3];
          var ruleClone = cloned.cssRules[i3] = new rule.constructor();
          var style = rule.style;
          if (style) {
            var styleClone = ruleClone.style = new CSSOM.CSSStyleDeclaration();
            for (var j3 = 0, styleLength = style.length; j3 < styleLength; j3++) {
              var name = styleClone[j3] = style[j3];
              styleClone[name] = style[name];
              styleClone._importants[name] = style.getPropertyPriority(name);
            }
            styleClone.length = style.length;
          }
          if (rule.hasOwnProperty("keyText")) {
            ruleClone.keyText = rule.keyText;
          }
          if (rule.hasOwnProperty("selectorText")) {
            ruleClone.selectorText = rule.selectorText;
          }
          if (rule.hasOwnProperty("mediaText")) {
            ruleClone.mediaText = rule.mediaText;
          }
          if (rule.hasOwnProperty("conditionText")) {
            ruleClone.conditionText = rule.conditionText;
          }
          if (rule.hasOwnProperty("cssRules")) {
            ruleClone.cssRules = clone2(rule).cssRules;
          }
        }
        return cloned;
      };
      exports2.clone = CSSOM.clone;
    }
  });

  // node_modules/cssom/lib/index.js
  var require_lib = __commonJS({
    "node_modules/cssom/lib/index.js"(exports2) {
      "use strict";
      exports2.CSSStyleDeclaration = require_CSSStyleDeclaration().CSSStyleDeclaration;
      exports2.CSSRule = require_CSSRule().CSSRule;
      exports2.CSSGroupingRule = require_CSSGroupingRule().CSSGroupingRule;
      exports2.CSSConditionRule = require_CSSConditionRule().CSSConditionRule;
      exports2.CSSStyleRule = require_CSSStyleRule().CSSStyleRule;
      exports2.MediaList = require_MediaList().MediaList;
      exports2.CSSMediaRule = require_CSSMediaRule().CSSMediaRule;
      exports2.CSSSupportsRule = require_CSSSupportsRule().CSSSupportsRule;
      exports2.CSSImportRule = require_CSSImportRule().CSSImportRule;
      exports2.CSSFontFaceRule = require_CSSFontFaceRule().CSSFontFaceRule;
      exports2.CSSHostRule = require_CSSHostRule().CSSHostRule;
      exports2.StyleSheet = require_StyleSheet().StyleSheet;
      exports2.CSSStyleSheet = require_CSSStyleSheet().CSSStyleSheet;
      exports2.CSSKeyframesRule = require_CSSKeyframesRule().CSSKeyframesRule;
      exports2.CSSKeyframeRule = require_CSSKeyframeRule().CSSKeyframeRule;
      exports2.MatcherList = require_MatcherList().MatcherList;
      exports2.CSSDocumentRule = require_CSSDocumentRule().CSSDocumentRule;
      exports2.CSSValue = require_CSSValue().CSSValue;
      exports2.CSSValueExpression = require_CSSValueExpression().CSSValueExpression;
      exports2.parse = require_parse().parse;
      exports2.clone = require_clone().clone;
    }
  });

  // node_modules/linkedom/commonjs/canvas-shim.cjs
  var require_canvas_shim = __commonJS({
    "node_modules/linkedom/commonjs/canvas-shim.cjs"(exports2, module2) {
      var Canvas2 = class {
        constructor(width, height) {
          this.width = width;
          this.height = height;
        }
        getContext() {
          return null;
        }
        toDataURL() {
          return "";
        }
      };
      module2.exports = {
        createCanvas: (width, height) => new Canvas2(width, height)
      };
    }
  });

  // node_modules/linkedom/commonjs/canvas.cjs
  var require_canvas = __commonJS({
    "node_modules/linkedom/commonjs/canvas.cjs"(exports2, module2) {
      try {
        module2.exports = __require("canvas");
      } catch (fallback) {
        module2.exports = require_canvas_shim();
      }
    }
  });

  // node_modules/preact/dist/preact.module.js
  var n;
  var l;
  var u;
  var i;
  var t;
  var o;
  var r;
  var f = {};
  var e = [];
  var c = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;
  function s(n2, l3) {
    for (var u3 in l3)
      n2[u3] = l3[u3];
    return n2;
  }
  function a(n2) {
    var l3 = n2.parentNode;
    l3 && l3.removeChild(n2);
  }
  function h(l3, u3, i3) {
    var t3, o3, r3, f3 = {};
    for (r3 in u3)
      "key" == r3 ? t3 = u3[r3] : "ref" == r3 ? o3 = u3[r3] : f3[r3] = u3[r3];
    if (arguments.length > 2 && (f3.children = arguments.length > 3 ? n.call(arguments, 2) : i3), "function" == typeof l3 && null != l3.defaultProps)
      for (r3 in l3.defaultProps)
        void 0 === f3[r3] && (f3[r3] = l3.defaultProps[r3]);
    return v(l3, f3, t3, o3, null);
  }
  function v(n2, i3, t3, o3, r3) {
    var f3 = { type: n2, props: i3, key: t3, ref: o3, __k: null, __: null, __b: 0, __e: null, __d: void 0, __c: null, __h: null, constructor: void 0, __v: null == r3 ? ++u : r3 };
    return null == r3 && null != l.vnode && l.vnode(f3), f3;
  }
  function p(n2) {
    return n2.children;
  }
  function d(n2, l3) {
    this.props = n2, this.context = l3;
  }
  function _(n2, l3) {
    if (null == l3)
      return n2.__ ? _(n2.__, n2.__.__k.indexOf(n2) + 1) : null;
    for (var u3; l3 < n2.__k.length; l3++)
      if (null != (u3 = n2.__k[l3]) && null != u3.__e)
        return u3.__e;
    return "function" == typeof n2.type ? _(n2) : null;
  }
  function k(n2) {
    var l3, u3;
    if (null != (n2 = n2.__) && null != n2.__c) {
      for (n2.__e = n2.__c.base = null, l3 = 0; l3 < n2.__k.length; l3++)
        if (null != (u3 = n2.__k[l3]) && null != u3.__e) {
          n2.__e = n2.__c.base = u3.__e;
          break;
        }
      return k(n2);
    }
  }
  function b(n2) {
    (!n2.__d && (n2.__d = true) && t.push(n2) && !g.__r++ || o !== l.debounceRendering) && ((o = l.debounceRendering) || setTimeout)(g);
  }
  function g() {
    for (var n2; g.__r = t.length; )
      n2 = t.sort(function(n3, l3) {
        return n3.__v.__b - l3.__v.__b;
      }), t = [], n2.some(function(n3) {
        var l3, u3, i3, t3, o3, r3;
        n3.__d && (o3 = (t3 = (l3 = n3).__v).__e, (r3 = l3.__P) && (u3 = [], (i3 = s({}, t3)).__v = t3.__v + 1, j(r3, t3, i3, l3.__n, void 0 !== r3.ownerSVGElement, null != t3.__h ? [o3] : null, u3, null == o3 ? _(t3) : o3, t3.__h), z(u3, t3), t3.__e != o3 && k(t3)));
      });
  }
  function w(n2, l3, u3, i3, t3, o3, r3, c3, s2, a3) {
    var h3, y2, d3, k3, b3, g3, w3, x = i3 && i3.__k || e, C2 = x.length;
    for (u3.__k = [], h3 = 0; h3 < l3.length; h3++)
      if (null != (k3 = u3.__k[h3] = null == (k3 = l3[h3]) || "boolean" == typeof k3 ? null : "string" == typeof k3 || "number" == typeof k3 || "bigint" == typeof k3 ? v(null, k3, null, null, k3) : Array.isArray(k3) ? v(p, { children: k3 }, null, null, null) : k3.__b > 0 ? v(k3.type, k3.props, k3.key, k3.ref ? k3.ref : null, k3.__v) : k3)) {
        if (k3.__ = u3, k3.__b = u3.__b + 1, null === (d3 = x[h3]) || d3 && k3.key == d3.key && k3.type === d3.type)
          x[h3] = void 0;
        else
          for (y2 = 0; y2 < C2; y2++) {
            if ((d3 = x[y2]) && k3.key == d3.key && k3.type === d3.type) {
              x[y2] = void 0;
              break;
            }
            d3 = null;
          }
        j(n2, k3, d3 = d3 || f, t3, o3, r3, c3, s2, a3), b3 = k3.__e, (y2 = k3.ref) && d3.ref != y2 && (w3 || (w3 = []), d3.ref && w3.push(d3.ref, null, k3), w3.push(y2, k3.__c || b3, k3)), null != b3 ? (null == g3 && (g3 = b3), "function" == typeof k3.type && k3.__k === d3.__k ? k3.__d = s2 = m(k3, s2, n2) : s2 = A(n2, k3, d3, x, b3, s2), "function" == typeof u3.type && (u3.__d = s2)) : s2 && d3.__e == s2 && s2.parentNode != n2 && (s2 = _(d3));
      }
    for (u3.__e = g3, h3 = C2; h3--; )
      null != x[h3] && N(x[h3], x[h3]);
    if (w3)
      for (h3 = 0; h3 < w3.length; h3++)
        M(w3[h3], w3[++h3], w3[++h3]);
  }
  function m(n2, l3, u3) {
    for (var i3, t3 = n2.__k, o3 = 0; t3 && o3 < t3.length; o3++)
      (i3 = t3[o3]) && (i3.__ = n2, l3 = "function" == typeof i3.type ? m(i3, l3, u3) : A(u3, i3, i3, t3, i3.__e, l3));
    return l3;
  }
  function A(n2, l3, u3, i3, t3, o3) {
    var r3, f3, e3;
    if (void 0 !== l3.__d)
      r3 = l3.__d, l3.__d = void 0;
    else if (null == u3 || t3 != o3 || null == t3.parentNode)
      n:
        if (null == o3 || o3.parentNode !== n2)
          n2.appendChild(t3), r3 = null;
        else {
          for (f3 = o3, e3 = 0; (f3 = f3.nextSibling) && e3 < i3.length; e3 += 1)
            if (f3 == t3)
              break n;
          n2.insertBefore(t3, o3), r3 = o3;
        }
    return void 0 !== r3 ? r3 : t3.nextSibling;
  }
  function C(n2, l3, u3, i3, t3) {
    var o3;
    for (o3 in u3)
      "children" === o3 || "key" === o3 || o3 in l3 || H(n2, o3, null, u3[o3], i3);
    for (o3 in l3)
      t3 && "function" != typeof l3[o3] || "children" === o3 || "key" === o3 || "value" === o3 || "checked" === o3 || u3[o3] === l3[o3] || H(n2, o3, l3[o3], u3[o3], i3);
  }
  function $(n2, l3, u3) {
    "-" === l3[0] ? n2.setProperty(l3, u3) : n2[l3] = null == u3 ? "" : "number" != typeof u3 || c.test(l3) ? u3 : u3 + "px";
  }
  function H(n2, l3, u3, i3, t3) {
    var o3;
    n:
      if ("style" === l3)
        if ("string" == typeof u3)
          n2.style.cssText = u3;
        else {
          if ("string" == typeof i3 && (n2.style.cssText = i3 = ""), i3)
            for (l3 in i3)
              u3 && l3 in u3 || $(n2.style, l3, "");
          if (u3)
            for (l3 in u3)
              i3 && u3[l3] === i3[l3] || $(n2.style, l3, u3[l3]);
        }
      else if ("o" === l3[0] && "n" === l3[1])
        o3 = l3 !== (l3 = l3.replace(/Capture$/, "")), l3 = l3.toLowerCase() in n2 ? l3.toLowerCase().slice(2) : l3.slice(2), n2.l || (n2.l = {}), n2.l[l3 + o3] = u3, u3 ? i3 || n2.addEventListener(l3, o3 ? T : I, o3) : n2.removeEventListener(l3, o3 ? T : I, o3);
      else if ("dangerouslySetInnerHTML" !== l3) {
        if (t3)
          l3 = l3.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
        else if ("href" !== l3 && "list" !== l3 && "form" !== l3 && "tabIndex" !== l3 && "download" !== l3 && l3 in n2)
          try {
            n2[l3] = null == u3 ? "" : u3;
            break n;
          } catch (n3) {
          }
        "function" == typeof u3 || (null == u3 || false === u3 && -1 == l3.indexOf("-") ? n2.removeAttribute(l3) : n2.setAttribute(l3, u3));
      }
  }
  function I(n2) {
    this.l[n2.type + false](l.event ? l.event(n2) : n2);
  }
  function T(n2) {
    this.l[n2.type + true](l.event ? l.event(n2) : n2);
  }
  function j(n2, u3, i3, t3, o3, r3, f3, e3, c3) {
    var a3, h3, v3, y2, _2, k3, b3, g3, m3, x, A2, C2, $3, H2, I2, T2 = u3.type;
    if (void 0 !== u3.constructor)
      return null;
    null != i3.__h && (c3 = i3.__h, e3 = u3.__e = i3.__e, u3.__h = null, r3 = [e3]), (a3 = l.__b) && a3(u3);
    try {
      n:
        if ("function" == typeof T2) {
          if (g3 = u3.props, m3 = (a3 = T2.contextType) && t3[a3.__c], x = a3 ? m3 ? m3.props.value : a3.__ : t3, i3.__c ? b3 = (h3 = u3.__c = i3.__c).__ = h3.__E : ("prototype" in T2 && T2.prototype.render ? u3.__c = h3 = new T2(g3, x) : (u3.__c = h3 = new d(g3, x), h3.constructor = T2, h3.render = O), m3 && m3.sub(h3), h3.props = g3, h3.state || (h3.state = {}), h3.context = x, h3.__n = t3, v3 = h3.__d = true, h3.__h = [], h3._sb = []), null == h3.__s && (h3.__s = h3.state), null != T2.getDerivedStateFromProps && (h3.__s == h3.state && (h3.__s = s({}, h3.__s)), s(h3.__s, T2.getDerivedStateFromProps(g3, h3.__s))), y2 = h3.props, _2 = h3.state, v3)
            null == T2.getDerivedStateFromProps && null != h3.componentWillMount && h3.componentWillMount(), null != h3.componentDidMount && h3.__h.push(h3.componentDidMount);
          else {
            if (null == T2.getDerivedStateFromProps && g3 !== y2 && null != h3.componentWillReceiveProps && h3.componentWillReceiveProps(g3, x), !h3.__e && null != h3.shouldComponentUpdate && false === h3.shouldComponentUpdate(g3, h3.__s, x) || u3.__v === i3.__v) {
              for (h3.props = g3, h3.state = h3.__s, u3.__v !== i3.__v && (h3.__d = false), h3.__v = u3, u3.__e = i3.__e, u3.__k = i3.__k, u3.__k.forEach(function(n3) {
                n3 && (n3.__ = u3);
              }), A2 = 0; A2 < h3._sb.length; A2++)
                h3.__h.push(h3._sb[A2]);
              h3._sb = [], h3.__h.length && f3.push(h3);
              break n;
            }
            null != h3.componentWillUpdate && h3.componentWillUpdate(g3, h3.__s, x), null != h3.componentDidUpdate && h3.__h.push(function() {
              h3.componentDidUpdate(y2, _2, k3);
            });
          }
          if (h3.context = x, h3.props = g3, h3.__v = u3, h3.__P = n2, C2 = l.__r, $3 = 0, "prototype" in T2 && T2.prototype.render) {
            for (h3.state = h3.__s, h3.__d = false, C2 && C2(u3), a3 = h3.render(h3.props, h3.state, h3.context), H2 = 0; H2 < h3._sb.length; H2++)
              h3.__h.push(h3._sb[H2]);
            h3._sb = [];
          } else
            do {
              h3.__d = false, C2 && C2(u3), a3 = h3.render(h3.props, h3.state, h3.context), h3.state = h3.__s;
            } while (h3.__d && ++$3 < 25);
          h3.state = h3.__s, null != h3.getChildContext && (t3 = s(s({}, t3), h3.getChildContext())), v3 || null == h3.getSnapshotBeforeUpdate || (k3 = h3.getSnapshotBeforeUpdate(y2, _2)), I2 = null != a3 && a3.type === p && null == a3.key ? a3.props.children : a3, w(n2, Array.isArray(I2) ? I2 : [I2], u3, i3, t3, o3, r3, f3, e3, c3), h3.base = u3.__e, u3.__h = null, h3.__h.length && f3.push(h3), b3 && (h3.__E = h3.__ = null), h3.__e = false;
        } else
          null == r3 && u3.__v === i3.__v ? (u3.__k = i3.__k, u3.__e = i3.__e) : u3.__e = L(i3.__e, u3, i3, t3, o3, r3, f3, c3);
      (a3 = l.diffed) && a3(u3);
    } catch (n3) {
      u3.__v = null, (c3 || null != r3) && (u3.__e = e3, u3.__h = !!c3, r3[r3.indexOf(e3)] = null), l.__e(n3, u3, i3);
    }
  }
  function z(n2, u3) {
    l.__c && l.__c(u3, n2), n2.some(function(u4) {
      try {
        n2 = u4.__h, u4.__h = [], n2.some(function(n3) {
          n3.call(u4);
        });
      } catch (n3) {
        l.__e(n3, u4.__v);
      }
    });
  }
  function L(l3, u3, i3, t3, o3, r3, e3, c3) {
    var s2, h3, v3, y2 = i3.props, p3 = u3.props, d3 = u3.type, k3 = 0;
    if ("svg" === d3 && (o3 = true), null != r3) {
      for (; k3 < r3.length; k3++)
        if ((s2 = r3[k3]) && "setAttribute" in s2 == !!d3 && (d3 ? s2.localName === d3 : 3 === s2.nodeType)) {
          l3 = s2, r3[k3] = null;
          break;
        }
    }
    if (null == l3) {
      if (null === d3)
        return document.createTextNode(p3);
      l3 = o3 ? document.createElementNS("http://www.w3.org/2000/svg", d3) : document.createElement(d3, p3.is && p3), r3 = null, c3 = false;
    }
    if (null === d3)
      y2 === p3 || c3 && l3.data === p3 || (l3.data = p3);
    else {
      if (r3 = r3 && n.call(l3.childNodes), h3 = (y2 = i3.props || f).dangerouslySetInnerHTML, v3 = p3.dangerouslySetInnerHTML, !c3) {
        if (null != r3)
          for (y2 = {}, k3 = 0; k3 < l3.attributes.length; k3++)
            y2[l3.attributes[k3].name] = l3.attributes[k3].value;
        (v3 || h3) && (v3 && (h3 && v3.__html == h3.__html || v3.__html === l3.innerHTML) || (l3.innerHTML = v3 && v3.__html || ""));
      }
      if (C(l3, p3, y2, o3, c3), v3)
        u3.__k = [];
      else if (k3 = u3.props.children, w(l3, Array.isArray(k3) ? k3 : [k3], u3, i3, t3, o3 && "foreignObject" !== d3, r3, e3, r3 ? r3[0] : i3.__k && _(i3, 0), c3), null != r3)
        for (k3 = r3.length; k3--; )
          null != r3[k3] && a(r3[k3]);
      c3 || ("value" in p3 && void 0 !== (k3 = p3.value) && (k3 !== l3.value || "progress" === d3 && !k3 || "option" === d3 && k3 !== y2.value) && H(l3, "value", k3, y2.value, false), "checked" in p3 && void 0 !== (k3 = p3.checked) && k3 !== l3.checked && H(l3, "checked", k3, y2.checked, false));
    }
    return l3;
  }
  function M(n2, u3, i3) {
    try {
      "function" == typeof n2 ? n2(u3) : n2.current = u3;
    } catch (n3) {
      l.__e(n3, i3);
    }
  }
  function N(n2, u3, i3) {
    var t3, o3;
    if (l.unmount && l.unmount(n2), (t3 = n2.ref) && (t3.current && t3.current !== n2.__e || M(t3, null, u3)), null != (t3 = n2.__c)) {
      if (t3.componentWillUnmount)
        try {
          t3.componentWillUnmount();
        } catch (n3) {
          l.__e(n3, u3);
        }
      t3.base = t3.__P = null, n2.__c = void 0;
    }
    if (t3 = n2.__k)
      for (o3 = 0; o3 < t3.length; o3++)
        t3[o3] && N(t3[o3], u3, i3 || "function" != typeof n2.type);
    i3 || null == n2.__e || a(n2.__e), n2.__ = n2.__e = n2.__d = void 0;
  }
  function O(n2, l3, u3) {
    return this.constructor(n2, u3);
  }
  function P(u3, i3, t3) {
    var o3, r3, e3;
    l.__ && l.__(u3, i3), r3 = (o3 = "function" == typeof t3) ? null : t3 && t3.__k || i3.__k, e3 = [], j(i3, u3 = (!o3 && t3 || i3).__k = h(p, null, [u3]), r3 || f, f, void 0 !== i3.ownerSVGElement, !o3 && t3 ? [t3] : r3 ? null : i3.firstChild ? n.call(i3.childNodes) : null, e3, !o3 && t3 ? t3 : r3 ? r3.__e : i3.firstChild, o3), z(e3, u3);
  }
  n = e.slice, l = { __e: function(n2, l3, u3, i3) {
    for (var t3, o3, r3; l3 = l3.__; )
      if ((t3 = l3.__c) && !t3.__)
        try {
          if ((o3 = t3.constructor) && null != o3.getDerivedStateFromError && (t3.setState(o3.getDerivedStateFromError(n2)), r3 = t3.__d), null != t3.componentDidCatch && (t3.componentDidCatch(n2, i3 || {}), r3 = t3.__d), r3)
            return t3.__E = t3;
        } catch (l4) {
          n2 = l4;
        }
    throw n2;
  } }, u = 0, i = function(n2) {
    return null != n2 && void 0 === n2.constructor;
  }, d.prototype.setState = function(n2, l3) {
    var u3;
    u3 = null != this.__s && this.__s !== this.state ? this.__s : this.__s = s({}, this.state), "function" == typeof n2 && (n2 = n2(s({}, u3), this.props)), n2 && s(u3, n2), null != n2 && this.__v && (l3 && this._sb.push(l3), b(this));
  }, d.prototype.forceUpdate = function(n2) {
    this.__v && (this.__e = true, n2 && this.__h.push(n2), b(this));
  }, d.prototype.render = p, t = [], g.__r = 0, r = 0;

  // src/util/elementFinder.ts
  function getTextArea() {
    return document.querySelector("textarea");
  }
  function getFooter() {
    return document.querySelector("div[class*='absolute bottom-0']");
  }
  function getRootElement() {
    return document.querySelector('div[id="__next"]');
  }
  function getWebChatGPTToolbar() {
    return document.querySelector("div[class*='wcg-toolbar']");
  }
  function getSubmitButton() {
    const textarea2 = getTextArea();
    if (!textarea2) {
      return null;
    }
    return textarea2.parentNode.querySelector("button");
  }

  // node_modules/preact/hooks/dist/hooks.module.js
  var t2;
  var r2;
  var u2;
  var i2;
  var o2 = 0;
  var f2 = [];
  var c2 = [];
  var e2 = l.__b;
  var a2 = l.__r;
  var v2 = l.diffed;
  var l2 = l.__c;
  var m2 = l.unmount;
  function d2(t3, u3) {
    l.__h && l.__h(r2, t3, o2 || u3), o2 = 0;
    var i3 = r2.__H || (r2.__H = { __: [], __h: [] });
    return t3 >= i3.__.length && i3.__.push({ __V: c2 }), i3.__[t3];
  }
  function p2(n2) {
    return o2 = 1, y(B, n2);
  }
  function y(n2, u3, i3) {
    var o3 = d2(t2++, 2);
    if (o3.t = n2, !o3.__c && (o3.__ = [i3 ? i3(u3) : B(void 0, u3), function(n3) {
      var t3 = o3.__N ? o3.__N[0] : o3.__[0], r3 = o3.t(t3, n3);
      t3 !== r3 && (o3.__N = [r3, o3.__[1]], o3.__c.setState({}));
    }], o3.__c = r2, !r2.u)) {
      r2.u = true;
      var f3 = r2.shouldComponentUpdate;
      r2.shouldComponentUpdate = function(n3, t3, r3) {
        if (!o3.__c.__H)
          return true;
        var u4 = o3.__c.__H.__.filter(function(n4) {
          return n4.__c;
        });
        if (u4.every(function(n4) {
          return !n4.__N;
        }))
          return !f3 || f3.call(this, n3, t3, r3);
        var i4 = false;
        return u4.forEach(function(n4) {
          if (n4.__N) {
            var t4 = n4.__[0];
            n4.__ = n4.__N, n4.__N = void 0, t4 !== n4.__[0] && (i4 = true);
          }
        }), !(!i4 && o3.__c.props === n3) && (!f3 || f3.call(this, n3, t3, r3));
      };
    }
    return o3.__N || o3.__;
  }
  function h2(u3, i3) {
    var o3 = d2(t2++, 3);
    !l.__s && z2(o3.__H, i3) && (o3.__ = u3, o3.i = i3, r2.__H.__h.push(o3));
  }
  function b2() {
    for (var t3; t3 = f2.shift(); )
      if (t3.__P && t3.__H)
        try {
          t3.__H.__h.forEach(k2), t3.__H.__h.forEach(w2), t3.__H.__h = [];
        } catch (r3) {
          t3.__H.__h = [], l.__e(r3, t3.__v);
        }
  }
  l.__b = function(n2) {
    r2 = null, e2 && e2(n2);
  }, l.__r = function(n2) {
    a2 && a2(n2), t2 = 0;
    var i3 = (r2 = n2.__c).__H;
    i3 && (u2 === r2 ? (i3.__h = [], r2.__h = [], i3.__.forEach(function(n3) {
      n3.__N && (n3.__ = n3.__N), n3.__V = c2, n3.__N = n3.i = void 0;
    })) : (i3.__h.forEach(k2), i3.__h.forEach(w2), i3.__h = [])), u2 = r2;
  }, l.diffed = function(t3) {
    v2 && v2(t3);
    var o3 = t3.__c;
    o3 && o3.__H && (o3.__H.__h.length && (1 !== f2.push(o3) && i2 === l.requestAnimationFrame || ((i2 = l.requestAnimationFrame) || j2)(b2)), o3.__H.__.forEach(function(n2) {
      n2.i && (n2.__H = n2.i), n2.__V !== c2 && (n2.__ = n2.__V), n2.i = void 0, n2.__V = c2;
    })), u2 = r2 = null;
  }, l.__c = function(t3, r3) {
    r3.some(function(t4) {
      try {
        t4.__h.forEach(k2), t4.__h = t4.__h.filter(function(n2) {
          return !n2.__ || w2(n2);
        });
      } catch (u3) {
        r3.some(function(n2) {
          n2.__h && (n2.__h = []);
        }), r3 = [], l.__e(u3, t4.__v);
      }
    }), l2 && l2(t3, r3);
  }, l.unmount = function(t3) {
    m2 && m2(t3);
    var r3, u3 = t3.__c;
    u3 && u3.__H && (u3.__H.__.forEach(function(n2) {
      try {
        k2(n2);
      } catch (n3) {
        r3 = n3;
      }
    }), u3.__H = void 0, r3 && l.__e(r3, u3.__v));
  };
  var g2 = "function" == typeof requestAnimationFrame;
  function j2(n2) {
    var t3, r3 = function() {
      clearTimeout(u3), g2 && cancelAnimationFrame(t3), setTimeout(n2);
    }, u3 = setTimeout(r3, 100);
    g2 && (t3 = requestAnimationFrame(r3));
  }
  function k2(n2) {
    var t3 = r2, u3 = n2.__c;
    "function" == typeof u3 && (n2.__c = void 0, u3()), r2 = t3;
  }
  function w2(n2) {
    var t3 = r2;
    n2.__c = n2.__(), r2 = t3;
  }
  function z2(n2, t3) {
    return !n2 || n2.length !== t3.length || t3.some(function(t4, r3) {
      return t4 !== n2[r3];
    });
  }
  function B(n2, t3) {
    return "function" == typeof t3 ? t3(n2) : t3;
  }

  // src/util/icons.tsx
  var twitterIcon = /* @__PURE__ */ h("svg", { xmlns: "http://www.w3.org/2000/svg", width: "24", height: "24", viewBox: "0 0 24 24", fill: "#8d9399", className: "wcg-fill-current wcg-text-gray-500 hover:wcg-text-blue-500 transition-colors duration-200" }, /* @__PURE__ */ h("path", { d: "M24 4.37a9.6 9.6 0 0 1-2.83.8 5.04 5.04 0 0 0 2.17-2.8c-.95.58-2 1-3.13 1.22A4.86 4.86 0 0 0 16.61 2a4.99 4.99 0 0 0-4.79 6.2A13.87 13.87 0 0 1 1.67 2.92 5.12 5.12 0 0 0 3.2 9.67a4.82 4.82 0 0 1-2.23-.64v.07c0 2.44 1.7 4.48 3.95 4.95a4.84 4.84 0 0 1-2.22.08c.63 2.01 2.45 3.47 4.6 3.51A9.72 9.72 0 0 1 0 19.74 13.68 13.68 0 0 0 7.55 22c9.06 0 14-7.7 14-14.37v-.65c.96-.71 1.79-1.6 2.45-2.61z" }));
  var discordIcon = /* @__PURE__ */ h("svg", { width: "24", height: "24", viewBox: "0 0 24 24", xmlns: "http://www.w3.org/2000/svg", className: "wcg-fill-current wcg-text-gray-500 hover:wcg-text-blue-500 transition-colors duration-200" }, /* @__PURE__ */ h("path", { d: "M18.942 5.556a16.299 16.299 0 0 0-4.126-1.297c-.178.321-.385.754-.529 1.097a15.175 15.175 0 0 0-4.573 0 11.583 11.583 0 0 0-.535-1.097 16.274 16.274 0 0 0-4.129 1.3c-2.611 3.946-3.319 7.794-2.965 11.587a16.494 16.494 0 0 0 5.061 2.593 12.65 12.65 0 0 0 1.084-1.785 10.689 10.689 0 0 1-1.707-.831c.143-.106.283-.217.418-.331 3.291 1.539 6.866 1.539 10.118 0 .137.114.277.225.418.331-.541.326-1.114.606-1.71.832a12.52 12.52 0 0 0 1.084 1.785 16.46 16.46 0 0 0 5.064-2.595c.415-4.396-.709-8.209-2.973-11.589zM8.678 14.813c-.988 0-1.798-.922-1.798-2.045s.793-2.047 1.798-2.047 1.815.922 1.798 2.047c.001 1.123-.793 2.045-1.798 2.045zm6.644 0c-.988 0-1.798-.922-1.798-2.045s.793-2.047 1.798-2.047 1.815.922 1.798 2.047c0 1.123-.793 2.045-1.798 2.045z", fill: "#currentColor", "fill-rule": "evenodd" }));
  var githubIcon = /* @__PURE__ */ h("svg", { width: "24", height: "24", viewBox: "0 0 24 24", xmlns: "http://www.w3.org/2000/svg" }, /* @__PURE__ */ h("path", { d: "M12 2C6.475 2 2 6.475 2 12a9.994 9.994 0 0 0 6.838 9.488c.5.087.687-.213.687-.476 0-.237-.013-1.024-.013-1.862-2.512.463-3.162-.612-3.362-1.175-.113-.288-.6-1.175-1.025-1.413-.35-.187-.85-.65-.013-.662.788-.013 1.35.725 1.538 1.025.9 1.512 2.338 1.087 2.912.825.088-.65.35-1.087.638-1.337-2.225-.25-4.55-1.113-4.55-4.938 0-1.088.387-1.987 1.025-2.688-.1-.25-.45-1.275.1-2.65 0 0 .837-.262 2.75 1.026a9.28 9.28 0 0 1 2.5-.338c.85 0 1.7.112 2.5.337 1.912-1.3 2.75-1.024 2.75-1.024.55 1.375.2 2.4.1 2.65.637.7 1.025 1.587 1.025 2.687 0 3.838-2.337 4.688-4.562 4.938.362.312.675.912.675 1.85 0 1.337-.013 2.412-.013 2.75 0 .262.188.574.688.474A10.016 10.016 0 0 0 22 12c0-5.525-4.475-10-10-10Z", fill: "#fff", "fill-rule": "evenodd" }));
  var tuneIcon = /* @__PURE__ */ h("svg", { xmlns: "http://www.w3.org/2000/svg", height: "24", width: "24" }, /* @__PURE__ */ h("path", { fill: "#aaa", d: "M15.808,14.066H6.516v-1.162H5.354v1.162H4.193c-0.321,0-0.581,0.26-0.581,0.58s0.26,0.58,0.581,0.58h1.162\r\n								v1.162h1.162v-1.162h9.292c0.32,0,0.58-0.26,0.58-0.58S16.128,14.066,15.808,14.066z M15.808,9.419h-1.742V8.258h-1.162v1.161\r\n								h-8.71c-0.321,0-0.581,0.26-0.581,0.581c0,0.321,0.26,0.581,0.581,0.581h8.71v1.161h1.162v-1.161h1.742\r\n								c0.32,0,0.58-0.26,0.58-0.581C16.388,9.679,16.128,9.419,15.808,9.419z M17.55,0.708H2.451c-0.962,0-1.742,0.78-1.742,1.742v15.1\r\n								c0,0.961,0.78,1.74,1.742,1.74H17.55c0.962,0,1.742-0.779,1.742-1.74v-15.1C19.292,1.488,18.512,0.708,17.55,0.708z M18.13,17.551\r\n								c0,0.32-0.26,0.58-0.58,0.58H2.451c-0.321,0-0.581-0.26-0.581-0.58v-15.1c0-0.321,0.26-0.581,0.581-0.581H17.55\r\n								c0.32,0,0.58,0.26,0.58,0.581V17.551z M15.808,4.774H9.419V3.612H8.258v1.162H4.193c-0.321,0-0.581,0.26-0.581,0.581\r\n								s0.26,0.581,0.581,0.581h4.065v1.162h1.161V5.935h6.388c0.32,0,0.58-0.26,0.58-0.581S16.128,4.774,15.808,4.774z" }));
  var Language = (
    // <svg xmlns="http://www.w3.org/2000/svg" height="24" width="24">
    //     <path fill="#fff" d="m11.9 22 4.55-12h2.1l4.55 12H21l-1.05-3.05H15.1L14 22Zm3.8-4.8h3.6l-1.75-4.95h-.1ZM4 19l-1.4-1.4 5.05-5.05q-.95-1.05-1.662-2.175Q5.275 9.25 4.75 8h2.1q.45.9.963 1.625.512.725 1.237 1.525 1.1-1.2 1.825-2.462Q11.6 7.425 12.1 6H1V4h7V2h2v2h7v2h-2.9q-.525 1.775-1.425 3.45-.9 1.675-2.225 3.15l2.4 2.45-.75 2.05L9 14Z" />
    // </svg>
    /* @__PURE__ */ h("svg", { height: "24", viewBox: "0 0 1792 1792", width: "24", xmlns: "http://www.w3.org/2000/svg" }, /* @__PURE__ */ h("path", { fill: "#fff", d: "M782 1078q-1 3-12.5-.5t-31.5-11.5l-20-9q-44-20-87-49-7-5-41-31.5t-38-28.5q-67 103-134 181-81 95-105 110-4 2-19.5 4t-18.5 0q6-4 82-92 21-24 85.5-115t78.5-118q17-30 51-98.5t36-77.5q-8-1-110 33-8 2-27.5 7.5t-34.5 9.5-17 5q-2 2-2 10.5t-1 9.5q-5 10-31 15-23 7-47 0-18-4-28-21-4-6-5-23 6-2 24.5-5t29.5-6q58-16 105-32 100-35 102-35 10-2 43-19.5t44-21.5q9-3 21.5-8t14.5-5.5 6 .5q2 12-1 33 0 2-12.5 27t-26.5 53.5-17 33.5q-25 50-77 131l64 28q12 6 74.5 32t67.5 28q4 1 10.5 25.5t4.5 30.5zm-205-486q3 15-4 28-12 23-50 38-30 12-60 12-26-3-49-26-14-15-18-41l1-3q3 3 19.5 5t26.5 0 58-16q36-12 55-14 17 0 21 17zm698 129l63 227-139-42zm-1108 800l694-232v-1032l-694 233v1031zm1241-317l102 31-181-657-100-31-216 536 102 31 45-110 211 65zm-503-962l573 184v-380zm311 1323l158 13-54 160-40-66q-130 83-276 108-58 12-91 12h-84q-79 0-199.5-39t-183.5-85q-8-7-8-16 0-8 5-13.5t13-5.5q4 0 18 7.5t30.5 16.5 20.5 11q73 37 159.5 61.5t157.5 24.5q95 0 167-14.5t157-50.5q15-7 30.5-15.5t34-19 28.5-16.5zm448-1079v1079l-774-246q-14 6-375 127.5t-368 121.5q-13 0-18-13 0-1-1-3v-1078q3-9 4-10 5-6 20-11 106-35 149-50v-384l558 198q2 0 160.5-55t316-108.5 161.5-53.5q20 0 20 21v418z" }))
  );
  var Expand = /* @__PURE__ */ h("svg", { xmlns: "http://www.w3.org/2000/svg", height: "24", width: "24" }, /* @__PURE__ */ h("path", { fill: "currentColor", d: "m12 15.375-6-6 1.4-1.4 4.6 4.6 4.6-4.6 1.4 1.4Z" }));
  var TabKey = /* @__PURE__ */ h("svg", { xmlns: "http://www.w3.org/2000/svg", height: "24", width: "24" }, /* @__PURE__ */ h("path", { fill: "#fff", d: "M22 4.25a.75.75 0 00-1.5 0v15a.75.75 0 001.5 0v-15zm-9.72 14.28a.75.75 0 11-1.06-1.06l4.97-4.97H1.75a.75.75 0 010-1.5h14.44l-4.97-4.97a.75.75 0 011.06-1.06l6.25 6.25a.75.75 0 010 1.06l-6.25 6.25z" }));
  var icons = {
    twitter: twitterIcon,
    discord: discordIcon,
    github: githubIcon,
    tune: tuneIcon,
    language: Language,
    expand: Expand,
    tabKey: TabKey
  };

  // src/util/promptManager.ts
  var import_webextension_polyfill3 = __toESM(require_browser_polyfill());

  // src/util/localization.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());

  // src/util/localizedStrings.json
  var localizedStrings_exports = {};
  __export(localizedStrings_exports, {
    choose_language: () => choose_language,
    current_date_placeholder_tip: () => current_date_placeholder_tip,
    default: () => localizedStrings_default,
    default_prompt: () => default_prompt,
    discord_button_tip: () => discord_button_tip,
    github_button_tip: () => github_button_tip,
    language: () => language,
    name_placeholder: () => name_placeholder,
    new_prompt: () => new_prompt,
    options: () => options,
    page_command_description: () => page_command_description,
    query_placeholder_tip: () => query_placeholder_tip,
    save: () => save,
    site_command_description: () => site_command_description,
    support_me: () => support_me,
    support_this_project: () => support_this_project,
    textarea_placeholder: () => textarea_placeholder,
    trim_long_text: () => trim_long_text,
    twitter_button_tip: () => twitter_button_tip,
    web_results_placeholder_tip: () => web_results_placeholder_tip
  });
  var default_prompt = {
    en: "Web search results:\n\n{web_results}\nCurrent date: {current_date}\n\nInstructions: Using the provided web search results, write a comprehensive reply to the given query. Make sure to cite results using [[number](URL)] notation after the reference. If the provided search results refer to multiple subjects with the same name, write separate answers for each subject.\nQuery: {query}"
  };
  var language = {
    en: "Language",
    pt: "Idioma",
    es: "Idioma",
    fa: "\u0632\u0628\u0627\u0646",
    fr: "Langue",
    de: "Sprache",
    in: "Bahasa",
    it: "Lingua",
    zh: "\u8BED\u8A00",
    "zh-TW": "\u8A9E\u8A00",
    ja: "\u8A00\u8A9E",
    ko: "\uC5B8\uC5B4",
    he: "\u05E9\u05E4\u05D4",
    ru: "\u044F\u0437\u044B\u043A",
    bg: "\u0415\u0437\u0438\u043A",
    pl: "J\u0119zyk",
    vi: "Ti\u1EBFng vi\u1EC7t",
    ua: "\u041C\u043E\u0432\u0430"
  };
  var choose_language = {
    en: "Choose language",
    pt: "Escolha o idioma",
    es: "Elegir idioma",
    fa: "\u0627\u0646\u062A\u062E\u0627\u0628 \u0632\u0628\u0627\u0646",
    fr: "Choisir la langue",
    de: "Sprache ausw\xE4hlen",
    in: "Pilih bahasa",
    it: "Scegli la lingua",
    zh: "\u9009\u62E9\u8BED\u8A00",
    "zh-TW": "\u9078\u64C7\u8A9E\u8A00",
    ja: "\u8A00\u8A9E\u3092\u9078\u629E",
    ko: "\uC5B8\uC5B4 \uC120\uD0DD",
    he: "\u05D1\u05D7\u05E8 \u05E9\u05E4\u05D4",
    ru: "\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u044F\u0437\u044B\u043A",
    bg: "\u0418\u0437\u0431\u0435\u0440\u0438 \u0435\u0437\u0438\u043A",
    pl: "Wybierz j\u0119zyk",
    vi: "Ch\u1ECDn ng\xF4n ng\u1EEF",
    ua: "\u041E\u0431\u0435\u0440\u0456\u0442\u044C \u043C\u043E\u0432\u0443"
  };
  var options = {
    en: "Options",
    pt: "Op\xE7\xF5es",
    es: "Opciones",
    fa: "\u06AF\u0632\u06CC\u0646\u0647 \u0647\u0627",
    fr: "Options",
    de: "Optionen",
    in: "Pengaturan",
    it: "Opzioni",
    zh: "\u9009\u9879",
    "zh-TW": "\u9078\u9805",
    ja: "\u30AA\u30D7\u30B7\u30E7\u30F3",
    ko: "\uC635\uC158",
    he: "\u05D0\u05E4\u05E9\u05E8\u05D5\u05D9\u05D5\u05EA",
    ru: "\u041E\u043F\u0446\u0438\u0438",
    bg: "\u041E\u043F\u0446\u0438\u0438",
    pl: "Opcje",
    vi: "T\xF9y ch\u1ECDn",
    ua: "\u041E\u043F\u0446\u0456\u0457"
  };
  var trim_long_text = {
    en: "Trim long text to fit into context limit",
    pt: "Recortar texto longo para caber no limite de contexto",
    es: "Recortar texto largo para que quepa en el l\xEDmite de contexto",
    fa: "\u0645\u062A\u0646 \u0637\u0648\u0644\u0627\u0646\u06CC \u0631\u0627 \u0628\u0627 \u062A\u0648\u062C\u0647 \u0628\u0647 \u0645\u062D\u062F\u0648\u062F\u06CC\u062A \u0645\u062A\u0646 \u06A9\u0648\u062A\u0627\u0647 \u06A9\u0646\u06CC\u062F",
    fr: "Raccourcir le texte long pour qu'il rentre dans la limite de contexte",
    de: "Langen Text k\xFCrzen, um in das Kontextlimit zu passen",
    in: "Potong teks panjang agar sesuai dengan batas konteks",
    it: "Riduci il testo lungo per adattarlo al limite di contesto",
    zh: "\u5C06\u957F\u6587\u672C\u4FEE\u526A\u4EE5\u9002\u5408\u4E0A\u4E0B\u6587\u9650\u5236",
    "zh-TW": "\u5C07\u9577\u6587\u672C\u4FEE\u526A\u4EE5\u9069\u5408\u4E0A\u4E0B\u6587\u9650\u5236",
    ja: "\u9577\u3044\u30C6\u30AD\u30B9\u30C8\u3092\u30B3\u30F3\u30C6\u30AD\u30B9\u30C8\u5236\u9650\u306B\u5408\u308F\u305B\u3066\u5207\u308A\u8A70\u3081\u307E\u3059",
    ko: "\uAE34 \uD14D\uC2A4\uD2B8\uB97C \uCEE8\uD14D\uC2A4\uD2B8 \uC81C\uD55C\uC5D0 \uB9DE\uAC8C \uC798\uB77C\uB0C5\uB2C8\uB2E4.",
    he: "\u05E7\u05E6\u05E8 \u05D0\u05EA \u05D4\u05D8\u05E7\u05E1\u05D8 \u05D4\u05D0\u05E8\u05D5\u05DA \u05DB\u05D3\u05D9 \u05DC\u05D4\u05EA\u05D0\u05D9\u05DD \u05DC\u05DE\u05D2\u05D1\u05DC\u05EA \u05D4\u05D4\u05E7\u05E9\u05E8",
    ru: "\u041E\u0431\u0440\u0435\u0437\u0430\u0442\u044C \u0434\u043B\u0438\u043D\u043D\u044B\u0439 \u0442\u0435\u043A\u0441\u0442, \u0447\u0442\u043E\u0431\u044B \u0443\u043B\u043E\u0436\u0438\u0442\u044C\u0441\u044F \u0432 \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u0435 \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442\u0430",
    bg: "\u0421\u043A\u044A\u0441\u0438 \u0434\u044A\u043B\u044A\u0433 \u0442\u0435\u043A\u0441\u0442, \u0437\u0430 \u0434\u0430 \u0441\u0435 \u043F\u043E\u0431\u0435\u0440\u0435 \u0432 \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442 \u043B\u0438\u043C\u0438\u0442\u0430",
    pl: "Przytnij d\u0142ugi tekst, aby zmie\u015Bci\u0107 si\u0119 w limicie kontekstu",
    vi: "C\u1EAFt ng\u1EAFn v\u0103n b\u1EA3n d\xE0i \u0111\u1EC3 v\u1EEBa gi\u1EDBi h\u1EA1n chat",
    ua: "\u041E\u0431\u0440\u0456\u0437\u0430\u0442\u0438 \u0434\u043E\u0432\u0433\u0438\u0439 \u0442\u0435\u043A\u0441\u0442, \u0449\u043E\u0431 \u0443\u043A\u043B\u0430\u0441\u0442\u0438\u0441\u044F \u0432 \u043E\u0431\u043C\u0435\u0436\u0435\u043D\u043D\u044F \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442\u0443"
  };
  var textarea_placeholder = {
    en: "Press / to open the commands menu",
    pt: "Pressione / para abrir o menu de comandos",
    es: "Presione / para abrir el men\xFA de comandos",
    fa: "\u0628\u0631\u0627\u06CC \u0628\u0627\u0632 \u06A9\u0631\u062F\u0646 \u0641\u0647\u0631\u0633\u062A \u062F\u0633\u062A\u0648\u0631\u0627\u062A / \u0631\u0627 \u0641\u0634\u0627\u0631 \u062F\u0647\u06CC\u062F",
    fr: "Appuyez sur / pour ouvrir le menu des commandes",
    de: "Dr\xFCcken Sie /, um das Befehlsmen\xFC zu \xF6ffnen",
    in: "Tekan / untuk membuka menu perintah",
    it: "Premi / per aprire il menu dei comandi",
    zh: "\u6309 / \u6253\u5F00\u547D\u4EE4\u83DC\u5355",
    "zh-TW": "\u6309 / \u958B\u555F\u547D\u4EE4\u9078\u55AE",
    ja: "/ \u3092\u62BC\u3057\u3066\u30B3\u30DE\u30F3\u30C9 \u30E1\u30CB\u30E5\u30FC\u3092\u958B\u304D\u307E\u3059",
    ko: "/\uB97C \uB20C\uB7EC \uBA85\uB839 \uBA54\uB274\uB97C \uC5FD\uB2C8\uB2E4.",
    he: "\u05DC\u05D7\u05E5 \u05E2\u05DC / \u05DB\u05D3\u05D9 \u05DC\u05E4\u05EA\u05D5\u05D7 \u05D0\u05EA \u05EA\u05E4\u05E8\u05D9\u05D8 \u05D4\u05E4\u05E7\u05D5\u05D3\u05D5\u05EA",
    ru: "\u041D\u0430\u0436\u043C\u0438\u0442\u0435 / \u0447\u0442\u043E\u0431\u044B \u043E\u0442\u043A\u0440\u044B\u0442\u044C \u043C\u0435\u043D\u044E \u043A\u043E\u043C\u0430\u043D\u0434",
    bg: "\u041D\u0430\u0442\u0438\u0441\u043D\u0435\u0442\u0435 / \u0437\u0430 \u0434\u0430 \u043E\u0442\u0432\u043E\u0440\u0438\u0442\u0435 \u043A\u043E\u043C\u0430\u043D\u0434\u043D\u043E\u0442\u043E \u043C\u0435\u043D\u044E",
    vi: "\u1EA4n / \u0111\u1EC3 m\u1EDF menu c\xE1c l\u1EC7nh",
    ua: "\u041D\u0430\u0442\u0438\u0441\u043D\u0456\u0442\u044C / \u0449\u043E\u0431 \u0432\u0456\u0434\u043A\u0440\u0438\u0442\u0438 \u043C\u0435\u043D\u044E \u043A\u043E\u043C\u0430\u043D\u0434"
  };
  var site_command_description = {
    en: "Restrict search results to a specific website, e.g. /site:wikipedia.com",
    pt: "Restringir resultados de pesquisa a um website espec\xEDfico, por exemplo /site:wikipedia.com",
    es: "Restringir los resultados de b\xFAsqueda a un sitio web espec\xEDfico, por ejemplo /site:wikipedia.com",
    fa: "\u0645\u062D\u062F\u0648\u062F \u06A9\u0631\u062F\u0646 \u0646\u062A\u0627\u06CC\u062C \u062C\u0633\u062A\u062C\u0648 \u0628\u0647 \u06CC\u06A9 \u0633\u0627\u06CC\u062A \u062E\u0627\u0635\u060C \u0645\u062B\u0644\u0627 /site:wikipedia.com",
    fr: "Restreindre les r\xE9sultats de recherche \xE0 un site Web sp\xE9cifique, par exemple /site:wikipedia.com",
    de: "Suchergebnisse auf eine bestimmte Website einschr\xE4nken, z. B. /site:wikipedia.com",
    in: "Batasi hasil pencarian untuk situs web tertentu, misalnya /site:wikipedia.com",
    it: "Limita i risultati della ricerca a un sito Web specifico, ad esempio /site:wikipedia.com",
    zh: "\u5C06\u641C\u7D22\u7ED3\u679C\u9650\u5236\u4E3A\u7279\u5B9A\u7F51\u7AD9(\u57DF\u540D)\uFF0C\u4F8B\u5982 /site:wikipedia.com",
    "zh-TW": "\u5C07\u641C\u5C0B\u7D50\u679C\u9650\u5236\u70BA\u7279\u5B9A\u7DB2\u7AD9(\u57DF\u540D)\uFF0C\u4F8B\u5982 /site:wikipedia.com",
    ja: "\u7279\u5B9A\u306EWeb\u30B5\u30A4\u30C8\u306E\u691C\u7D22\u7D50\u679C\u3092\u5236\u9650\u3057\u307E\u3059\u3002\u4F8B: /site:wikipedia.com",
    ko: "\uAC80\uC0C9 \uACB0\uACFC\uB97C \uD2B9\uC815 \uC6F9\uC0AC\uC774\uD2B8\uB85C \uC81C\uD55C\uD569\uB2C8\uB2E4. \uC608: /site:wikipedia.com",
    he: "\u05D4\u05D2\u05D1\u05DC \u05D0\u05EA \u05EA\u05D5\u05E6\u05D0\u05D5\u05EA \u05D4\u05D7\u05D9\u05E4\u05D5\u05E9 \u05DC\u05D0\u05EA\u05E8 \u05DE\u05E1\u05D5\u05D9\u05DD, \u05DC\u05DE\u05E9\u05DC /site:wikipedia.com",
    ru: "\u041E\u0433\u0440\u0430\u043D\u0438\u0447\u0438\u0442\u044C \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u044B \u043F\u043E\u0438\u0441\u043A\u0430 \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D\u043D\u044B\u043C \u0441\u0430\u0439\u0442\u043E\u043C, \u043D\u0430\u043F\u0440\u0438\u043C\u0435\u0440, /site:wikipedia.com",
    bg: "\u041E\u0433\u0440\u0430\u043D\u0438\u0447\u0438 \u0440\u0435\u0437\u0443\u043B\u0442\u0430\u0442\u0438 \u043E\u0442 \u0442\u044A\u0440\u0441\u0435\u043D\u0435\u0442\u043E \u0434\u043E \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D\u0438 \u0441\u0430\u0439\u0442\u043E\u0432\u0435, \u043D\u0430\u043F\u0440\u0438\u043C\u0435\u0440 /site:wikipedia.com",
    vi: "Gi\u1EDBi h\u1EA1n k\u1EBFt qu\u1EA3 t\xECm ki\u1EBFm \u1EDF 1 trang web c\u1ED1 \u0111\u1ECBnh, v\xED d\u1EE5: /site:wikipedia.com",
    ua: "\u041E\u0431\u043C\u0435\u0436\u0438\u0442\u0438 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u0438 \u043F\u043E\u0448\u0443\u043A\u0443 \u043F\u0435\u0432\u043D\u0438\u043C \u0441\u0430\u0439\u0442\u043E\u043C, \u043D\u0430\u043F\u0440\u0438\u043A\u043B\u0430\u0434, /site:wikipedia.com"
  };
  var page_command_description = {
    en: "Get the content of a specific page, e.g. /page:buymeacoffee.com/anzorq",
    pt: "Obter o conte\xFAdo de uma p\xE1gina espec\xEDfica, por exemplo /page:buymeacoffee.com/anzorq",
    es: "Obtener el contenido de una p\xE1gina espec\xEDfica, por ejemplo /page:buymeacoffee.com/anzorq",
    fa: "\u062F\u0631\u06CC\u0627\u0641\u062A \u0645\u062D\u062A\u0648\u0627\u06CC \u06CC\u06A9 \u0635\u0641\u062D\u0647 \u062E\u0627\u0635\u060C \u0645\u062B\u0644\u0627 /page:buymeacoffee.com/anzorq",
    fr: "Obtenir le contenu d'une page sp\xE9cifique, par exemple /page:buymeacoffee.com/anzorq",
    de: "Den Inhalt einer bestimmten Seite erhalten, z. B. /page:buymeacoffee.com/anzorq",
    in: "Dapatkan konten halaman tertentu, misalnya /page:buymeacoffee.com/anzorq",
    it: "Ottenere il contenuto di una pagina specifica, ad esempio, /page:buymeacoffee.com/anzorq",
    zh: "\u83B7\u53D6\u7279\u5B9A\u9875\u9762\u7684\u5185\u5BB9\uFF0C\u4F8B\u5982 /page:buymeacoffee.com/anzorq",
    "zh-TW": "\u53D6\u5F97\u7279\u5B9A\u9801\u9762\u7684\u5167\u5BB9\uFF0C\u4F8B\u5982 /page:buymeacoffee.com/anzorq",
    ja: "\u7279\u5B9A\u306E\u30DA\u30FC\u30B8\u306E\u30B3\u30F3\u30C6\u30F3\u30C4\u3092\u53D6\u5F97\u3057\u307E\u3059\u3002\u4F8B: /page:buymeacoffee.com/anzorq",
    ko: "\uD2B9\uC815 \uD398\uC774\uC9C0\uC758 \uB0B4\uC6A9\uC744 \uAC00\uC838\uC635\uB2C8\uB2E4. \uC608: /page:buymeacoffee.com/anzorq",
    he: "\u05E7\u05D1\u05DC \u05D0\u05EA \u05EA\u05D5\u05DB\u05DF \u05D3\u05E3 \u05DE\u05E1\u05D5\u05D9\u05DD, \u05DC\u05DE\u05E9\u05DC /page:buymeacoffee.com/anzorq",
    ru: "\u041F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0435 \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D\u043D\u043E\u0439 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B, \u043D\u0430\u043F\u0440\u0438\u043C\u0435\u0440, /page:buymeacoffee.com/anzorq",
    bg: "\u0412\u0437\u0435\u043C\u0438 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F \u043E\u0442 \u0441\u043F\u0435\u0441\u0438\u0444\u0438\u0447\u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0430, \u043D\u0430\u043F\u0440\u0438\u043C\u0435\u0440 /page:buymeacoffee.com/anzorq",
    vi: "L\u1EA5y n\u1ED9i dung c\u1EE7a 1 trang nh\u1EA5t \u0111\u1ECBnh, v\xED d\u1EE5: /page:buymeacoffee.com/anzorq",
    ua: "\u041E\u0442\u0440\u0438\u043C\u0430\u0442\u0438 \u0432\u043C\u0456\u0441\u0442 \u043F\u0435\u0432\u043D\u043E\u0457 \u0441\u0442\u043E\u0440\u0456\u043D\u043A\u0438, \u043D\u0430\u043F\u0440\u0438\u043A\u043B\u0430\u0434, /page:buymeacoffee.com/anzorq"
  };
  var support_this_project = {
    en: "Support this project",
    pt: "Apoie este projeto",
    es: "Apoya este proyecto",
    fa: "\u062D\u0645\u0627\u06CC\u062A \u0627\u0632 \u067E\u0631\u0648\u0698\u0647",
    fr: "Soutenez ce projet",
    de: "Unterst\xFCtzen Sie dieses Projekt",
    in: "Dukung Proyek ini",
    it: "Sostieni questo progetto",
    zh: "\u652F\u6301\u6B64\u9879\u76EE",
    "zh-TW": "\u652F\u6301\u6B64\u5C08\u6848",
    ja: "\u3053\u306E\u30D7\u30ED\u30B8\u30A7\u30AF\u30C8\u3092\u652F\u63F4",
    ko: "\uC774 \uD504\uB85C\uC81D\uD2B8 \uC9C0\uC6D0",
    he: "\u05DC\u05EA\u05E8\u05D5\u05DD \u05DC\u05E4\u05E8\u05D5\u05D9\u05D9\u05E7\u05D8",
    ru: "\u041F\u043E\u0434\u0434\u0435\u0440\u0436\u0430\u0442\u044C \u043F\u0440\u043E\u0435\u043A\u0442",
    pl: "Wesprzyj ten projekt",
    bg: "\u041F\u043E\u0434\u043A\u0440\u0435\u043F\u0435\u0442\u0435 \u0442\u043E\u0437\u0438 \u043F\u0440\u043E\u0435\u043A\u0442",
    vi: "H\u1ED7 tr\u1EE3 d\u1EF1 \xE1n n\xE0y",
    ua: "\u041F\u0456\u0434\u0442\u0440\u0438\u043C\u0430\u0442\u0438 \u043F\u0440\u043E\u0454\u043A\u0442"
  };
  var support_me = {
    en: "If you find this extension useful, please consider supporting me \u2935\uFE0F",
    pt: "Se voc\xEA achar \xFAtil esta extens\xE3o, por favor, considere apoiar-me \u2935\uFE0F",
    es: "Si encuentra \xFAtil esta extensi\xF3n, por favor considere apoyarme \u2935\uFE0F",
    fa: "\u0627\u06AF\u0631 \u0627\u06CC\u0646 \u0627\u0641\u0632\u0648\u0646\u0647 \u0631\u0627 \u0645\u0641\u06CC\u062F \u0645\u06CC\u200C\u062F\u0627\u0646\u06CC\u062F\u060C \u0644\u0637\u0641\u0627 \u062F\u0631 \u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u06CC \u0627\u0632 \u0645\u0646 \u062F\u0631 \u0646\u0638\u0631 \u0628\u06AF\u06CC\u0631\u06CC\u062F \u2935\uFE0F",
    fr: "Si vous trouvez cette extension utile, pensez \xE0 me soutenir \u2935\uFE0F",
    de: "Wenn Sie diese Erweiterung n\xFCtzlich finden, unterst\xFCtzen Sie mich bitte \u2935\uFE0F",
    in: "Jika Anda merasa ekstensi ini bermanfaat, pertimbangkan untuk mendukung saya \u2935\uFE0F",
    it: "Se trovi questo estensione utile, considera di supportarmi \u2935\uFE0F",
    zh: "\u5982\u679C\u60A8\u89C9\u5F97\u8FD9\u4E2A\u6269\u5C55\u6709\u7528\uFF0C\u8BF7\u8003\u8651\u652F\u6301\u6211\u2935\uFE0F",
    "zh-TW": "\u5982\u679C\u60A8\u89BA\u5F97\u9019\u500B\u64F4\u5145\u529F\u80FD\u6709\u7528\uFF0C\u8ACB\u8003\u616E\u652F\u6301\u6211\u2935\uFE0F",
    ja: "\u3053\u306E\u62E1\u5F35\u6A5F\u80FD\u304C\u5F79\u7ACB\u3064\u3068\u601D\u308F\u308C\u308B\u5834\u5408\u306F\u3001\u79C1\u3092\u30B5\u30DD\u30FC\u30C8\u3059\u308B\u3053\u3068\u3092\u691C\u8A0E\u3057\u3066\u304F\u3060\u3055\u3044 \u2935\uFE0F",
    ko: "\uC774 \uD655\uC7A5 \uD504\uB85C\uADF8\uB7A8\uC774 \uC720\uC6A9\uD558\uB2E4\uACE0 \uC0DD\uAC01\uB418\uBA74 \uC800\uB97C \uC9C0\uC6D0\uD574 \uC8FC\uC138\uC694 \u2935\uFE0F",
    he: "\u05D0\u05DD \u05D0\u05EA\u05D4 \u05DE\u05E6\u05D0\u05EA \u05D0\u05EA \u05D4\u05EA\u05D5\u05E1\u05E3 \u05E9\u05D9\u05DE\u05D5\u05E9\u05D9, \u05D0\u05E0\u05D0 \u05E9\u05E7\u05D5\u05DC \u05DC\u05EA\u05DE\u05D5\u05DA \u05D1\u05D9 \u2935\uFE0F",
    ru: "\u0415\u0441\u043B\u0438 \u0432\u0430\u043C \u043D\u0440\u0430\u0432\u0438\u0442\u0441\u044F \u044D\u0442\u043E \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435, \u043F\u043E\u0436\u0430\u043B\u0443\u0439\u0441\u0442\u0430, \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0442\u0435 \u043C\u0435\u043D\u044F \u2935\uFE0F",
    pl: "Je\u015Bli uwa\u017Casz to rozszerzenie za przydatne, rozwa\u017C prosz\u0119 wsparcie mnie \u2935\uFE0F",
    bg: "\u0410\u043A\u043E \u0442\u043E\u0432\u0430 \u0440\u0430\u0437\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0432\u0438 \u0435 \u043E\u0442 \u043F\u043E\u043B\u0437\u0430, \u043C\u043E\u043B\u044F, \u043E\u0431\u043C\u0438\u0441\u043B\u0435\u0442\u0435 \u0434\u0430 \u043C\u0435 \u043F\u043E\u0434\u043A\u0440\u0435\u043F\u0438\u0442\u0435 \u2935\uFE0F",
    vi: "N\u1EBFu b\u1EA1n th\u1EA5y ti\u1EC7n \xEDch n\xE0y c\xF3 \xEDch, h\xE3y h\u1ED7 tr\u1EE3 t\xF4i \u2935\uFE0F",
    ua: "\u042F\u043A\u0449\u043E \u0432\u0430\u043C \u043F\u043E\u0434\u043E\u0431\u0430\u0454\u0442\u044C\u0441\u044F \u0446\u0435\u0439 \u0434\u043E\u0434\u0430\u0442\u043E\u043A, \u0431\u0443\u0434\u044C \u043B\u0430\u0441\u043A\u0430, \u043F\u0456\u0434\u0442\u0440\u0438\u043C\u0430\u0439\u0442\u0435 \u043C\u0435\u043D\u0435 \u2935\uFE0F"
  };
  var save = {
    en: "Save",
    pt: "Salvar",
    es: "Guardar",
    fa: "\u0630\u062E\u06CC\u0631\u0647",
    fr: "Enregistrer",
    de: "Speichern",
    in: "Simpan",
    it: "Salva",
    zh: "\u4FDD\u5B58",
    "zh-TW": "\u5132\u5B58",
    ja: "\u4FDD\u5B58",
    ko: "\uC800\uC7A5",
    he: "\u05E9\u05DE\u05D5\u05E8",
    ru: "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C",
    pl: "Zapisz",
    bg: "\u0417\u0430\u043F\u0430\u0437\u0438",
    vi: "L\u01B0u",
    ua: "\u0417\u0431\u0435\u0440\u0435\u0433\u0442\u0438"
  };
  var new_prompt = {
    en: "New prompt",
    pt: "Novo prompt",
    es: "Nuevo prompt",
    fa: "\u0627\u0639\u0644\u0627\u0646 \u062C\u062F\u06CC\u062F",
    fr: "Nouveau prompt",
    de: "Neues Prompt",
    in: "Prompt Baru",
    it: "Nuovo prompt",
    zh: "\u65B0\u63D0\u793A",
    "zh-TW": "\u65B0\u63D0\u793A",
    ja: "\u65B0\u3057\u3044\u30D7\u30ED\u30F3\u30D7\u30C8",
    ko: "\uC0C8\uB85C\uC6B4 \uD504\uB86C\uD504\uD2B8",
    he: "\u05D1\u05E7\u05E9\u05D4 \u05D7\u05D3\u05E9\u05D4",
    ru: "\u041D\u043E\u0432\u044B\u0439 \u0437\u0430\u043F\u0440\u043E\u0441",
    pl: "Nowe zapytanie",
    bg: "\u041D\u043E\u0432\u043E \u0437\u0430\u0434\u0430\u043D\u0438\u0435",
    vi: "Promt m\u1EDBi",
    ua: "\u041D\u043E\u0432\u0438\u0439 \u0437\u0430\u043F\u0438\u0442"
  };
  var name_placeholder = {
    en: "Name",
    pt: "Nome",
    es: "Nombre",
    fa: "\u0646\u0627\u0645",
    fr: "Nom",
    de: "Name",
    in: "Nama",
    it: "Nome",
    zh: "\u540D\u79F0",
    "zh-TW": "\u540D\u7A31",
    ja: "\u540D\u524D",
    ko: "\uC774\uB984",
    he: "\u05E9\u05DD",
    ru: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435",
    pl: "Nazwa",
    bg: "\u0418\u043C\u0435",
    vi: "T\xEAn",
    ua: "\u041D\u0430\u0437\u0432\u0430"
  };
  var current_date_placeholder_tip = {
    en: "Insert placeholder for the current date (optional)",
    pt: "Insira o espa\xE7o reservado para a data atual (opcional)",
    es: "Ingrese un marcador de posici\xF3n para la fecha actual (opcional)",
    fa: "\u062F\u0631\u062C \u0645\u062A\u063A\u06CC\u0631 \u062A\u0627\u0631\u06CC\u062E \u0641\u0639\u0644\u06CC (\u0627\u062E\u062A\u06CC\u0627\u0631\u06CC)",
    fr: "Ins\xE9rer un marqueur de place pour la date actuelle (facultatif)",
    de: "Platzhalter f\xFCr das aktuelle Datum einf\xFCgen (optional)",
    in: "Masukkan placeholder untuk tanggal saat ini (opsional)",
    it: "Inserisci il segnaposto per la data attuale (opzionale)",
    zh: "\u63D2\u5165\u5F53\u524D\u65E5\u671F\u7684\u5360\u4F4D\u7B26\uFF08\u53EF\u9009\uFF09",
    "zh-TW": "\u63D2\u5165\u76EE\u524D\u65E5\u671F\u7684\u4F54\u4F4D\u7B26\uFF08\u9078\u586B\uFF09",
    ja: "\u73FE\u5728\u306E\u65E5\u4ED8\u306E\u30D7\u30EC\u30FC\u30B9\u30DB\u30EB\u30C0\u30FC\u3092\u633F\u5165\uFF08\u4EFB\u610F\uFF09",
    ko: "\uD604\uC7AC \uB0A0\uC9DC\uC758 \uC790\uB9AC \uD45C\uC2DC\uC790\uB97C \uC0BD\uC785 (\uC120\uD0DD \uC0AC\uD56D)",
    he: "\u05D4\u05D5\u05E1\u05E3 \u05DE\u05E6\u05D9\u05D9\u05DF \u05DE\u05D9\u05E7\u05D5\u05DD \u05E2\u05D1\u05D5\u05E8 \u05D4\u05EA\u05D0\u05E8\u05D9\u05DA \u05D4\u05E0\u05D5\u05DB\u05D7\u05D9 (\u05D0\u05D5\u05E4\u05E6\u05D9\u05D5\u05E0\u05DC\u05D9)",
    ru: "\u0412\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043F\u043B\u0435\u0439\u0441\u0445\u043E\u043B\u0434\u0435\u0440 \u0442\u0435\u043A\u0443\u0449\u0435\u0439 \u0434\u0430\u0442\u044B (\u043D\u0435\u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E)",
    pl: "Wstaw znacznik dla bie\u017C\u0105cej daty (opcjonalne)",
    bg: "\u0412\u043C\u044A\u043A\u043D\u0438 \u0437\u0430\u043C\u0435\u0441\u0442\u0438\u0442\u0435\u043B \u0437\u0430 \u0441\u0435\u0433\u0430\u0448\u043D\u0430\u0442\u0430 \u0434\u0430\u0442\u0430 (\u043F\u043E \u0436\u0435\u043B\u0430\u043D\u0438\u0435)",
    vi: "Ch\xE8n m\u1EB7c \u0111\u1ECBnh cho ng\xE0y hi\u1EC7n t\u1EA1i (t\xF9y ch\u1ECDn)",
    ua: "\u0412\u0441\u0442\u0430\u0432\u0438\u0442\u0438 \u043C\u0456\u0442\u043A\u0443 \u0434\u043B\u044F \u043F\u043E\u0442\u043E\u0447\u043D\u043E\u0457 \u0434\u0430\u0442\u0438 (\u043D\u0435\u043E\u0431\u043E\u0432'\u044F\u0437\u043A\u043E\u0432\u043E)"
  };
  var web_results_placeholder_tip = {
    en: "Insert placeholder for the web results (optional)",
    pt: "Insira o espa\xE7o reservado para os resultados da pesquisa na web (opcional)",
    es: "Ingrese un marcador de posici\xF3n para los resultados de b\xFAsqueda web (opcional)",
    fa: "\u062F\u0631\u062C \u0645\u062A\u063A\u06CC\u0631\u0647\u0627\u06CC\u06CC \u0628\u0631\u0627\u06CC \u0646\u062A\u0627\u06CC\u062C \u062C\u0633\u062A\u062C\u0648\u06CC \u0648\u0628 (\u0627\u062E\u062A\u06CC\u0627\u0631\u06CC)",
    fr: "Ins\xE9rer un marqueur de place pour les r\xE9sultats de recherche web (facultatif)",
    de: "Platzhalter f\xFCr die Web-Ergebnisse einf\xFCgen (optional)",
    in: "Masukkan placeholder untuk hasil web (opsional)",
    it: "Inserisci il segnaposto per i risultati web (opzionale)",
    zh: "\u63D2\u5165\u7F51\u7EDC\u641C\u7D22\u7ED3\u679C\u7684\u5360\u4F4D\u7B26\uFF08\u53EF\u9009\uFF09",
    "zh-TW": "\u63D2\u5165\u7DB2\u8DEF\u641C\u5C0B\u7D50\u679C\u7684\u4F54\u4F4D\u7B26\uFF08\u9078\u586B\uFF09",
    ja: "Web\u7D50\u679C\u306E\u30D7\u30EC\u30FC\u30B9\u30DB\u30EB\u30C0\u30FC\u3092\u633F\u5165\uFF08\u4EFB\u610F\uFF09",
    ko: "\uC6F9 \uAC80\uC0C9 \uACB0\uACFC\uC758 \uC790\uB9AC \uD45C\uC2DC\uC790\uB97C \uC0BD\uC785 (\uC120\uD0DD \uC0AC\uD56D)",
    he: "\u05D4\u05D5\u05E1\u05E3 \u05DE\u05E6\u05D9\u05D9\u05DF \u05DE\u05D9\u05E7\u05D5\u05DD \u05E2\u05D1\u05D5\u05E8 \u05EA\u05D5\u05E6\u05D0\u05D5\u05EA \u05D4\u05D0\u05D9\u05E0\u05D8\u05E8\u05E0\u05D8 (\u05D0\u05D5\u05E4\u05E6\u05D9\u05D5\u05E0\u05DC\u05D9)",
    ru: "\u0412\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043F\u043B\u0435\u0439\u0441\u0445\u043E\u043B\u0434\u0435\u0440 \u0432\u0435\u0431-\u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u043E\u0432 (\u043D\u0435\u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E)",
    pl: "Wstaw znacznik dla wynik\xF3w wyszukiwania w sieci (opcjonalne)",
    bg: "\u0412\u043C\u044A\u043A\u043D\u0438 \u0437\u0430\u043C\u0435\u0441\u0442\u0438\u0442\u0435\u043B \u0437\u0430 \u0443\u0435\u0431 \u0440\u0435\u0437\u0443\u043B\u0442\u0430\u0442\u0438 (\u043F\u043E \u0436\u0435\u043B\u0430\u043D\u0438\u0435)",
    vi: "Ch\xE8n m\u1EB7c \u0111\u1ECBnh cho k\u1EBFt qu\u1EA3 t\xECm ki\u1EBFm (t\xF9y ch\u1ECDn)",
    ua: "\u0412\u0441\u0442\u0430\u0432\u0438\u0442\u0438 \u043C\u0456\u0442\u043A\u0443 \u0434\u043B\u044F \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u0456\u0432 \u0432\u0435\u0431-\u043F\u043E\u0448\u0443\u043A\u0443 (\u043D\u0435\u043E\u0431\u043E\u0432'\u044F\u0437\u043A\u043E\u0432\u043E)"
  };
  var query_placeholder_tip = {
    en: "Insert placeholder for the initial query (required)",
    pt: "Insira o espa\xE7o reservado para a pergunta inicial (obrigat\xF3rio)",
    es: "Ingrese un marcador de posici\xF3n para la consulta inicial (requerido)",
    fr: "Ins\xE9rer un marqueur de place pour la requ\xEAte initiale (requis)",
    fa: "\u062F\u0631\u062C \u0645\u062A\u063A\u06CC\u0631\u0647\u0627\u06CC\u06CC \u0628\u0631\u0627\u06CC \u067E\u0631\u0633\u0634 \u0627\u0648\u0644\u06CC\u0647 (\u0627\u0644\u0632\u0627\u0645\u06CC)",
    de: "Platzhalter f\xFCr die urspr\xFCngliche Anfrage einf\xFCgen (erforderlich)",
    in: "Masukkan placeholder untuk kueri awal (wajib)",
    it: "Inserisci il segnaposto per la query iniziale (richiesto)",
    zh: "\u63D2\u5165\u521D\u59CB\u67E5\u8BE2\u7684\u5360\u4F4D\u7B26\uFF08\u5FC5\u9700\uFF09",
    "zh-TW": "\u63D2\u5165\u521D\u59CB\u67E5\u8A62\u7684\u4F54\u4F4D\u7B26\uFF08\u5FC5\u586B\uFF09",
    ja: "\u521D\u671F\u30AF\u30A8\u30EA\u306E\u30D7\u30EC\u30FC\u30B9\u30DB\u30EB\u30C0\u30FC\u3092\u633F\u5165\uFF08\u5FC5\u9808\uFF09",
    ko: "\uCD08\uAE30 \uCFFC\uB9AC\uC758 \uC790\uB9AC \uD45C\uC2DC\uC790\uB97C \uC0BD\uC785 (\uD544\uC218)",
    he: "\u05D4\u05D5\u05E1\u05E3 \u05DE\u05E6\u05D9\u05D9\u05DF \u05DE\u05D9\u05E7\u05D5\u05DD \u05E2\u05D1\u05D5\u05E8 \u05D4\u05E9\u05D0\u05D9\u05DC\u05EA\u05D4 \u05D4\u05E8\u05D0\u05E9\u05D5\u05E0\u05D9\u05EA (\u05D7\u05D5\u05D1\u05D4)",
    ru: "\u0412\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043F\u043B\u0435\u0439\u0441\u0445\u043E\u043B\u0434\u0435\u0440 \u043D\u0430\u0447\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u0437\u0430\u043F\u0440\u043E\u0441\u0430 (\u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E)",
    pl: "Wstaw znacznik dla pocz\u0105tkowego zapytania (wymagane)",
    bg: "\u0412\u043C\u044A\u043A\u043D\u0438 \u0437\u0430\u043C\u0435\u0441\u0442\u0438\u0442\u0435\u043B \u0437\u0430 \u043D\u0430\u0447\u0430\u043B\u043D\u043E \u0442\u044A\u0440\u0441\u0435\u043D\u0435 (\u043F\u043E \u0436\u0435\u043B\u0430\u043D\u0438\u0435)",
    vi: "Ch\xE8n m\u1EB7c \u0111\u1ECBnh cho c\xE2u l\u1EC7nh b\u1EAFt \u0111\u1EA7u (b\u1EAFt bu\u1ED9c)",
    ua: "\u0412\u0441\u0442\u0430\u0432\u0442\u0435 \u043C\u0456\u0442\u043A\u0443 \u0434\u043B\u044F \u043F\u043E\u0447\u0430\u0442\u043A\u043E\u0432\u043E\u0433\u043E \u0437\u0430\u043F\u0438\u0442\u0443 (\u043E\u0431\u043E\u0432'\u044F\u0437\u043A\u043E\u0432\u043E)"
  };
  var twitter_button_tip = {
    en: "Follow me on Twitter",
    pt: "Siga-me no Twitter",
    es: "S\xEDgueme en Twitter",
    fa: "\u062F\u0646\u0628\u0627\u0644 \u06A9\u0631\u062F\u0646 \u0645\u0646 \u062F\u0631 \u062A\u0648\u06CC\u06CC\u062A\u0631",
    fr: "Me suivre sur Twitter",
    de: "Folgen Sie mir auf Twitter",
    in: "Ikuti saya di Twitter",
    it: "Seguimi su Twitter",
    zh: "\u5728 Twitter \u4E0A\u5173\u6CE8\u6211",
    "zh-TW": "\u5728 Twitter \u4E0A\u8DDF\u96A8\u6211",
    ja: "Twitter\u3067\u79C1\u3092\u30D5\u30A9\u30ED\u30FC",
    ko: "Twitter\uC5D0\uC11C \uB098\uB97C \uD314\uB85C\uC6B0\uD558\uC138\uC694",
    he: "\u05E2\u05E7\u05D1\u05D5 \u05D0\u05D7\u05E8\u05D9 \u05D1\u05D8\u05D5\u05D5\u05D9\u05D8\u05E8",
    ru: "\u041F\u043E\u0434\u043F\u0438\u0441\u0430\u0442\u044C\u0441\u044F \u043D\u0430 \u043C\u0435\u043D\u044F \u0432 Twitter",
    pl: "Obserwuj mnie na Twitterze",
    bg: "\u041F\u043E\u0441\u043B\u0435\u0434\u0432\u0430\u0439\u0442\u0435 \u043C\u0435 \u043D\u0430 Twitter",
    vi: "Theo d\xF5i t\xF4i tr\xEAn Twitter",
    ua: "\u041F\u0456\u0434\u043F\u0438\u0441\u0430\u0442\u0438\u0441\u044F \u043D\u0430 \u043C\u0435\u043D\u0435 \u0432 Twitter"
  };
  var github_button_tip = {
    en: "View the source code on GitHub",
    pt: "Veja o c\xF3digo fonte no GitHub",
    es: "Ver el c\xF3digo fuente en GitHub",
    fa: "\u0645\u0634\u0627\u0647\u062F\u0647 \u06A9\u062F \u0645\u0646\u0628\u0639 \u062F\u0631 \u06AF\u06CC\u062A \u0647\u0627\u0628",
    fr: "Voir le code source sur GitHub",
    de: "Quellcode auf GitHub anzeigen",
    in: "Lihat kode sumber di GitHub",
    it: "Visualizza il codice sorgente su GitHub",
    zh: "\u5728 GitHub \u4E0A\u67E5\u770B\u6E90\u4EE3\u7801",
    "zh-TW": "\u5728 GitHub \u4E0A\u67E5\u770B\u539F\u59CB\u78BC",
    ja: "GitHub\u4E0A\u306E\u30BD\u30FC\u30B9\u30B3\u30FC\u30C9\u3092\u898B\u308B",
    ko: "GitHub\uC5D0\uC11C \uC18C\uC2A4 \uCF54\uB4DC \uBCF4\uAE30",
    he: "\u05E8\u05D0\u05D5 \u05D0\u05EA \u05D4\u05E7\u05D5\u05D3 \u05D1\u05D2\u05D9\u05D8\u05D4\u05D0\u05D1",
    ru: "\u041F\u043E\u0441\u043C\u043E\u0442\u0440\u0435\u0442\u044C \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u043A\u043E\u0434 \u043D\u0430 GitHub",
    pl: "Zobacz kod \u017Ar\xF3d\u0142owy na GitHubie",
    bg: "\u0412\u0438\u0436 \u0438\u0437\u0445\u043E\u0434\u043D\u0438\u044F \u043A\u043E\u0434 \u043D\u0430 Github",
    vi: "Xem m\xE3 ngu\u1ED3n tr\xEAn github",
    ua: "\u041F\u0435\u0440\u0435\u0433\u043B\u044F\u043D\u0443\u0442\u0438 \u0432\u0438\u0445\u0456\u0434\u043D\u0438\u0439 \u043A\u043E\u0434 \u043D\u0430 GitHub"
  };
  var discord_button_tip = {
    en: "Join our Discord community",
    pt: "Junte-se \xE0 nossa comunidade no Discord",
    es: "\xDAnete a nuestra comunidad de Discord",
    fr: "Rejoignez notre communaut\xE9 Discord",
    fa: "\u067E\u06CC\u0648\u0633\u062A\u0646 \u0628\u0647 \u0627\u0646\u062C\u0645\u0646 \u062F\u06CC\u0633\u06A9\u0648\u0631\u062F",
    de: "Treten Sie unserer Discord-Community bei",
    in: "Bergabunglah dengan komunitas Discord kami",
    it: "Unisciti alla nostra comunit\xE0 su Discord",
    zh: "\u52A0\u5165\u6211\u4EEC\u7684 Discord \u793E\u533A",
    "zh-TW": "\u52A0\u5165\u6211\u5011\u7684 Discord \u793E\u7FA4",
    ja: "\u79C1\u305F\u3061\u306EDiscord\u30B3\u30DF\u30E5\u30CB\u30C6\u30A3\u306B\u53C2\u52A0\u3057\u3066\u304F\u3060\u3055\u3044",
    ko: "\uC6B0\uB9AC\uC758 Discord \uCEE4\uBBA4\uB2C8\uD2F0\uC5D0 \uAC00\uC785\uD558\uC138\uC694",
    he: "\u05D1\u05D5\u05D0\u05D5 \u05DC\u05E7\u05D4\u05D9\u05DC\u05EA \u05D4\u05D3\u05D9\u05E1\u05E7\u05D5\u05E8\u05D3 \u05E9\u05DC\u05E0\u05D5",
    ru: "\u041F\u0440\u0438\u0441\u043E\u0435\u0434\u0438\u043D\u0438\u0442\u044C\u0441\u044F \u043A \u043D\u0430\u0448\u0435\u043C\u0443 \u0441\u043E\u043E\u0431\u0449\u0435\u0441\u0442\u0432\u0443 \u043D\u0430 Discord",
    pl: "Do\u0142\u0105cz do naszej spo\u0142eczno\u015Bci na Discordzie",
    bg: "\u041F\u0440\u0438\u0441\u044A\u0435\u0434\u0438\u043D\u0438 \u0441\u0435 \u043A\u044A\u043C \u043D\u0430\u0448a\u0442a Discord \u043E\u0431\u0449\u043D\u043E\u0441\u0442",
    vi: "Tham gia c\u1ED9ng \u0111\u1ED3ng Discord",
    ua: "\u041F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F \u0434\u043E \u043D\u0430\u0448\u043E\u0457 \u0441\u043F\u0456\u043B\u044C\u043D\u043E\u0442\u0438 Discord"
  };
  var localizedStrings_default = {
    default_prompt,
    language,
    choose_language,
    options,
    trim_long_text,
    textarea_placeholder,
    site_command_description,
    page_command_description,
    support_this_project,
    support_me,
    save,
    new_prompt,
    name_placeholder,
    current_date_placeholder_tip,
    web_results_placeholder_tip,
    query_placeholder_tip,
    twitter_button_tip,
    github_button_tip,
    discord_button_tip
  };

  // src/util/localization.ts
  var getSystemLanguage = () => import_webextension_polyfill.default.i18n.getUILanguage().split("-")[0];
  var Languages = {
    auto: "Auto",
    en: "English",
    de: "Deutsch",
    es: "Espa\xF1ol",
    fa: "Persian (\u0641\u0627\u0631\u0633\u06CC)",
    fr: "Fran\xE7ais",
    in: "Indonesia",
    it: "Italiano",
    ja: "\u65E5\u672C\u8A9E",
    ko: "\uD55C\uAD6D\uC5B4",
    pl: "Polski",
    pt: "Portugu\xEAs",
    ru: "\u0420\u0443\u0441\u0441\u043A\u0438\u0439",
    zh: "\u4E2D\u6587",
    "zh-TW": "\u4E2D\u6587\uFF08\u81FA\u7063\uFF09",
    he: "\u05E2\u05D1\u05E8\u05D9\u05EA",
    bg: "\u0411\u044A\u043B\u0433\u0430\u0440\u0441\u043A\u0438"
  };
  var DEFAULT_LANGUAGE = "en";
  var language2 = getSystemLanguage();
  var getLocaleLanguage = () => language2;
  var getCurrentLanguageName = () => language2 === Languages.auto ? Languages.en : Languages[language2];
  var setLocaleLanguage = (newLanguage) => {
    language2 = newLanguage === "auto" ? getSystemLanguage() : newLanguage;
  };
  var getTranslation = (key2, lang) => {
    if (lang) {
      return localizedStrings_exports[key2][lang];
    }
    if (language2 in localizedStrings_exports[key2]) {
      return localizedStrings_exports[key2][language2];
    }
    return localizedStrings_exports[key2][DEFAULT_LANGUAGE];
  };
  var localizationKeys = {
    defaultPrompt: "default_prompt",
    UI: {
      language: "language",
      options: "options",
      trimLongText: "trim_long_text",
      supportThisProject: "support_this_project",
      supportMe: "support_me",
      chooseLanguage: "choose_language",
      textareaPlaceholder: "textarea_placeholder"
    },
    slashCommandsMenu: {
      siteCommandDescription: "site_command_description",
      pageCommandDescription: "page_command_description"
    },
    placeholders: {
      namePlaceholder: "name_placeholder"
    },
    buttons: {
      save: "save",
      newPrompt: "new_prompt"
    },
    placeHolderTips: {
      currentDate: "current_date_placeholder_tip",
      webResults: "web_results_placeholder_tip",
      query: "query_placeholder_tip"
    },
    socialButtonTips: {
      twitter: "twitter_button_tip",
      github: "github_button_tip",
      discord: "discord_button_tip"
    }
  };

  // node_modules/lodash-es/_freeGlobal.js
  var freeGlobal = typeof global == "object" && global && global.Object === Object && global;
  var freeGlobal_default = freeGlobal;

  // node_modules/lodash-es/_root.js
  var freeSelf = typeof self == "object" && self && self.Object === Object && self;
  var root = freeGlobal_default || freeSelf || Function("return this")();
  var root_default = root;

  // node_modules/lodash-es/_Symbol.js
  var Symbol2 = root_default.Symbol;
  var Symbol_default = Symbol2;

  // node_modules/lodash-es/_getRawTag.js
  var objectProto = Object.prototype;
  var hasOwnProperty = objectProto.hasOwnProperty;
  var nativeObjectToString = objectProto.toString;
  var symToStringTag = Symbol_default ? Symbol_default.toStringTag : void 0;
  function getRawTag(value) {
    var isOwn = hasOwnProperty.call(value, symToStringTag), tag = value[symToStringTag];
    try {
      value[symToStringTag] = void 0;
      var unmasked = true;
    } catch (e3) {
    }
    var result = nativeObjectToString.call(value);
    if (unmasked) {
      if (isOwn) {
        value[symToStringTag] = tag;
      } else {
        delete value[symToStringTag];
      }
    }
    return result;
  }
  var getRawTag_default = getRawTag;

  // node_modules/lodash-es/_objectToString.js
  var objectProto2 = Object.prototype;
  var nativeObjectToString2 = objectProto2.toString;
  function objectToString(value) {
    return nativeObjectToString2.call(value);
  }
  var objectToString_default = objectToString;

  // node_modules/lodash-es/_baseGetTag.js
  var nullTag = "[object Null]";
  var undefinedTag = "[object Undefined]";
  var symToStringTag2 = Symbol_default ? Symbol_default.toStringTag : void 0;
  function baseGetTag(value) {
    if (value == null) {
      return value === void 0 ? undefinedTag : nullTag;
    }
    return symToStringTag2 && symToStringTag2 in Object(value) ? getRawTag_default(value) : objectToString_default(value);
  }
  var baseGetTag_default = baseGetTag;

  // node_modules/lodash-es/isObjectLike.js
  function isObjectLike(value) {
    return value != null && typeof value == "object";
  }
  var isObjectLike_default = isObjectLike;

  // node_modules/lodash-es/isArray.js
  var isArray = Array.isArray;
  var isArray_default = isArray;

  // node_modules/lodash-es/isObject.js
  function isObject(value) {
    var type = typeof value;
    return value != null && (type == "object" || type == "function");
  }
  var isObject_default = isObject;

  // node_modules/lodash-es/identity.js
  function identity(value) {
    return value;
  }
  var identity_default = identity;

  // node_modules/lodash-es/isFunction.js
  var asyncTag = "[object AsyncFunction]";
  var funcTag = "[object Function]";
  var genTag = "[object GeneratorFunction]";
  var proxyTag = "[object Proxy]";
  function isFunction(value) {
    if (!isObject_default(value)) {
      return false;
    }
    var tag = baseGetTag_default(value);
    return tag == funcTag || tag == genTag || tag == asyncTag || tag == proxyTag;
  }
  var isFunction_default = isFunction;

  // node_modules/lodash-es/_coreJsData.js
  var coreJsData = root_default["__core-js_shared__"];
  var coreJsData_default = coreJsData;

  // node_modules/lodash-es/_isMasked.js
  var maskSrcKey = function() {
    var uid = /[^.]+$/.exec(coreJsData_default && coreJsData_default.keys && coreJsData_default.keys.IE_PROTO || "");
    return uid ? "Symbol(src)_1." + uid : "";
  }();
  function isMasked(func) {
    return !!maskSrcKey && maskSrcKey in func;
  }
  var isMasked_default = isMasked;

  // node_modules/lodash-es/_toSource.js
  var funcProto = Function.prototype;
  var funcToString = funcProto.toString;
  function toSource(func) {
    if (func != null) {
      try {
        return funcToString.call(func);
      } catch (e3) {
      }
      try {
        return func + "";
      } catch (e3) {
      }
    }
    return "";
  }
  var toSource_default = toSource;

  // node_modules/lodash-es/_baseIsNative.js
  var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;
  var reIsHostCtor = /^\[object .+?Constructor\]$/;
  var funcProto2 = Function.prototype;
  var objectProto3 = Object.prototype;
  var funcToString2 = funcProto2.toString;
  var hasOwnProperty2 = objectProto3.hasOwnProperty;
  var reIsNative = RegExp(
    "^" + funcToString2.call(hasOwnProperty2).replace(reRegExpChar, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"
  );
  function baseIsNative(value) {
    if (!isObject_default(value) || isMasked_default(value)) {
      return false;
    }
    var pattern = isFunction_default(value) ? reIsNative : reIsHostCtor;
    return pattern.test(toSource_default(value));
  }
  var baseIsNative_default = baseIsNative;

  // node_modules/lodash-es/_getValue.js
  function getValue(object, key2) {
    return object == null ? void 0 : object[key2];
  }
  var getValue_default = getValue;

  // node_modules/lodash-es/_getNative.js
  function getNative(object, key2) {
    var value = getValue_default(object, key2);
    return baseIsNative_default(value) ? value : void 0;
  }
  var getNative_default = getNative;

  // node_modules/lodash-es/_apply.js
  function apply(func, thisArg, args) {
    switch (args.length) {
      case 0:
        return func.call(thisArg);
      case 1:
        return func.call(thisArg, args[0]);
      case 2:
        return func.call(thisArg, args[0], args[1]);
      case 3:
        return func.call(thisArg, args[0], args[1], args[2]);
    }
    return func.apply(thisArg, args);
  }
  var apply_default = apply;

  // node_modules/lodash-es/_shortOut.js
  var HOT_COUNT = 800;
  var HOT_SPAN = 16;
  var nativeNow = Date.now;
  function shortOut(func) {
    var count = 0, lastCalled = 0;
    return function() {
      var stamp = nativeNow(), remaining = HOT_SPAN - (stamp - lastCalled);
      lastCalled = stamp;
      if (remaining > 0) {
        if (++count >= HOT_COUNT) {
          return arguments[0];
        }
      } else {
        count = 0;
      }
      return func.apply(void 0, arguments);
    };
  }
  var shortOut_default = shortOut;

  // node_modules/lodash-es/constant.js
  function constant(value) {
    return function() {
      return value;
    };
  }
  var constant_default = constant;

  // node_modules/lodash-es/_defineProperty.js
  var defineProperty = function() {
    try {
      var func = getNative_default(Object, "defineProperty");
      func({}, "", {});
      return func;
    } catch (e3) {
    }
  }();
  var defineProperty_default = defineProperty;

  // node_modules/lodash-es/_baseSetToString.js
  var baseSetToString = !defineProperty_default ? identity_default : function(func, string) {
    return defineProperty_default(func, "toString", {
      "configurable": true,
      "enumerable": false,
      "value": constant_default(string),
      "writable": true
    });
  };
  var baseSetToString_default = baseSetToString;

  // node_modules/lodash-es/_setToString.js
  var setToString = shortOut_default(baseSetToString_default);
  var setToString_default = setToString;

  // node_modules/lodash-es/_isIndex.js
  var MAX_SAFE_INTEGER = 9007199254740991;
  var reIsUint = /^(?:0|[1-9]\d*)$/;
  function isIndex(value, length) {
    var type = typeof value;
    length = length == null ? MAX_SAFE_INTEGER : length;
    return !!length && (type == "number" || type != "symbol" && reIsUint.test(value)) && (value > -1 && value % 1 == 0 && value < length);
  }
  var isIndex_default = isIndex;

  // node_modules/lodash-es/eq.js
  function eq(value, other) {
    return value === other || value !== value && other !== other;
  }
  var eq_default = eq;

  // node_modules/lodash-es/_overRest.js
  var nativeMax = Math.max;
  function overRest(func, start, transform) {
    start = nativeMax(start === void 0 ? func.length - 1 : start, 0);
    return function() {
      var args = arguments, index2 = -1, length = nativeMax(args.length - start, 0), array = Array(length);
      while (++index2 < length) {
        array[index2] = args[start + index2];
      }
      index2 = -1;
      var otherArgs = Array(start + 1);
      while (++index2 < start) {
        otherArgs[index2] = args[index2];
      }
      otherArgs[start] = transform(array);
      return apply_default(func, this, otherArgs);
    };
  }
  var overRest_default = overRest;

  // node_modules/lodash-es/_baseRest.js
  function baseRest(func, start) {
    return setToString_default(overRest_default(func, start, identity_default), func + "");
  }
  var baseRest_default = baseRest;

  // node_modules/lodash-es/isLength.js
  var MAX_SAFE_INTEGER2 = 9007199254740991;
  function isLength(value) {
    return typeof value == "number" && value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER2;
  }
  var isLength_default = isLength;

  // node_modules/lodash-es/isArrayLike.js
  function isArrayLike(value) {
    return value != null && isLength_default(value.length) && !isFunction_default(value);
  }
  var isArrayLike_default = isArrayLike;

  // node_modules/lodash-es/_isIterateeCall.js
  function isIterateeCall(value, index2, object) {
    if (!isObject_default(object)) {
      return false;
    }
    var type = typeof index2;
    if (type == "number" ? isArrayLike_default(object) && isIndex_default(index2, object.length) : type == "string" && index2 in object) {
      return eq_default(object[index2], value);
    }
    return false;
  }
  var isIterateeCall_default = isIterateeCall;

  // node_modules/lodash-es/_isPrototype.js
  var objectProto4 = Object.prototype;
  function isPrototype(value) {
    var Ctor = value && value.constructor, proto = typeof Ctor == "function" && Ctor.prototype || objectProto4;
    return value === proto;
  }
  var isPrototype_default = isPrototype;

  // node_modules/lodash-es/_baseTimes.js
  function baseTimes(n2, iteratee) {
    var index2 = -1, result = Array(n2);
    while (++index2 < n2) {
      result[index2] = iteratee(index2);
    }
    return result;
  }
  var baseTimes_default = baseTimes;

  // node_modules/lodash-es/_baseIsArguments.js
  var argsTag = "[object Arguments]";
  function baseIsArguments(value) {
    return isObjectLike_default(value) && baseGetTag_default(value) == argsTag;
  }
  var baseIsArguments_default = baseIsArguments;

  // node_modules/lodash-es/isArguments.js
  var objectProto5 = Object.prototype;
  var hasOwnProperty3 = objectProto5.hasOwnProperty;
  var propertyIsEnumerable = objectProto5.propertyIsEnumerable;
  var isArguments = baseIsArguments_default(function() {
    return arguments;
  }()) ? baseIsArguments_default : function(value) {
    return isObjectLike_default(value) && hasOwnProperty3.call(value, "callee") && !propertyIsEnumerable.call(value, "callee");
  };
  var isArguments_default = isArguments;

  // node_modules/lodash-es/stubFalse.js
  function stubFalse() {
    return false;
  }
  var stubFalse_default = stubFalse;

  // node_modules/lodash-es/isBuffer.js
  var freeExports = typeof exports == "object" && exports && !exports.nodeType && exports;
  var freeModule = freeExports && typeof module == "object" && module && !module.nodeType && module;
  var moduleExports = freeModule && freeModule.exports === freeExports;
  var Buffer2 = moduleExports ? root_default.Buffer : void 0;
  var nativeIsBuffer = Buffer2 ? Buffer2.isBuffer : void 0;
  var isBuffer = nativeIsBuffer || stubFalse_default;
  var isBuffer_default = isBuffer;

  // node_modules/lodash-es/_baseIsTypedArray.js
  var argsTag2 = "[object Arguments]";
  var arrayTag = "[object Array]";
  var boolTag = "[object Boolean]";
  var dateTag = "[object Date]";
  var errorTag = "[object Error]";
  var funcTag2 = "[object Function]";
  var mapTag = "[object Map]";
  var numberTag = "[object Number]";
  var objectTag = "[object Object]";
  var regexpTag = "[object RegExp]";
  var setTag = "[object Set]";
  var stringTag = "[object String]";
  var weakMapTag = "[object WeakMap]";
  var arrayBufferTag = "[object ArrayBuffer]";
  var dataViewTag = "[object DataView]";
  var float32Tag = "[object Float32Array]";
  var float64Tag = "[object Float64Array]";
  var int8Tag = "[object Int8Array]";
  var int16Tag = "[object Int16Array]";
  var int32Tag = "[object Int32Array]";
  var uint8Tag = "[object Uint8Array]";
  var uint8ClampedTag = "[object Uint8ClampedArray]";
  var uint16Tag = "[object Uint16Array]";
  var uint32Tag = "[object Uint32Array]";
  var typedArrayTags = {};
  typedArrayTags[float32Tag] = typedArrayTags[float64Tag] = typedArrayTags[int8Tag] = typedArrayTags[int16Tag] = typedArrayTags[int32Tag] = typedArrayTags[uint8Tag] = typedArrayTags[uint8ClampedTag] = typedArrayTags[uint16Tag] = typedArrayTags[uint32Tag] = true;
  typedArrayTags[argsTag2] = typedArrayTags[arrayTag] = typedArrayTags[arrayBufferTag] = typedArrayTags[boolTag] = typedArrayTags[dataViewTag] = typedArrayTags[dateTag] = typedArrayTags[errorTag] = typedArrayTags[funcTag2] = typedArrayTags[mapTag] = typedArrayTags[numberTag] = typedArrayTags[objectTag] = typedArrayTags[regexpTag] = typedArrayTags[setTag] = typedArrayTags[stringTag] = typedArrayTags[weakMapTag] = false;
  function baseIsTypedArray(value) {
    return isObjectLike_default(value) && isLength_default(value.length) && !!typedArrayTags[baseGetTag_default(value)];
  }
  var baseIsTypedArray_default = baseIsTypedArray;

  // node_modules/lodash-es/_baseUnary.js
  function baseUnary(func) {
    return function(value) {
      return func(value);
    };
  }
  var baseUnary_default = baseUnary;

  // node_modules/lodash-es/_nodeUtil.js
  var freeExports2 = typeof exports == "object" && exports && !exports.nodeType && exports;
  var freeModule2 = freeExports2 && typeof module == "object" && module && !module.nodeType && module;
  var moduleExports2 = freeModule2 && freeModule2.exports === freeExports2;
  var freeProcess = moduleExports2 && freeGlobal_default.process;
  var nodeUtil = function() {
    try {
      var types = freeModule2 && freeModule2.require && freeModule2.require("util").types;
      if (types) {
        return types;
      }
      return freeProcess && freeProcess.binding && freeProcess.binding("util");
    } catch (e3) {
    }
  }();
  var nodeUtil_default = nodeUtil;

  // node_modules/lodash-es/isTypedArray.js
  var nodeIsTypedArray = nodeUtil_default && nodeUtil_default.isTypedArray;
  var isTypedArray = nodeIsTypedArray ? baseUnary_default(nodeIsTypedArray) : baseIsTypedArray_default;
  var isTypedArray_default = isTypedArray;

  // node_modules/lodash-es/_arrayLikeKeys.js
  var objectProto6 = Object.prototype;
  var hasOwnProperty4 = objectProto6.hasOwnProperty;
  function arrayLikeKeys(value, inherited) {
    var isArr = isArray_default(value), isArg = !isArr && isArguments_default(value), isBuff = !isArr && !isArg && isBuffer_default(value), isType = !isArr && !isArg && !isBuff && isTypedArray_default(value), skipIndexes = isArr || isArg || isBuff || isType, result = skipIndexes ? baseTimes_default(value.length, String) : [], length = result.length;
    for (var key2 in value) {
      if ((inherited || hasOwnProperty4.call(value, key2)) && !(skipIndexes && // Safari 9 has enumerable `arguments.length` in strict mode.
      (key2 == "length" || // Node.js 0.10 has enumerable non-index properties on buffers.
      isBuff && (key2 == "offset" || key2 == "parent") || // PhantomJS 2 has enumerable non-index properties on typed arrays.
      isType && (key2 == "buffer" || key2 == "byteLength" || key2 == "byteOffset") || // Skip index properties.
      isIndex_default(key2, length)))) {
        result.push(key2);
      }
    }
    return result;
  }
  var arrayLikeKeys_default = arrayLikeKeys;

  // node_modules/lodash-es/_nativeKeysIn.js
  function nativeKeysIn(object) {
    var result = [];
    if (object != null) {
      for (var key2 in Object(object)) {
        result.push(key2);
      }
    }
    return result;
  }
  var nativeKeysIn_default = nativeKeysIn;

  // node_modules/lodash-es/_baseKeysIn.js
  var objectProto7 = Object.prototype;
  var hasOwnProperty5 = objectProto7.hasOwnProperty;
  function baseKeysIn(object) {
    if (!isObject_default(object)) {
      return nativeKeysIn_default(object);
    }
    var isProto = isPrototype_default(object), result = [];
    for (var key2 in object) {
      if (!(key2 == "constructor" && (isProto || !hasOwnProperty5.call(object, key2)))) {
        result.push(key2);
      }
    }
    return result;
  }
  var baseKeysIn_default = baseKeysIn;

  // node_modules/lodash-es/keysIn.js
  function keysIn(object) {
    return isArrayLike_default(object) ? arrayLikeKeys_default(object, true) : baseKeysIn_default(object);
  }
  var keysIn_default = keysIn;

  // node_modules/lodash-es/defaults.js
  var objectProto8 = Object.prototype;
  var hasOwnProperty6 = objectProto8.hasOwnProperty;
  var defaults = baseRest_default(function(object, sources) {
    object = Object(object);
    var index2 = -1;
    var length = sources.length;
    var guard = length > 2 ? sources[2] : void 0;
    if (guard && isIterateeCall_default(sources[0], sources[1], guard)) {
      length = 1;
    }
    while (++index2 < length) {
      var source = sources[index2];
      var props = keysIn_default(source);
      var propsIndex = -1;
      var propsLength = props.length;
      while (++propsIndex < propsLength) {
        var key2 = props[propsIndex];
        var value = object[key2];
        if (value === void 0 || eq_default(value, objectProto8[key2]) && !hasOwnProperty6.call(object, key2)) {
          object[key2] = source[key2];
        }
      }
    }
    return object;
  });
  var defaults_default = defaults;

  // src/util/userConfig.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());
  var defaultConfig = {
    numWebResults: 3,
    webAccess: true,
    region: "wt-wt",
    timePeriod: "",
    language: getSystemLanguage(),
    promptUUID: "default",
    trimLongText: false
  };
  async function getUserConfig() {
    const config = await import_webextension_polyfill2.default.storage.sync.get(defaultConfig);
    return defaults_default(config, defaultConfig);
  }
  async function updateUserConfig(config) {
    await import_webextension_polyfill2.default.storage.sync.set(config);
  }

  // src/util/promptManager.ts
  var SAVED_PROMPTS_KEY = "saved_prompts";
  var SAVED_PROMPTS_MOVED_KEY = "saved_prompts_moved_to_local";
  var removeCommands = (query2) => query2.replace(/\/page:(\S+)\s*/g, "").replace(/\/site:(\S+)\s*/g, "");
  var promptContainsWebResults = async () => {
    const currentPrompt = await getCurrentPrompt();
    return currentPrompt.text.includes("{web_results}");
  };
  var compilePrompt = async (results, query2, selectedPrompt) => {
    let prompt = "";
    if (selectedPrompt) {
      prompt = replaceVariables(selectedPrompt.text, {
        "{web_results}": formatWebResults(results),
        "{query}": removeCommands(query2),
        "{current_date}": new Date().toLocaleDateString()
      });
    } else {
      prompt = query2;
    }
    console.log("prompt: ", prompt);
    return prompt;
  };
  var formatWebResults = (results) => {
    if (!results) {
      return "";
    }
    if (results.length === 0) {
      return "No results found.\n";
    }
    let counter = 1;
    return results.reduce((acc, result) => acc += `[${counter++}] "${result.body}"
URL: ${result.url}

`, "");
  };
  var replaceVariables = (prompt, variables) => {
    let newPrompt = prompt;
    for (const key2 in variables) {
      try {
        newPrompt = newPrompt.replaceAll(key2, variables[key2]);
      } catch (error) {
        console.info("WebChatGPT error --> API error: ", error);
      }
    }
    return newPrompt;
  };
  var getDefaultPrompt = () => {
    return {
      name: "Default prompt",
      text: getTranslation(localizationKeys.defaultPrompt, "en") + (getLocaleLanguage() !== "en" ? `
Reply in ${getCurrentLanguageName()}` : ""),
      uuid: "default"
    };
  };
  var getDefaultEnglishPrompt = () => {
    return { name: "Default English", text: getTranslation(localizationKeys.defaultPrompt, "en"), uuid: "default_en" };
  };
  var getCurrentPrompt = async () => {
    const userConfig = await getUserConfig();
    const currentPromptUuid = userConfig.promptUUID;
    const savedPrompts = await getSavedPrompts();
    return savedPrompts.find((i3) => i3.uuid === currentPromptUuid) || getDefaultPrompt();
  };
  var getSavedPrompts = async (addDefaults = true) => {
    const { [SAVED_PROMPTS_KEY]: localPrompts, [SAVED_PROMPTS_MOVED_KEY]: promptsMoved } = await import_webextension_polyfill3.default.storage.local.get({ [SAVED_PROMPTS_KEY]: [], [SAVED_PROMPTS_MOVED_KEY]: false });
    let savedPrompts = localPrompts;
    if (!promptsMoved) {
      const syncStorage = await import_webextension_polyfill3.default.storage.sync.get({ [SAVED_PROMPTS_KEY]: [] });
      const syncPrompts = syncStorage?.[SAVED_PROMPTS_KEY] ?? [];
      savedPrompts = localPrompts.reduce((prompts, prompt) => {
        if (!prompts.some(({ uuid }) => uuid === prompt.uuid))
          prompts.push(prompt);
        return prompts;
      }, syncPrompts);
      await import_webextension_polyfill3.default.storage.local.set({ [SAVED_PROMPTS_KEY]: savedPrompts, [SAVED_PROMPTS_MOVED_KEY]: true });
      await import_webextension_polyfill3.default.storage.sync.set({ [SAVED_PROMPTS_KEY]: [] });
    }
    return addDefaults ? addDefaultPrompts(savedPrompts) : savedPrompts;
  };
  function addDefaultPrompts(prompts) {
    if (getLocaleLanguage() !== "en") {
      addPrompt(prompts, getDefaultEnglishPrompt());
    }
    addPrompt(prompts, getDefaultPrompt());
    return prompts;
    function addPrompt(prompts2, prompt) {
      const index2 = prompts2.findIndex((i3) => i3.uuid === prompt.uuid);
      if (index2 >= 0) {
        prompts2[index2] = prompt;
      } else {
        prompts2.unshift(prompt);
      }
    }
  }

  // src/components/toolbar.tsx
  var import_webextension_polyfill4 = __toESM(require_browser_polyfill());

  // src/components/dropdown.tsx
  function Dropdown(props) {
    return /* @__PURE__ */ h(
      "select",
      {
        className: "wcg-block wcg-max-w-[9.5rem] wcg-border-0 wcg-p-2.5 wcg-pr-2 wcg-text-sm focus:wcg-ring-0 dark:wcg-bg-neutral",
        value: props.value,
        onChange: props.onChange,
        onClick: props.onClick
      },
      props.options.map(({ value, label }) => /* @__PURE__ */ h(
        "option",
        {
          className: "wcg-bg-[#343541] wcg-text-white",
          key: value,
          value
        },
        label
      ))
    );
  }
  var dropdown_default = Dropdown;

  // src/components/toolbar.tsx
  var numResultsOptions = Array.from({ length: 10 }, (_2, i3) => i3 + 1).map((num) => ({
    value: num,
    label: `${num} result${num === 1 ? "" : "s"}`
  }));
  numResultsOptions.push({
    value: 100,
    label: "Max results"
  });
  var Toolbar = ({ textarea: textarea2 }) => {
    const [webAccess, setWebAccess] = p2(false);
    const [numResults, setNumResults] = p2(3);
    const [timePeriod, setTimePeriod] = p2("");
    const [region, setRegion] = p2("wt-wt");
    const [promptUUID, setPromptUUID] = p2("");
    const [prompts, setPrompts] = p2([]);
    const [selectedCategory, setSelectedCategory] = p2("");
    h2(() => {
      getUserConfig().then((userConfig) => {
        setWebAccess(userConfig.webAccess);
        setNumResults(userConfig.numWebResults);
        setTimePeriod(userConfig.timePeriod);
        setRegion(userConfig.region);
        setPromptUUID(userConfig.promptUUID);
        setLocaleLanguage(userConfig.language);
        updateTextAreaPlaceholder(userConfig.webAccess);
      });
      updatePrompts();
    }, []);
    h2(() => {
      const handleMessage = async (request) => {
        if (request === "toggle-web-access") {
          handleWebAccessToggle();
        }
      };
      import_webextension_polyfill4.default.runtime.onMessage.addListener(handleMessage);
      return () => import_webextension_polyfill4.default.runtime.onMessage.removeListener(handleMessage);
    }, []);
    h2(() => {
      updateUserConfig({ webAccess });
      updateTextAreaPlaceholder(webAccess);
      textarea2?.focus();
    }, [webAccess]);
    const handlePromptClick = () => updatePrompts();
    const updatePrompts = () => {
      getSavedPrompts().then((savedPrompts) => {
        setPrompts(savedPrompts);
      });
    };
    const updateTextAreaPlaceholder = (show) => {
      textarea2?.setAttribute("placeholder", show ? getTranslation(localizationKeys.UI.textareaPlaceholder) : "");
    };
    const handleWebAccessToggle = () => setWebAccess((prev2) => !prev2);
    const handleNumResultsChange = (e3) => {
      const value = parseInt(e3.target.value, 10);
      setNumResults(value);
      updateUserConfig({ numWebResults: value });
    };
    const handleTimePeriodChange = (e3) => {
      setTimePeriod(e3.target.value);
      updateUserConfig({ timePeriod: e3.target.value });
    };
    const handleRegionChange = (e3) => {
      setRegion(e3.target.value);
      updateUserConfig({ region: e3.target.value });
    };
    const handlePromptChange = (e3) => {
      const uuid = e3.target.value;
      if (uuid === "wcg-new-prompt") {
        import_webextension_polyfill4.default.runtime.sendMessage("show_options");
        e3.target.value = promptUUID;
        return;
      }
      removeFocusFromCurrentElement();
      setPromptUUID(uuid);
      updateUserConfig({ promptUUID: uuid });
      const selectedPrompt = prompts.find((prompt) => prompt.uuid === uuid);
      console.log("Selected Prompt: ", selectedPrompt);
      console.log("Saved Prompt Text:", selectedPrompt?.text);
      if (selectedPrompt) {
        const promptText = selectedPrompt.text;
        const textarea3 = document.getElementsByTagName("textarea")[0];
        if (textarea3) {
          textarea3.value = promptText;
        }
      }
      ;
    };
    const removeFocusFromCurrentElement = () => document.activeElement?.blur();
    const webAccessToggle = /* @__PURE__ */ h("div", { className: "wcg-group wcg-relative wcg-flex" });
    return /* @__PURE__ */ h("div", { className: "wcg-flex wcg-flex-col wcg-gap-0" }, /* @__PURE__ */ h("div", { className: "wcg-toolbar wcg-flex wcg-items-center wcg-gap-2 wcg-rounded-md wcg-px-1" }, /* @__PURE__ */ h(
      "div",
      {
        className: "wcg-btn-xs wcg-btn focus:wcg-ring-2 focus:wcg-ring-white",
        tabIndex: 0,
        onClick: () => import_webextension_polyfill4.default.runtime.sendMessage("show_options")
      },
      icons.tune
    ), /* @__PURE__ */ h("div", { class: "wcg-scrollbar-hidden wcg-flex wcg-items-center wcg-justify-between wcg-gap-2 wcg-overflow-x-scroll wcg-px-1 lg:wcg-overflow-x-hidden" }, /* @__PURE__ */ h(
      dropdown_default,
      {
        value: promptUUID,
        onChange: handlePromptChange,
        options: prompts.map((prompt) => ({ value: prompt.uuid ?? "undefin", label: prompt.name })).concat({ value: "wcg-new-prompt", label: `+ ${getTranslation(localizationKeys.buttons.newPrompt)}` }),
        onClick: handlePromptClick
      }
    ))));
  };
  var toolbar_default = Toolbar;

  // src/components/errorMessage.tsx
  function ErrorMessage(props) {
    const [show, setShow] = p2(true);
    h2(() => {
      const timer = setTimeout(() => {
        setShow(false);
      }, 1e4);
      return () => clearTimeout(timer);
    }, []);
    if (!props.message)
      return null;
    if (!show)
      return null;
    return (
      // <div className="absolute wcg-bottom-0 wcg-right-1 dark:wcg-text-white wcg-bg-red-500 wcg-p-4 wcg-rounded-lg wcg-mb-4 wcg-mr-4 wcg-text-sm">
      /* @__PURE__ */ h("div", { role: "alert", className: "absolute bottom-0 right-1 dark:text-white bg-red-500 p-4 rounded-lg mb-4 mr-4 text-sm max-w-sm" }, /* @__PURE__ */ h("b", null, "An error occurred"), /* @__PURE__ */ h("br", null), props.message, /* @__PURE__ */ h("br", null), /* @__PURE__ */ h("br", null), "You can check the console for more details. (Ctrl+Shift+J)")
    );
  }
  var errorMessage_default = ErrorMessage;

  // node_modules/cheerio/lib/esm/options.js
  var defaultOpts = {
    xml: false,
    decodeEntities: true
  };
  var options_default = defaultOpts;
  var xmlModeDefault = {
    _useHtmlParser2: true,
    xmlMode: true
  };
  function flatten(options2) {
    return (options2 === null || options2 === void 0 ? void 0 : options2.xml) ? typeof options2.xml === "boolean" ? xmlModeDefault : { ...xmlModeDefault, ...options2.xml } : options2 !== null && options2 !== void 0 ? options2 : void 0;
  }

  // node_modules/cheerio/lib/esm/static.js
  var static_exports = {};
  __export(static_exports, {
    contains: () => contains,
    html: () => html,
    merge: () => merge,
    parseHTML: () => parseHTML,
    root: () => root2,
    text: () => text,
    xml: () => xml
  });

  // node_modules/domutils/lib/esm/index.js
  var esm_exports2 = {};
  __export(esm_exports2, {
    DocumentPosition: () => DocumentPosition,
    append: () => append,
    appendChild: () => appendChild,
    compareDocumentPosition: () => compareDocumentPosition,
    existsOne: () => existsOne,
    filter: () => filter,
    find: () => find,
    findAll: () => findAll,
    findOne: () => findOne,
    findOneChild: () => findOneChild,
    getAttributeValue: () => getAttributeValue,
    getChildren: () => getChildren,
    getElementById: () => getElementById,
    getElements: () => getElements,
    getElementsByTagName: () => getElementsByTagName,
    getElementsByTagType: () => getElementsByTagType,
    getFeed: () => getFeed,
    getInnerHTML: () => getInnerHTML,
    getName: () => getName,
    getOuterHTML: () => getOuterHTML,
    getParent: () => getParent,
    getSiblings: () => getSiblings,
    getText: () => getText,
    hasAttrib: () => hasAttrib,
    hasChildren: () => hasChildren,
    innerText: () => innerText,
    isCDATA: () => isCDATA,
    isComment: () => isComment,
    isDocument: () => isDocument,
    isTag: () => isTag2,
    isText: () => isText,
    nextElementSibling: () => nextElementSibling,
    prepend: () => prepend,
    prependChild: () => prependChild,
    prevElementSibling: () => prevElementSibling,
    removeElement: () => removeElement,
    removeSubsets: () => removeSubsets,
    replaceElement: () => replaceElement,
    testElement: () => testElement,
    textContent: () => textContent,
    uniqueSort: () => uniqueSort
  });

  // node_modules/domelementtype/lib/esm/index.js
  var esm_exports = {};
  __export(esm_exports, {
    CDATA: () => CDATA,
    Comment: () => Comment,
    Directive: () => Directive,
    Doctype: () => Doctype,
    ElementType: () => ElementType,
    Root: () => Root,
    Script: () => Script,
    Style: () => Style,
    Tag: () => Tag,
    Text: () => Text,
    isTag: () => isTag
  });
  var ElementType;
  (function(ElementType2) {
    ElementType2["Root"] = "root";
    ElementType2["Text"] = "text";
    ElementType2["Directive"] = "directive";
    ElementType2["Comment"] = "comment";
    ElementType2["Script"] = "script";
    ElementType2["Style"] = "style";
    ElementType2["Tag"] = "tag";
    ElementType2["CDATA"] = "cdata";
    ElementType2["Doctype"] = "doctype";
  })(ElementType || (ElementType = {}));
  function isTag(elem) {
    return elem.type === ElementType.Tag || elem.type === ElementType.Script || elem.type === ElementType.Style;
  }
  var Root = ElementType.Root;
  var Text = ElementType.Text;
  var Directive = ElementType.Directive;
  var Comment = ElementType.Comment;
  var Script = ElementType.Script;
  var Style = ElementType.Style;
  var Tag = ElementType.Tag;
  var CDATA = ElementType.CDATA;
  var Doctype = ElementType.Doctype;

  // node_modules/domhandler/lib/esm/node.js
  var Node = class {
    constructor() {
      this.parent = null;
      this.prev = null;
      this.next = null;
      this.startIndex = null;
      this.endIndex = null;
    }
    // Read-write aliases for properties
    /**
     * Same as {@link parent}.
     * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
     */
    get parentNode() {
      return this.parent;
    }
    set parentNode(parent2) {
      this.parent = parent2;
    }
    /**
     * Same as {@link prev}.
     * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
     */
    get previousSibling() {
      return this.prev;
    }
    set previousSibling(prev2) {
      this.prev = prev2;
    }
    /**
     * Same as {@link next}.
     * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
     */
    get nextSibling() {
      return this.next;
    }
    set nextSibling(next2) {
      this.next = next2;
    }
    /**
     * Clone this node, and optionally its children.
     *
     * @param recursive Clone child nodes as well.
     * @returns A clone of the node.
     */
    cloneNode(recursive = false) {
      return cloneNode(this, recursive);
    }
  };
  var DataNode = class extends Node {
    /**
     * @param data The content of the data node
     */
    constructor(data2) {
      super();
      this.data = data2;
    }
    /**
     * Same as {@link data}.
     * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
     */
    get nodeValue() {
      return this.data;
    }
    set nodeValue(data2) {
      this.data = data2;
    }
  };
  var Text2 = class extends DataNode {
    constructor() {
      super(...arguments);
      this.type = ElementType.Text;
    }
    get nodeType() {
      return 3;
    }
  };
  var Comment2 = class extends DataNode {
    constructor() {
      super(...arguments);
      this.type = ElementType.Comment;
    }
    get nodeType() {
      return 8;
    }
  };
  var ProcessingInstruction = class extends DataNode {
    constructor(name, data2) {
      super(data2);
      this.name = name;
      this.type = ElementType.Directive;
    }
    get nodeType() {
      return 1;
    }
  };
  var NodeWithChildren = class extends Node {
    /**
     * @param children Children of the node. Only certain node types can have children.
     */
    constructor(children2) {
      super();
      this.children = children2;
    }
    // Aliases
    /** First child of the node. */
    get firstChild() {
      var _a2;
      return (_a2 = this.children[0]) !== null && _a2 !== void 0 ? _a2 : null;
    }
    /** Last child of the node. */
    get lastChild() {
      return this.children.length > 0 ? this.children[this.children.length - 1] : null;
    }
    /**
     * Same as {@link children}.
     * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
     */
    get childNodes() {
      return this.children;
    }
    set childNodes(children2) {
      this.children = children2;
    }
  };
  var CDATA2 = class extends NodeWithChildren {
    constructor() {
      super(...arguments);
      this.type = ElementType.CDATA;
    }
    get nodeType() {
      return 4;
    }
  };
  var Document = class extends NodeWithChildren {
    constructor() {
      super(...arguments);
      this.type = ElementType.Root;
    }
    get nodeType() {
      return 9;
    }
  };
  var Element = class extends NodeWithChildren {
    /**
     * @param name Name of the tag, eg. `div`, `span`.
     * @param attribs Object mapping attribute names to attribute values.
     * @param children Children of the node.
     */
    constructor(name, attribs, children2 = [], type = name === "script" ? ElementType.Script : name === "style" ? ElementType.Style : ElementType.Tag) {
      super(children2);
      this.name = name;
      this.attribs = attribs;
      this.type = type;
    }
    get nodeType() {
      return 1;
    }
    // DOM Level 1 aliases
    /**
     * Same as {@link name}.
     * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
     */
    get tagName() {
      return this.name;
    }
    set tagName(name) {
      this.name = name;
    }
    get attributes() {
      return Object.keys(this.attribs).map((name) => {
        var _a2, _b;
        return {
          name,
          value: this.attribs[name],
          namespace: (_a2 = this["x-attribsNamespace"]) === null || _a2 === void 0 ? void 0 : _a2[name],
          prefix: (_b = this["x-attribsPrefix"]) === null || _b === void 0 ? void 0 : _b[name]
        };
      });
    }
  };
  function isTag2(node) {
    return isTag(node);
  }
  function isCDATA(node) {
    return node.type === ElementType.CDATA;
  }
  function isText(node) {
    return node.type === ElementType.Text;
  }
  function isComment(node) {
    return node.type === ElementType.Comment;
  }
  function isDirective(node) {
    return node.type === ElementType.Directive;
  }
  function isDocument(node) {
    return node.type === ElementType.Root;
  }
  function hasChildren(node) {
    return Object.prototype.hasOwnProperty.call(node, "children");
  }
  function cloneNode(node, recursive = false) {
    let result;
    if (isText(node)) {
      result = new Text2(node.data);
    } else if (isComment(node)) {
      result = new Comment2(node.data);
    } else if (isTag2(node)) {
      const children2 = recursive ? cloneChildren(node.children) : [];
      const clone2 = new Element(node.name, { ...node.attribs }, children2);
      children2.forEach((child) => child.parent = clone2);
      if (node.namespace != null) {
        clone2.namespace = node.namespace;
      }
      if (node["x-attribsNamespace"]) {
        clone2["x-attribsNamespace"] = { ...node["x-attribsNamespace"] };
      }
      if (node["x-attribsPrefix"]) {
        clone2["x-attribsPrefix"] = { ...node["x-attribsPrefix"] };
      }
      result = clone2;
    } else if (isCDATA(node)) {
      const children2 = recursive ? cloneChildren(node.children) : [];
      const clone2 = new CDATA2(children2);
      children2.forEach((child) => child.parent = clone2);
      result = clone2;
    } else if (isDocument(node)) {
      const children2 = recursive ? cloneChildren(node.children) : [];
      const clone2 = new Document(children2);
      children2.forEach((child) => child.parent = clone2);
      if (node["x-mode"]) {
        clone2["x-mode"] = node["x-mode"];
      }
      result = clone2;
    } else if (isDirective(node)) {
      const instruction = new ProcessingInstruction(node.name, node.data);
      if (node["x-name"] != null) {
        instruction["x-name"] = node["x-name"];
        instruction["x-publicId"] = node["x-publicId"];
        instruction["x-systemId"] = node["x-systemId"];
      }
      result = instruction;
    } else {
      throw new Error(`Not implemented yet: ${node.type}`);
    }
    result.startIndex = node.startIndex;
    result.endIndex = node.endIndex;
    if (node.sourceCodeLocation != null) {
      result.sourceCodeLocation = node.sourceCodeLocation;
    }
    return result;
  }
  function cloneChildren(childs) {
    const children2 = childs.map((child) => cloneNode(child, true));
    for (let i3 = 1; i3 < children2.length; i3++) {
      children2[i3].prev = children2[i3 - 1];
      children2[i3 - 1].next = children2[i3];
    }
    return children2;
  }

  // node_modules/domhandler/lib/esm/index.js
  var defaultOpts2 = {
    withStartIndices: false,
    withEndIndices: false,
    xmlMode: false
  };
  var DomHandler = class {
    /**
     * @param callback Called once parsing has completed.
     * @param options Settings for the handler.
     * @param elementCB Callback whenever a tag is closed.
     */
    constructor(callback, options2, elementCB) {
      this.dom = [];
      this.root = new Document(this.dom);
      this.done = false;
      this.tagStack = [this.root];
      this.lastNode = null;
      this.parser = null;
      if (typeof options2 === "function") {
        elementCB = options2;
        options2 = defaultOpts2;
      }
      if (typeof callback === "object") {
        options2 = callback;
        callback = void 0;
      }
      this.callback = callback !== null && callback !== void 0 ? callback : null;
      this.options = options2 !== null && options2 !== void 0 ? options2 : defaultOpts2;
      this.elementCB = elementCB !== null && elementCB !== void 0 ? elementCB : null;
    }
    onparserinit(parser) {
      this.parser = parser;
    }
    // Resets the handler back to starting state
    onreset() {
      this.dom = [];
      this.root = new Document(this.dom);
      this.done = false;
      this.tagStack = [this.root];
      this.lastNode = null;
      this.parser = null;
    }
    // Signals the handler that parsing is done
    onend() {
      if (this.done)
        return;
      this.done = true;
      this.parser = null;
      this.handleCallback(null);
    }
    onerror(error) {
      this.handleCallback(error);
    }
    onclosetag() {
      this.lastNode = null;
      const elem = this.tagStack.pop();
      if (this.options.withEndIndices) {
        elem.endIndex = this.parser.endIndex;
      }
      if (this.elementCB)
        this.elementCB(elem);
    }
    onopentag(name, attribs) {
      const type = this.options.xmlMode ? ElementType.Tag : void 0;
      const element = new Element(name, attribs, void 0, type);
      this.addNode(element);
      this.tagStack.push(element);
    }
    ontext(data2) {
      const { lastNode } = this;
      if (lastNode && lastNode.type === ElementType.Text) {
        lastNode.data += data2;
        if (this.options.withEndIndices) {
          lastNode.endIndex = this.parser.endIndex;
        }
      } else {
        const node = new Text2(data2);
        this.addNode(node);
        this.lastNode = node;
      }
    }
    oncomment(data2) {
      if (this.lastNode && this.lastNode.type === ElementType.Comment) {
        this.lastNode.data += data2;
        return;
      }
      const node = new Comment2(data2);
      this.addNode(node);
      this.lastNode = node;
    }
    oncommentend() {
      this.lastNode = null;
    }
    oncdatastart() {
      const text3 = new Text2("");
      const node = new CDATA2([text3]);
      this.addNode(node);
      text3.parent = node;
      this.lastNode = text3;
    }
    oncdataend() {
      this.lastNode = null;
    }
    onprocessinginstruction(name, data2) {
      const node = new ProcessingInstruction(name, data2);
      this.addNode(node);
    }
    handleCallback(error) {
      if (typeof this.callback === "function") {
        this.callback(error, this.dom);
      } else if (error) {
        throw error;
      }
    }
    addNode(node) {
      const parent2 = this.tagStack[this.tagStack.length - 1];
      const previousSibling2 = parent2.children[parent2.children.length - 1];
      if (this.options.withStartIndices) {
        node.startIndex = this.parser.startIndex;
      }
      if (this.options.withEndIndices) {
        node.endIndex = this.parser.endIndex;
      }
      parent2.children.push(node);
      if (previousSibling2) {
        node.prev = previousSibling2;
        previousSibling2.next = node;
      }
      node.parent = parent2;
      this.lastNode = null;
    }
  };

  // node_modules/entities/lib/esm/generated/decode-data-html.js
  var decode_data_html_default = new Uint16Array(
    // prettier-ignore
    '\u1D41<\xD5\u0131\u028A\u049D\u057B\u05D0\u0675\u06DE\u07A2\u07D6\u080F\u0A4A\u0A91\u0DA1\u0E6D\u0F09\u0F26\u10CA\u1228\u12E1\u1415\u149D\u14C3\u14DF\u1525\0\0\0\0\0\0\u156B\u16CD\u198D\u1C12\u1DDD\u1F7E\u2060\u21B0\u228D\u23C0\u23FB\u2442\u2824\u2912\u2D08\u2E48\u2FCE\u3016\u32BA\u3639\u37AC\u38FE\u3A28\u3A71\u3AE0\u3B2E\u0800EMabcfglmnoprstu\\bfms\x7F\x84\x8B\x90\x95\x98\xA6\xB3\xB9\xC8\xCFlig\u803B\xC6\u40C6P\u803B&\u4026cute\u803B\xC1\u40C1reve;\u4102\u0100iyx}rc\u803B\xC2\u40C2;\u4410r;\uC000\u{1D504}rave\u803B\xC0\u40C0pha;\u4391acr;\u4100d;\u6A53\u0100gp\x9D\xA1on;\u4104f;\uC000\u{1D538}plyFunction;\u6061ing\u803B\xC5\u40C5\u0100cs\xBE\xC3r;\uC000\u{1D49C}ign;\u6254ilde\u803B\xC3\u40C3ml\u803B\xC4\u40C4\u0400aceforsu\xE5\xFB\xFE\u0117\u011C\u0122\u0127\u012A\u0100cr\xEA\xF2kslash;\u6216\u0176\xF6\xF8;\u6AE7ed;\u6306y;\u4411\u0180crt\u0105\u010B\u0114ause;\u6235noullis;\u612Ca;\u4392r;\uC000\u{1D505}pf;\uC000\u{1D539}eve;\u42D8c\xF2\u0113mpeq;\u624E\u0700HOacdefhilorsu\u014D\u0151\u0156\u0180\u019E\u01A2\u01B5\u01B7\u01BA\u01DC\u0215\u0273\u0278\u027Ecy;\u4427PY\u803B\xA9\u40A9\u0180cpy\u015D\u0162\u017Aute;\u4106\u0100;i\u0167\u0168\u62D2talDifferentialD;\u6145leys;\u612D\u0200aeio\u0189\u018E\u0194\u0198ron;\u410Cdil\u803B\xC7\u40C7rc;\u4108nint;\u6230ot;\u410A\u0100dn\u01A7\u01ADilla;\u40B8terDot;\u40B7\xF2\u017Fi;\u43A7rcle\u0200DMPT\u01C7\u01CB\u01D1\u01D6ot;\u6299inus;\u6296lus;\u6295imes;\u6297o\u0100cs\u01E2\u01F8kwiseContourIntegral;\u6232eCurly\u0100DQ\u0203\u020FoubleQuote;\u601Duote;\u6019\u0200lnpu\u021E\u0228\u0247\u0255on\u0100;e\u0225\u0226\u6237;\u6A74\u0180git\u022F\u0236\u023Aruent;\u6261nt;\u622FourIntegral;\u622E\u0100fr\u024C\u024E;\u6102oduct;\u6210nterClockwiseContourIntegral;\u6233oss;\u6A2Fcr;\uC000\u{1D49E}p\u0100;C\u0284\u0285\u62D3ap;\u624D\u0580DJSZacefios\u02A0\u02AC\u02B0\u02B4\u02B8\u02CB\u02D7\u02E1\u02E6\u0333\u048D\u0100;o\u0179\u02A5trahd;\u6911cy;\u4402cy;\u4405cy;\u440F\u0180grs\u02BF\u02C4\u02C7ger;\u6021r;\u61A1hv;\u6AE4\u0100ay\u02D0\u02D5ron;\u410E;\u4414l\u0100;t\u02DD\u02DE\u6207a;\u4394r;\uC000\u{1D507}\u0100af\u02EB\u0327\u0100cm\u02F0\u0322ritical\u0200ADGT\u0300\u0306\u0316\u031Ccute;\u40B4o\u0174\u030B\u030D;\u42D9bleAcute;\u42DDrave;\u4060ilde;\u42DCond;\u62C4ferentialD;\u6146\u0470\u033D\0\0\0\u0342\u0354\0\u0405f;\uC000\u{1D53B}\u0180;DE\u0348\u0349\u034D\u40A8ot;\u60DCqual;\u6250ble\u0300CDLRUV\u0363\u0372\u0382\u03CF\u03E2\u03F8ontourIntegra\xEC\u0239o\u0274\u0379\0\0\u037B\xBB\u0349nArrow;\u61D3\u0100eo\u0387\u03A4ft\u0180ART\u0390\u0396\u03A1rrow;\u61D0ightArrow;\u61D4e\xE5\u02CAng\u0100LR\u03AB\u03C4eft\u0100AR\u03B3\u03B9rrow;\u67F8ightArrow;\u67FAightArrow;\u67F9ight\u0100AT\u03D8\u03DErrow;\u61D2ee;\u62A8p\u0241\u03E9\0\0\u03EFrrow;\u61D1ownArrow;\u61D5erticalBar;\u6225n\u0300ABLRTa\u0412\u042A\u0430\u045E\u047F\u037Crrow\u0180;BU\u041D\u041E\u0422\u6193ar;\u6913pArrow;\u61F5reve;\u4311eft\u02D2\u043A\0\u0446\0\u0450ightVector;\u6950eeVector;\u695Eector\u0100;B\u0459\u045A\u61BDar;\u6956ight\u01D4\u0467\0\u0471eeVector;\u695Fector\u0100;B\u047A\u047B\u61C1ar;\u6957ee\u0100;A\u0486\u0487\u62A4rrow;\u61A7\u0100ct\u0492\u0497r;\uC000\u{1D49F}rok;\u4110\u0800NTacdfglmopqstux\u04BD\u04C0\u04C4\u04CB\u04DE\u04E2\u04E7\u04EE\u04F5\u0521\u052F\u0536\u0552\u055D\u0560\u0565G;\u414AH\u803B\xD0\u40D0cute\u803B\xC9\u40C9\u0180aiy\u04D2\u04D7\u04DCron;\u411Arc\u803B\xCA\u40CA;\u442Dot;\u4116r;\uC000\u{1D508}rave\u803B\xC8\u40C8ement;\u6208\u0100ap\u04FA\u04FEcr;\u4112ty\u0253\u0506\0\0\u0512mallSquare;\u65FBerySmallSquare;\u65AB\u0100gp\u0526\u052Aon;\u4118f;\uC000\u{1D53C}silon;\u4395u\u0100ai\u053C\u0549l\u0100;T\u0542\u0543\u6A75ilde;\u6242librium;\u61CC\u0100ci\u0557\u055Ar;\u6130m;\u6A73a;\u4397ml\u803B\xCB\u40CB\u0100ip\u056A\u056Fsts;\u6203onentialE;\u6147\u0280cfios\u0585\u0588\u058D\u05B2\u05CCy;\u4424r;\uC000\u{1D509}lled\u0253\u0597\0\0\u05A3mallSquare;\u65FCerySmallSquare;\u65AA\u0370\u05BA\0\u05BF\0\0\u05C4f;\uC000\u{1D53D}All;\u6200riertrf;\u6131c\xF2\u05CB\u0600JTabcdfgorst\u05E8\u05EC\u05EF\u05FA\u0600\u0612\u0616\u061B\u061D\u0623\u066C\u0672cy;\u4403\u803B>\u403Emma\u0100;d\u05F7\u05F8\u4393;\u43DCreve;\u411E\u0180eiy\u0607\u060C\u0610dil;\u4122rc;\u411C;\u4413ot;\u4120r;\uC000\u{1D50A};\u62D9pf;\uC000\u{1D53E}eater\u0300EFGLST\u0635\u0644\u064E\u0656\u065B\u0666qual\u0100;L\u063E\u063F\u6265ess;\u62DBullEqual;\u6267reater;\u6AA2ess;\u6277lantEqual;\u6A7Eilde;\u6273cr;\uC000\u{1D4A2};\u626B\u0400Aacfiosu\u0685\u068B\u0696\u069B\u069E\u06AA\u06BE\u06CARDcy;\u442A\u0100ct\u0690\u0694ek;\u42C7;\u405Eirc;\u4124r;\u610ClbertSpace;\u610B\u01F0\u06AF\0\u06B2f;\u610DizontalLine;\u6500\u0100ct\u06C3\u06C5\xF2\u06A9rok;\u4126mp\u0144\u06D0\u06D8ownHum\xF0\u012Fqual;\u624F\u0700EJOacdfgmnostu\u06FA\u06FE\u0703\u0707\u070E\u071A\u071E\u0721\u0728\u0744\u0778\u078B\u078F\u0795cy;\u4415lig;\u4132cy;\u4401cute\u803B\xCD\u40CD\u0100iy\u0713\u0718rc\u803B\xCE\u40CE;\u4418ot;\u4130r;\u6111rave\u803B\xCC\u40CC\u0180;ap\u0720\u072F\u073F\u0100cg\u0734\u0737r;\u412AinaryI;\u6148lie\xF3\u03DD\u01F4\u0749\0\u0762\u0100;e\u074D\u074E\u622C\u0100gr\u0753\u0758ral;\u622Bsection;\u62C2isible\u0100CT\u076C\u0772omma;\u6063imes;\u6062\u0180gpt\u077F\u0783\u0788on;\u412Ef;\uC000\u{1D540}a;\u4399cr;\u6110ilde;\u4128\u01EB\u079A\0\u079Ecy;\u4406l\u803B\xCF\u40CF\u0280cfosu\u07AC\u07B7\u07BC\u07C2\u07D0\u0100iy\u07B1\u07B5rc;\u4134;\u4419r;\uC000\u{1D50D}pf;\uC000\u{1D541}\u01E3\u07C7\0\u07CCr;\uC000\u{1D4A5}rcy;\u4408kcy;\u4404\u0380HJacfos\u07E4\u07E8\u07EC\u07F1\u07FD\u0802\u0808cy;\u4425cy;\u440Cppa;\u439A\u0100ey\u07F6\u07FBdil;\u4136;\u441Ar;\uC000\u{1D50E}pf;\uC000\u{1D542}cr;\uC000\u{1D4A6}\u0580JTaceflmost\u0825\u0829\u082C\u0850\u0863\u09B3\u09B8\u09C7\u09CD\u0A37\u0A47cy;\u4409\u803B<\u403C\u0280cmnpr\u0837\u083C\u0841\u0844\u084Dute;\u4139bda;\u439Bg;\u67EAlacetrf;\u6112r;\u619E\u0180aey\u0857\u085C\u0861ron;\u413Ddil;\u413B;\u441B\u0100fs\u0868\u0970t\u0500ACDFRTUVar\u087E\u08A9\u08B1\u08E0\u08E6\u08FC\u092F\u095B\u0390\u096A\u0100nr\u0883\u088FgleBracket;\u67E8row\u0180;BR\u0899\u089A\u089E\u6190ar;\u61E4ightArrow;\u61C6eiling;\u6308o\u01F5\u08B7\0\u08C3bleBracket;\u67E6n\u01D4\u08C8\0\u08D2eeVector;\u6961ector\u0100;B\u08DB\u08DC\u61C3ar;\u6959loor;\u630Aight\u0100AV\u08EF\u08F5rrow;\u6194ector;\u694E\u0100er\u0901\u0917e\u0180;AV\u0909\u090A\u0910\u62A3rrow;\u61A4ector;\u695Aiangle\u0180;BE\u0924\u0925\u0929\u62B2ar;\u69CFqual;\u62B4p\u0180DTV\u0937\u0942\u094CownVector;\u6951eeVector;\u6960ector\u0100;B\u0956\u0957\u61BFar;\u6958ector\u0100;B\u0965\u0966\u61BCar;\u6952ight\xE1\u039Cs\u0300EFGLST\u097E\u098B\u0995\u099D\u09A2\u09ADqualGreater;\u62DAullEqual;\u6266reater;\u6276ess;\u6AA1lantEqual;\u6A7Dilde;\u6272r;\uC000\u{1D50F}\u0100;e\u09BD\u09BE\u62D8ftarrow;\u61DAidot;\u413F\u0180npw\u09D4\u0A16\u0A1Bg\u0200LRlr\u09DE\u09F7\u0A02\u0A10eft\u0100AR\u09E6\u09ECrrow;\u67F5ightArrow;\u67F7ightArrow;\u67F6eft\u0100ar\u03B3\u0A0Aight\xE1\u03BFight\xE1\u03CAf;\uC000\u{1D543}er\u0100LR\u0A22\u0A2CeftArrow;\u6199ightArrow;\u6198\u0180cht\u0A3E\u0A40\u0A42\xF2\u084C;\u61B0rok;\u4141;\u626A\u0400acefiosu\u0A5A\u0A5D\u0A60\u0A77\u0A7C\u0A85\u0A8B\u0A8Ep;\u6905y;\u441C\u0100dl\u0A65\u0A6FiumSpace;\u605Flintrf;\u6133r;\uC000\u{1D510}nusPlus;\u6213pf;\uC000\u{1D544}c\xF2\u0A76;\u439C\u0480Jacefostu\u0AA3\u0AA7\u0AAD\u0AC0\u0B14\u0B19\u0D91\u0D97\u0D9Ecy;\u440Acute;\u4143\u0180aey\u0AB4\u0AB9\u0ABEron;\u4147dil;\u4145;\u441D\u0180gsw\u0AC7\u0AF0\u0B0Eative\u0180MTV\u0AD3\u0ADF\u0AE8ediumSpace;\u600Bhi\u0100cn\u0AE6\u0AD8\xEB\u0AD9eryThi\xEE\u0AD9ted\u0100GL\u0AF8\u0B06reaterGreate\xF2\u0673essLes\xF3\u0A48Line;\u400Ar;\uC000\u{1D511}\u0200Bnpt\u0B22\u0B28\u0B37\u0B3Areak;\u6060BreakingSpace;\u40A0f;\u6115\u0680;CDEGHLNPRSTV\u0B55\u0B56\u0B6A\u0B7C\u0BA1\u0BEB\u0C04\u0C5E\u0C84\u0CA6\u0CD8\u0D61\u0D85\u6AEC\u0100ou\u0B5B\u0B64ngruent;\u6262pCap;\u626DoubleVerticalBar;\u6226\u0180lqx\u0B83\u0B8A\u0B9Bement;\u6209ual\u0100;T\u0B92\u0B93\u6260ilde;\uC000\u2242\u0338ists;\u6204reater\u0380;EFGLST\u0BB6\u0BB7\u0BBD\u0BC9\u0BD3\u0BD8\u0BE5\u626Fqual;\u6271ullEqual;\uC000\u2267\u0338reater;\uC000\u226B\u0338ess;\u6279lantEqual;\uC000\u2A7E\u0338ilde;\u6275ump\u0144\u0BF2\u0BFDownHump;\uC000\u224E\u0338qual;\uC000\u224F\u0338e\u0100fs\u0C0A\u0C27tTriangle\u0180;BE\u0C1A\u0C1B\u0C21\u62EAar;\uC000\u29CF\u0338qual;\u62ECs\u0300;EGLST\u0C35\u0C36\u0C3C\u0C44\u0C4B\u0C58\u626Equal;\u6270reater;\u6278ess;\uC000\u226A\u0338lantEqual;\uC000\u2A7D\u0338ilde;\u6274ested\u0100GL\u0C68\u0C79reaterGreater;\uC000\u2AA2\u0338essLess;\uC000\u2AA1\u0338recedes\u0180;ES\u0C92\u0C93\u0C9B\u6280qual;\uC000\u2AAF\u0338lantEqual;\u62E0\u0100ei\u0CAB\u0CB9verseElement;\u620CghtTriangle\u0180;BE\u0CCB\u0CCC\u0CD2\u62EBar;\uC000\u29D0\u0338qual;\u62ED\u0100qu\u0CDD\u0D0CuareSu\u0100bp\u0CE8\u0CF9set\u0100;E\u0CF0\u0CF3\uC000\u228F\u0338qual;\u62E2erset\u0100;E\u0D03\u0D06\uC000\u2290\u0338qual;\u62E3\u0180bcp\u0D13\u0D24\u0D4Eset\u0100;E\u0D1B\u0D1E\uC000\u2282\u20D2qual;\u6288ceeds\u0200;EST\u0D32\u0D33\u0D3B\u0D46\u6281qual;\uC000\u2AB0\u0338lantEqual;\u62E1ilde;\uC000\u227F\u0338erset\u0100;E\u0D58\u0D5B\uC000\u2283\u20D2qual;\u6289ilde\u0200;EFT\u0D6E\u0D6F\u0D75\u0D7F\u6241qual;\u6244ullEqual;\u6247ilde;\u6249erticalBar;\u6224cr;\uC000\u{1D4A9}ilde\u803B\xD1\u40D1;\u439D\u0700Eacdfgmoprstuv\u0DBD\u0DC2\u0DC9\u0DD5\u0DDB\u0DE0\u0DE7\u0DFC\u0E02\u0E20\u0E22\u0E32\u0E3F\u0E44lig;\u4152cute\u803B\xD3\u40D3\u0100iy\u0DCE\u0DD3rc\u803B\xD4\u40D4;\u441Eblac;\u4150r;\uC000\u{1D512}rave\u803B\xD2\u40D2\u0180aei\u0DEE\u0DF2\u0DF6cr;\u414Cga;\u43A9cron;\u439Fpf;\uC000\u{1D546}enCurly\u0100DQ\u0E0E\u0E1AoubleQuote;\u601Cuote;\u6018;\u6A54\u0100cl\u0E27\u0E2Cr;\uC000\u{1D4AA}ash\u803B\xD8\u40D8i\u016C\u0E37\u0E3Cde\u803B\xD5\u40D5es;\u6A37ml\u803B\xD6\u40D6er\u0100BP\u0E4B\u0E60\u0100ar\u0E50\u0E53r;\u603Eac\u0100ek\u0E5A\u0E5C;\u63DEet;\u63B4arenthesis;\u63DC\u0480acfhilors\u0E7F\u0E87\u0E8A\u0E8F\u0E92\u0E94\u0E9D\u0EB0\u0EFCrtialD;\u6202y;\u441Fr;\uC000\u{1D513}i;\u43A6;\u43A0usMinus;\u40B1\u0100ip\u0EA2\u0EADncareplan\xE5\u069Df;\u6119\u0200;eio\u0EB9\u0EBA\u0EE0\u0EE4\u6ABBcedes\u0200;EST\u0EC8\u0EC9\u0ECF\u0EDA\u627Aqual;\u6AAFlantEqual;\u627Cilde;\u627Eme;\u6033\u0100dp\u0EE9\u0EEEuct;\u620Fortion\u0100;a\u0225\u0EF9l;\u621D\u0100ci\u0F01\u0F06r;\uC000\u{1D4AB};\u43A8\u0200Ufos\u0F11\u0F16\u0F1B\u0F1FOT\u803B"\u4022r;\uC000\u{1D514}pf;\u611Acr;\uC000\u{1D4AC}\u0600BEacefhiorsu\u0F3E\u0F43\u0F47\u0F60\u0F73\u0FA7\u0FAA\u0FAD\u1096\u10A9\u10B4\u10BEarr;\u6910G\u803B\xAE\u40AE\u0180cnr\u0F4E\u0F53\u0F56ute;\u4154g;\u67EBr\u0100;t\u0F5C\u0F5D\u61A0l;\u6916\u0180aey\u0F67\u0F6C\u0F71ron;\u4158dil;\u4156;\u4420\u0100;v\u0F78\u0F79\u611Cerse\u0100EU\u0F82\u0F99\u0100lq\u0F87\u0F8Eement;\u620Builibrium;\u61CBpEquilibrium;\u696Fr\xBB\u0F79o;\u43A1ght\u0400ACDFTUVa\u0FC1\u0FEB\u0FF3\u1022\u1028\u105B\u1087\u03D8\u0100nr\u0FC6\u0FD2gleBracket;\u67E9row\u0180;BL\u0FDC\u0FDD\u0FE1\u6192ar;\u61E5eftArrow;\u61C4eiling;\u6309o\u01F5\u0FF9\0\u1005bleBracket;\u67E7n\u01D4\u100A\0\u1014eeVector;\u695Dector\u0100;B\u101D\u101E\u61C2ar;\u6955loor;\u630B\u0100er\u102D\u1043e\u0180;AV\u1035\u1036\u103C\u62A2rrow;\u61A6ector;\u695Biangle\u0180;BE\u1050\u1051\u1055\u62B3ar;\u69D0qual;\u62B5p\u0180DTV\u1063\u106E\u1078ownVector;\u694FeeVector;\u695Cector\u0100;B\u1082\u1083\u61BEar;\u6954ector\u0100;B\u1091\u1092\u61C0ar;\u6953\u0100pu\u109B\u109Ef;\u611DndImplies;\u6970ightarrow;\u61DB\u0100ch\u10B9\u10BCr;\u611B;\u61B1leDelayed;\u69F4\u0680HOacfhimoqstu\u10E4\u10F1\u10F7\u10FD\u1119\u111E\u1151\u1156\u1161\u1167\u11B5\u11BB\u11BF\u0100Cc\u10E9\u10EEHcy;\u4429y;\u4428FTcy;\u442Ccute;\u415A\u0280;aeiy\u1108\u1109\u110E\u1113\u1117\u6ABCron;\u4160dil;\u415Erc;\u415C;\u4421r;\uC000\u{1D516}ort\u0200DLRU\u112A\u1134\u113E\u1149ownArrow\xBB\u041EeftArrow\xBB\u089AightArrow\xBB\u0FDDpArrow;\u6191gma;\u43A3allCircle;\u6218pf;\uC000\u{1D54A}\u0272\u116D\0\0\u1170t;\u621Aare\u0200;ISU\u117B\u117C\u1189\u11AF\u65A1ntersection;\u6293u\u0100bp\u118F\u119Eset\u0100;E\u1197\u1198\u628Fqual;\u6291erset\u0100;E\u11A8\u11A9\u6290qual;\u6292nion;\u6294cr;\uC000\u{1D4AE}ar;\u62C6\u0200bcmp\u11C8\u11DB\u1209\u120B\u0100;s\u11CD\u11CE\u62D0et\u0100;E\u11CD\u11D5qual;\u6286\u0100ch\u11E0\u1205eeds\u0200;EST\u11ED\u11EE\u11F4\u11FF\u627Bqual;\u6AB0lantEqual;\u627Dilde;\u627FTh\xE1\u0F8C;\u6211\u0180;es\u1212\u1213\u1223\u62D1rset\u0100;E\u121C\u121D\u6283qual;\u6287et\xBB\u1213\u0580HRSacfhiors\u123E\u1244\u1249\u1255\u125E\u1271\u1276\u129F\u12C2\u12C8\u12D1ORN\u803B\xDE\u40DEADE;\u6122\u0100Hc\u124E\u1252cy;\u440By;\u4426\u0100bu\u125A\u125C;\u4009;\u43A4\u0180aey\u1265\u126A\u126Fron;\u4164dil;\u4162;\u4422r;\uC000\u{1D517}\u0100ei\u127B\u1289\u01F2\u1280\0\u1287efore;\u6234a;\u4398\u0100cn\u128E\u1298kSpace;\uC000\u205F\u200ASpace;\u6009lde\u0200;EFT\u12AB\u12AC\u12B2\u12BC\u623Cqual;\u6243ullEqual;\u6245ilde;\u6248pf;\uC000\u{1D54B}ipleDot;\u60DB\u0100ct\u12D6\u12DBr;\uC000\u{1D4AF}rok;\u4166\u0AE1\u12F7\u130E\u131A\u1326\0\u132C\u1331\0\0\0\0\0\u1338\u133D\u1377\u1385\0\u13FF\u1404\u140A\u1410\u0100cr\u12FB\u1301ute\u803B\xDA\u40DAr\u0100;o\u1307\u1308\u619Fcir;\u6949r\u01E3\u1313\0\u1316y;\u440Eve;\u416C\u0100iy\u131E\u1323rc\u803B\xDB\u40DB;\u4423blac;\u4170r;\uC000\u{1D518}rave\u803B\xD9\u40D9acr;\u416A\u0100di\u1341\u1369er\u0100BP\u1348\u135D\u0100ar\u134D\u1350r;\u405Fac\u0100ek\u1357\u1359;\u63DFet;\u63B5arenthesis;\u63DDon\u0100;P\u1370\u1371\u62C3lus;\u628E\u0100gp\u137B\u137Fon;\u4172f;\uC000\u{1D54C}\u0400ADETadps\u1395\u13AE\u13B8\u13C4\u03E8\u13D2\u13D7\u13F3rrow\u0180;BD\u1150\u13A0\u13A4ar;\u6912ownArrow;\u61C5ownArrow;\u6195quilibrium;\u696Eee\u0100;A\u13CB\u13CC\u62A5rrow;\u61A5own\xE1\u03F3er\u0100LR\u13DE\u13E8eftArrow;\u6196ightArrow;\u6197i\u0100;l\u13F9\u13FA\u43D2on;\u43A5ing;\u416Ecr;\uC000\u{1D4B0}ilde;\u4168ml\u803B\xDC\u40DC\u0480Dbcdefosv\u1427\u142C\u1430\u1433\u143E\u1485\u148A\u1490\u1496ash;\u62ABar;\u6AEBy;\u4412ash\u0100;l\u143B\u143C\u62A9;\u6AE6\u0100er\u1443\u1445;\u62C1\u0180bty\u144C\u1450\u147Aar;\u6016\u0100;i\u144F\u1455cal\u0200BLST\u1461\u1465\u146A\u1474ar;\u6223ine;\u407Ceparator;\u6758ilde;\u6240ThinSpace;\u600Ar;\uC000\u{1D519}pf;\uC000\u{1D54D}cr;\uC000\u{1D4B1}dash;\u62AA\u0280cefos\u14A7\u14AC\u14B1\u14B6\u14BCirc;\u4174dge;\u62C0r;\uC000\u{1D51A}pf;\uC000\u{1D54E}cr;\uC000\u{1D4B2}\u0200fios\u14CB\u14D0\u14D2\u14D8r;\uC000\u{1D51B};\u439Epf;\uC000\u{1D54F}cr;\uC000\u{1D4B3}\u0480AIUacfosu\u14F1\u14F5\u14F9\u14FD\u1504\u150F\u1514\u151A\u1520cy;\u442Fcy;\u4407cy;\u442Ecute\u803B\xDD\u40DD\u0100iy\u1509\u150Drc;\u4176;\u442Br;\uC000\u{1D51C}pf;\uC000\u{1D550}cr;\uC000\u{1D4B4}ml;\u4178\u0400Hacdefos\u1535\u1539\u153F\u154B\u154F\u155D\u1560\u1564cy;\u4416cute;\u4179\u0100ay\u1544\u1549ron;\u417D;\u4417ot;\u417B\u01F2\u1554\0\u155BoWidt\xE8\u0AD9a;\u4396r;\u6128pf;\u6124cr;\uC000\u{1D4B5}\u0BE1\u1583\u158A\u1590\0\u15B0\u15B6\u15BF\0\0\0\0\u15C6\u15DB\u15EB\u165F\u166D\0\u1695\u169B\u16B2\u16B9\0\u16BEcute\u803B\xE1\u40E1reve;\u4103\u0300;Ediuy\u159C\u159D\u15A1\u15A3\u15A8\u15AD\u623E;\uC000\u223E\u0333;\u623Frc\u803B\xE2\u40E2te\u80BB\xB4\u0306;\u4430lig\u803B\xE6\u40E6\u0100;r\xB2\u15BA;\uC000\u{1D51E}rave\u803B\xE0\u40E0\u0100ep\u15CA\u15D6\u0100fp\u15CF\u15D4sym;\u6135\xE8\u15D3ha;\u43B1\u0100ap\u15DFc\u0100cl\u15E4\u15E7r;\u4101g;\u6A3F\u0264\u15F0\0\0\u160A\u0280;adsv\u15FA\u15FB\u15FF\u1601\u1607\u6227nd;\u6A55;\u6A5Clope;\u6A58;\u6A5A\u0380;elmrsz\u1618\u1619\u161B\u161E\u163F\u164F\u1659\u6220;\u69A4e\xBB\u1619sd\u0100;a\u1625\u1626\u6221\u0461\u1630\u1632\u1634\u1636\u1638\u163A\u163C\u163E;\u69A8;\u69A9;\u69AA;\u69AB;\u69AC;\u69AD;\u69AE;\u69AFt\u0100;v\u1645\u1646\u621Fb\u0100;d\u164C\u164D\u62BE;\u699D\u0100pt\u1654\u1657h;\u6222\xBB\xB9arr;\u637C\u0100gp\u1663\u1667on;\u4105f;\uC000\u{1D552}\u0380;Eaeiop\u12C1\u167B\u167D\u1682\u1684\u1687\u168A;\u6A70cir;\u6A6F;\u624Ad;\u624Bs;\u4027rox\u0100;e\u12C1\u1692\xF1\u1683ing\u803B\xE5\u40E5\u0180cty\u16A1\u16A6\u16A8r;\uC000\u{1D4B6};\u402Amp\u0100;e\u12C1\u16AF\xF1\u0288ilde\u803B\xE3\u40E3ml\u803B\xE4\u40E4\u0100ci\u16C2\u16C8onin\xF4\u0272nt;\u6A11\u0800Nabcdefiklnoprsu\u16ED\u16F1\u1730\u173C\u1743\u1748\u1778\u177D\u17E0\u17E6\u1839\u1850\u170D\u193D\u1948\u1970ot;\u6AED\u0100cr\u16F6\u171Ek\u0200ceps\u1700\u1705\u170D\u1713ong;\u624Cpsilon;\u43F6rime;\u6035im\u0100;e\u171A\u171B\u623Dq;\u62CD\u0176\u1722\u1726ee;\u62BDed\u0100;g\u172C\u172D\u6305e\xBB\u172Drk\u0100;t\u135C\u1737brk;\u63B6\u0100oy\u1701\u1741;\u4431quo;\u601E\u0280cmprt\u1753\u175B\u1761\u1764\u1768aus\u0100;e\u010A\u0109ptyv;\u69B0s\xE9\u170Cno\xF5\u0113\u0180ahw\u176F\u1771\u1773;\u43B2;\u6136een;\u626Cr;\uC000\u{1D51F}g\u0380costuvw\u178D\u179D\u17B3\u17C1\u17D5\u17DB\u17DE\u0180aiu\u1794\u1796\u179A\xF0\u0760rc;\u65EFp\xBB\u1371\u0180dpt\u17A4\u17A8\u17ADot;\u6A00lus;\u6A01imes;\u6A02\u0271\u17B9\0\0\u17BEcup;\u6A06ar;\u6605riangle\u0100du\u17CD\u17D2own;\u65BDp;\u65B3plus;\u6A04e\xE5\u1444\xE5\u14ADarow;\u690D\u0180ako\u17ED\u1826\u1835\u0100cn\u17F2\u1823k\u0180lst\u17FA\u05AB\u1802ozenge;\u69EBriangle\u0200;dlr\u1812\u1813\u1818\u181D\u65B4own;\u65BEeft;\u65C2ight;\u65B8k;\u6423\u01B1\u182B\0\u1833\u01B2\u182F\0\u1831;\u6592;\u65914;\u6593ck;\u6588\u0100eo\u183E\u184D\u0100;q\u1843\u1846\uC000=\u20E5uiv;\uC000\u2261\u20E5t;\u6310\u0200ptwx\u1859\u185E\u1867\u186Cf;\uC000\u{1D553}\u0100;t\u13CB\u1863om\xBB\u13CCtie;\u62C8\u0600DHUVbdhmptuv\u1885\u1896\u18AA\u18BB\u18D7\u18DB\u18EC\u18FF\u1905\u190A\u1910\u1921\u0200LRlr\u188E\u1890\u1892\u1894;\u6557;\u6554;\u6556;\u6553\u0280;DUdu\u18A1\u18A2\u18A4\u18A6\u18A8\u6550;\u6566;\u6569;\u6564;\u6567\u0200LRlr\u18B3\u18B5\u18B7\u18B9;\u655D;\u655A;\u655C;\u6559\u0380;HLRhlr\u18CA\u18CB\u18CD\u18CF\u18D1\u18D3\u18D5\u6551;\u656C;\u6563;\u6560;\u656B;\u6562;\u655Fox;\u69C9\u0200LRlr\u18E4\u18E6\u18E8\u18EA;\u6555;\u6552;\u6510;\u650C\u0280;DUdu\u06BD\u18F7\u18F9\u18FB\u18FD;\u6565;\u6568;\u652C;\u6534inus;\u629Flus;\u629Eimes;\u62A0\u0200LRlr\u1919\u191B\u191D\u191F;\u655B;\u6558;\u6518;\u6514\u0380;HLRhlr\u1930\u1931\u1933\u1935\u1937\u1939\u193B\u6502;\u656A;\u6561;\u655E;\u653C;\u6524;\u651C\u0100ev\u0123\u1942bar\u803B\xA6\u40A6\u0200ceio\u1951\u1956\u195A\u1960r;\uC000\u{1D4B7}mi;\u604Fm\u0100;e\u171A\u171Cl\u0180;bh\u1968\u1969\u196B\u405C;\u69C5sub;\u67C8\u016C\u1974\u197El\u0100;e\u1979\u197A\u6022t\xBB\u197Ap\u0180;Ee\u012F\u1985\u1987;\u6AAE\u0100;q\u06DC\u06DB\u0CE1\u19A7\0\u19E8\u1A11\u1A15\u1A32\0\u1A37\u1A50\0\0\u1AB4\0\0\u1AC1\0\0\u1B21\u1B2E\u1B4D\u1B52\0\u1BFD\0\u1C0C\u0180cpr\u19AD\u19B2\u19DDute;\u4107\u0300;abcds\u19BF\u19C0\u19C4\u19CA\u19D5\u19D9\u6229nd;\u6A44rcup;\u6A49\u0100au\u19CF\u19D2p;\u6A4Bp;\u6A47ot;\u6A40;\uC000\u2229\uFE00\u0100eo\u19E2\u19E5t;\u6041\xEE\u0693\u0200aeiu\u19F0\u19FB\u1A01\u1A05\u01F0\u19F5\0\u19F8s;\u6A4Don;\u410Ddil\u803B\xE7\u40E7rc;\u4109ps\u0100;s\u1A0C\u1A0D\u6A4Cm;\u6A50ot;\u410B\u0180dmn\u1A1B\u1A20\u1A26il\u80BB\xB8\u01ADptyv;\u69B2t\u8100\xA2;e\u1A2D\u1A2E\u40A2r\xE4\u01B2r;\uC000\u{1D520}\u0180cei\u1A3D\u1A40\u1A4Dy;\u4447ck\u0100;m\u1A47\u1A48\u6713ark\xBB\u1A48;\u43C7r\u0380;Ecefms\u1A5F\u1A60\u1A62\u1A6B\u1AA4\u1AAA\u1AAE\u65CB;\u69C3\u0180;el\u1A69\u1A6A\u1A6D\u42C6q;\u6257e\u0261\u1A74\0\0\u1A88rrow\u0100lr\u1A7C\u1A81eft;\u61BAight;\u61BB\u0280RSacd\u1A92\u1A94\u1A96\u1A9A\u1A9F\xBB\u0F47;\u64C8st;\u629Birc;\u629Aash;\u629Dnint;\u6A10id;\u6AEFcir;\u69C2ubs\u0100;u\u1ABB\u1ABC\u6663it\xBB\u1ABC\u02EC\u1AC7\u1AD4\u1AFA\0\u1B0Aon\u0100;e\u1ACD\u1ACE\u403A\u0100;q\xC7\xC6\u026D\u1AD9\0\0\u1AE2a\u0100;t\u1ADE\u1ADF\u402C;\u4040\u0180;fl\u1AE8\u1AE9\u1AEB\u6201\xEE\u1160e\u0100mx\u1AF1\u1AF6ent\xBB\u1AE9e\xF3\u024D\u01E7\u1AFE\0\u1B07\u0100;d\u12BB\u1B02ot;\u6A6Dn\xF4\u0246\u0180fry\u1B10\u1B14\u1B17;\uC000\u{1D554}o\xE4\u0254\u8100\xA9;s\u0155\u1B1Dr;\u6117\u0100ao\u1B25\u1B29rr;\u61B5ss;\u6717\u0100cu\u1B32\u1B37r;\uC000\u{1D4B8}\u0100bp\u1B3C\u1B44\u0100;e\u1B41\u1B42\u6ACF;\u6AD1\u0100;e\u1B49\u1B4A\u6AD0;\u6AD2dot;\u62EF\u0380delprvw\u1B60\u1B6C\u1B77\u1B82\u1BAC\u1BD4\u1BF9arr\u0100lr\u1B68\u1B6A;\u6938;\u6935\u0270\u1B72\0\0\u1B75r;\u62DEc;\u62DFarr\u0100;p\u1B7F\u1B80\u61B6;\u693D\u0300;bcdos\u1B8F\u1B90\u1B96\u1BA1\u1BA5\u1BA8\u622Arcap;\u6A48\u0100au\u1B9B\u1B9Ep;\u6A46p;\u6A4Aot;\u628Dr;\u6A45;\uC000\u222A\uFE00\u0200alrv\u1BB5\u1BBF\u1BDE\u1BE3rr\u0100;m\u1BBC\u1BBD\u61B7;\u693Cy\u0180evw\u1BC7\u1BD4\u1BD8q\u0270\u1BCE\0\0\u1BD2re\xE3\u1B73u\xE3\u1B75ee;\u62CEedge;\u62CFen\u803B\xA4\u40A4earrow\u0100lr\u1BEE\u1BF3eft\xBB\u1B80ight\xBB\u1BBDe\xE4\u1BDD\u0100ci\u1C01\u1C07onin\xF4\u01F7nt;\u6231lcty;\u632D\u0980AHabcdefhijlorstuwz\u1C38\u1C3B\u1C3F\u1C5D\u1C69\u1C75\u1C8A\u1C9E\u1CAC\u1CB7\u1CFB\u1CFF\u1D0D\u1D7B\u1D91\u1DAB\u1DBB\u1DC6\u1DCDr\xF2\u0381ar;\u6965\u0200glrs\u1C48\u1C4D\u1C52\u1C54ger;\u6020eth;\u6138\xF2\u1133h\u0100;v\u1C5A\u1C5B\u6010\xBB\u090A\u016B\u1C61\u1C67arow;\u690Fa\xE3\u0315\u0100ay\u1C6E\u1C73ron;\u410F;\u4434\u0180;ao\u0332\u1C7C\u1C84\u0100gr\u02BF\u1C81r;\u61CAtseq;\u6A77\u0180glm\u1C91\u1C94\u1C98\u803B\xB0\u40B0ta;\u43B4ptyv;\u69B1\u0100ir\u1CA3\u1CA8sht;\u697F;\uC000\u{1D521}ar\u0100lr\u1CB3\u1CB5\xBB\u08DC\xBB\u101E\u0280aegsv\u1CC2\u0378\u1CD6\u1CDC\u1CE0m\u0180;os\u0326\u1CCA\u1CD4nd\u0100;s\u0326\u1CD1uit;\u6666amma;\u43DDin;\u62F2\u0180;io\u1CE7\u1CE8\u1CF8\u40F7de\u8100\xF7;o\u1CE7\u1CF0ntimes;\u62C7n\xF8\u1CF7cy;\u4452c\u026F\u1D06\0\0\u1D0Arn;\u631Eop;\u630D\u0280lptuw\u1D18\u1D1D\u1D22\u1D49\u1D55lar;\u4024f;\uC000\u{1D555}\u0280;emps\u030B\u1D2D\u1D37\u1D3D\u1D42q\u0100;d\u0352\u1D33ot;\u6251inus;\u6238lus;\u6214quare;\u62A1blebarwedg\xE5\xFAn\u0180adh\u112E\u1D5D\u1D67ownarrow\xF3\u1C83arpoon\u0100lr\u1D72\u1D76ef\xF4\u1CB4igh\xF4\u1CB6\u0162\u1D7F\u1D85karo\xF7\u0F42\u026F\u1D8A\0\0\u1D8Ern;\u631Fop;\u630C\u0180cot\u1D98\u1DA3\u1DA6\u0100ry\u1D9D\u1DA1;\uC000\u{1D4B9};\u4455l;\u69F6rok;\u4111\u0100dr\u1DB0\u1DB4ot;\u62F1i\u0100;f\u1DBA\u1816\u65BF\u0100ah\u1DC0\u1DC3r\xF2\u0429a\xF2\u0FA6angle;\u69A6\u0100ci\u1DD2\u1DD5y;\u445Fgrarr;\u67FF\u0900Dacdefglmnopqrstux\u1E01\u1E09\u1E19\u1E38\u0578\u1E3C\u1E49\u1E61\u1E7E\u1EA5\u1EAF\u1EBD\u1EE1\u1F2A\u1F37\u1F44\u1F4E\u1F5A\u0100Do\u1E06\u1D34o\xF4\u1C89\u0100cs\u1E0E\u1E14ute\u803B\xE9\u40E9ter;\u6A6E\u0200aioy\u1E22\u1E27\u1E31\u1E36ron;\u411Br\u0100;c\u1E2D\u1E2E\u6256\u803B\xEA\u40EAlon;\u6255;\u444Dot;\u4117\u0100Dr\u1E41\u1E45ot;\u6252;\uC000\u{1D522}\u0180;rs\u1E50\u1E51\u1E57\u6A9Aave\u803B\xE8\u40E8\u0100;d\u1E5C\u1E5D\u6A96ot;\u6A98\u0200;ils\u1E6A\u1E6B\u1E72\u1E74\u6A99nters;\u63E7;\u6113\u0100;d\u1E79\u1E7A\u6A95ot;\u6A97\u0180aps\u1E85\u1E89\u1E97cr;\u4113ty\u0180;sv\u1E92\u1E93\u1E95\u6205et\xBB\u1E93p\u01001;\u1E9D\u1EA4\u0133\u1EA1\u1EA3;\u6004;\u6005\u6003\u0100gs\u1EAA\u1EAC;\u414Bp;\u6002\u0100gp\u1EB4\u1EB8on;\u4119f;\uC000\u{1D556}\u0180als\u1EC4\u1ECE\u1ED2r\u0100;s\u1ECA\u1ECB\u62D5l;\u69E3us;\u6A71i\u0180;lv\u1EDA\u1EDB\u1EDF\u43B5on\xBB\u1EDB;\u43F5\u0200csuv\u1EEA\u1EF3\u1F0B\u1F23\u0100io\u1EEF\u1E31rc\xBB\u1E2E\u0269\u1EF9\0\0\u1EFB\xED\u0548ant\u0100gl\u1F02\u1F06tr\xBB\u1E5Dess\xBB\u1E7A\u0180aei\u1F12\u1F16\u1F1Als;\u403Dst;\u625Fv\u0100;D\u0235\u1F20D;\u6A78parsl;\u69E5\u0100Da\u1F2F\u1F33ot;\u6253rr;\u6971\u0180cdi\u1F3E\u1F41\u1EF8r;\u612Fo\xF4\u0352\u0100ah\u1F49\u1F4B;\u43B7\u803B\xF0\u40F0\u0100mr\u1F53\u1F57l\u803B\xEB\u40EBo;\u60AC\u0180cip\u1F61\u1F64\u1F67l;\u4021s\xF4\u056E\u0100eo\u1F6C\u1F74ctatio\xEE\u0559nential\xE5\u0579\u09E1\u1F92\0\u1F9E\0\u1FA1\u1FA7\0\0\u1FC6\u1FCC\0\u1FD3\0\u1FE6\u1FEA\u2000\0\u2008\u205Allingdotse\xF1\u1E44y;\u4444male;\u6640\u0180ilr\u1FAD\u1FB3\u1FC1lig;\u8000\uFB03\u0269\u1FB9\0\0\u1FBDg;\u8000\uFB00ig;\u8000\uFB04;\uC000\u{1D523}lig;\u8000\uFB01lig;\uC000fj\u0180alt\u1FD9\u1FDC\u1FE1t;\u666Dig;\u8000\uFB02ns;\u65B1of;\u4192\u01F0\u1FEE\0\u1FF3f;\uC000\u{1D557}\u0100ak\u05BF\u1FF7\u0100;v\u1FFC\u1FFD\u62D4;\u6AD9artint;\u6A0D\u0100ao\u200C\u2055\u0100cs\u2011\u2052\u03B1\u201A\u2030\u2038\u2045\u2048\0\u2050\u03B2\u2022\u2025\u2027\u202A\u202C\0\u202E\u803B\xBD\u40BD;\u6153\u803B\xBC\u40BC;\u6155;\u6159;\u615B\u01B3\u2034\0\u2036;\u6154;\u6156\u02B4\u203E\u2041\0\0\u2043\u803B\xBE\u40BE;\u6157;\u615C5;\u6158\u01B6\u204C\0\u204E;\u615A;\u615D8;\u615El;\u6044wn;\u6322cr;\uC000\u{1D4BB}\u0880Eabcdefgijlnorstv\u2082\u2089\u209F\u20A5\u20B0\u20B4\u20F0\u20F5\u20FA\u20FF\u2103\u2112\u2138\u0317\u213E\u2152\u219E\u0100;l\u064D\u2087;\u6A8C\u0180cmp\u2090\u2095\u209Dute;\u41F5ma\u0100;d\u209C\u1CDA\u43B3;\u6A86reve;\u411F\u0100iy\u20AA\u20AErc;\u411D;\u4433ot;\u4121\u0200;lqs\u063E\u0642\u20BD\u20C9\u0180;qs\u063E\u064C\u20C4lan\xF4\u0665\u0200;cdl\u0665\u20D2\u20D5\u20E5c;\u6AA9ot\u0100;o\u20DC\u20DD\u6A80\u0100;l\u20E2\u20E3\u6A82;\u6A84\u0100;e\u20EA\u20ED\uC000\u22DB\uFE00s;\u6A94r;\uC000\u{1D524}\u0100;g\u0673\u061Bmel;\u6137cy;\u4453\u0200;Eaj\u065A\u210C\u210E\u2110;\u6A92;\u6AA5;\u6AA4\u0200Eaes\u211B\u211D\u2129\u2134;\u6269p\u0100;p\u2123\u2124\u6A8Arox\xBB\u2124\u0100;q\u212E\u212F\u6A88\u0100;q\u212E\u211Bim;\u62E7pf;\uC000\u{1D558}\u0100ci\u2143\u2146r;\u610Am\u0180;el\u066B\u214E\u2150;\u6A8E;\u6A90\u8300>;cdlqr\u05EE\u2160\u216A\u216E\u2173\u2179\u0100ci\u2165\u2167;\u6AA7r;\u6A7Aot;\u62D7Par;\u6995uest;\u6A7C\u0280adels\u2184\u216A\u2190\u0656\u219B\u01F0\u2189\0\u218Epro\xF8\u209Er;\u6978q\u0100lq\u063F\u2196les\xF3\u2088i\xED\u066B\u0100en\u21A3\u21ADrtneqq;\uC000\u2269\uFE00\xC5\u21AA\u0500Aabcefkosy\u21C4\u21C7\u21F1\u21F5\u21FA\u2218\u221D\u222F\u2268\u227Dr\xF2\u03A0\u0200ilmr\u21D0\u21D4\u21D7\u21DBrs\xF0\u1484f\xBB\u2024il\xF4\u06A9\u0100dr\u21E0\u21E4cy;\u444A\u0180;cw\u08F4\u21EB\u21EFir;\u6948;\u61ADar;\u610Firc;\u4125\u0180alr\u2201\u220E\u2213rts\u0100;u\u2209\u220A\u6665it\xBB\u220Alip;\u6026con;\u62B9r;\uC000\u{1D525}s\u0100ew\u2223\u2229arow;\u6925arow;\u6926\u0280amopr\u223A\u223E\u2243\u225E\u2263rr;\u61FFtht;\u623Bk\u0100lr\u2249\u2253eftarrow;\u61A9ightarrow;\u61AAf;\uC000\u{1D559}bar;\u6015\u0180clt\u226F\u2274\u2278r;\uC000\u{1D4BD}as\xE8\u21F4rok;\u4127\u0100bp\u2282\u2287ull;\u6043hen\xBB\u1C5B\u0AE1\u22A3\0\u22AA\0\u22B8\u22C5\u22CE\0\u22D5\u22F3\0\0\u22F8\u2322\u2367\u2362\u237F\0\u2386\u23AA\u23B4cute\u803B\xED\u40ED\u0180;iy\u0771\u22B0\u22B5rc\u803B\xEE\u40EE;\u4438\u0100cx\u22BC\u22BFy;\u4435cl\u803B\xA1\u40A1\u0100fr\u039F\u22C9;\uC000\u{1D526}rave\u803B\xEC\u40EC\u0200;ino\u073E\u22DD\u22E9\u22EE\u0100in\u22E2\u22E6nt;\u6A0Ct;\u622Dfin;\u69DCta;\u6129lig;\u4133\u0180aop\u22FE\u231A\u231D\u0180cgt\u2305\u2308\u2317r;\u412B\u0180elp\u071F\u230F\u2313in\xE5\u078Ear\xF4\u0720h;\u4131f;\u62B7ed;\u41B5\u0280;cfot\u04F4\u232C\u2331\u233D\u2341are;\u6105in\u0100;t\u2338\u2339\u621Eie;\u69DDdo\xF4\u2319\u0280;celp\u0757\u234C\u2350\u235B\u2361al;\u62BA\u0100gr\u2355\u2359er\xF3\u1563\xE3\u234Darhk;\u6A17rod;\u6A3C\u0200cgpt\u236F\u2372\u2376\u237By;\u4451on;\u412Ff;\uC000\u{1D55A}a;\u43B9uest\u803B\xBF\u40BF\u0100ci\u238A\u238Fr;\uC000\u{1D4BE}n\u0280;Edsv\u04F4\u239B\u239D\u23A1\u04F3;\u62F9ot;\u62F5\u0100;v\u23A6\u23A7\u62F4;\u62F3\u0100;i\u0777\u23AElde;\u4129\u01EB\u23B8\0\u23BCcy;\u4456l\u803B\xEF\u40EF\u0300cfmosu\u23CC\u23D7\u23DC\u23E1\u23E7\u23F5\u0100iy\u23D1\u23D5rc;\u4135;\u4439r;\uC000\u{1D527}ath;\u4237pf;\uC000\u{1D55B}\u01E3\u23EC\0\u23F1r;\uC000\u{1D4BF}rcy;\u4458kcy;\u4454\u0400acfghjos\u240B\u2416\u2422\u2427\u242D\u2431\u2435\u243Bppa\u0100;v\u2413\u2414\u43BA;\u43F0\u0100ey\u241B\u2420dil;\u4137;\u443Ar;\uC000\u{1D528}reen;\u4138cy;\u4445cy;\u445Cpf;\uC000\u{1D55C}cr;\uC000\u{1D4C0}\u0B80ABEHabcdefghjlmnoprstuv\u2470\u2481\u2486\u248D\u2491\u250E\u253D\u255A\u2580\u264E\u265E\u2665\u2679\u267D\u269A\u26B2\u26D8\u275D\u2768\u278B\u27C0\u2801\u2812\u0180art\u2477\u247A\u247Cr\xF2\u09C6\xF2\u0395ail;\u691Barr;\u690E\u0100;g\u0994\u248B;\u6A8Bar;\u6962\u0963\u24A5\0\u24AA\0\u24B1\0\0\0\0\0\u24B5\u24BA\0\u24C6\u24C8\u24CD\0\u24F9ute;\u413Amptyv;\u69B4ra\xEE\u084Cbda;\u43BBg\u0180;dl\u088E\u24C1\u24C3;\u6991\xE5\u088E;\u6A85uo\u803B\xAB\u40ABr\u0400;bfhlpst\u0899\u24DE\u24E6\u24E9\u24EB\u24EE\u24F1\u24F5\u0100;f\u089D\u24E3s;\u691Fs;\u691D\xEB\u2252p;\u61ABl;\u6939im;\u6973l;\u61A2\u0180;ae\u24FF\u2500\u2504\u6AABil;\u6919\u0100;s\u2509\u250A\u6AAD;\uC000\u2AAD\uFE00\u0180abr\u2515\u2519\u251Drr;\u690Crk;\u6772\u0100ak\u2522\u252Cc\u0100ek\u2528\u252A;\u407B;\u405B\u0100es\u2531\u2533;\u698Bl\u0100du\u2539\u253B;\u698F;\u698D\u0200aeuy\u2546\u254B\u2556\u2558ron;\u413E\u0100di\u2550\u2554il;\u413C\xEC\u08B0\xE2\u2529;\u443B\u0200cqrs\u2563\u2566\u256D\u257Da;\u6936uo\u0100;r\u0E19\u1746\u0100du\u2572\u2577har;\u6967shar;\u694Bh;\u61B2\u0280;fgqs\u258B\u258C\u0989\u25F3\u25FF\u6264t\u0280ahlrt\u2598\u25A4\u25B7\u25C2\u25E8rrow\u0100;t\u0899\u25A1a\xE9\u24F6arpoon\u0100du\u25AF\u25B4own\xBB\u045Ap\xBB\u0966eftarrows;\u61C7ight\u0180ahs\u25CD\u25D6\u25DErrow\u0100;s\u08F4\u08A7arpoon\xF3\u0F98quigarro\xF7\u21F0hreetimes;\u62CB\u0180;qs\u258B\u0993\u25FAlan\xF4\u09AC\u0280;cdgs\u09AC\u260A\u260D\u261D\u2628c;\u6AA8ot\u0100;o\u2614\u2615\u6A7F\u0100;r\u261A\u261B\u6A81;\u6A83\u0100;e\u2622\u2625\uC000\u22DA\uFE00s;\u6A93\u0280adegs\u2633\u2639\u263D\u2649\u264Bppro\xF8\u24C6ot;\u62D6q\u0100gq\u2643\u2645\xF4\u0989gt\xF2\u248C\xF4\u099Bi\xED\u09B2\u0180ilr\u2655\u08E1\u265Asht;\u697C;\uC000\u{1D529}\u0100;E\u099C\u2663;\u6A91\u0161\u2669\u2676r\u0100du\u25B2\u266E\u0100;l\u0965\u2673;\u696Alk;\u6584cy;\u4459\u0280;acht\u0A48\u2688\u268B\u2691\u2696r\xF2\u25C1orne\xF2\u1D08ard;\u696Bri;\u65FA\u0100io\u269F\u26A4dot;\u4140ust\u0100;a\u26AC\u26AD\u63B0che\xBB\u26AD\u0200Eaes\u26BB\u26BD\u26C9\u26D4;\u6268p\u0100;p\u26C3\u26C4\u6A89rox\xBB\u26C4\u0100;q\u26CE\u26CF\u6A87\u0100;q\u26CE\u26BBim;\u62E6\u0400abnoptwz\u26E9\u26F4\u26F7\u271A\u272F\u2741\u2747\u2750\u0100nr\u26EE\u26F1g;\u67ECr;\u61FDr\xEB\u08C1g\u0180lmr\u26FF\u270D\u2714eft\u0100ar\u09E6\u2707ight\xE1\u09F2apsto;\u67FCight\xE1\u09FDparrow\u0100lr\u2725\u2729ef\xF4\u24EDight;\u61AC\u0180afl\u2736\u2739\u273Dr;\u6985;\uC000\u{1D55D}us;\u6A2Dimes;\u6A34\u0161\u274B\u274Fst;\u6217\xE1\u134E\u0180;ef\u2757\u2758\u1800\u65CAnge\xBB\u2758ar\u0100;l\u2764\u2765\u4028t;\u6993\u0280achmt\u2773\u2776\u277C\u2785\u2787r\xF2\u08A8orne\xF2\u1D8Car\u0100;d\u0F98\u2783;\u696D;\u600Eri;\u62BF\u0300achiqt\u2798\u279D\u0A40\u27A2\u27AE\u27BBquo;\u6039r;\uC000\u{1D4C1}m\u0180;eg\u09B2\u27AA\u27AC;\u6A8D;\u6A8F\u0100bu\u252A\u27B3o\u0100;r\u0E1F\u27B9;\u601Arok;\u4142\u8400<;cdhilqr\u082B\u27D2\u2639\u27DC\u27E0\u27E5\u27EA\u27F0\u0100ci\u27D7\u27D9;\u6AA6r;\u6A79re\xE5\u25F2mes;\u62C9arr;\u6976uest;\u6A7B\u0100Pi\u27F5\u27F9ar;\u6996\u0180;ef\u2800\u092D\u181B\u65C3r\u0100du\u2807\u280Dshar;\u694Ahar;\u6966\u0100en\u2817\u2821rtneqq;\uC000\u2268\uFE00\xC5\u281E\u0700Dacdefhilnopsu\u2840\u2845\u2882\u288E\u2893\u28A0\u28A5\u28A8\u28DA\u28E2\u28E4\u0A83\u28F3\u2902Dot;\u623A\u0200clpr\u284E\u2852\u2863\u287Dr\u803B\xAF\u40AF\u0100et\u2857\u2859;\u6642\u0100;e\u285E\u285F\u6720se\xBB\u285F\u0100;s\u103B\u2868to\u0200;dlu\u103B\u2873\u2877\u287Bow\xEE\u048Cef\xF4\u090F\xF0\u13D1ker;\u65AE\u0100oy\u2887\u288Cmma;\u6A29;\u443Cash;\u6014asuredangle\xBB\u1626r;\uC000\u{1D52A}o;\u6127\u0180cdn\u28AF\u28B4\u28C9ro\u803B\xB5\u40B5\u0200;acd\u1464\u28BD\u28C0\u28C4s\xF4\u16A7ir;\u6AF0ot\u80BB\xB7\u01B5us\u0180;bd\u28D2\u1903\u28D3\u6212\u0100;u\u1D3C\u28D8;\u6A2A\u0163\u28DE\u28E1p;\u6ADB\xF2\u2212\xF0\u0A81\u0100dp\u28E9\u28EEels;\u62A7f;\uC000\u{1D55E}\u0100ct\u28F8\u28FDr;\uC000\u{1D4C2}pos\xBB\u159D\u0180;lm\u2909\u290A\u290D\u43BCtimap;\u62B8\u0C00GLRVabcdefghijlmoprstuvw\u2942\u2953\u297E\u2989\u2998\u29DA\u29E9\u2A15\u2A1A\u2A58\u2A5D\u2A83\u2A95\u2AA4\u2AA8\u2B04\u2B07\u2B44\u2B7F\u2BAE\u2C34\u2C67\u2C7C\u2CE9\u0100gt\u2947\u294B;\uC000\u22D9\u0338\u0100;v\u2950\u0BCF\uC000\u226B\u20D2\u0180elt\u295A\u2972\u2976ft\u0100ar\u2961\u2967rrow;\u61CDightarrow;\u61CE;\uC000\u22D8\u0338\u0100;v\u297B\u0C47\uC000\u226A\u20D2ightarrow;\u61CF\u0100Dd\u298E\u2993ash;\u62AFash;\u62AE\u0280bcnpt\u29A3\u29A7\u29AC\u29B1\u29CCla\xBB\u02DEute;\u4144g;\uC000\u2220\u20D2\u0280;Eiop\u0D84\u29BC\u29C0\u29C5\u29C8;\uC000\u2A70\u0338d;\uC000\u224B\u0338s;\u4149ro\xF8\u0D84ur\u0100;a\u29D3\u29D4\u666El\u0100;s\u29D3\u0B38\u01F3\u29DF\0\u29E3p\u80BB\xA0\u0B37mp\u0100;e\u0BF9\u0C00\u0280aeouy\u29F4\u29FE\u2A03\u2A10\u2A13\u01F0\u29F9\0\u29FB;\u6A43on;\u4148dil;\u4146ng\u0100;d\u0D7E\u2A0Aot;\uC000\u2A6D\u0338p;\u6A42;\u443Dash;\u6013\u0380;Aadqsx\u0B92\u2A29\u2A2D\u2A3B\u2A41\u2A45\u2A50rr;\u61D7r\u0100hr\u2A33\u2A36k;\u6924\u0100;o\u13F2\u13F0ot;\uC000\u2250\u0338ui\xF6\u0B63\u0100ei\u2A4A\u2A4Ear;\u6928\xED\u0B98ist\u0100;s\u0BA0\u0B9Fr;\uC000\u{1D52B}\u0200Eest\u0BC5\u2A66\u2A79\u2A7C\u0180;qs\u0BBC\u2A6D\u0BE1\u0180;qs\u0BBC\u0BC5\u2A74lan\xF4\u0BE2i\xED\u0BEA\u0100;r\u0BB6\u2A81\xBB\u0BB7\u0180Aap\u2A8A\u2A8D\u2A91r\xF2\u2971rr;\u61AEar;\u6AF2\u0180;sv\u0F8D\u2A9C\u0F8C\u0100;d\u2AA1\u2AA2\u62FC;\u62FAcy;\u445A\u0380AEadest\u2AB7\u2ABA\u2ABE\u2AC2\u2AC5\u2AF6\u2AF9r\xF2\u2966;\uC000\u2266\u0338rr;\u619Ar;\u6025\u0200;fqs\u0C3B\u2ACE\u2AE3\u2AEFt\u0100ar\u2AD4\u2AD9rro\xF7\u2AC1ightarro\xF7\u2A90\u0180;qs\u0C3B\u2ABA\u2AEAlan\xF4\u0C55\u0100;s\u0C55\u2AF4\xBB\u0C36i\xED\u0C5D\u0100;r\u0C35\u2AFEi\u0100;e\u0C1A\u0C25i\xE4\u0D90\u0100pt\u2B0C\u2B11f;\uC000\u{1D55F}\u8180\xAC;in\u2B19\u2B1A\u2B36\u40ACn\u0200;Edv\u0B89\u2B24\u2B28\u2B2E;\uC000\u22F9\u0338ot;\uC000\u22F5\u0338\u01E1\u0B89\u2B33\u2B35;\u62F7;\u62F6i\u0100;v\u0CB8\u2B3C\u01E1\u0CB8\u2B41\u2B43;\u62FE;\u62FD\u0180aor\u2B4B\u2B63\u2B69r\u0200;ast\u0B7B\u2B55\u2B5A\u2B5Flle\xEC\u0B7Bl;\uC000\u2AFD\u20E5;\uC000\u2202\u0338lint;\u6A14\u0180;ce\u0C92\u2B70\u2B73u\xE5\u0CA5\u0100;c\u0C98\u2B78\u0100;e\u0C92\u2B7D\xF1\u0C98\u0200Aait\u2B88\u2B8B\u2B9D\u2BA7r\xF2\u2988rr\u0180;cw\u2B94\u2B95\u2B99\u619B;\uC000\u2933\u0338;\uC000\u219D\u0338ghtarrow\xBB\u2B95ri\u0100;e\u0CCB\u0CD6\u0380chimpqu\u2BBD\u2BCD\u2BD9\u2B04\u0B78\u2BE4\u2BEF\u0200;cer\u0D32\u2BC6\u0D37\u2BC9u\xE5\u0D45;\uC000\u{1D4C3}ort\u026D\u2B05\0\0\u2BD6ar\xE1\u2B56m\u0100;e\u0D6E\u2BDF\u0100;q\u0D74\u0D73su\u0100bp\u2BEB\u2BED\xE5\u0CF8\xE5\u0D0B\u0180bcp\u2BF6\u2C11\u2C19\u0200;Ees\u2BFF\u2C00\u0D22\u2C04\u6284;\uC000\u2AC5\u0338et\u0100;e\u0D1B\u2C0Bq\u0100;q\u0D23\u2C00c\u0100;e\u0D32\u2C17\xF1\u0D38\u0200;Ees\u2C22\u2C23\u0D5F\u2C27\u6285;\uC000\u2AC6\u0338et\u0100;e\u0D58\u2C2Eq\u0100;q\u0D60\u2C23\u0200gilr\u2C3D\u2C3F\u2C45\u2C47\xEC\u0BD7lde\u803B\xF1\u40F1\xE7\u0C43iangle\u0100lr\u2C52\u2C5Ceft\u0100;e\u0C1A\u2C5A\xF1\u0C26ight\u0100;e\u0CCB\u2C65\xF1\u0CD7\u0100;m\u2C6C\u2C6D\u43BD\u0180;es\u2C74\u2C75\u2C79\u4023ro;\u6116p;\u6007\u0480DHadgilrs\u2C8F\u2C94\u2C99\u2C9E\u2CA3\u2CB0\u2CB6\u2CD3\u2CE3ash;\u62ADarr;\u6904p;\uC000\u224D\u20D2ash;\u62AC\u0100et\u2CA8\u2CAC;\uC000\u2265\u20D2;\uC000>\u20D2nfin;\u69DE\u0180Aet\u2CBD\u2CC1\u2CC5rr;\u6902;\uC000\u2264\u20D2\u0100;r\u2CCA\u2CCD\uC000<\u20D2ie;\uC000\u22B4\u20D2\u0100At\u2CD8\u2CDCrr;\u6903rie;\uC000\u22B5\u20D2im;\uC000\u223C\u20D2\u0180Aan\u2CF0\u2CF4\u2D02rr;\u61D6r\u0100hr\u2CFA\u2CFDk;\u6923\u0100;o\u13E7\u13E5ear;\u6927\u1253\u1A95\0\0\0\0\0\0\0\0\0\0\0\0\0\u2D2D\0\u2D38\u2D48\u2D60\u2D65\u2D72\u2D84\u1B07\0\0\u2D8D\u2DAB\0\u2DC8\u2DCE\0\u2DDC\u2E19\u2E2B\u2E3E\u2E43\u0100cs\u2D31\u1A97ute\u803B\xF3\u40F3\u0100iy\u2D3C\u2D45r\u0100;c\u1A9E\u2D42\u803B\xF4\u40F4;\u443E\u0280abios\u1AA0\u2D52\u2D57\u01C8\u2D5Alac;\u4151v;\u6A38old;\u69BClig;\u4153\u0100cr\u2D69\u2D6Dir;\u69BF;\uC000\u{1D52C}\u036F\u2D79\0\0\u2D7C\0\u2D82n;\u42DBave\u803B\xF2\u40F2;\u69C1\u0100bm\u2D88\u0DF4ar;\u69B5\u0200acit\u2D95\u2D98\u2DA5\u2DA8r\xF2\u1A80\u0100ir\u2D9D\u2DA0r;\u69BEoss;\u69BBn\xE5\u0E52;\u69C0\u0180aei\u2DB1\u2DB5\u2DB9cr;\u414Dga;\u43C9\u0180cdn\u2DC0\u2DC5\u01CDron;\u43BF;\u69B6pf;\uC000\u{1D560}\u0180ael\u2DD4\u2DD7\u01D2r;\u69B7rp;\u69B9\u0380;adiosv\u2DEA\u2DEB\u2DEE\u2E08\u2E0D\u2E10\u2E16\u6228r\xF2\u1A86\u0200;efm\u2DF7\u2DF8\u2E02\u2E05\u6A5Dr\u0100;o\u2DFE\u2DFF\u6134f\xBB\u2DFF\u803B\xAA\u40AA\u803B\xBA\u40BAgof;\u62B6r;\u6A56lope;\u6A57;\u6A5B\u0180clo\u2E1F\u2E21\u2E27\xF2\u2E01ash\u803B\xF8\u40F8l;\u6298i\u016C\u2E2F\u2E34de\u803B\xF5\u40F5es\u0100;a\u01DB\u2E3As;\u6A36ml\u803B\xF6\u40F6bar;\u633D\u0AE1\u2E5E\0\u2E7D\0\u2E80\u2E9D\0\u2EA2\u2EB9\0\0\u2ECB\u0E9C\0\u2F13\0\0\u2F2B\u2FBC\0\u2FC8r\u0200;ast\u0403\u2E67\u2E72\u0E85\u8100\xB6;l\u2E6D\u2E6E\u40B6le\xEC\u0403\u0269\u2E78\0\0\u2E7Bm;\u6AF3;\u6AFDy;\u443Fr\u0280cimpt\u2E8B\u2E8F\u2E93\u1865\u2E97nt;\u4025od;\u402Eil;\u6030enk;\u6031r;\uC000\u{1D52D}\u0180imo\u2EA8\u2EB0\u2EB4\u0100;v\u2EAD\u2EAE\u43C6;\u43D5ma\xF4\u0A76ne;\u660E\u0180;tv\u2EBF\u2EC0\u2EC8\u43C0chfork\xBB\u1FFD;\u43D6\u0100au\u2ECF\u2EDFn\u0100ck\u2ED5\u2EDDk\u0100;h\u21F4\u2EDB;\u610E\xF6\u21F4s\u0480;abcdemst\u2EF3\u2EF4\u1908\u2EF9\u2EFD\u2F04\u2F06\u2F0A\u2F0E\u402Bcir;\u6A23ir;\u6A22\u0100ou\u1D40\u2F02;\u6A25;\u6A72n\u80BB\xB1\u0E9Dim;\u6A26wo;\u6A27\u0180ipu\u2F19\u2F20\u2F25ntint;\u6A15f;\uC000\u{1D561}nd\u803B\xA3\u40A3\u0500;Eaceinosu\u0EC8\u2F3F\u2F41\u2F44\u2F47\u2F81\u2F89\u2F92\u2F7E\u2FB6;\u6AB3p;\u6AB7u\xE5\u0ED9\u0100;c\u0ECE\u2F4C\u0300;acens\u0EC8\u2F59\u2F5F\u2F66\u2F68\u2F7Eppro\xF8\u2F43urlye\xF1\u0ED9\xF1\u0ECE\u0180aes\u2F6F\u2F76\u2F7Approx;\u6AB9qq;\u6AB5im;\u62E8i\xED\u0EDFme\u0100;s\u2F88\u0EAE\u6032\u0180Eas\u2F78\u2F90\u2F7A\xF0\u2F75\u0180dfp\u0EEC\u2F99\u2FAF\u0180als\u2FA0\u2FA5\u2FAAlar;\u632Eine;\u6312urf;\u6313\u0100;t\u0EFB\u2FB4\xEF\u0EFBrel;\u62B0\u0100ci\u2FC0\u2FC5r;\uC000\u{1D4C5};\u43C8ncsp;\u6008\u0300fiopsu\u2FDA\u22E2\u2FDF\u2FE5\u2FEB\u2FF1r;\uC000\u{1D52E}pf;\uC000\u{1D562}rime;\u6057cr;\uC000\u{1D4C6}\u0180aeo\u2FF8\u3009\u3013t\u0100ei\u2FFE\u3005rnion\xF3\u06B0nt;\u6A16st\u0100;e\u3010\u3011\u403F\xF1\u1F19\xF4\u0F14\u0A80ABHabcdefhilmnoprstux\u3040\u3051\u3055\u3059\u30E0\u310E\u312B\u3147\u3162\u3172\u318E\u3206\u3215\u3224\u3229\u3258\u326E\u3272\u3290\u32B0\u32B7\u0180art\u3047\u304A\u304Cr\xF2\u10B3\xF2\u03DDail;\u691Car\xF2\u1C65ar;\u6964\u0380cdenqrt\u3068\u3075\u3078\u307F\u308F\u3094\u30CC\u0100eu\u306D\u3071;\uC000\u223D\u0331te;\u4155i\xE3\u116Emptyv;\u69B3g\u0200;del\u0FD1\u3089\u308B\u308D;\u6992;\u69A5\xE5\u0FD1uo\u803B\xBB\u40BBr\u0580;abcfhlpstw\u0FDC\u30AC\u30AF\u30B7\u30B9\u30BC\u30BE\u30C0\u30C3\u30C7\u30CAp;\u6975\u0100;f\u0FE0\u30B4s;\u6920;\u6933s;\u691E\xEB\u225D\xF0\u272El;\u6945im;\u6974l;\u61A3;\u619D\u0100ai\u30D1\u30D5il;\u691Ao\u0100;n\u30DB\u30DC\u6236al\xF3\u0F1E\u0180abr\u30E7\u30EA\u30EEr\xF2\u17E5rk;\u6773\u0100ak\u30F3\u30FDc\u0100ek\u30F9\u30FB;\u407D;\u405D\u0100es\u3102\u3104;\u698Cl\u0100du\u310A\u310C;\u698E;\u6990\u0200aeuy\u3117\u311C\u3127\u3129ron;\u4159\u0100di\u3121\u3125il;\u4157\xEC\u0FF2\xE2\u30FA;\u4440\u0200clqs\u3134\u3137\u313D\u3144a;\u6937dhar;\u6969uo\u0100;r\u020E\u020Dh;\u61B3\u0180acg\u314E\u315F\u0F44l\u0200;ips\u0F78\u3158\u315B\u109Cn\xE5\u10BBar\xF4\u0FA9t;\u65AD\u0180ilr\u3169\u1023\u316Esht;\u697D;\uC000\u{1D52F}\u0100ao\u3177\u3186r\u0100du\u317D\u317F\xBB\u047B\u0100;l\u1091\u3184;\u696C\u0100;v\u318B\u318C\u43C1;\u43F1\u0180gns\u3195\u31F9\u31FCht\u0300ahlrst\u31A4\u31B0\u31C2\u31D8\u31E4\u31EErrow\u0100;t\u0FDC\u31ADa\xE9\u30C8arpoon\u0100du\u31BB\u31BFow\xEE\u317Ep\xBB\u1092eft\u0100ah\u31CA\u31D0rrow\xF3\u0FEAarpoon\xF3\u0551ightarrows;\u61C9quigarro\xF7\u30CBhreetimes;\u62CCg;\u42DAingdotse\xF1\u1F32\u0180ahm\u320D\u3210\u3213r\xF2\u0FEAa\xF2\u0551;\u600Foust\u0100;a\u321E\u321F\u63B1che\xBB\u321Fmid;\u6AEE\u0200abpt\u3232\u323D\u3240\u3252\u0100nr\u3237\u323Ag;\u67EDr;\u61FEr\xEB\u1003\u0180afl\u3247\u324A\u324Er;\u6986;\uC000\u{1D563}us;\u6A2Eimes;\u6A35\u0100ap\u325D\u3267r\u0100;g\u3263\u3264\u4029t;\u6994olint;\u6A12ar\xF2\u31E3\u0200achq\u327B\u3280\u10BC\u3285quo;\u603Ar;\uC000\u{1D4C7}\u0100bu\u30FB\u328Ao\u0100;r\u0214\u0213\u0180hir\u3297\u329B\u32A0re\xE5\u31F8mes;\u62CAi\u0200;efl\u32AA\u1059\u1821\u32AB\u65B9tri;\u69CEluhar;\u6968;\u611E\u0D61\u32D5\u32DB\u32DF\u332C\u3338\u3371\0\u337A\u33A4\0\0\u33EC\u33F0\0\u3428\u3448\u345A\u34AD\u34B1\u34CA\u34F1\0\u3616\0\0\u3633cute;\u415Bqu\xEF\u27BA\u0500;Eaceinpsy\u11ED\u32F3\u32F5\u32FF\u3302\u330B\u330F\u331F\u3326\u3329;\u6AB4\u01F0\u32FA\0\u32FC;\u6AB8on;\u4161u\xE5\u11FE\u0100;d\u11F3\u3307il;\u415Frc;\u415D\u0180Eas\u3316\u3318\u331B;\u6AB6p;\u6ABAim;\u62E9olint;\u6A13i\xED\u1204;\u4441ot\u0180;be\u3334\u1D47\u3335\u62C5;\u6A66\u0380Aacmstx\u3346\u334A\u3357\u335B\u335E\u3363\u336Drr;\u61D8r\u0100hr\u3350\u3352\xEB\u2228\u0100;o\u0A36\u0A34t\u803B\xA7\u40A7i;\u403Bwar;\u6929m\u0100in\u3369\xF0nu\xF3\xF1t;\u6736r\u0100;o\u3376\u2055\uC000\u{1D530}\u0200acoy\u3382\u3386\u3391\u33A0rp;\u666F\u0100hy\u338B\u338Fcy;\u4449;\u4448rt\u026D\u3399\0\0\u339Ci\xE4\u1464ara\xEC\u2E6F\u803B\xAD\u40AD\u0100gm\u33A8\u33B4ma\u0180;fv\u33B1\u33B2\u33B2\u43C3;\u43C2\u0400;deglnpr\u12AB\u33C5\u33C9\u33CE\u33D6\u33DE\u33E1\u33E6ot;\u6A6A\u0100;q\u12B1\u12B0\u0100;E\u33D3\u33D4\u6A9E;\u6AA0\u0100;E\u33DB\u33DC\u6A9D;\u6A9Fe;\u6246lus;\u6A24arr;\u6972ar\xF2\u113D\u0200aeit\u33F8\u3408\u340F\u3417\u0100ls\u33FD\u3404lsetm\xE9\u336Ahp;\u6A33parsl;\u69E4\u0100dl\u1463\u3414e;\u6323\u0100;e\u341C\u341D\u6AAA\u0100;s\u3422\u3423\u6AAC;\uC000\u2AAC\uFE00\u0180flp\u342E\u3433\u3442tcy;\u444C\u0100;b\u3438\u3439\u402F\u0100;a\u343E\u343F\u69C4r;\u633Ff;\uC000\u{1D564}a\u0100dr\u344D\u0402es\u0100;u\u3454\u3455\u6660it\xBB\u3455\u0180csu\u3460\u3479\u349F\u0100au\u3465\u346Fp\u0100;s\u1188\u346B;\uC000\u2293\uFE00p\u0100;s\u11B4\u3475;\uC000\u2294\uFE00u\u0100bp\u347F\u348F\u0180;es\u1197\u119C\u3486et\u0100;e\u1197\u348D\xF1\u119D\u0180;es\u11A8\u11AD\u3496et\u0100;e\u11A8\u349D\xF1\u11AE\u0180;af\u117B\u34A6\u05B0r\u0165\u34AB\u05B1\xBB\u117Car\xF2\u1148\u0200cemt\u34B9\u34BE\u34C2\u34C5r;\uC000\u{1D4C8}tm\xEE\xF1i\xEC\u3415ar\xE6\u11BE\u0100ar\u34CE\u34D5r\u0100;f\u34D4\u17BF\u6606\u0100an\u34DA\u34EDight\u0100ep\u34E3\u34EApsilo\xEE\u1EE0h\xE9\u2EAFs\xBB\u2852\u0280bcmnp\u34FB\u355E\u1209\u358B\u358E\u0480;Edemnprs\u350E\u350F\u3511\u3515\u351E\u3523\u352C\u3531\u3536\u6282;\u6AC5ot;\u6ABD\u0100;d\u11DA\u351Aot;\u6AC3ult;\u6AC1\u0100Ee\u3528\u352A;\u6ACB;\u628Alus;\u6ABFarr;\u6979\u0180eiu\u353D\u3552\u3555t\u0180;en\u350E\u3545\u354Bq\u0100;q\u11DA\u350Feq\u0100;q\u352B\u3528m;\u6AC7\u0100bp\u355A\u355C;\u6AD5;\u6AD3c\u0300;acens\u11ED\u356C\u3572\u3579\u357B\u3326ppro\xF8\u32FAurlye\xF1\u11FE\xF1\u11F3\u0180aes\u3582\u3588\u331Bppro\xF8\u331Aq\xF1\u3317g;\u666A\u0680123;Edehlmnps\u35A9\u35AC\u35AF\u121C\u35B2\u35B4\u35C0\u35C9\u35D5\u35DA\u35DF\u35E8\u35ED\u803B\xB9\u40B9\u803B\xB2\u40B2\u803B\xB3\u40B3;\u6AC6\u0100os\u35B9\u35BCt;\u6ABEub;\u6AD8\u0100;d\u1222\u35C5ot;\u6AC4s\u0100ou\u35CF\u35D2l;\u67C9b;\u6AD7arr;\u697Bult;\u6AC2\u0100Ee\u35E4\u35E6;\u6ACC;\u628Blus;\u6AC0\u0180eiu\u35F4\u3609\u360Ct\u0180;en\u121C\u35FC\u3602q\u0100;q\u1222\u35B2eq\u0100;q\u35E7\u35E4m;\u6AC8\u0100bp\u3611\u3613;\u6AD4;\u6AD6\u0180Aan\u361C\u3620\u362Drr;\u61D9r\u0100hr\u3626\u3628\xEB\u222E\u0100;o\u0A2B\u0A29war;\u692Alig\u803B\xDF\u40DF\u0BE1\u3651\u365D\u3660\u12CE\u3673\u3679\0\u367E\u36C2\0\0\0\0\0\u36DB\u3703\0\u3709\u376C\0\0\0\u3787\u0272\u3656\0\0\u365Bget;\u6316;\u43C4r\xEB\u0E5F\u0180aey\u3666\u366B\u3670ron;\u4165dil;\u4163;\u4442lrec;\u6315r;\uC000\u{1D531}\u0200eiko\u3686\u369D\u36B5\u36BC\u01F2\u368B\0\u3691e\u01004f\u1284\u1281a\u0180;sv\u3698\u3699\u369B\u43B8ym;\u43D1\u0100cn\u36A2\u36B2k\u0100as\u36A8\u36AEppro\xF8\u12C1im\xBB\u12ACs\xF0\u129E\u0100as\u36BA\u36AE\xF0\u12C1rn\u803B\xFE\u40FE\u01EC\u031F\u36C6\u22E7es\u8180\xD7;bd\u36CF\u36D0\u36D8\u40D7\u0100;a\u190F\u36D5r;\u6A31;\u6A30\u0180eps\u36E1\u36E3\u3700\xE1\u2A4D\u0200;bcf\u0486\u36EC\u36F0\u36F4ot;\u6336ir;\u6AF1\u0100;o\u36F9\u36FC\uC000\u{1D565}rk;\u6ADA\xE1\u3362rime;\u6034\u0180aip\u370F\u3712\u3764d\xE5\u1248\u0380adempst\u3721\u374D\u3740\u3751\u3757\u375C\u375Fngle\u0280;dlqr\u3730\u3731\u3736\u3740\u3742\u65B5own\xBB\u1DBBeft\u0100;e\u2800\u373E\xF1\u092E;\u625Cight\u0100;e\u32AA\u374B\xF1\u105Aot;\u65ECinus;\u6A3Alus;\u6A39b;\u69CDime;\u6A3Bezium;\u63E2\u0180cht\u3772\u377D\u3781\u0100ry\u3777\u377B;\uC000\u{1D4C9};\u4446cy;\u445Brok;\u4167\u0100io\u378B\u378Ex\xF4\u1777head\u0100lr\u3797\u37A0eftarro\xF7\u084Fightarrow\xBB\u0F5D\u0900AHabcdfghlmoprstuw\u37D0\u37D3\u37D7\u37E4\u37F0\u37FC\u380E\u381C\u3823\u3834\u3851\u385D\u386B\u38A9\u38CC\u38D2\u38EA\u38F6r\xF2\u03EDar;\u6963\u0100cr\u37DC\u37E2ute\u803B\xFA\u40FA\xF2\u1150r\u01E3\u37EA\0\u37EDy;\u445Eve;\u416D\u0100iy\u37F5\u37FArc\u803B\xFB\u40FB;\u4443\u0180abh\u3803\u3806\u380Br\xF2\u13ADlac;\u4171a\xF2\u13C3\u0100ir\u3813\u3818sht;\u697E;\uC000\u{1D532}rave\u803B\xF9\u40F9\u0161\u3827\u3831r\u0100lr\u382C\u382E\xBB\u0957\xBB\u1083lk;\u6580\u0100ct\u3839\u384D\u026F\u383F\0\0\u384Arn\u0100;e\u3845\u3846\u631Cr\xBB\u3846op;\u630Fri;\u65F8\u0100al\u3856\u385Acr;\u416B\u80BB\xA8\u0349\u0100gp\u3862\u3866on;\u4173f;\uC000\u{1D566}\u0300adhlsu\u114B\u3878\u387D\u1372\u3891\u38A0own\xE1\u13B3arpoon\u0100lr\u3888\u388Cef\xF4\u382Digh\xF4\u382Fi\u0180;hl\u3899\u389A\u389C\u43C5\xBB\u13FAon\xBB\u389Aparrows;\u61C8\u0180cit\u38B0\u38C4\u38C8\u026F\u38B6\0\0\u38C1rn\u0100;e\u38BC\u38BD\u631Dr\xBB\u38BDop;\u630Eng;\u416Fri;\u65F9cr;\uC000\u{1D4CA}\u0180dir\u38D9\u38DD\u38E2ot;\u62F0lde;\u4169i\u0100;f\u3730\u38E8\xBB\u1813\u0100am\u38EF\u38F2r\xF2\u38A8l\u803B\xFC\u40FCangle;\u69A7\u0780ABDacdeflnoprsz\u391C\u391F\u3929\u392D\u39B5\u39B8\u39BD\u39DF\u39E4\u39E8\u39F3\u39F9\u39FD\u3A01\u3A20r\xF2\u03F7ar\u0100;v\u3926\u3927\u6AE8;\u6AE9as\xE8\u03E1\u0100nr\u3932\u3937grt;\u699C\u0380eknprst\u34E3\u3946\u394B\u3952\u395D\u3964\u3996app\xE1\u2415othin\xE7\u1E96\u0180hir\u34EB\u2EC8\u3959op\xF4\u2FB5\u0100;h\u13B7\u3962\xEF\u318D\u0100iu\u3969\u396Dgm\xE1\u33B3\u0100bp\u3972\u3984setneq\u0100;q\u397D\u3980\uC000\u228A\uFE00;\uC000\u2ACB\uFE00setneq\u0100;q\u398F\u3992\uC000\u228B\uFE00;\uC000\u2ACC\uFE00\u0100hr\u399B\u399Fet\xE1\u369Ciangle\u0100lr\u39AA\u39AFeft\xBB\u0925ight\xBB\u1051y;\u4432ash\xBB\u1036\u0180elr\u39C4\u39D2\u39D7\u0180;be\u2DEA\u39CB\u39CFar;\u62BBq;\u625Alip;\u62EE\u0100bt\u39DC\u1468a\xF2\u1469r;\uC000\u{1D533}tr\xE9\u39AEsu\u0100bp\u39EF\u39F1\xBB\u0D1C\xBB\u0D59pf;\uC000\u{1D567}ro\xF0\u0EFBtr\xE9\u39B4\u0100cu\u3A06\u3A0Br;\uC000\u{1D4CB}\u0100bp\u3A10\u3A18n\u0100Ee\u3980\u3A16\xBB\u397En\u0100Ee\u3992\u3A1E\xBB\u3990igzag;\u699A\u0380cefoprs\u3A36\u3A3B\u3A56\u3A5B\u3A54\u3A61\u3A6Airc;\u4175\u0100di\u3A40\u3A51\u0100bg\u3A45\u3A49ar;\u6A5Fe\u0100;q\u15FA\u3A4F;\u6259erp;\u6118r;\uC000\u{1D534}pf;\uC000\u{1D568}\u0100;e\u1479\u3A66at\xE8\u1479cr;\uC000\u{1D4CC}\u0AE3\u178E\u3A87\0\u3A8B\0\u3A90\u3A9B\0\0\u3A9D\u3AA8\u3AAB\u3AAF\0\0\u3AC3\u3ACE\0\u3AD8\u17DC\u17DFtr\xE9\u17D1r;\uC000\u{1D535}\u0100Aa\u3A94\u3A97r\xF2\u03C3r\xF2\u09F6;\u43BE\u0100Aa\u3AA1\u3AA4r\xF2\u03B8r\xF2\u09EBa\xF0\u2713is;\u62FB\u0180dpt\u17A4\u3AB5\u3ABE\u0100fl\u3ABA\u17A9;\uC000\u{1D569}im\xE5\u17B2\u0100Aa\u3AC7\u3ACAr\xF2\u03CEr\xF2\u0A01\u0100cq\u3AD2\u17B8r;\uC000\u{1D4CD}\u0100pt\u17D6\u3ADCr\xE9\u17D4\u0400acefiosu\u3AF0\u3AFD\u3B08\u3B0C\u3B11\u3B15\u3B1B\u3B21c\u0100uy\u3AF6\u3AFBte\u803B\xFD\u40FD;\u444F\u0100iy\u3B02\u3B06rc;\u4177;\u444Bn\u803B\xA5\u40A5r;\uC000\u{1D536}cy;\u4457pf;\uC000\u{1D56A}cr;\uC000\u{1D4CE}\u0100cm\u3B26\u3B29y;\u444El\u803B\xFF\u40FF\u0500acdefhiosw\u3B42\u3B48\u3B54\u3B58\u3B64\u3B69\u3B6D\u3B74\u3B7A\u3B80cute;\u417A\u0100ay\u3B4D\u3B52ron;\u417E;\u4437ot;\u417C\u0100et\u3B5D\u3B61tr\xE6\u155Fa;\u43B6r;\uC000\u{1D537}cy;\u4436grarr;\u61DDpf;\uC000\u{1D56B}cr;\uC000\u{1D4CF}\u0100jn\u3B85\u3B87;\u600Dj;\u600C'.split("").map((c3) => c3.charCodeAt(0))
  );

  // node_modules/entities/lib/esm/generated/decode-data-xml.js
  var decode_data_xml_default = new Uint16Array(
    // prettier-ignore
    "\u0200aglq	\x1B\u026D\0\0p;\u4026os;\u4027t;\u403Et;\u403Cuot;\u4022".split("").map((c3) => c3.charCodeAt(0))
  );

  // node_modules/entities/lib/esm/decode_codepoint.js
  var _a;
  var decodeMap = /* @__PURE__ */ new Map([
    [0, 65533],
    [128, 8364],
    [130, 8218],
    [131, 402],
    [132, 8222],
    [133, 8230],
    [134, 8224],
    [135, 8225],
    [136, 710],
    [137, 8240],
    [138, 352],
    [139, 8249],
    [140, 338],
    [142, 381],
    [145, 8216],
    [146, 8217],
    [147, 8220],
    [148, 8221],
    [149, 8226],
    [150, 8211],
    [151, 8212],
    [152, 732],
    [153, 8482],
    [154, 353],
    [155, 8250],
    [156, 339],
    [158, 382],
    [159, 376]
  ]);
  var fromCodePoint = (
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition, node/no-unsupported-features/es-builtins
    (_a = String.fromCodePoint) !== null && _a !== void 0 ? _a : function(codePoint) {
      let output = "";
      if (codePoint > 65535) {
        codePoint -= 65536;
        output += String.fromCharCode(codePoint >>> 10 & 1023 | 55296);
        codePoint = 56320 | codePoint & 1023;
      }
      output += String.fromCharCode(codePoint);
      return output;
    }
  );
  function replaceCodePoint(codePoint) {
    var _a2;
    if (codePoint >= 55296 && codePoint <= 57343 || codePoint > 1114111) {
      return 65533;
    }
    return (_a2 = decodeMap.get(codePoint)) !== null && _a2 !== void 0 ? _a2 : codePoint;
  }
  function decodeCodePoint(codePoint) {
    return fromCodePoint(replaceCodePoint(codePoint));
  }

  // node_modules/entities/lib/esm/decode.js
  var CharCodes;
  (function(CharCodes3) {
    CharCodes3[CharCodes3["NUM"] = 35] = "NUM";
    CharCodes3[CharCodes3["SEMI"] = 59] = "SEMI";
    CharCodes3[CharCodes3["ZERO"] = 48] = "ZERO";
    CharCodes3[CharCodes3["NINE"] = 57] = "NINE";
    CharCodes3[CharCodes3["LOWER_A"] = 97] = "LOWER_A";
    CharCodes3[CharCodes3["LOWER_F"] = 102] = "LOWER_F";
    CharCodes3[CharCodes3["LOWER_X"] = 120] = "LOWER_X";
    CharCodes3[CharCodes3["To_LOWER_BIT"] = 32] = "To_LOWER_BIT";
  })(CharCodes || (CharCodes = {}));
  var BinTrieFlags;
  (function(BinTrieFlags2) {
    BinTrieFlags2[BinTrieFlags2["VALUE_LENGTH"] = 49152] = "VALUE_LENGTH";
    BinTrieFlags2[BinTrieFlags2["BRANCH_LENGTH"] = 16256] = "BRANCH_LENGTH";
    BinTrieFlags2[BinTrieFlags2["JUMP_TABLE"] = 127] = "JUMP_TABLE";
  })(BinTrieFlags || (BinTrieFlags = {}));
  function getDecoder(decodeTree) {
    return function decodeHTMLBinary(str, strict) {
      let ret = "";
      let lastIdx = 0;
      let strIdx = 0;
      while ((strIdx = str.indexOf("&", strIdx)) >= 0) {
        ret += str.slice(lastIdx, strIdx);
        lastIdx = strIdx;
        strIdx += 1;
        if (str.charCodeAt(strIdx) === CharCodes.NUM) {
          let start = strIdx + 1;
          let base = 10;
          let cp = str.charCodeAt(start);
          if ((cp | CharCodes.To_LOWER_BIT) === CharCodes.LOWER_X) {
            base = 16;
            strIdx += 1;
            start += 1;
          }
          do
            cp = str.charCodeAt(++strIdx);
          while (cp >= CharCodes.ZERO && cp <= CharCodes.NINE || base === 16 && (cp | CharCodes.To_LOWER_BIT) >= CharCodes.LOWER_A && (cp | CharCodes.To_LOWER_BIT) <= CharCodes.LOWER_F);
          if (start !== strIdx) {
            const entity = str.substring(start, strIdx);
            const parsed = parseInt(entity, base);
            if (str.charCodeAt(strIdx) === CharCodes.SEMI) {
              strIdx += 1;
            } else if (strict) {
              continue;
            }
            ret += decodeCodePoint(parsed);
            lastIdx = strIdx;
          }
          continue;
        }
        let resultIdx = 0;
        let excess = 1;
        let treeIdx = 0;
        let current = decodeTree[treeIdx];
        for (; strIdx < str.length; strIdx++, excess++) {
          treeIdx = determineBranch(decodeTree, current, treeIdx + 1, str.charCodeAt(strIdx));
          if (treeIdx < 0)
            break;
          current = decodeTree[treeIdx];
          const masked = current & BinTrieFlags.VALUE_LENGTH;
          if (masked) {
            if (!strict || str.charCodeAt(strIdx) === CharCodes.SEMI) {
              resultIdx = treeIdx;
              excess = 0;
            }
            const valueLength = (masked >> 14) - 1;
            if (valueLength === 0)
              break;
            treeIdx += valueLength;
          }
        }
        if (resultIdx !== 0) {
          const valueLength = (decodeTree[resultIdx] & BinTrieFlags.VALUE_LENGTH) >> 14;
          ret += valueLength === 1 ? String.fromCharCode(decodeTree[resultIdx] & ~BinTrieFlags.VALUE_LENGTH) : valueLength === 2 ? String.fromCharCode(decodeTree[resultIdx + 1]) : String.fromCharCode(decodeTree[resultIdx + 1], decodeTree[resultIdx + 2]);
          lastIdx = strIdx - excess + 1;
        }
      }
      return ret + str.slice(lastIdx);
    };
  }
  function determineBranch(decodeTree, current, nodeIdx, char) {
    const branchCount = (current & BinTrieFlags.BRANCH_LENGTH) >> 7;
    const jumpOffset = current & BinTrieFlags.JUMP_TABLE;
    if (branchCount === 0) {
      return jumpOffset !== 0 && char === jumpOffset ? nodeIdx : -1;
    }
    if (jumpOffset) {
      const value = char - jumpOffset;
      return value < 0 || value >= branchCount ? -1 : decodeTree[nodeIdx + value] - 1;
    }
    let lo = nodeIdx;
    let hi = lo + branchCount - 1;
    while (lo <= hi) {
      const mid = lo + hi >>> 1;
      const midVal = decodeTree[mid];
      if (midVal < char) {
        lo = mid + 1;
      } else if (midVal > char) {
        hi = mid - 1;
      } else {
        return decodeTree[mid + branchCount];
      }
    }
    return -1;
  }
  var htmlDecoder = getDecoder(decode_data_html_default);
  var xmlDecoder = getDecoder(decode_data_xml_default);

  // node_modules/entities/lib/esm/generated/encode-html.js
  function restoreDiff(arr) {
    for (let i3 = 1; i3 < arr.length; i3++) {
      arr[i3][0] += arr[i3 - 1][0] + 1;
    }
    return arr;
  }
  var encode_html_default = new Map(/* @__PURE__ */ restoreDiff([[9, "&Tab;"], [0, "&NewLine;"], [22, "&excl;"], [0, "&quot;"], [0, "&num;"], [0, "&dollar;"], [0, "&percnt;"], [0, "&amp;"], [0, "&apos;"], [0, "&lpar;"], [0, "&rpar;"], [0, "&ast;"], [0, "&plus;"], [0, "&comma;"], [1, "&period;"], [0, "&sol;"], [10, "&colon;"], [0, "&semi;"], [0, { v: "&lt;", n: 8402, o: "&nvlt;" }], [0, { v: "&equals;", n: 8421, o: "&bne;" }], [0, { v: "&gt;", n: 8402, o: "&nvgt;" }], [0, "&quest;"], [0, "&commat;"], [26, "&lbrack;"], [0, "&bsol;"], [0, "&rbrack;"], [0, "&Hat;"], [0, "&lowbar;"], [0, "&DiacriticalGrave;"], [5, { n: 106, o: "&fjlig;" }], [20, "&lbrace;"], [0, "&verbar;"], [0, "&rbrace;"], [34, "&nbsp;"], [0, "&iexcl;"], [0, "&cent;"], [0, "&pound;"], [0, "&curren;"], [0, "&yen;"], [0, "&brvbar;"], [0, "&sect;"], [0, "&die;"], [0, "&copy;"], [0, "&ordf;"], [0, "&laquo;"], [0, "&not;"], [0, "&shy;"], [0, "&circledR;"], [0, "&macr;"], [0, "&deg;"], [0, "&PlusMinus;"], [0, "&sup2;"], [0, "&sup3;"], [0, "&acute;"], [0, "&micro;"], [0, "&para;"], [0, "&centerdot;"], [0, "&cedil;"], [0, "&sup1;"], [0, "&ordm;"], [0, "&raquo;"], [0, "&frac14;"], [0, "&frac12;"], [0, "&frac34;"], [0, "&iquest;"], [0, "&Agrave;"], [0, "&Aacute;"], [0, "&Acirc;"], [0, "&Atilde;"], [0, "&Auml;"], [0, "&angst;"], [0, "&AElig;"], [0, "&Ccedil;"], [0, "&Egrave;"], [0, "&Eacute;"], [0, "&Ecirc;"], [0, "&Euml;"], [0, "&Igrave;"], [0, "&Iacute;"], [0, "&Icirc;"], [0, "&Iuml;"], [0, "&ETH;"], [0, "&Ntilde;"], [0, "&Ograve;"], [0, "&Oacute;"], [0, "&Ocirc;"], [0, "&Otilde;"], [0, "&Ouml;"], [0, "&times;"], [0, "&Oslash;"], [0, "&Ugrave;"], [0, "&Uacute;"], [0, "&Ucirc;"], [0, "&Uuml;"], [0, "&Yacute;"], [0, "&THORN;"], [0, "&szlig;"], [0, "&agrave;"], [0, "&aacute;"], [0, "&acirc;"], [0, "&atilde;"], [0, "&auml;"], [0, "&aring;"], [0, "&aelig;"], [0, "&ccedil;"], [0, "&egrave;"], [0, "&eacute;"], [0, "&ecirc;"], [0, "&euml;"], [0, "&igrave;"], [0, "&iacute;"], [0, "&icirc;"], [0, "&iuml;"], [0, "&eth;"], [0, "&ntilde;"], [0, "&ograve;"], [0, "&oacute;"], [0, "&ocirc;"], [0, "&otilde;"], [0, "&ouml;"], [0, "&div;"], [0, "&oslash;"], [0, "&ugrave;"], [0, "&uacute;"], [0, "&ucirc;"], [0, "&uuml;"], [0, "&yacute;"], [0, "&thorn;"], [0, "&yuml;"], [0, "&Amacr;"], [0, "&amacr;"], [0, "&Abreve;"], [0, "&abreve;"], [0, "&Aogon;"], [0, "&aogon;"], [0, "&Cacute;"], [0, "&cacute;"], [0, "&Ccirc;"], [0, "&ccirc;"], [0, "&Cdot;"], [0, "&cdot;"], [0, "&Ccaron;"], [0, "&ccaron;"], [0, "&Dcaron;"], [0, "&dcaron;"], [0, "&Dstrok;"], [0, "&dstrok;"], [0, "&Emacr;"], [0, "&emacr;"], [2, "&Edot;"], [0, "&edot;"], [0, "&Eogon;"], [0, "&eogon;"], [0, "&Ecaron;"], [0, "&ecaron;"], [0, "&Gcirc;"], [0, "&gcirc;"], [0, "&Gbreve;"], [0, "&gbreve;"], [0, "&Gdot;"], [0, "&gdot;"], [0, "&Gcedil;"], [1, "&Hcirc;"], [0, "&hcirc;"], [0, "&Hstrok;"], [0, "&hstrok;"], [0, "&Itilde;"], [0, "&itilde;"], [0, "&Imacr;"], [0, "&imacr;"], [2, "&Iogon;"], [0, "&iogon;"], [0, "&Idot;"], [0, "&imath;"], [0, "&IJlig;"], [0, "&ijlig;"], [0, "&Jcirc;"], [0, "&jcirc;"], [0, "&Kcedil;"], [0, "&kcedil;"], [0, "&kgreen;"], [0, "&Lacute;"], [0, "&lacute;"], [0, "&Lcedil;"], [0, "&lcedil;"], [0, "&Lcaron;"], [0, "&lcaron;"], [0, "&Lmidot;"], [0, "&lmidot;"], [0, "&Lstrok;"], [0, "&lstrok;"], [0, "&Nacute;"], [0, "&nacute;"], [0, "&Ncedil;"], [0, "&ncedil;"], [0, "&Ncaron;"], [0, "&ncaron;"], [0, "&napos;"], [0, "&ENG;"], [0, "&eng;"], [0, "&Omacr;"], [0, "&omacr;"], [2, "&Odblac;"], [0, "&odblac;"], [0, "&OElig;"], [0, "&oelig;"], [0, "&Racute;"], [0, "&racute;"], [0, "&Rcedil;"], [0, "&rcedil;"], [0, "&Rcaron;"], [0, "&rcaron;"], [0, "&Sacute;"], [0, "&sacute;"], [0, "&Scirc;"], [0, "&scirc;"], [0, "&Scedil;"], [0, "&scedil;"], [0, "&Scaron;"], [0, "&scaron;"], [0, "&Tcedil;"], [0, "&tcedil;"], [0, "&Tcaron;"], [0, "&tcaron;"], [0, "&Tstrok;"], [0, "&tstrok;"], [0, "&Utilde;"], [0, "&utilde;"], [0, "&Umacr;"], [0, "&umacr;"], [0, "&Ubreve;"], [0, "&ubreve;"], [0, "&Uring;"], [0, "&uring;"], [0, "&Udblac;"], [0, "&udblac;"], [0, "&Uogon;"], [0, "&uogon;"], [0, "&Wcirc;"], [0, "&wcirc;"], [0, "&Ycirc;"], [0, "&ycirc;"], [0, "&Yuml;"], [0, "&Zacute;"], [0, "&zacute;"], [0, "&Zdot;"], [0, "&zdot;"], [0, "&Zcaron;"], [0, "&zcaron;"], [19, "&fnof;"], [34, "&imped;"], [63, "&gacute;"], [65, "&jmath;"], [142, "&circ;"], [0, "&caron;"], [16, "&breve;"], [0, "&DiacriticalDot;"], [0, "&ring;"], [0, "&ogon;"], [0, "&DiacriticalTilde;"], [0, "&dblac;"], [51, "&DownBreve;"], [127, "&Alpha;"], [0, "&Beta;"], [0, "&Gamma;"], [0, "&Delta;"], [0, "&Epsilon;"], [0, "&Zeta;"], [0, "&Eta;"], [0, "&Theta;"], [0, "&Iota;"], [0, "&Kappa;"], [0, "&Lambda;"], [0, "&Mu;"], [0, "&Nu;"], [0, "&Xi;"], [0, "&Omicron;"], [0, "&Pi;"], [0, "&Rho;"], [1, "&Sigma;"], [0, "&Tau;"], [0, "&Upsilon;"], [0, "&Phi;"], [0, "&Chi;"], [0, "&Psi;"], [0, "&ohm;"], [7, "&alpha;"], [0, "&beta;"], [0, "&gamma;"], [0, "&delta;"], [0, "&epsi;"], [0, "&zeta;"], [0, "&eta;"], [0, "&theta;"], [0, "&iota;"], [0, "&kappa;"], [0, "&lambda;"], [0, "&mu;"], [0, "&nu;"], [0, "&xi;"], [0, "&omicron;"], [0, "&pi;"], [0, "&rho;"], [0, "&sigmaf;"], [0, "&sigma;"], [0, "&tau;"], [0, "&upsi;"], [0, "&phi;"], [0, "&chi;"], [0, "&psi;"], [0, "&omega;"], [7, "&thetasym;"], [0, "&Upsi;"], [2, "&phiv;"], [0, "&piv;"], [5, "&Gammad;"], [0, "&digamma;"], [18, "&kappav;"], [0, "&rhov;"], [3, "&epsiv;"], [0, "&backepsilon;"], [10, "&IOcy;"], [0, "&DJcy;"], [0, "&GJcy;"], [0, "&Jukcy;"], [0, "&DScy;"], [0, "&Iukcy;"], [0, "&YIcy;"], [0, "&Jsercy;"], [0, "&LJcy;"], [0, "&NJcy;"], [0, "&TSHcy;"], [0, "&KJcy;"], [1, "&Ubrcy;"], [0, "&DZcy;"], [0, "&Acy;"], [0, "&Bcy;"], [0, "&Vcy;"], [0, "&Gcy;"], [0, "&Dcy;"], [0, "&IEcy;"], [0, "&ZHcy;"], [0, "&Zcy;"], [0, "&Icy;"], [0, "&Jcy;"], [0, "&Kcy;"], [0, "&Lcy;"], [0, "&Mcy;"], [0, "&Ncy;"], [0, "&Ocy;"], [0, "&Pcy;"], [0, "&Rcy;"], [0, "&Scy;"], [0, "&Tcy;"], [0, "&Ucy;"], [0, "&Fcy;"], [0, "&KHcy;"], [0, "&TScy;"], [0, "&CHcy;"], [0, "&SHcy;"], [0, "&SHCHcy;"], [0, "&HARDcy;"], [0, "&Ycy;"], [0, "&SOFTcy;"], [0, "&Ecy;"], [0, "&YUcy;"], [0, "&YAcy;"], [0, "&acy;"], [0, "&bcy;"], [0, "&vcy;"], [0, "&gcy;"], [0, "&dcy;"], [0, "&iecy;"], [0, "&zhcy;"], [0, "&zcy;"], [0, "&icy;"], [0, "&jcy;"], [0, "&kcy;"], [0, "&lcy;"], [0, "&mcy;"], [0, "&ncy;"], [0, "&ocy;"], [0, "&pcy;"], [0, "&rcy;"], [0, "&scy;"], [0, "&tcy;"], [0, "&ucy;"], [0, "&fcy;"], [0, "&khcy;"], [0, "&tscy;"], [0, "&chcy;"], [0, "&shcy;"], [0, "&shchcy;"], [0, "&hardcy;"], [0, "&ycy;"], [0, "&softcy;"], [0, "&ecy;"], [0, "&yucy;"], [0, "&yacy;"], [1, "&iocy;"], [0, "&djcy;"], [0, "&gjcy;"], [0, "&jukcy;"], [0, "&dscy;"], [0, "&iukcy;"], [0, "&yicy;"], [0, "&jsercy;"], [0, "&ljcy;"], [0, "&njcy;"], [0, "&tshcy;"], [0, "&kjcy;"], [1, "&ubrcy;"], [0, "&dzcy;"], [7074, "&ensp;"], [0, "&emsp;"], [0, "&emsp13;"], [0, "&emsp14;"], [1, "&numsp;"], [0, "&puncsp;"], [0, "&ThinSpace;"], [0, "&hairsp;"], [0, "&NegativeMediumSpace;"], [0, "&zwnj;"], [0, "&zwj;"], [0, "&lrm;"], [0, "&rlm;"], [0, "&dash;"], [2, "&ndash;"], [0, "&mdash;"], [0, "&horbar;"], [0, "&Verbar;"], [1, "&lsquo;"], [0, "&CloseCurlyQuote;"], [0, "&lsquor;"], [1, "&ldquo;"], [0, "&CloseCurlyDoubleQuote;"], [0, "&bdquo;"], [1, "&dagger;"], [0, "&Dagger;"], [0, "&bull;"], [2, "&nldr;"], [0, "&hellip;"], [9, "&permil;"], [0, "&pertenk;"], [0, "&prime;"], [0, "&Prime;"], [0, "&tprime;"], [0, "&backprime;"], [3, "&lsaquo;"], [0, "&rsaquo;"], [3, "&oline;"], [2, "&caret;"], [1, "&hybull;"], [0, "&frasl;"], [10, "&bsemi;"], [7, "&qprime;"], [7, { v: "&MediumSpace;", n: 8202, o: "&ThickSpace;" }], [0, "&NoBreak;"], [0, "&af;"], [0, "&InvisibleTimes;"], [0, "&ic;"], [72, "&euro;"], [46, "&tdot;"], [0, "&DotDot;"], [37, "&complexes;"], [2, "&incare;"], [4, "&gscr;"], [0, "&hamilt;"], [0, "&Hfr;"], [0, "&Hopf;"], [0, "&planckh;"], [0, "&hbar;"], [0, "&imagline;"], [0, "&Ifr;"], [0, "&lagran;"], [0, "&ell;"], [1, "&naturals;"], [0, "&numero;"], [0, "&copysr;"], [0, "&weierp;"], [0, "&Popf;"], [0, "&Qopf;"], [0, "&realine;"], [0, "&real;"], [0, "&reals;"], [0, "&rx;"], [3, "&trade;"], [1, "&integers;"], [2, "&mho;"], [0, "&zeetrf;"], [0, "&iiota;"], [2, "&bernou;"], [0, "&Cayleys;"], [1, "&escr;"], [0, "&Escr;"], [0, "&Fouriertrf;"], [1, "&Mellintrf;"], [0, "&order;"], [0, "&alefsym;"], [0, "&beth;"], [0, "&gimel;"], [0, "&daleth;"], [12, "&CapitalDifferentialD;"], [0, "&dd;"], [0, "&ee;"], [0, "&ii;"], [10, "&frac13;"], [0, "&frac23;"], [0, "&frac15;"], [0, "&frac25;"], [0, "&frac35;"], [0, "&frac45;"], [0, "&frac16;"], [0, "&frac56;"], [0, "&frac18;"], [0, "&frac38;"], [0, "&frac58;"], [0, "&frac78;"], [49, "&larr;"], [0, "&ShortUpArrow;"], [0, "&rarr;"], [0, "&darr;"], [0, "&harr;"], [0, "&updownarrow;"], [0, "&nwarr;"], [0, "&nearr;"], [0, "&LowerRightArrow;"], [0, "&LowerLeftArrow;"], [0, "&nlarr;"], [0, "&nrarr;"], [1, { v: "&rarrw;", n: 824, o: "&nrarrw;" }], [0, "&Larr;"], [0, "&Uarr;"], [0, "&Rarr;"], [0, "&Darr;"], [0, "&larrtl;"], [0, "&rarrtl;"], [0, "&LeftTeeArrow;"], [0, "&mapstoup;"], [0, "&map;"], [0, "&DownTeeArrow;"], [1, "&hookleftarrow;"], [0, "&hookrightarrow;"], [0, "&larrlp;"], [0, "&looparrowright;"], [0, "&harrw;"], [0, "&nharr;"], [1, "&lsh;"], [0, "&rsh;"], [0, "&ldsh;"], [0, "&rdsh;"], [1, "&crarr;"], [0, "&cularr;"], [0, "&curarr;"], [2, "&circlearrowleft;"], [0, "&circlearrowright;"], [0, "&leftharpoonup;"], [0, "&DownLeftVector;"], [0, "&RightUpVector;"], [0, "&LeftUpVector;"], [0, "&rharu;"], [0, "&DownRightVector;"], [0, "&dharr;"], [0, "&dharl;"], [0, "&RightArrowLeftArrow;"], [0, "&udarr;"], [0, "&LeftArrowRightArrow;"], [0, "&leftleftarrows;"], [0, "&upuparrows;"], [0, "&rightrightarrows;"], [0, "&ddarr;"], [0, "&leftrightharpoons;"], [0, "&Equilibrium;"], [0, "&nlArr;"], [0, "&nhArr;"], [0, "&nrArr;"], [0, "&DoubleLeftArrow;"], [0, "&DoubleUpArrow;"], [0, "&DoubleRightArrow;"], [0, "&dArr;"], [0, "&DoubleLeftRightArrow;"], [0, "&DoubleUpDownArrow;"], [0, "&nwArr;"], [0, "&neArr;"], [0, "&seArr;"], [0, "&swArr;"], [0, "&lAarr;"], [0, "&rAarr;"], [1, "&zigrarr;"], [6, "&larrb;"], [0, "&rarrb;"], [15, "&DownArrowUpArrow;"], [7, "&loarr;"], [0, "&roarr;"], [0, "&hoarr;"], [0, "&forall;"], [0, "&comp;"], [0, { v: "&part;", n: 824, o: "&npart;" }], [0, "&exist;"], [0, "&nexist;"], [0, "&empty;"], [1, "&Del;"], [0, "&Element;"], [0, "&NotElement;"], [1, "&ni;"], [0, "&notni;"], [2, "&prod;"], [0, "&coprod;"], [0, "&sum;"], [0, "&minus;"], [0, "&MinusPlus;"], [0, "&dotplus;"], [1, "&Backslash;"], [0, "&lowast;"], [0, "&compfn;"], [1, "&radic;"], [2, "&prop;"], [0, "&infin;"], [0, "&angrt;"], [0, { v: "&ang;", n: 8402, o: "&nang;" }], [0, "&angmsd;"], [0, "&angsph;"], [0, "&mid;"], [0, "&nmid;"], [0, "&DoubleVerticalBar;"], [0, "&NotDoubleVerticalBar;"], [0, "&and;"], [0, "&or;"], [0, { v: "&cap;", n: 65024, o: "&caps;" }], [0, { v: "&cup;", n: 65024, o: "&cups;" }], [0, "&int;"], [0, "&Int;"], [0, "&iiint;"], [0, "&conint;"], [0, "&Conint;"], [0, "&Cconint;"], [0, "&cwint;"], [0, "&ClockwiseContourIntegral;"], [0, "&awconint;"], [0, "&there4;"], [0, "&becaus;"], [0, "&ratio;"], [0, "&Colon;"], [0, "&dotminus;"], [1, "&mDDot;"], [0, "&homtht;"], [0, { v: "&sim;", n: 8402, o: "&nvsim;" }], [0, { v: "&backsim;", n: 817, o: "&race;" }], [0, { v: "&ac;", n: 819, o: "&acE;" }], [0, "&acd;"], [0, "&VerticalTilde;"], [0, "&NotTilde;"], [0, { v: "&eqsim;", n: 824, o: "&nesim;" }], [0, "&sime;"], [0, "&NotTildeEqual;"], [0, "&cong;"], [0, "&simne;"], [0, "&ncong;"], [0, "&ap;"], [0, "&nap;"], [0, "&ape;"], [0, { v: "&apid;", n: 824, o: "&napid;" }], [0, "&backcong;"], [0, { v: "&asympeq;", n: 8402, o: "&nvap;" }], [0, { v: "&bump;", n: 824, o: "&nbump;" }], [0, { v: "&bumpe;", n: 824, o: "&nbumpe;" }], [0, { v: "&doteq;", n: 824, o: "&nedot;" }], [0, "&doteqdot;"], [0, "&efDot;"], [0, "&erDot;"], [0, "&Assign;"], [0, "&ecolon;"], [0, "&ecir;"], [0, "&circeq;"], [1, "&wedgeq;"], [0, "&veeeq;"], [1, "&triangleq;"], [2, "&equest;"], [0, "&ne;"], [0, { v: "&Congruent;", n: 8421, o: "&bnequiv;" }], [0, "&nequiv;"], [1, { v: "&le;", n: 8402, o: "&nvle;" }], [0, { v: "&ge;", n: 8402, o: "&nvge;" }], [0, { v: "&lE;", n: 824, o: "&nlE;" }], [0, { v: "&gE;", n: 824, o: "&ngE;" }], [0, { v: "&lnE;", n: 65024, o: "&lvertneqq;" }], [0, { v: "&gnE;", n: 65024, o: "&gvertneqq;" }], [0, { v: "&ll;", n: new Map(/* @__PURE__ */ restoreDiff([[824, "&nLtv;"], [7577, "&nLt;"]])) }], [0, { v: "&gg;", n: new Map(/* @__PURE__ */ restoreDiff([[824, "&nGtv;"], [7577, "&nGt;"]])) }], [0, "&between;"], [0, "&NotCupCap;"], [0, "&nless;"], [0, "&ngt;"], [0, "&nle;"], [0, "&nge;"], [0, "&lesssim;"], [0, "&GreaterTilde;"], [0, "&nlsim;"], [0, "&ngsim;"], [0, "&LessGreater;"], [0, "&gl;"], [0, "&NotLessGreater;"], [0, "&NotGreaterLess;"], [0, "&pr;"], [0, "&sc;"], [0, "&prcue;"], [0, "&sccue;"], [0, "&PrecedesTilde;"], [0, { v: "&scsim;", n: 824, o: "&NotSucceedsTilde;" }], [0, "&NotPrecedes;"], [0, "&NotSucceeds;"], [0, { v: "&sub;", n: 8402, o: "&NotSubset;" }], [0, { v: "&sup;", n: 8402, o: "&NotSuperset;" }], [0, "&nsub;"], [0, "&nsup;"], [0, "&sube;"], [0, "&supe;"], [0, "&NotSubsetEqual;"], [0, "&NotSupersetEqual;"], [0, { v: "&subne;", n: 65024, o: "&varsubsetneq;" }], [0, { v: "&supne;", n: 65024, o: "&varsupsetneq;" }], [1, "&cupdot;"], [0, "&UnionPlus;"], [0, { v: "&sqsub;", n: 824, o: "&NotSquareSubset;" }], [0, { v: "&sqsup;", n: 824, o: "&NotSquareSuperset;" }], [0, "&sqsube;"], [0, "&sqsupe;"], [0, { v: "&sqcap;", n: 65024, o: "&sqcaps;" }], [0, { v: "&sqcup;", n: 65024, o: "&sqcups;" }], [0, "&CirclePlus;"], [0, "&CircleMinus;"], [0, "&CircleTimes;"], [0, "&osol;"], [0, "&CircleDot;"], [0, "&circledcirc;"], [0, "&circledast;"], [1, "&circleddash;"], [0, "&boxplus;"], [0, "&boxminus;"], [0, "&boxtimes;"], [0, "&dotsquare;"], [0, "&RightTee;"], [0, "&dashv;"], [0, "&DownTee;"], [0, "&bot;"], [1, "&models;"], [0, "&DoubleRightTee;"], [0, "&Vdash;"], [0, "&Vvdash;"], [0, "&VDash;"], [0, "&nvdash;"], [0, "&nvDash;"], [0, "&nVdash;"], [0, "&nVDash;"], [0, "&prurel;"], [1, "&LeftTriangle;"], [0, "&RightTriangle;"], [0, { v: "&LeftTriangleEqual;", n: 8402, o: "&nvltrie;" }], [0, { v: "&RightTriangleEqual;", n: 8402, o: "&nvrtrie;" }], [0, "&origof;"], [0, "&imof;"], [0, "&multimap;"], [0, "&hercon;"], [0, "&intcal;"], [0, "&veebar;"], [1, "&barvee;"], [0, "&angrtvb;"], [0, "&lrtri;"], [0, "&bigwedge;"], [0, "&bigvee;"], [0, "&bigcap;"], [0, "&bigcup;"], [0, "&diam;"], [0, "&sdot;"], [0, "&sstarf;"], [0, "&divideontimes;"], [0, "&bowtie;"], [0, "&ltimes;"], [0, "&rtimes;"], [0, "&leftthreetimes;"], [0, "&rightthreetimes;"], [0, "&backsimeq;"], [0, "&curlyvee;"], [0, "&curlywedge;"], [0, "&Sub;"], [0, "&Sup;"], [0, "&Cap;"], [0, "&Cup;"], [0, "&fork;"], [0, "&epar;"], [0, "&lessdot;"], [0, "&gtdot;"], [0, { v: "&Ll;", n: 824, o: "&nLl;" }], [0, { v: "&Gg;", n: 824, o: "&nGg;" }], [0, { v: "&leg;", n: 65024, o: "&lesg;" }], [0, { v: "&gel;", n: 65024, o: "&gesl;" }], [2, "&cuepr;"], [0, "&cuesc;"], [0, "&NotPrecedesSlantEqual;"], [0, "&NotSucceedsSlantEqual;"], [0, "&NotSquareSubsetEqual;"], [0, "&NotSquareSupersetEqual;"], [2, "&lnsim;"], [0, "&gnsim;"], [0, "&precnsim;"], [0, "&scnsim;"], [0, "&nltri;"], [0, "&NotRightTriangle;"], [0, "&nltrie;"], [0, "&NotRightTriangleEqual;"], [0, "&vellip;"], [0, "&ctdot;"], [0, "&utdot;"], [0, "&dtdot;"], [0, "&disin;"], [0, "&isinsv;"], [0, "&isins;"], [0, { v: "&isindot;", n: 824, o: "&notindot;" }], [0, "&notinvc;"], [0, "&notinvb;"], [1, { v: "&isinE;", n: 824, o: "&notinE;" }], [0, "&nisd;"], [0, "&xnis;"], [0, "&nis;"], [0, "&notnivc;"], [0, "&notnivb;"], [6, "&barwed;"], [0, "&Barwed;"], [1, "&lceil;"], [0, "&rceil;"], [0, "&LeftFloor;"], [0, "&rfloor;"], [0, "&drcrop;"], [0, "&dlcrop;"], [0, "&urcrop;"], [0, "&ulcrop;"], [0, "&bnot;"], [1, "&profline;"], [0, "&profsurf;"], [1, "&telrec;"], [0, "&target;"], [5, "&ulcorn;"], [0, "&urcorn;"], [0, "&dlcorn;"], [0, "&drcorn;"], [2, "&frown;"], [0, "&smile;"], [9, "&cylcty;"], [0, "&profalar;"], [7, "&topbot;"], [6, "&ovbar;"], [1, "&solbar;"], [60, "&angzarr;"], [51, "&lmoustache;"], [0, "&rmoustache;"], [2, "&OverBracket;"], [0, "&bbrk;"], [0, "&bbrktbrk;"], [37, "&OverParenthesis;"], [0, "&UnderParenthesis;"], [0, "&OverBrace;"], [0, "&UnderBrace;"], [2, "&trpezium;"], [4, "&elinters;"], [59, "&blank;"], [164, "&circledS;"], [55, "&boxh;"], [1, "&boxv;"], [9, "&boxdr;"], [3, "&boxdl;"], [3, "&boxur;"], [3, "&boxul;"], [3, "&boxvr;"], [7, "&boxvl;"], [7, "&boxhd;"], [7, "&boxhu;"], [7, "&boxvh;"], [19, "&boxH;"], [0, "&boxV;"], [0, "&boxdR;"], [0, "&boxDr;"], [0, "&boxDR;"], [0, "&boxdL;"], [0, "&boxDl;"], [0, "&boxDL;"], [0, "&boxuR;"], [0, "&boxUr;"], [0, "&boxUR;"], [0, "&boxuL;"], [0, "&boxUl;"], [0, "&boxUL;"], [0, "&boxvR;"], [0, "&boxVr;"], [0, "&boxVR;"], [0, "&boxvL;"], [0, "&boxVl;"], [0, "&boxVL;"], [0, "&boxHd;"], [0, "&boxhD;"], [0, "&boxHD;"], [0, "&boxHu;"], [0, "&boxhU;"], [0, "&boxHU;"], [0, "&boxvH;"], [0, "&boxVh;"], [0, "&boxVH;"], [19, "&uhblk;"], [3, "&lhblk;"], [3, "&block;"], [8, "&blk14;"], [0, "&blk12;"], [0, "&blk34;"], [13, "&square;"], [8, "&blacksquare;"], [0, "&EmptyVerySmallSquare;"], [1, "&rect;"], [0, "&marker;"], [2, "&fltns;"], [1, "&bigtriangleup;"], [0, "&blacktriangle;"], [0, "&triangle;"], [2, "&blacktriangleright;"], [0, "&rtri;"], [3, "&bigtriangledown;"], [0, "&blacktriangledown;"], [0, "&dtri;"], [2, "&blacktriangleleft;"], [0, "&ltri;"], [6, "&loz;"], [0, "&cir;"], [32, "&tridot;"], [2, "&bigcirc;"], [8, "&ultri;"], [0, "&urtri;"], [0, "&lltri;"], [0, "&EmptySmallSquare;"], [0, "&FilledSmallSquare;"], [8, "&bigstar;"], [0, "&star;"], [7, "&phone;"], [49, "&female;"], [1, "&male;"], [29, "&spades;"], [2, "&clubs;"], [1, "&hearts;"], [0, "&diamondsuit;"], [3, "&sung;"], [2, "&flat;"], [0, "&natural;"], [0, "&sharp;"], [163, "&check;"], [3, "&cross;"], [8, "&malt;"], [21, "&sext;"], [33, "&VerticalSeparator;"], [25, "&lbbrk;"], [0, "&rbbrk;"], [84, "&bsolhsub;"], [0, "&suphsol;"], [28, "&LeftDoubleBracket;"], [0, "&RightDoubleBracket;"], [0, "&lang;"], [0, "&rang;"], [0, "&Lang;"], [0, "&Rang;"], [0, "&loang;"], [0, "&roang;"], [7, "&longleftarrow;"], [0, "&longrightarrow;"], [0, "&longleftrightarrow;"], [0, "&DoubleLongLeftArrow;"], [0, "&DoubleLongRightArrow;"], [0, "&DoubleLongLeftRightArrow;"], [1, "&longmapsto;"], [2, "&dzigrarr;"], [258, "&nvlArr;"], [0, "&nvrArr;"], [0, "&nvHarr;"], [0, "&Map;"], [6, "&lbarr;"], [0, "&bkarow;"], [0, "&lBarr;"], [0, "&dbkarow;"], [0, "&drbkarow;"], [0, "&DDotrahd;"], [0, "&UpArrowBar;"], [0, "&DownArrowBar;"], [2, "&Rarrtl;"], [2, "&latail;"], [0, "&ratail;"], [0, "&lAtail;"], [0, "&rAtail;"], [0, "&larrfs;"], [0, "&rarrfs;"], [0, "&larrbfs;"], [0, "&rarrbfs;"], [2, "&nwarhk;"], [0, "&nearhk;"], [0, "&hksearow;"], [0, "&hkswarow;"], [0, "&nwnear;"], [0, "&nesear;"], [0, "&seswar;"], [0, "&swnwar;"], [8, { v: "&rarrc;", n: 824, o: "&nrarrc;" }], [1, "&cudarrr;"], [0, "&ldca;"], [0, "&rdca;"], [0, "&cudarrl;"], [0, "&larrpl;"], [2, "&curarrm;"], [0, "&cularrp;"], [7, "&rarrpl;"], [2, "&harrcir;"], [0, "&Uarrocir;"], [0, "&lurdshar;"], [0, "&ldrushar;"], [2, "&LeftRightVector;"], [0, "&RightUpDownVector;"], [0, "&DownLeftRightVector;"], [0, "&LeftUpDownVector;"], [0, "&LeftVectorBar;"], [0, "&RightVectorBar;"], [0, "&RightUpVectorBar;"], [0, "&RightDownVectorBar;"], [0, "&DownLeftVectorBar;"], [0, "&DownRightVectorBar;"], [0, "&LeftUpVectorBar;"], [0, "&LeftDownVectorBar;"], [0, "&LeftTeeVector;"], [0, "&RightTeeVector;"], [0, "&RightUpTeeVector;"], [0, "&RightDownTeeVector;"], [0, "&DownLeftTeeVector;"], [0, "&DownRightTeeVector;"], [0, "&LeftUpTeeVector;"], [0, "&LeftDownTeeVector;"], [0, "&lHar;"], [0, "&uHar;"], [0, "&rHar;"], [0, "&dHar;"], [0, "&luruhar;"], [0, "&ldrdhar;"], [0, "&ruluhar;"], [0, "&rdldhar;"], [0, "&lharul;"], [0, "&llhard;"], [0, "&rharul;"], [0, "&lrhard;"], [0, "&udhar;"], [0, "&duhar;"], [0, "&RoundImplies;"], [0, "&erarr;"], [0, "&simrarr;"], [0, "&larrsim;"], [0, "&rarrsim;"], [0, "&rarrap;"], [0, "&ltlarr;"], [1, "&gtrarr;"], [0, "&subrarr;"], [1, "&suplarr;"], [0, "&lfisht;"], [0, "&rfisht;"], [0, "&ufisht;"], [0, "&dfisht;"], [5, "&lopar;"], [0, "&ropar;"], [4, "&lbrke;"], [0, "&rbrke;"], [0, "&lbrkslu;"], [0, "&rbrksld;"], [0, "&lbrksld;"], [0, "&rbrkslu;"], [0, "&langd;"], [0, "&rangd;"], [0, "&lparlt;"], [0, "&rpargt;"], [0, "&gtlPar;"], [0, "&ltrPar;"], [3, "&vzigzag;"], [1, "&vangrt;"], [0, "&angrtvbd;"], [6, "&ange;"], [0, "&range;"], [0, "&dwangle;"], [0, "&uwangle;"], [0, "&angmsdaa;"], [0, "&angmsdab;"], [0, "&angmsdac;"], [0, "&angmsdad;"], [0, "&angmsdae;"], [0, "&angmsdaf;"], [0, "&angmsdag;"], [0, "&angmsdah;"], [0, "&bemptyv;"], [0, "&demptyv;"], [0, "&cemptyv;"], [0, "&raemptyv;"], [0, "&laemptyv;"], [0, "&ohbar;"], [0, "&omid;"], [0, "&opar;"], [1, "&operp;"], [1, "&olcross;"], [0, "&odsold;"], [1, "&olcir;"], [0, "&ofcir;"], [0, "&olt;"], [0, "&ogt;"], [0, "&cirscir;"], [0, "&cirE;"], [0, "&solb;"], [0, "&bsolb;"], [3, "&boxbox;"], [3, "&trisb;"], [0, "&rtriltri;"], [0, { v: "&LeftTriangleBar;", n: 824, o: "&NotLeftTriangleBar;" }], [0, { v: "&RightTriangleBar;", n: 824, o: "&NotRightTriangleBar;" }], [11, "&iinfin;"], [0, "&infintie;"], [0, "&nvinfin;"], [4, "&eparsl;"], [0, "&smeparsl;"], [0, "&eqvparsl;"], [5, "&blacklozenge;"], [8, "&RuleDelayed;"], [1, "&dsol;"], [9, "&bigodot;"], [0, "&bigoplus;"], [0, "&bigotimes;"], [1, "&biguplus;"], [1, "&bigsqcup;"], [5, "&iiiint;"], [0, "&fpartint;"], [2, "&cirfnint;"], [0, "&awint;"], [0, "&rppolint;"], [0, "&scpolint;"], [0, "&npolint;"], [0, "&pointint;"], [0, "&quatint;"], [0, "&intlarhk;"], [10, "&pluscir;"], [0, "&plusacir;"], [0, "&simplus;"], [0, "&plusdu;"], [0, "&plussim;"], [0, "&plustwo;"], [1, "&mcomma;"], [0, "&minusdu;"], [2, "&loplus;"], [0, "&roplus;"], [0, "&Cross;"], [0, "&timesd;"], [0, "&timesbar;"], [1, "&smashp;"], [0, "&lotimes;"], [0, "&rotimes;"], [0, "&otimesas;"], [0, "&Otimes;"], [0, "&odiv;"], [0, "&triplus;"], [0, "&triminus;"], [0, "&tritime;"], [0, "&intprod;"], [2, "&amalg;"], [0, "&capdot;"], [1, "&ncup;"], [0, "&ncap;"], [0, "&capand;"], [0, "&cupor;"], [0, "&cupcap;"], [0, "&capcup;"], [0, "&cupbrcap;"], [0, "&capbrcup;"], [0, "&cupcup;"], [0, "&capcap;"], [0, "&ccups;"], [0, "&ccaps;"], [2, "&ccupssm;"], [2, "&And;"], [0, "&Or;"], [0, "&andand;"], [0, "&oror;"], [0, "&orslope;"], [0, "&andslope;"], [1, "&andv;"], [0, "&orv;"], [0, "&andd;"], [0, "&ord;"], [1, "&wedbar;"], [6, "&sdote;"], [3, "&simdot;"], [2, { v: "&congdot;", n: 824, o: "&ncongdot;" }], [0, "&easter;"], [0, "&apacir;"], [0, { v: "&apE;", n: 824, o: "&napE;" }], [0, "&eplus;"], [0, "&pluse;"], [0, "&Esim;"], [0, "&Colone;"], [0, "&Equal;"], [1, "&ddotseq;"], [0, "&equivDD;"], [0, "&ltcir;"], [0, "&gtcir;"], [0, "&ltquest;"], [0, "&gtquest;"], [0, { v: "&leqslant;", n: 824, o: "&nleqslant;" }], [0, { v: "&geqslant;", n: 824, o: "&ngeqslant;" }], [0, "&lesdot;"], [0, "&gesdot;"], [0, "&lesdoto;"], [0, "&gesdoto;"], [0, "&lesdotor;"], [0, "&gesdotol;"], [0, "&lap;"], [0, "&gap;"], [0, "&lne;"], [0, "&gne;"], [0, "&lnap;"], [0, "&gnap;"], [0, "&lEg;"], [0, "&gEl;"], [0, "&lsime;"], [0, "&gsime;"], [0, "&lsimg;"], [0, "&gsiml;"], [0, "&lgE;"], [0, "&glE;"], [0, "&lesges;"], [0, "&gesles;"], [0, "&els;"], [0, "&egs;"], [0, "&elsdot;"], [0, "&egsdot;"], [0, "&el;"], [0, "&eg;"], [2, "&siml;"], [0, "&simg;"], [0, "&simlE;"], [0, "&simgE;"], [0, { v: "&LessLess;", n: 824, o: "&NotNestedLessLess;" }], [0, { v: "&GreaterGreater;", n: 824, o: "&NotNestedGreaterGreater;" }], [1, "&glj;"], [0, "&gla;"], [0, "&ltcc;"], [0, "&gtcc;"], [0, "&lescc;"], [0, "&gescc;"], [0, "&smt;"], [0, "&lat;"], [0, { v: "&smte;", n: 65024, o: "&smtes;" }], [0, { v: "&late;", n: 65024, o: "&lates;" }], [0, "&bumpE;"], [0, { v: "&PrecedesEqual;", n: 824, o: "&NotPrecedesEqual;" }], [0, { v: "&sce;", n: 824, o: "&NotSucceedsEqual;" }], [2, "&prE;"], [0, "&scE;"], [0, "&precneqq;"], [0, "&scnE;"], [0, "&prap;"], [0, "&scap;"], [0, "&precnapprox;"], [0, "&scnap;"], [0, "&Pr;"], [0, "&Sc;"], [0, "&subdot;"], [0, "&supdot;"], [0, "&subplus;"], [0, "&supplus;"], [0, "&submult;"], [0, "&supmult;"], [0, "&subedot;"], [0, "&supedot;"], [0, { v: "&subE;", n: 824, o: "&nsubE;" }], [0, { v: "&supE;", n: 824, o: "&nsupE;" }], [0, "&subsim;"], [0, "&supsim;"], [2, { v: "&subnE;", n: 65024, o: "&varsubsetneqq;" }], [0, { v: "&supnE;", n: 65024, o: "&varsupsetneqq;" }], [2, "&csub;"], [0, "&csup;"], [0, "&csube;"], [0, "&csupe;"], [0, "&subsup;"], [0, "&supsub;"], [0, "&subsub;"], [0, "&supsup;"], [0, "&suphsub;"], [0, "&supdsub;"], [0, "&forkv;"], [0, "&topfork;"], [0, "&mlcp;"], [8, "&Dashv;"], [1, "&Vdashl;"], [0, "&Barv;"], [0, "&vBar;"], [0, "&vBarv;"], [1, "&Vbar;"], [0, "&Not;"], [0, "&bNot;"], [0, "&rnmid;"], [0, "&cirmid;"], [0, "&midcir;"], [0, "&topcir;"], [0, "&nhpar;"], [0, "&parsim;"], [9, { v: "&parsl;", n: 8421, o: "&nparsl;" }], [44343, { n: new Map(/* @__PURE__ */ restoreDiff([[56476, "&Ascr;"], [1, "&Cscr;"], [0, "&Dscr;"], [2, "&Gscr;"], [2, "&Jscr;"], [0, "&Kscr;"], [2, "&Nscr;"], [0, "&Oscr;"], [0, "&Pscr;"], [0, "&Qscr;"], [1, "&Sscr;"], [0, "&Tscr;"], [0, "&Uscr;"], [0, "&Vscr;"], [0, "&Wscr;"], [0, "&Xscr;"], [0, "&Yscr;"], [0, "&Zscr;"], [0, "&ascr;"], [0, "&bscr;"], [0, "&cscr;"], [0, "&dscr;"], [1, "&fscr;"], [1, "&hscr;"], [0, "&iscr;"], [0, "&jscr;"], [0, "&kscr;"], [0, "&lscr;"], [0, "&mscr;"], [0, "&nscr;"], [1, "&pscr;"], [0, "&qscr;"], [0, "&rscr;"], [0, "&sscr;"], [0, "&tscr;"], [0, "&uscr;"], [0, "&vscr;"], [0, "&wscr;"], [0, "&xscr;"], [0, "&yscr;"], [0, "&zscr;"], [52, "&Afr;"], [0, "&Bfr;"], [1, "&Dfr;"], [0, "&Efr;"], [0, "&Ffr;"], [0, "&Gfr;"], [2, "&Jfr;"], [0, "&Kfr;"], [0, "&Lfr;"], [0, "&Mfr;"], [0, "&Nfr;"], [0, "&Ofr;"], [0, "&Pfr;"], [0, "&Qfr;"], [1, "&Sfr;"], [0, "&Tfr;"], [0, "&Ufr;"], [0, "&Vfr;"], [0, "&Wfr;"], [0, "&Xfr;"], [0, "&Yfr;"], [1, "&afr;"], [0, "&bfr;"], [0, "&cfr;"], [0, "&dfr;"], [0, "&efr;"], [0, "&ffr;"], [0, "&gfr;"], [0, "&hfr;"], [0, "&ifr;"], [0, "&jfr;"], [0, "&kfr;"], [0, "&lfr;"], [0, "&mfr;"], [0, "&nfr;"], [0, "&ofr;"], [0, "&pfr;"], [0, "&qfr;"], [0, "&rfr;"], [0, "&sfr;"], [0, "&tfr;"], [0, "&ufr;"], [0, "&vfr;"], [0, "&wfr;"], [0, "&xfr;"], [0, "&yfr;"], [0, "&zfr;"], [0, "&Aopf;"], [0, "&Bopf;"], [1, "&Dopf;"], [0, "&Eopf;"], [0, "&Fopf;"], [0, "&Gopf;"], [1, "&Iopf;"], [0, "&Jopf;"], [0, "&Kopf;"], [0, "&Lopf;"], [0, "&Mopf;"], [1, "&Oopf;"], [3, "&Sopf;"], [0, "&Topf;"], [0, "&Uopf;"], [0, "&Vopf;"], [0, "&Wopf;"], [0, "&Xopf;"], [0, "&Yopf;"], [1, "&aopf;"], [0, "&bopf;"], [0, "&copf;"], [0, "&dopf;"], [0, "&eopf;"], [0, "&fopf;"], [0, "&gopf;"], [0, "&hopf;"], [0, "&iopf;"], [0, "&jopf;"], [0, "&kopf;"], [0, "&lopf;"], [0, "&mopf;"], [0, "&nopf;"], [0, "&oopf;"], [0, "&popf;"], [0, "&qopf;"], [0, "&ropf;"], [0, "&sopf;"], [0, "&topf;"], [0, "&uopf;"], [0, "&vopf;"], [0, "&wopf;"], [0, "&xopf;"], [0, "&yopf;"], [0, "&zopf;"]])) }], [8906, "&fflig;"], [0, "&filig;"], [0, "&fllig;"], [0, "&ffilig;"], [0, "&ffllig;"]]));

  // node_modules/entities/lib/esm/escape.js
  var xmlReplacer = /["&'<>$\x80-\uFFFF]/g;
  var xmlCodeMap = /* @__PURE__ */ new Map([
    [34, "&quot;"],
    [38, "&amp;"],
    [39, "&apos;"],
    [60, "&lt;"],
    [62, "&gt;"]
  ]);
  var getCodePoint = (
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
    String.prototype.codePointAt != null ? (str, index2) => str.codePointAt(index2) : (
      // http://mathiasbynens.be/notes/javascript-encoding#surrogate-formulae
      (c3, index2) => (c3.charCodeAt(index2) & 64512) === 55296 ? (c3.charCodeAt(index2) - 55296) * 1024 + c3.charCodeAt(index2 + 1) - 56320 + 65536 : c3.charCodeAt(index2)
    )
  );
  function encodeXML(str) {
    let ret = "";
    let lastIdx = 0;
    let match;
    while ((match = xmlReplacer.exec(str)) !== null) {
      const i3 = match.index;
      const char = str.charCodeAt(i3);
      const next2 = xmlCodeMap.get(char);
      if (next2 !== void 0) {
        ret += str.substring(lastIdx, i3) + next2;
        lastIdx = i3 + 1;
      } else {
        ret += `${str.substring(lastIdx, i3)}&#x${getCodePoint(str, i3).toString(16)};`;
        lastIdx = xmlReplacer.lastIndex += Number((char & 64512) === 55296);
      }
    }
    return ret + str.substr(lastIdx);
  }
  function getEscaper(regex, map2) {
    return function escape3(data2) {
      let match;
      let lastIdx = 0;
      let result = "";
      while (match = regex.exec(data2)) {
        if (lastIdx !== match.index) {
          result += data2.substring(lastIdx, match.index);
        }
        result += map2.get(match[0].charCodeAt(0));
        lastIdx = match.index + 1;
      }
      return result + data2.substring(lastIdx);
    };
  }
  var escapeUTF8 = getEscaper(/[&<>'"]/g, xmlCodeMap);
  var escapeAttribute = getEscaper(/["&\u00A0]/g, /* @__PURE__ */ new Map([
    [34, "&quot;"],
    [38, "&amp;"],
    [160, "&nbsp;"]
  ]));
  var escapeText = getEscaper(/[&<>\u00A0]/g, /* @__PURE__ */ new Map([
    [38, "&amp;"],
    [60, "&lt;"],
    [62, "&gt;"],
    [160, "&nbsp;"]
  ]));

  // node_modules/entities/lib/esm/index.js
  var EntityLevel;
  (function(EntityLevel2) {
    EntityLevel2[EntityLevel2["XML"] = 0] = "XML";
    EntityLevel2[EntityLevel2["HTML"] = 1] = "HTML";
  })(EntityLevel || (EntityLevel = {}));
  var DecodingMode;
  (function(DecodingMode2) {
    DecodingMode2[DecodingMode2["Legacy"] = 0] = "Legacy";
    DecodingMode2[DecodingMode2["Strict"] = 1] = "Strict";
  })(DecodingMode || (DecodingMode = {}));
  var EncodingMode;
  (function(EncodingMode2) {
    EncodingMode2[EncodingMode2["UTF8"] = 0] = "UTF8";
    EncodingMode2[EncodingMode2["ASCII"] = 1] = "ASCII";
    EncodingMode2[EncodingMode2["Extensive"] = 2] = "Extensive";
    EncodingMode2[EncodingMode2["Attribute"] = 3] = "Attribute";
    EncodingMode2[EncodingMode2["Text"] = 4] = "Text";
  })(EncodingMode || (EncodingMode = {}));

  // node_modules/dom-serializer/lib/esm/foreignNames.js
  var elementNames = new Map([
    "altGlyph",
    "altGlyphDef",
    "altGlyphItem",
    "animateColor",
    "animateMotion",
    "animateTransform",
    "clipPath",
    "feBlend",
    "feColorMatrix",
    "feComponentTransfer",
    "feComposite",
    "feConvolveMatrix",
    "feDiffuseLighting",
    "feDisplacementMap",
    "feDistantLight",
    "feDropShadow",
    "feFlood",
    "feFuncA",
    "feFuncB",
    "feFuncG",
    "feFuncR",
    "feGaussianBlur",
    "feImage",
    "feMerge",
    "feMergeNode",
    "feMorphology",
    "feOffset",
    "fePointLight",
    "feSpecularLighting",
    "feSpotLight",
    "feTile",
    "feTurbulence",
    "foreignObject",
    "glyphRef",
    "linearGradient",
    "radialGradient",
    "textPath"
  ].map((val2) => [val2.toLowerCase(), val2]));
  var attributeNames = new Map([
    "definitionURL",
    "attributeName",
    "attributeType",
    "baseFrequency",
    "baseProfile",
    "calcMode",
    "clipPathUnits",
    "diffuseConstant",
    "edgeMode",
    "filterUnits",
    "glyphRef",
    "gradientTransform",
    "gradientUnits",
    "kernelMatrix",
    "kernelUnitLength",
    "keyPoints",
    "keySplines",
    "keyTimes",
    "lengthAdjust",
    "limitingConeAngle",
    "markerHeight",
    "markerUnits",
    "markerWidth",
    "maskContentUnits",
    "maskUnits",
    "numOctaves",
    "pathLength",
    "patternContentUnits",
    "patternTransform",
    "patternUnits",
    "pointsAtX",
    "pointsAtY",
    "pointsAtZ",
    "preserveAlpha",
    "preserveAspectRatio",
    "primitiveUnits",
    "refX",
    "refY",
    "repeatCount",
    "repeatDur",
    "requiredExtensions",
    "requiredFeatures",
    "specularConstant",
    "specularExponent",
    "spreadMethod",
    "startOffset",
    "stdDeviation",
    "stitchTiles",
    "surfaceScale",
    "systemLanguage",
    "tableValues",
    "targetX",
    "targetY",
    "textLength",
    "viewBox",
    "viewTarget",
    "xChannelSelector",
    "yChannelSelector",
    "zoomAndPan"
  ].map((val2) => [val2.toLowerCase(), val2]));

  // node_modules/dom-serializer/lib/esm/index.js
  var unencodedElements = /* @__PURE__ */ new Set([
    "style",
    "script",
    "xmp",
    "iframe",
    "noembed",
    "noframes",
    "plaintext",
    "noscript"
  ]);
  function replaceQuotes(value) {
    return value.replace(/"/g, "&quot;");
  }
  function formatAttributes(attributes2, opts) {
    var _a2;
    if (!attributes2)
      return;
    const encode = ((_a2 = opts.encodeEntities) !== null && _a2 !== void 0 ? _a2 : opts.decodeEntities) === false ? replaceQuotes : opts.xmlMode || opts.encodeEntities !== "utf8" ? encodeXML : escapeAttribute;
    return Object.keys(attributes2).map((key2) => {
      var _a3, _b;
      const value = (_a3 = attributes2[key2]) !== null && _a3 !== void 0 ? _a3 : "";
      if (opts.xmlMode === "foreign") {
        key2 = (_b = attributeNames.get(key2)) !== null && _b !== void 0 ? _b : key2;
      }
      if (!opts.emptyAttrs && !opts.xmlMode && value === "") {
        return key2;
      }
      return `${key2}="${encode(value)}"`;
    }).join(" ");
  }
  var singleTag = /* @__PURE__ */ new Set([
    "area",
    "base",
    "basefont",
    "br",
    "col",
    "command",
    "embed",
    "frame",
    "hr",
    "img",
    "input",
    "isindex",
    "keygen",
    "link",
    "meta",
    "param",
    "source",
    "track",
    "wbr"
  ]);
  function render(node, options2 = {}) {
    const nodes = "length" in node ? node : [node];
    let output = "";
    for (let i3 = 0; i3 < nodes.length; i3++) {
      output += renderNode(nodes[i3], options2);
    }
    return output;
  }
  var esm_default = render;
  function renderNode(node, options2) {
    switch (node.type) {
      case Root:
        return render(node.children, options2);
      case Doctype:
      case Directive:
        return renderDirective(node);
      case Comment:
        return renderComment(node);
      case CDATA:
        return renderCdata(node);
      case Script:
      case Style:
      case Tag:
        return renderTag(node, options2);
      case Text:
        return renderText(node, options2);
    }
  }
  var foreignModeIntegrationPoints = /* @__PURE__ */ new Set([
    "mi",
    "mo",
    "mn",
    "ms",
    "mtext",
    "annotation-xml",
    "foreignObject",
    "desc",
    "title"
  ]);
  var foreignElements = /* @__PURE__ */ new Set(["svg", "math"]);
  function renderTag(elem, opts) {
    var _a2;
    if (opts.xmlMode === "foreign") {
      elem.name = (_a2 = elementNames.get(elem.name)) !== null && _a2 !== void 0 ? _a2 : elem.name;
      if (elem.parent && foreignModeIntegrationPoints.has(elem.parent.name)) {
        opts = { ...opts, xmlMode: false };
      }
    }
    if (!opts.xmlMode && foreignElements.has(elem.name)) {
      opts = { ...opts, xmlMode: "foreign" };
    }
    let tag = `<${elem.name}`;
    const attribs = formatAttributes(elem.attribs, opts);
    if (attribs) {
      tag += ` ${attribs}`;
    }
    if (elem.children.length === 0 && (opts.xmlMode ? (
      // In XML mode or foreign mode, and user hasn't explicitly turned off self-closing tags
      opts.selfClosingTags !== false
    ) : (
      // User explicitly asked for self-closing tags, even in HTML mode
      opts.selfClosingTags && singleTag.has(elem.name)
    ))) {
      if (!opts.xmlMode)
        tag += " ";
      tag += "/>";
    } else {
      tag += ">";
      if (elem.children.length > 0) {
        tag += render(elem.children, opts);
      }
      if (opts.xmlMode || !singleTag.has(elem.name)) {
        tag += `</${elem.name}>`;
      }
    }
    return tag;
  }
  function renderDirective(elem) {
    return `<${elem.data}>`;
  }
  function renderText(elem, opts) {
    var _a2;
    let data2 = elem.data || "";
    if (((_a2 = opts.encodeEntities) !== null && _a2 !== void 0 ? _a2 : opts.decodeEntities) !== false && !(!opts.xmlMode && elem.parent && unencodedElements.has(elem.parent.name))) {
      data2 = opts.xmlMode || opts.encodeEntities !== "utf8" ? encodeXML(data2) : escapeText(data2);
    }
    return data2;
  }
  function renderCdata(elem) {
    return `<![CDATA[${elem.children[0].data}]]>`;
  }
  function renderComment(elem) {
    return `<!--${elem.data}-->`;
  }

  // node_modules/domutils/lib/esm/stringify.js
  function getOuterHTML(node, options2) {
    return esm_default(node, options2);
  }
  function getInnerHTML(node, options2) {
    return hasChildren(node) ? node.children.map((node2) => getOuterHTML(node2, options2)).join("") : "";
  }
  function getText(node) {
    if (Array.isArray(node))
      return node.map(getText).join("");
    if (isTag2(node))
      return node.name === "br" ? "\n" : getText(node.children);
    if (isCDATA(node))
      return getText(node.children);
    if (isText(node))
      return node.data;
    return "";
  }
  function textContent(node) {
    if (Array.isArray(node))
      return node.map(textContent).join("");
    if (hasChildren(node) && !isComment(node)) {
      return textContent(node.children);
    }
    if (isText(node))
      return node.data;
    return "";
  }
  function innerText(node) {
    if (Array.isArray(node))
      return node.map(innerText).join("");
    if (hasChildren(node) && (node.type === ElementType.Tag || isCDATA(node))) {
      return innerText(node.children);
    }
    if (isText(node))
      return node.data;
    return "";
  }

  // node_modules/domutils/lib/esm/traversal.js
  function getChildren(elem) {
    return hasChildren(elem) ? elem.children : [];
  }
  function getParent(elem) {
    return elem.parent || null;
  }
  function getSiblings(elem) {
    const parent2 = getParent(elem);
    if (parent2 != null)
      return getChildren(parent2);
    const siblings2 = [elem];
    let { prev: prev2, next: next2 } = elem;
    while (prev2 != null) {
      siblings2.unshift(prev2);
      ({ prev: prev2 } = prev2);
    }
    while (next2 != null) {
      siblings2.push(next2);
      ({ next: next2 } = next2);
    }
    return siblings2;
  }
  function getAttributeValue(elem, name) {
    var _a2;
    return (_a2 = elem.attribs) === null || _a2 === void 0 ? void 0 : _a2[name];
  }
  function hasAttrib(elem, name) {
    return elem.attribs != null && Object.prototype.hasOwnProperty.call(elem.attribs, name) && elem.attribs[name] != null;
  }
  function getName(elem) {
    return elem.name;
  }
  function nextElementSibling(elem) {
    let { next: next2 } = elem;
    while (next2 !== null && !isTag2(next2))
      ({ next: next2 } = next2);
    return next2;
  }
  function prevElementSibling(elem) {
    let { prev: prev2 } = elem;
    while (prev2 !== null && !isTag2(prev2))
      ({ prev: prev2 } = prev2);
    return prev2;
  }

  // node_modules/domutils/lib/esm/manipulation.js
  function removeElement(elem) {
    if (elem.prev)
      elem.prev.next = elem.next;
    if (elem.next)
      elem.next.prev = elem.prev;
    if (elem.parent) {
      const childs = elem.parent.children;
      childs.splice(childs.lastIndexOf(elem), 1);
    }
  }
  function replaceElement(elem, replacement) {
    const prev2 = replacement.prev = elem.prev;
    if (prev2) {
      prev2.next = replacement;
    }
    const next2 = replacement.next = elem.next;
    if (next2) {
      next2.prev = replacement;
    }
    const parent2 = replacement.parent = elem.parent;
    if (parent2) {
      const childs = parent2.children;
      childs[childs.lastIndexOf(elem)] = replacement;
      elem.parent = null;
    }
  }
  function appendChild(elem, child) {
    removeElement(child);
    child.next = null;
    child.parent = elem;
    if (elem.children.push(child) > 1) {
      const sibling = elem.children[elem.children.length - 2];
      sibling.next = child;
      child.prev = sibling;
    } else {
      child.prev = null;
    }
  }
  function append(elem, next2) {
    removeElement(next2);
    const { parent: parent2 } = elem;
    const currNext = elem.next;
    next2.next = currNext;
    next2.prev = elem;
    elem.next = next2;
    next2.parent = parent2;
    if (currNext) {
      currNext.prev = next2;
      if (parent2) {
        const childs = parent2.children;
        childs.splice(childs.lastIndexOf(currNext), 0, next2);
      }
    } else if (parent2) {
      parent2.children.push(next2);
    }
  }
  function prependChild(elem, child) {
    removeElement(child);
    child.parent = elem;
    child.prev = null;
    if (elem.children.unshift(child) !== 1) {
      const sibling = elem.children[1];
      sibling.prev = child;
      child.next = sibling;
    } else {
      child.next = null;
    }
  }
  function prepend(elem, prev2) {
    removeElement(prev2);
    const { parent: parent2 } = elem;
    if (parent2) {
      const childs = parent2.children;
      childs.splice(childs.indexOf(elem), 0, prev2);
    }
    if (elem.prev) {
      elem.prev.next = prev2;
    }
    prev2.parent = parent2;
    prev2.prev = elem.prev;
    prev2.next = elem;
    elem.prev = prev2;
  }

  // node_modules/domutils/lib/esm/querying.js
  function filter(test, node, recurse = true, limit = Infinity) {
    if (!Array.isArray(node))
      node = [node];
    return find(test, node, recurse, limit);
  }
  function find(test, nodes, recurse, limit) {
    const result = [];
    for (const elem of nodes) {
      if (test(elem)) {
        result.push(elem);
        if (--limit <= 0)
          break;
      }
      if (recurse && hasChildren(elem) && elem.children.length > 0) {
        const children2 = find(test, elem.children, recurse, limit);
        result.push(...children2);
        limit -= children2.length;
        if (limit <= 0)
          break;
      }
    }
    return result;
  }
  function findOneChild(test, nodes) {
    return nodes.find(test);
  }
  function findOne(test, nodes, recurse = true) {
    let elem = null;
    for (let i3 = 0; i3 < nodes.length && !elem; i3++) {
      const checked = nodes[i3];
      if (!isTag2(checked)) {
        continue;
      } else if (test(checked)) {
        elem = checked;
      } else if (recurse && checked.children.length > 0) {
        elem = findOne(test, checked.children, true);
      }
    }
    return elem;
  }
  function existsOne(test, nodes) {
    return nodes.some((checked) => isTag2(checked) && (test(checked) || checked.children.length > 0 && existsOne(test, checked.children)));
  }
  function findAll(test, nodes) {
    var _a2;
    const result = [];
    const stack = nodes.filter(isTag2);
    let elem;
    while (elem = stack.shift()) {
      const children2 = (_a2 = elem.children) === null || _a2 === void 0 ? void 0 : _a2.filter(isTag2);
      if (children2 && children2.length > 0) {
        stack.unshift(...children2);
      }
      if (test(elem))
        result.push(elem);
    }
    return result;
  }

  // node_modules/domutils/lib/esm/legacy.js
  var Checks = {
    tag_name(name) {
      if (typeof name === "function") {
        return (elem) => isTag2(elem) && name(elem.name);
      } else if (name === "*") {
        return isTag2;
      }
      return (elem) => isTag2(elem) && elem.name === name;
    },
    tag_type(type) {
      if (typeof type === "function") {
        return (elem) => type(elem.type);
      }
      return (elem) => elem.type === type;
    },
    tag_contains(data2) {
      if (typeof data2 === "function") {
        return (elem) => isText(elem) && data2(elem.data);
      }
      return (elem) => isText(elem) && elem.data === data2;
    }
  };
  function getAttribCheck(attrib, value) {
    if (typeof value === "function") {
      return (elem) => isTag2(elem) && value(elem.attribs[attrib]);
    }
    return (elem) => isTag2(elem) && elem.attribs[attrib] === value;
  }
  function combineFuncs(a3, b3) {
    return (elem) => a3(elem) || b3(elem);
  }
  function compileTest(options2) {
    const funcs = Object.keys(options2).map((key2) => {
      const value = options2[key2];
      return Object.prototype.hasOwnProperty.call(Checks, key2) ? Checks[key2](value) : getAttribCheck(key2, value);
    });
    return funcs.length === 0 ? null : funcs.reduce(combineFuncs);
  }
  function testElement(options2, node) {
    const test = compileTest(options2);
    return test ? test(node) : true;
  }
  function getElements(options2, nodes, recurse, limit = Infinity) {
    const test = compileTest(options2);
    return test ? filter(test, nodes, recurse, limit) : [];
  }
  function getElementById(id, nodes, recurse = true) {
    if (!Array.isArray(nodes))
      nodes = [nodes];
    return findOne(getAttribCheck("id", id), nodes, recurse);
  }
  function getElementsByTagName(tagName18, nodes, recurse = true, limit = Infinity) {
    return filter(Checks["tag_name"](tagName18), nodes, recurse, limit);
  }
  function getElementsByTagType(type, nodes, recurse = true, limit = Infinity) {
    return filter(Checks["tag_type"](type), nodes, recurse, limit);
  }

  // node_modules/domutils/lib/esm/helpers.js
  function removeSubsets(nodes) {
    let idx = nodes.length;
    while (--idx >= 0) {
      const node = nodes[idx];
      if (idx > 0 && nodes.lastIndexOf(node, idx - 1) >= 0) {
        nodes.splice(idx, 1);
        continue;
      }
      for (let ancestor = node.parent; ancestor; ancestor = ancestor.parent) {
        if (nodes.includes(ancestor)) {
          nodes.splice(idx, 1);
          break;
        }
      }
    }
    return nodes;
  }
  var DocumentPosition;
  (function(DocumentPosition2) {
    DocumentPosition2[DocumentPosition2["DISCONNECTED"] = 1] = "DISCONNECTED";
    DocumentPosition2[DocumentPosition2["PRECEDING"] = 2] = "PRECEDING";
    DocumentPosition2[DocumentPosition2["FOLLOWING"] = 4] = "FOLLOWING";
    DocumentPosition2[DocumentPosition2["CONTAINS"] = 8] = "CONTAINS";
    DocumentPosition2[DocumentPosition2["CONTAINED_BY"] = 16] = "CONTAINED_BY";
  })(DocumentPosition || (DocumentPosition = {}));
  function compareDocumentPosition(nodeA, nodeB) {
    const aParents = [];
    const bParents = [];
    if (nodeA === nodeB) {
      return 0;
    }
    let current = hasChildren(nodeA) ? nodeA : nodeA.parent;
    while (current) {
      aParents.unshift(current);
      current = current.parent;
    }
    current = hasChildren(nodeB) ? nodeB : nodeB.parent;
    while (current) {
      bParents.unshift(current);
      current = current.parent;
    }
    const maxIdx = Math.min(aParents.length, bParents.length);
    let idx = 0;
    while (idx < maxIdx && aParents[idx] === bParents[idx]) {
      idx++;
    }
    if (idx === 0) {
      return DocumentPosition.DISCONNECTED;
    }
    const sharedParent = aParents[idx - 1];
    const siblings2 = sharedParent.children;
    const aSibling = aParents[idx];
    const bSibling = bParents[idx];
    if (siblings2.indexOf(aSibling) > siblings2.indexOf(bSibling)) {
      if (sharedParent === nodeB) {
        return DocumentPosition.FOLLOWING | DocumentPosition.CONTAINED_BY;
      }
      return DocumentPosition.FOLLOWING;
    }
    if (sharedParent === nodeA) {
      return DocumentPosition.PRECEDING | DocumentPosition.CONTAINS;
    }
    return DocumentPosition.PRECEDING;
  }
  function uniqueSort(nodes) {
    nodes = nodes.filter((node, i3, arr) => !arr.includes(node, i3 + 1));
    nodes.sort((a3, b3) => {
      const relative = compareDocumentPosition(a3, b3);
      if (relative & DocumentPosition.PRECEDING) {
        return -1;
      } else if (relative & DocumentPosition.FOLLOWING) {
        return 1;
      }
      return 0;
    });
    return nodes;
  }

  // node_modules/domutils/lib/esm/feeds.js
  function getFeed(doc) {
    const feedRoot = getOneElement(isValidFeed, doc);
    return !feedRoot ? null : feedRoot.name === "feed" ? getAtomFeed(feedRoot) : getRssFeed(feedRoot);
  }
  function getAtomFeed(feedRoot) {
    var _a2;
    const childs = feedRoot.children;
    const feed = {
      type: "atom",
      items: getElementsByTagName("entry", childs).map((item) => {
        var _a3;
        const { children: children2 } = item;
        const entry = { media: getMediaElements(children2) };
        addConditionally(entry, "id", "id", children2);
        addConditionally(entry, "title", "title", children2);
        const href2 = (_a3 = getOneElement("link", children2)) === null || _a3 === void 0 ? void 0 : _a3.attribs["href"];
        if (href2) {
          entry.link = href2;
        }
        const description = fetch2("summary", children2) || fetch2("content", children2);
        if (description) {
          entry.description = description;
        }
        const pubDate = fetch2("updated", children2);
        if (pubDate) {
          entry.pubDate = new Date(pubDate);
        }
        return entry;
      })
    };
    addConditionally(feed, "id", "id", childs);
    addConditionally(feed, "title", "title", childs);
    const href = (_a2 = getOneElement("link", childs)) === null || _a2 === void 0 ? void 0 : _a2.attribs["href"];
    if (href) {
      feed.link = href;
    }
    addConditionally(feed, "description", "subtitle", childs);
    const updated = fetch2("updated", childs);
    if (updated) {
      feed.updated = new Date(updated);
    }
    addConditionally(feed, "author", "email", childs, true);
    return feed;
  }
  function getRssFeed(feedRoot) {
    var _a2, _b;
    const childs = (_b = (_a2 = getOneElement("channel", feedRoot.children)) === null || _a2 === void 0 ? void 0 : _a2.children) !== null && _b !== void 0 ? _b : [];
    const feed = {
      type: feedRoot.name.substr(0, 3),
      id: "",
      items: getElementsByTagName("item", feedRoot.children).map((item) => {
        const { children: children2 } = item;
        const entry = { media: getMediaElements(children2) };
        addConditionally(entry, "id", "guid", children2);
        addConditionally(entry, "title", "title", children2);
        addConditionally(entry, "link", "link", children2);
        addConditionally(entry, "description", "description", children2);
        const pubDate = fetch2("pubDate", children2);
        if (pubDate)
          entry.pubDate = new Date(pubDate);
        return entry;
      })
    };
    addConditionally(feed, "title", "title", childs);
    addConditionally(feed, "link", "link", childs);
    addConditionally(feed, "description", "description", childs);
    const updated = fetch2("lastBuildDate", childs);
    if (updated) {
      feed.updated = new Date(updated);
    }
    addConditionally(feed, "author", "managingEditor", childs, true);
    return feed;
  }
  var MEDIA_KEYS_STRING = ["url", "type", "lang"];
  var MEDIA_KEYS_INT = [
    "fileSize",
    "bitrate",
    "framerate",
    "samplingrate",
    "channels",
    "duration",
    "height",
    "width"
  ];
  function getMediaElements(where) {
    return getElementsByTagName("media:content", where).map((elem) => {
      const { attribs } = elem;
      const media = {
        medium: attribs["medium"],
        isDefault: !!attribs["isDefault"]
      };
      for (const attrib of MEDIA_KEYS_STRING) {
        if (attribs[attrib]) {
          media[attrib] = attribs[attrib];
        }
      }
      for (const attrib of MEDIA_KEYS_INT) {
        if (attribs[attrib]) {
          media[attrib] = parseInt(attribs[attrib], 10);
        }
      }
      if (attribs["expression"]) {
        media.expression = attribs["expression"];
      }
      return media;
    });
  }
  function getOneElement(tagName18, node) {
    return getElementsByTagName(tagName18, node, true, 1)[0];
  }
  function fetch2(tagName18, where, recurse = false) {
    return textContent(getElementsByTagName(tagName18, where, recurse, 1)).trim();
  }
  function addConditionally(obj, prop3, tagName18, where, recurse = false) {
    const val2 = fetch2(tagName18, where, recurse);
    if (val2)
      obj[prop3] = val2;
  }
  function isValidFeed(value) {
    return value === "rss" || value === "feed" || value === "rdf:RDF";
  }

  // node_modules/cheerio/lib/esm/static.js
  function render2(that, dom, options2) {
    if (!that)
      return "";
    return that(dom !== null && dom !== void 0 ? dom : that._root.children, null, void 0, options2).toString();
  }
  function isOptions(dom, options2) {
    return !options2 && typeof dom === "object" && dom != null && !("length" in dom) && !("type" in dom);
  }
  function html(dom, options2) {
    const toRender = isOptions(dom) ? (options2 = dom, void 0) : dom;
    const opts = {
      ...options_default,
      ...this === null || this === void 0 ? void 0 : this._options,
      ...flatten(options2 !== null && options2 !== void 0 ? options2 : {})
    };
    return render2(this, toRender, opts);
  }
  function xml(dom) {
    const options2 = { ...this._options, xmlMode: true };
    return render2(this, dom, options2);
  }
  function text(elements) {
    const elems = elements ? elements : this ? this.root() : [];
    let ret = "";
    for (let i3 = 0; i3 < elems.length; i3++) {
      ret += textContent(elems[i3]);
    }
    return ret;
  }
  function parseHTML(data2, context, keepScripts = typeof context === "boolean" ? context : false) {
    if (!data2 || typeof data2 !== "string") {
      return null;
    }
    if (typeof context === "boolean") {
      keepScripts = context;
    }
    const parsed = this.load(data2, options_default, false);
    if (!keepScripts) {
      parsed("script").remove();
    }
    return parsed.root()[0].children.slice();
  }
  function root2() {
    return this(this._root);
  }
  function contains(container, contained) {
    if (contained === container) {
      return false;
    }
    let next2 = contained;
    while (next2 && next2 !== next2.parent) {
      next2 = next2.parent;
      if (next2 === container) {
        return true;
      }
    }
    return false;
  }
  function merge(arr1, arr2) {
    if (!isArrayLike2(arr1) || !isArrayLike2(arr2)) {
      return;
    }
    let newLength = arr1.length;
    const len = +arr2.length;
    for (let i3 = 0; i3 < len; i3++) {
      arr1[newLength++] = arr2[i3];
    }
    arr1.length = newLength;
    return arr1;
  }
  function isArrayLike2(item) {
    if (Array.isArray(item)) {
      return true;
    }
    if (typeof item !== "object" || !Object.prototype.hasOwnProperty.call(item, "length") || typeof item.length !== "number" || item.length < 0) {
      return false;
    }
    for (let i3 = 0; i3 < item.length; i3++) {
      if (!(i3 in item)) {
        return false;
      }
    }
    return true;
  }

  // node_modules/cheerio/lib/esm/api/attributes.js
  var attributes_exports = {};
  __export(attributes_exports, {
    addClass: () => addClass,
    attr: () => attr,
    data: () => data,
    hasClass: () => hasClass,
    prop: () => prop,
    removeAttr: () => removeAttr,
    removeClass: () => removeClass,
    toggleClass: () => toggleClass,
    val: () => val
  });

  // node_modules/cheerio/lib/esm/utils.js
  function isCheerio(maybeCheerio) {
    return maybeCheerio.cheerio != null;
  }
  function camelCase(str) {
    return str.replace(/[_.-](\w|$)/g, (_2, x) => x.toUpperCase());
  }
  function cssCase(str) {
    return str.replace(/[A-Z]/g, "-$&").toLowerCase();
  }
  function domEach(array, fn) {
    const len = array.length;
    for (let i3 = 0; i3 < len; i3++)
      fn(array[i3], i3);
    return array;
  }
  function cloneDom(dom) {
    const clone2 = "length" in dom ? Array.prototype.map.call(dom, (el) => cloneNode(el, true)) : [cloneNode(dom, true)];
    const root4 = new Document(clone2);
    clone2.forEach((node) => {
      node.parent = root4;
    });
    return clone2;
  }
  var CharacterCodes;
  (function(CharacterCodes2) {
    CharacterCodes2[CharacterCodes2["LowerA"] = 97] = "LowerA";
    CharacterCodes2[CharacterCodes2["LowerZ"] = 122] = "LowerZ";
    CharacterCodes2[CharacterCodes2["UpperA"] = 65] = "UpperA";
    CharacterCodes2[CharacterCodes2["UpperZ"] = 90] = "UpperZ";
    CharacterCodes2[CharacterCodes2["Exclamation"] = 33] = "Exclamation";
  })(CharacterCodes || (CharacterCodes = {}));
  function isHtml(str) {
    const tagStart = str.indexOf("<");
    if (tagStart < 0 || tagStart > str.length - 3)
      return false;
    const tagChar = str.charCodeAt(tagStart + 1);
    return (tagChar >= CharacterCodes.LowerA && tagChar <= CharacterCodes.LowerZ || tagChar >= CharacterCodes.UpperA && tagChar <= CharacterCodes.UpperZ || tagChar === CharacterCodes.Exclamation) && str.includes(">", tagStart + 2);
  }

  // node_modules/cheerio/lib/esm/api/attributes.js
  var hasOwn = Object.prototype.hasOwnProperty;
  var rspace = /\s+/;
  var dataAttrPrefix = "data-";
  var primitives = {
    null: null,
    true: true,
    false: false
  };
  var rboolean = /^(?:autofocus|autoplay|async|checked|controls|defer|disabled|hidden|loop|multiple|open|readonly|required|scoped|selected)$/i;
  var rbrace = /^{[^]*}$|^\[[^]*]$/;
  function getAttr(elem, name, xmlMode) {
    var _a2;
    if (!elem || !isTag2(elem))
      return void 0;
    (_a2 = elem.attribs) !== null && _a2 !== void 0 ? _a2 : elem.attribs = {};
    if (!name) {
      return elem.attribs;
    }
    if (hasOwn.call(elem.attribs, name)) {
      return !xmlMode && rboolean.test(name) ? name : elem.attribs[name];
    }
    if (elem.name === "option" && name === "value") {
      return text(elem.children);
    }
    if (elem.name === "input" && (elem.attribs["type"] === "radio" || elem.attribs["type"] === "checkbox") && name === "value") {
      return "on";
    }
    return void 0;
  }
  function setAttr(el, name, value) {
    if (value === null) {
      removeAttribute(el, name);
    } else {
      el.attribs[name] = `${value}`;
    }
  }
  function attr(name, value) {
    if (typeof name === "object" || value !== void 0) {
      if (typeof value === "function") {
        if (typeof name !== "string") {
          {
            throw new Error("Bad combination of arguments.");
          }
        }
        return domEach(this, (el, i3) => {
          if (isTag2(el))
            setAttr(el, name, value.call(el, i3, el.attribs[name]));
        });
      }
      return domEach(this, (el) => {
        if (!isTag2(el))
          return;
        if (typeof name === "object") {
          Object.keys(name).forEach((objName) => {
            const objValue = name[objName];
            setAttr(el, objName, objValue);
          });
        } else {
          setAttr(el, name, value);
        }
      });
    }
    return arguments.length > 1 ? this : getAttr(this[0], name, this.options.xmlMode);
  }
  function getProp(el, name, xmlMode) {
    return name in el ? (
      // @ts-expect-error TS doesn't like us accessing the value directly here.
      el[name]
    ) : !xmlMode && rboolean.test(name) ? getAttr(el, name, false) !== void 0 : getAttr(el, name, xmlMode);
  }
  function setProp(el, name, value, xmlMode) {
    if (name in el) {
      el[name] = value;
    } else {
      setAttr(el, name, !xmlMode && rboolean.test(name) ? value ? "" : null : `${value}`);
    }
  }
  function prop(name, value) {
    var _a2;
    if (typeof name === "string" && value === void 0) {
      const el = this[0];
      if (!el || !isTag2(el))
        return void 0;
      switch (name) {
        case "style": {
          const property = this.css();
          const keys2 = Object.keys(property);
          keys2.forEach((p3, i3) => {
            property[i3] = p3;
          });
          property.length = keys2.length;
          return property;
        }
        case "tagName":
        case "nodeName": {
          return el.name.toUpperCase();
        }
        case "href":
        case "src": {
          const prop3 = (_a2 = el.attribs) === null || _a2 === void 0 ? void 0 : _a2[name];
          if (typeof URL !== "undefined" && (name === "href" && (el.tagName === "a" || el.name === "link") || name === "src" && (el.tagName === "img" || el.tagName === "iframe" || el.tagName === "audio" || el.tagName === "video" || el.tagName === "source")) && prop3 !== void 0 && this.options.baseURI) {
            return new URL(prop3, this.options.baseURI).href;
          }
          return prop3;
        }
        case "innerText": {
          return innerText(el);
        }
        case "textContent": {
          return textContent(el);
        }
        case "outerHTML":
          return this.clone().wrap("<container />").parent().html();
        case "innerHTML":
          return this.html();
        default:
          return getProp(el, name, this.options.xmlMode);
      }
    }
    if (typeof name === "object" || value !== void 0) {
      if (typeof value === "function") {
        if (typeof name === "object") {
          throw new Error("Bad combination of arguments.");
        }
        return domEach(this, (el, i3) => {
          if (isTag2(el)) {
            setProp(el, name, value.call(el, i3, getProp(el, name, this.options.xmlMode)), this.options.xmlMode);
          }
        });
      }
      return domEach(this, (el) => {
        if (!isTag2(el))
          return;
        if (typeof name === "object") {
          Object.keys(name).forEach((key2) => {
            const val2 = name[key2];
            setProp(el, key2, val2, this.options.xmlMode);
          });
        } else {
          setProp(el, name, value, this.options.xmlMode);
        }
      });
    }
    return void 0;
  }
  function setData(el, name, value) {
    var _a2;
    const elem = el;
    (_a2 = elem.data) !== null && _a2 !== void 0 ? _a2 : elem.data = {};
    if (typeof name === "object")
      Object.assign(elem.data, name);
    else if (typeof name === "string" && value !== void 0) {
      elem.data[name] = value;
    }
  }
  function readData(el, name) {
    let domNames;
    let jsNames;
    let value;
    if (name == null) {
      domNames = Object.keys(el.attribs).filter((attrName) => attrName.startsWith(dataAttrPrefix));
      jsNames = domNames.map((domName) => camelCase(domName.slice(dataAttrPrefix.length)));
    } else {
      domNames = [dataAttrPrefix + cssCase(name)];
      jsNames = [name];
    }
    for (let idx = 0; idx < domNames.length; ++idx) {
      const domName = domNames[idx];
      const jsName = jsNames[idx];
      if (hasOwn.call(el.attribs, domName) && !hasOwn.call(el.data, jsName)) {
        value = el.attribs[domName];
        if (hasOwn.call(primitives, value)) {
          value = primitives[value];
        } else if (value === String(Number(value))) {
          value = Number(value);
        } else if (rbrace.test(value)) {
          try {
            value = JSON.parse(value);
          } catch (e3) {
          }
        }
        el.data[jsName] = value;
      }
    }
    return name == null ? el.data : value;
  }
  function data(name, value) {
    var _a2;
    const elem = this[0];
    if (!elem || !isTag2(elem))
      return;
    const dataEl = elem;
    (_a2 = dataEl.data) !== null && _a2 !== void 0 ? _a2 : dataEl.data = {};
    if (!name) {
      return readData(dataEl);
    }
    if (typeof name === "object" || value !== void 0) {
      domEach(this, (el) => {
        if (isTag2(el)) {
          if (typeof name === "object")
            setData(el, name);
          else
            setData(el, name, value);
        }
      });
      return this;
    }
    if (hasOwn.call(dataEl.data, name)) {
      return dataEl.data[name];
    }
    return readData(dataEl, name);
  }
  function val(value) {
    const querying = arguments.length === 0;
    const element = this[0];
    if (!element || !isTag2(element))
      return querying ? void 0 : this;
    switch (element.name) {
      case "textarea":
        return this.text(value);
      case "select": {
        const option = this.find("option:selected");
        if (!querying) {
          if (this.attr("multiple") == null && typeof value === "object") {
            return this;
          }
          this.find("option").removeAttr("selected");
          const values = typeof value !== "object" ? [value] : value;
          for (let i3 = 0; i3 < values.length; i3++) {
            this.find(`option[value="${values[i3]}"]`).attr("selected", "");
          }
          return this;
        }
        return this.attr("multiple") ? option.toArray().map((el) => text(el.children)) : option.attr("value");
      }
      case "input":
      case "option":
        return querying ? this.attr("value") : this.attr("value", value);
    }
    return void 0;
  }
  function removeAttribute(elem, name) {
    if (!elem.attribs || !hasOwn.call(elem.attribs, name))
      return;
    delete elem.attribs[name];
  }
  function splitNames(names) {
    return names ? names.trim().split(rspace) : [];
  }
  function removeAttr(name) {
    const attrNames = splitNames(name);
    for (let i3 = 0; i3 < attrNames.length; i3++) {
      domEach(this, (elem) => {
        if (isTag2(elem))
          removeAttribute(elem, attrNames[i3]);
      });
    }
    return this;
  }
  function hasClass(className) {
    return this.toArray().some((elem) => {
      const clazz = isTag2(elem) && elem.attribs["class"];
      let idx = -1;
      if (clazz && className.length) {
        while ((idx = clazz.indexOf(className, idx + 1)) > -1) {
          const end2 = idx + className.length;
          if ((idx === 0 || rspace.test(clazz[idx - 1])) && (end2 === clazz.length || rspace.test(clazz[end2]))) {
            return true;
          }
        }
      }
      return false;
    });
  }
  function addClass(value) {
    if (typeof value === "function") {
      return domEach(this, (el, i3) => {
        if (isTag2(el)) {
          const className = el.attribs["class"] || "";
          addClass.call([el], value.call(el, i3, className));
        }
      });
    }
    if (!value || typeof value !== "string")
      return this;
    const classNames2 = value.split(rspace);
    const numElements = this.length;
    for (let i3 = 0; i3 < numElements; i3++) {
      const el = this[i3];
      if (!isTag2(el))
        continue;
      const className = getAttr(el, "class", false);
      if (!className) {
        setAttr(el, "class", classNames2.join(" ").trim());
      } else {
        let setClass = ` ${className} `;
        for (let j3 = 0; j3 < classNames2.length; j3++) {
          const appendClass = `${classNames2[j3]} `;
          if (!setClass.includes(` ${appendClass}`))
            setClass += appendClass;
        }
        setAttr(el, "class", setClass.trim());
      }
    }
    return this;
  }
  function removeClass(name) {
    if (typeof name === "function") {
      return domEach(this, (el, i3) => {
        if (isTag2(el)) {
          removeClass.call([el], name.call(el, i3, el.attribs["class"] || ""));
        }
      });
    }
    const classes = splitNames(name);
    const numClasses = classes.length;
    const removeAll = arguments.length === 0;
    return domEach(this, (el) => {
      if (!isTag2(el))
        return;
      if (removeAll) {
        el.attribs["class"] = "";
      } else {
        const elClasses = splitNames(el.attribs["class"]);
        let changed = false;
        for (let j3 = 0; j3 < numClasses; j3++) {
          const index2 = elClasses.indexOf(classes[j3]);
          if (index2 >= 0) {
            elClasses.splice(index2, 1);
            changed = true;
            j3--;
          }
        }
        if (changed) {
          el.attribs["class"] = elClasses.join(" ");
        }
      }
    });
  }
  function toggleClass(value, stateVal) {
    if (typeof value === "function") {
      return domEach(this, (el, i3) => {
        if (isTag2(el)) {
          toggleClass.call([el], value.call(el, i3, el.attribs["class"] || "", stateVal), stateVal);
        }
      });
    }
    if (!value || typeof value !== "string")
      return this;
    const classNames2 = value.split(rspace);
    const numClasses = classNames2.length;
    const state = typeof stateVal === "boolean" ? stateVal ? 1 : -1 : 0;
    const numElements = this.length;
    for (let i3 = 0; i3 < numElements; i3++) {
      const el = this[i3];
      if (!isTag2(el))
        continue;
      const elementClasses = splitNames(el.attribs["class"]);
      for (let j3 = 0; j3 < numClasses; j3++) {
        const index2 = elementClasses.indexOf(classNames2[j3]);
        if (state >= 0 && index2 < 0) {
          elementClasses.push(classNames2[j3]);
        } else if (state <= 0 && index2 >= 0) {
          elementClasses.splice(index2, 1);
        }
      }
      el.attribs["class"] = elementClasses.join(" ");
    }
    return this;
  }

  // node_modules/cheerio/lib/esm/api/traversing.js
  var traversing_exports = {};
  __export(traversing_exports, {
    add: () => add,
    addBack: () => addBack,
    children: () => children,
    closest: () => closest,
    contents: () => contents,
    each: () => each,
    end: () => end,
    eq: () => eq2,
    filter: () => filter3,
    filterArray: () => filterArray,
    find: () => find3,
    first: () => first,
    get: () => get,
    has: () => has,
    index: () => index,
    is: () => is4,
    last: () => last,
    map: () => map,
    next: () => next,
    nextAll: () => nextAll,
    nextUntil: () => nextUntil,
    not: () => not,
    parent: () => parent,
    parents: () => parents,
    parentsUntil: () => parentsUntil,
    prev: () => prev,
    prevAll: () => prevAll,
    prevUntil: () => prevUntil,
    siblings: () => siblings,
    slice: () => slice,
    toArray: () => toArray
  });

  // node_modules/css-what/lib/es/types.js
  var SelectorType;
  (function(SelectorType2) {
    SelectorType2["Attribute"] = "attribute";
    SelectorType2["Pseudo"] = "pseudo";
    SelectorType2["PseudoElement"] = "pseudo-element";
    SelectorType2["Tag"] = "tag";
    SelectorType2["Universal"] = "universal";
    SelectorType2["Adjacent"] = "adjacent";
    SelectorType2["Child"] = "child";
    SelectorType2["Descendant"] = "descendant";
    SelectorType2["Parent"] = "parent";
    SelectorType2["Sibling"] = "sibling";
    SelectorType2["ColumnCombinator"] = "column-combinator";
  })(SelectorType || (SelectorType = {}));
  var AttributeAction;
  (function(AttributeAction2) {
    AttributeAction2["Any"] = "any";
    AttributeAction2["Element"] = "element";
    AttributeAction2["End"] = "end";
    AttributeAction2["Equals"] = "equals";
    AttributeAction2["Exists"] = "exists";
    AttributeAction2["Hyphen"] = "hyphen";
    AttributeAction2["Not"] = "not";
    AttributeAction2["Start"] = "start";
  })(AttributeAction || (AttributeAction = {}));

  // node_modules/css-what/lib/es/parse.js
  var reName = /^[^\\#]?(?:\\(?:[\da-f]{1,6}\s?|.)|[\w\-\u00b0-\uFFFF])+/;
  var reEscape = /\\([\da-f]{1,6}\s?|(\s)|.)/gi;
  var actionTypes = /* @__PURE__ */ new Map([
    [126, AttributeAction.Element],
    [94, AttributeAction.Start],
    [36, AttributeAction.End],
    [42, AttributeAction.Any],
    [33, AttributeAction.Not],
    [124, AttributeAction.Hyphen]
  ]);
  var unpackPseudos = /* @__PURE__ */ new Set([
    "has",
    "not",
    "matches",
    "is",
    "where",
    "host",
    "host-context"
  ]);
  function isTraversal(selector) {
    switch (selector.type) {
      case SelectorType.Adjacent:
      case SelectorType.Child:
      case SelectorType.Descendant:
      case SelectorType.Parent:
      case SelectorType.Sibling:
      case SelectorType.ColumnCombinator:
        return true;
      default:
        return false;
    }
  }
  var stripQuotesFromPseudos = /* @__PURE__ */ new Set(["contains", "icontains"]);
  function funescape(_2, escaped, escapedWhitespace) {
    const high = parseInt(escaped, 16) - 65536;
    return high !== high || escapedWhitespace ? escaped : high < 0 ? (
      // BMP codepoint
      String.fromCharCode(high + 65536)
    ) : (
      // Supplemental Plane codepoint (surrogate pair)
      String.fromCharCode(high >> 10 | 55296, high & 1023 | 56320)
    );
  }
  function unescapeCSS(str) {
    return str.replace(reEscape, funescape);
  }
  function isQuote(c3) {
    return c3 === 39 || c3 === 34;
  }
  function isWhitespace(c3) {
    return c3 === 32 || c3 === 9 || c3 === 10 || c3 === 12 || c3 === 13;
  }
  function parse(selector) {
    const subselects2 = [];
    const endIndex = parseSelector(subselects2, `${selector}`, 0);
    if (endIndex < selector.length) {
      throw new Error(`Unmatched selector: ${selector.slice(endIndex)}`);
    }
    return subselects2;
  }
  function parseSelector(subselects2, selector, selectorIndex) {
    let tokens = [];
    function getName3(offset) {
      const match = selector.slice(selectorIndex + offset).match(reName);
      if (!match) {
        throw new Error(`Expected name, found ${selector.slice(selectorIndex)}`);
      }
      const [name] = match;
      selectorIndex += offset + name.length;
      return unescapeCSS(name);
    }
    function stripWhitespace(offset) {
      selectorIndex += offset;
      while (selectorIndex < selector.length && isWhitespace(selector.charCodeAt(selectorIndex))) {
        selectorIndex++;
      }
    }
    function readValueWithParenthesis() {
      selectorIndex += 1;
      const start = selectorIndex;
      let counter = 1;
      for (; counter > 0 && selectorIndex < selector.length; selectorIndex++) {
        if (selector.charCodeAt(selectorIndex) === 40 && !isEscaped(selectorIndex)) {
          counter++;
        } else if (selector.charCodeAt(selectorIndex) === 41 && !isEscaped(selectorIndex)) {
          counter--;
        }
      }
      if (counter) {
        throw new Error("Parenthesis not matched");
      }
      return unescapeCSS(selector.slice(start, selectorIndex - 1));
    }
    function isEscaped(pos) {
      let slashCount = 0;
      while (selector.charCodeAt(--pos) === 92)
        slashCount++;
      return (slashCount & 1) === 1;
    }
    function ensureNotTraversal() {
      if (tokens.length > 0 && isTraversal(tokens[tokens.length - 1])) {
        throw new Error("Did not expect successive traversals.");
      }
    }
    function addTraversal(type) {
      if (tokens.length > 0 && tokens[tokens.length - 1].type === SelectorType.Descendant) {
        tokens[tokens.length - 1].type = type;
        return;
      }
      ensureNotTraversal();
      tokens.push({ type });
    }
    function addSpecialAttribute(name, action) {
      tokens.push({
        type: SelectorType.Attribute,
        name,
        action,
        value: getName3(1),
        namespace: null,
        ignoreCase: "quirks"
      });
    }
    function finalizeSubselector() {
      if (tokens.length && tokens[tokens.length - 1].type === SelectorType.Descendant) {
        tokens.pop();
      }
      if (tokens.length === 0) {
        throw new Error("Empty sub-selector");
      }
      subselects2.push(tokens);
    }
    stripWhitespace(0);
    if (selector.length === selectorIndex) {
      return selectorIndex;
    }
    loop:
      while (selectorIndex < selector.length) {
        const firstChar = selector.charCodeAt(selectorIndex);
        switch (firstChar) {
          case 32:
          case 9:
          case 10:
          case 12:
          case 13: {
            if (tokens.length === 0 || tokens[0].type !== SelectorType.Descendant) {
              ensureNotTraversal();
              tokens.push({ type: SelectorType.Descendant });
            }
            stripWhitespace(1);
            break;
          }
          case 62: {
            addTraversal(SelectorType.Child);
            stripWhitespace(1);
            break;
          }
          case 60: {
            addTraversal(SelectorType.Parent);
            stripWhitespace(1);
            break;
          }
          case 126: {
            addTraversal(SelectorType.Sibling);
            stripWhitespace(1);
            break;
          }
          case 43: {
            addTraversal(SelectorType.Adjacent);
            stripWhitespace(1);
            break;
          }
          case 46: {
            addSpecialAttribute("class", AttributeAction.Element);
            break;
          }
          case 35: {
            addSpecialAttribute("id", AttributeAction.Equals);
            break;
          }
          case 91: {
            stripWhitespace(1);
            let name;
            let namespace = null;
            if (selector.charCodeAt(selectorIndex) === 124) {
              name = getName3(1);
            } else if (selector.startsWith("*|", selectorIndex)) {
              namespace = "*";
              name = getName3(2);
            } else {
              name = getName3(0);
              if (selector.charCodeAt(selectorIndex) === 124 && selector.charCodeAt(selectorIndex + 1) !== 61) {
                namespace = name;
                name = getName3(1);
              }
            }
            stripWhitespace(0);
            let action = AttributeAction.Exists;
            const possibleAction = actionTypes.get(selector.charCodeAt(selectorIndex));
            if (possibleAction) {
              action = possibleAction;
              if (selector.charCodeAt(selectorIndex + 1) !== 61) {
                throw new Error("Expected `=`");
              }
              stripWhitespace(2);
            } else if (selector.charCodeAt(selectorIndex) === 61) {
              action = AttributeAction.Equals;
              stripWhitespace(1);
            }
            let value = "";
            let ignoreCase2 = null;
            if (action !== "exists") {
              if (isQuote(selector.charCodeAt(selectorIndex))) {
                const quote = selector.charCodeAt(selectorIndex);
                let sectionEnd = selectorIndex + 1;
                while (sectionEnd < selector.length && (selector.charCodeAt(sectionEnd) !== quote || isEscaped(sectionEnd))) {
                  sectionEnd += 1;
                }
                if (selector.charCodeAt(sectionEnd) !== quote) {
                  throw new Error("Attribute value didn't end");
                }
                value = unescapeCSS(selector.slice(selectorIndex + 1, sectionEnd));
                selectorIndex = sectionEnd + 1;
              } else {
                const valueStart = selectorIndex;
                while (selectorIndex < selector.length && (!isWhitespace(selector.charCodeAt(selectorIndex)) && selector.charCodeAt(selectorIndex) !== 93 || isEscaped(selectorIndex))) {
                  selectorIndex += 1;
                }
                value = unescapeCSS(selector.slice(valueStart, selectorIndex));
              }
              stripWhitespace(0);
              const forceIgnore = selector.charCodeAt(selectorIndex) | 32;
              if (forceIgnore === 115) {
                ignoreCase2 = false;
                stripWhitespace(1);
              } else if (forceIgnore === 105) {
                ignoreCase2 = true;
                stripWhitespace(1);
              }
            }
            if (selector.charCodeAt(selectorIndex) !== 93) {
              throw new Error("Attribute selector didn't terminate");
            }
            selectorIndex += 1;
            const attributeSelector = {
              type: SelectorType.Attribute,
              name,
              action,
              value,
              namespace,
              ignoreCase: ignoreCase2
            };
            tokens.push(attributeSelector);
            break;
          }
          case 58: {
            if (selector.charCodeAt(selectorIndex + 1) === 58) {
              tokens.push({
                type: SelectorType.PseudoElement,
                name: getName3(2).toLowerCase(),
                data: selector.charCodeAt(selectorIndex) === 40 ? readValueWithParenthesis() : null
              });
              continue;
            }
            const name = getName3(1).toLowerCase();
            let data2 = null;
            if (selector.charCodeAt(selectorIndex) === 40) {
              if (unpackPseudos.has(name)) {
                if (isQuote(selector.charCodeAt(selectorIndex + 1))) {
                  throw new Error(`Pseudo-selector ${name} cannot be quoted`);
                }
                data2 = [];
                selectorIndex = parseSelector(data2, selector, selectorIndex + 1);
                if (selector.charCodeAt(selectorIndex) !== 41) {
                  throw new Error(`Missing closing parenthesis in :${name} (${selector})`);
                }
                selectorIndex += 1;
              } else {
                data2 = readValueWithParenthesis();
                if (stripQuotesFromPseudos.has(name)) {
                  const quot = data2.charCodeAt(0);
                  if (quot === data2.charCodeAt(data2.length - 1) && isQuote(quot)) {
                    data2 = data2.slice(1, -1);
                  }
                }
                data2 = unescapeCSS(data2);
              }
            }
            tokens.push({ type: SelectorType.Pseudo, name, data: data2 });
            break;
          }
          case 44: {
            finalizeSubselector();
            tokens = [];
            stripWhitespace(1);
            break;
          }
          default: {
            if (selector.startsWith("/*", selectorIndex)) {
              const endIndex = selector.indexOf("*/", selectorIndex + 2);
              if (endIndex < 0) {
                throw new Error("Comment was not terminated");
              }
              selectorIndex = endIndex + 2;
              if (tokens.length === 0) {
                stripWhitespace(0);
              }
              break;
            }
            let namespace = null;
            let name;
            if (firstChar === 42) {
              selectorIndex += 1;
              name = "*";
            } else if (firstChar === 124) {
              name = "";
              if (selector.charCodeAt(selectorIndex + 1) === 124) {
                addTraversal(SelectorType.ColumnCombinator);
                stripWhitespace(2);
                break;
              }
            } else if (reName.test(selector.slice(selectorIndex))) {
              name = getName3(0);
            } else {
              break loop;
            }
            if (selector.charCodeAt(selectorIndex) === 124 && selector.charCodeAt(selectorIndex + 1) !== 124) {
              namespace = name;
              if (selector.charCodeAt(selectorIndex + 1) === 42) {
                name = "*";
                selectorIndex += 2;
              } else {
                name = getName3(1);
              }
            }
            tokens.push(name === "*" ? { type: SelectorType.Universal, namespace } : { type: SelectorType.Tag, name, namespace });
          }
        }
      }
    finalizeSubselector();
    return selectorIndex;
  }

  // node_modules/css-select/lib/esm/index.js
  var import_boolbase6 = __toESM(require_boolbase(), 1);

  // node_modules/css-select/lib/esm/compile.js
  var import_boolbase5 = __toESM(require_boolbase(), 1);

  // node_modules/css-select/lib/esm/sort.js
  var procedure = /* @__PURE__ */ new Map([
    [SelectorType.Universal, 50],
    [SelectorType.Tag, 30],
    [SelectorType.Attribute, 1],
    [SelectorType.Pseudo, 0]
  ]);
  function isTraversal2(token) {
    return !procedure.has(token.type);
  }
  var attributes = /* @__PURE__ */ new Map([
    [AttributeAction.Exists, 10],
    [AttributeAction.Equals, 8],
    [AttributeAction.Not, 7],
    [AttributeAction.Start, 6],
    [AttributeAction.End, 6],
    [AttributeAction.Any, 5]
  ]);
  function sortByProcedure(arr) {
    const procs = arr.map(getProcedure);
    for (let i3 = 1; i3 < arr.length; i3++) {
      const procNew = procs[i3];
      if (procNew < 0)
        continue;
      for (let j3 = i3 - 1; j3 >= 0 && procNew < procs[j3]; j3--) {
        const token = arr[j3 + 1];
        arr[j3 + 1] = arr[j3];
        arr[j3] = token;
        procs[j3 + 1] = procs[j3];
        procs[j3] = procNew;
      }
    }
  }
  function getProcedure(token) {
    var _a2, _b;
    let proc = (_a2 = procedure.get(token.type)) !== null && _a2 !== void 0 ? _a2 : -1;
    if (token.type === SelectorType.Attribute) {
      proc = (_b = attributes.get(token.action)) !== null && _b !== void 0 ? _b : 4;
      if (token.action === AttributeAction.Equals && token.name === "id") {
        proc = 9;
      }
      if (token.ignoreCase) {
        proc >>= 1;
      }
    } else if (token.type === SelectorType.Pseudo) {
      if (!token.data) {
        proc = 3;
      } else if (token.name === "has" || token.name === "contains") {
        proc = 0;
      } else if (Array.isArray(token.data)) {
        proc = Math.min(...token.data.map((d3) => Math.min(...d3.map(getProcedure))));
        if (proc < 0) {
          proc = 0;
        }
      } else {
        proc = 2;
      }
    }
    return proc;
  }

  // node_modules/css-select/lib/esm/attributes.js
  var import_boolbase = __toESM(require_boolbase(), 1);
  var reChars = /[-[\]{}()*+?.,\\^$|#\s]/g;
  function escapeRegex(value) {
    return value.replace(reChars, "\\$&");
  }
  var caseInsensitiveAttributes = /* @__PURE__ */ new Set([
    "accept",
    "accept-charset",
    "align",
    "alink",
    "axis",
    "bgcolor",
    "charset",
    "checked",
    "clear",
    "codetype",
    "color",
    "compact",
    "declare",
    "defer",
    "dir",
    "direction",
    "disabled",
    "enctype",
    "face",
    "frame",
    "hreflang",
    "http-equiv",
    "lang",
    "language",
    "link",
    "media",
    "method",
    "multiple",
    "nohref",
    "noresize",
    "noshade",
    "nowrap",
    "readonly",
    "rel",
    "rev",
    "rules",
    "scope",
    "scrolling",
    "selected",
    "shape",
    "target",
    "text",
    "type",
    "valign",
    "valuetype",
    "vlink"
  ]);
  function shouldIgnoreCase(selector, options2) {
    return typeof selector.ignoreCase === "boolean" ? selector.ignoreCase : selector.ignoreCase === "quirks" ? !!options2.quirksMode : !options2.xmlMode && caseInsensitiveAttributes.has(selector.name);
  }
  var attributeRules = {
    equals(next2, data2, options2) {
      const { adapter: adapter3 } = options2;
      const { name } = data2;
      let { value } = data2;
      if (shouldIgnoreCase(data2, options2)) {
        value = value.toLowerCase();
        return (elem) => {
          const attr2 = adapter3.getAttributeValue(elem, name);
          return attr2 != null && attr2.length === value.length && attr2.toLowerCase() === value && next2(elem);
        };
      }
      return (elem) => adapter3.getAttributeValue(elem, name) === value && next2(elem);
    },
    hyphen(next2, data2, options2) {
      const { adapter: adapter3 } = options2;
      const { name } = data2;
      let { value } = data2;
      const len = value.length;
      if (shouldIgnoreCase(data2, options2)) {
        value = value.toLowerCase();
        return function hyphenIC(elem) {
          const attr2 = adapter3.getAttributeValue(elem, name);
          return attr2 != null && (attr2.length === len || attr2.charAt(len) === "-") && attr2.substr(0, len).toLowerCase() === value && next2(elem);
        };
      }
      return function hyphen(elem) {
        const attr2 = adapter3.getAttributeValue(elem, name);
        return attr2 != null && (attr2.length === len || attr2.charAt(len) === "-") && attr2.substr(0, len) === value && next2(elem);
      };
    },
    element(next2, data2, options2) {
      const { adapter: adapter3 } = options2;
      const { name, value } = data2;
      if (/\s/.test(value)) {
        return import_boolbase.default.falseFunc;
      }
      const regex = new RegExp(`(?:^|\\s)${escapeRegex(value)}(?:$|\\s)`, shouldIgnoreCase(data2, options2) ? "i" : "");
      return function element(elem) {
        const attr2 = adapter3.getAttributeValue(elem, name);
        return attr2 != null && attr2.length >= value.length && regex.test(attr2) && next2(elem);
      };
    },
    exists(next2, { name }, { adapter: adapter3 }) {
      return (elem) => adapter3.hasAttrib(elem, name) && next2(elem);
    },
    start(next2, data2, options2) {
      const { adapter: adapter3 } = options2;
      const { name } = data2;
      let { value } = data2;
      const len = value.length;
      if (len === 0) {
        return import_boolbase.default.falseFunc;
      }
      if (shouldIgnoreCase(data2, options2)) {
        value = value.toLowerCase();
        return (elem) => {
          const attr2 = adapter3.getAttributeValue(elem, name);
          return attr2 != null && attr2.length >= len && attr2.substr(0, len).toLowerCase() === value && next2(elem);
        };
      }
      return (elem) => {
        var _a2;
        return !!((_a2 = adapter3.getAttributeValue(elem, name)) === null || _a2 === void 0 ? void 0 : _a2.startsWith(value)) && next2(elem);
      };
    },
    end(next2, data2, options2) {
      const { adapter: adapter3 } = options2;
      const { name } = data2;
      let { value } = data2;
      const len = -value.length;
      if (len === 0) {
        return import_boolbase.default.falseFunc;
      }
      if (shouldIgnoreCase(data2, options2)) {
        value = value.toLowerCase();
        return (elem) => {
          var _a2;
          return ((_a2 = adapter3.getAttributeValue(elem, name)) === null || _a2 === void 0 ? void 0 : _a2.substr(len).toLowerCase()) === value && next2(elem);
        };
      }
      return (elem) => {
        var _a2;
        return !!((_a2 = adapter3.getAttributeValue(elem, name)) === null || _a2 === void 0 ? void 0 : _a2.endsWith(value)) && next2(elem);
      };
    },
    any(next2, data2, options2) {
      const { adapter: adapter3 } = options2;
      const { name, value } = data2;
      if (value === "") {
        return import_boolbase.default.falseFunc;
      }
      if (shouldIgnoreCase(data2, options2)) {
        const regex = new RegExp(escapeRegex(value), "i");
        return function anyIC(elem) {
          const attr2 = adapter3.getAttributeValue(elem, name);
          return attr2 != null && attr2.length >= value.length && regex.test(attr2) && next2(elem);
        };
      }
      return (elem) => {
        var _a2;
        return !!((_a2 = adapter3.getAttributeValue(elem, name)) === null || _a2 === void 0 ? void 0 : _a2.includes(value)) && next2(elem);
      };
    },
    not(next2, data2, options2) {
      const { adapter: adapter3 } = options2;
      const { name } = data2;
      let { value } = data2;
      if (value === "") {
        return (elem) => !!adapter3.getAttributeValue(elem, name) && next2(elem);
      } else if (shouldIgnoreCase(data2, options2)) {
        value = value.toLowerCase();
        return (elem) => {
          const attr2 = adapter3.getAttributeValue(elem, name);
          return (attr2 == null || attr2.length !== value.length || attr2.toLowerCase() !== value) && next2(elem);
        };
      }
      return (elem) => adapter3.getAttributeValue(elem, name) !== value && next2(elem);
    }
  };

  // node_modules/nth-check/lib/esm/parse.js
  var whitespace = /* @__PURE__ */ new Set([9, 10, 12, 13, 32]);
  var ZERO = "0".charCodeAt(0);
  var NINE = "9".charCodeAt(0);
  function parse2(formula) {
    formula = formula.trim().toLowerCase();
    if (formula === "even") {
      return [2, 0];
    } else if (formula === "odd") {
      return [2, 1];
    }
    let idx = 0;
    let a3 = 0;
    let sign = readSign();
    let number = readNumber();
    if (idx < formula.length && formula.charAt(idx) === "n") {
      idx++;
      a3 = sign * (number !== null && number !== void 0 ? number : 1);
      skipWhitespace();
      if (idx < formula.length) {
        sign = readSign();
        skipWhitespace();
        number = readNumber();
      } else {
        sign = number = 0;
      }
    }
    if (number === null || idx < formula.length) {
      throw new Error(`n-th rule couldn't be parsed ('${formula}')`);
    }
    return [a3, sign * number];
    function readSign() {
      if (formula.charAt(idx) === "-") {
        idx++;
        return -1;
      }
      if (formula.charAt(idx) === "+") {
        idx++;
      }
      return 1;
    }
    function readNumber() {
      const start = idx;
      let value = 0;
      while (idx < formula.length && formula.charCodeAt(idx) >= ZERO && formula.charCodeAt(idx) <= NINE) {
        value = value * 10 + (formula.charCodeAt(idx) - ZERO);
        idx++;
      }
      return idx === start ? null : value;
    }
    function skipWhitespace() {
      while (idx < formula.length && whitespace.has(formula.charCodeAt(idx))) {
        idx++;
      }
    }
  }

  // node_modules/nth-check/lib/esm/compile.js
  var import_boolbase2 = __toESM(require_boolbase(), 1);
  function compile(parsed) {
    const a3 = parsed[0];
    const b3 = parsed[1] - 1;
    if (b3 < 0 && a3 <= 0)
      return import_boolbase2.default.falseFunc;
    if (a3 === -1)
      return (index2) => index2 <= b3;
    if (a3 === 0)
      return (index2) => index2 === b3;
    if (a3 === 1)
      return b3 < 0 ? import_boolbase2.default.trueFunc : (index2) => index2 >= b3;
    const absA = Math.abs(a3);
    const bMod = (b3 % absA + absA) % absA;
    return a3 > 1 ? (index2) => index2 >= b3 && index2 % absA === bMod : (index2) => index2 <= b3 && index2 % absA === bMod;
  }

  // node_modules/nth-check/lib/esm/index.js
  function nthCheck(formula) {
    return compile(parse2(formula));
  }

  // node_modules/css-select/lib/esm/pseudo-selectors/filters.js
  var import_boolbase3 = __toESM(require_boolbase(), 1);
  function getChildFunc(next2, adapter3) {
    return (elem) => {
      const parent2 = adapter3.getParent(elem);
      return parent2 != null && adapter3.isTag(parent2) && next2(elem);
    };
  }
  var filters = {
    contains(next2, text3, { adapter: adapter3 }) {
      return function contains3(elem) {
        return next2(elem) && adapter3.getText(elem).includes(text3);
      };
    },
    icontains(next2, text3, { adapter: adapter3 }) {
      const itext = text3.toLowerCase();
      return function icontains(elem) {
        return next2(elem) && adapter3.getText(elem).toLowerCase().includes(itext);
      };
    },
    // Location specific methods
    "nth-child"(next2, rule, { adapter: adapter3, equals }) {
      const func = nthCheck(rule);
      if (func === import_boolbase3.default.falseFunc)
        return import_boolbase3.default.falseFunc;
      if (func === import_boolbase3.default.trueFunc)
        return getChildFunc(next2, adapter3);
      return function nthChild(elem) {
        const siblings2 = adapter3.getSiblings(elem);
        let pos = 0;
        for (let i3 = 0; i3 < siblings2.length; i3++) {
          if (equals(elem, siblings2[i3]))
            break;
          if (adapter3.isTag(siblings2[i3])) {
            pos++;
          }
        }
        return func(pos) && next2(elem);
      };
    },
    "nth-last-child"(next2, rule, { adapter: adapter3, equals }) {
      const func = nthCheck(rule);
      if (func === import_boolbase3.default.falseFunc)
        return import_boolbase3.default.falseFunc;
      if (func === import_boolbase3.default.trueFunc)
        return getChildFunc(next2, adapter3);
      return function nthLastChild(elem) {
        const siblings2 = adapter3.getSiblings(elem);
        let pos = 0;
        for (let i3 = siblings2.length - 1; i3 >= 0; i3--) {
          if (equals(elem, siblings2[i3]))
            break;
          if (adapter3.isTag(siblings2[i3])) {
            pos++;
          }
        }
        return func(pos) && next2(elem);
      };
    },
    "nth-of-type"(next2, rule, { adapter: adapter3, equals }) {
      const func = nthCheck(rule);
      if (func === import_boolbase3.default.falseFunc)
        return import_boolbase3.default.falseFunc;
      if (func === import_boolbase3.default.trueFunc)
        return getChildFunc(next2, adapter3);
      return function nthOfType(elem) {
        const siblings2 = adapter3.getSiblings(elem);
        let pos = 0;
        for (let i3 = 0; i3 < siblings2.length; i3++) {
          const currentSibling = siblings2[i3];
          if (equals(elem, currentSibling))
            break;
          if (adapter3.isTag(currentSibling) && adapter3.getName(currentSibling) === adapter3.getName(elem)) {
            pos++;
          }
        }
        return func(pos) && next2(elem);
      };
    },
    "nth-last-of-type"(next2, rule, { adapter: adapter3, equals }) {
      const func = nthCheck(rule);
      if (func === import_boolbase3.default.falseFunc)
        return import_boolbase3.default.falseFunc;
      if (func === import_boolbase3.default.trueFunc)
        return getChildFunc(next2, adapter3);
      return function nthLastOfType(elem) {
        const siblings2 = adapter3.getSiblings(elem);
        let pos = 0;
        for (let i3 = siblings2.length - 1; i3 >= 0; i3--) {
          const currentSibling = siblings2[i3];
          if (equals(elem, currentSibling))
            break;
          if (adapter3.isTag(currentSibling) && adapter3.getName(currentSibling) === adapter3.getName(elem)) {
            pos++;
          }
        }
        return func(pos) && next2(elem);
      };
    },
    // TODO determine the actual root element
    root(next2, _rule, { adapter: adapter3 }) {
      return (elem) => {
        const parent2 = adapter3.getParent(elem);
        return (parent2 == null || !adapter3.isTag(parent2)) && next2(elem);
      };
    },
    scope(next2, rule, options2, context) {
      const { equals } = options2;
      if (!context || context.length === 0) {
        return filters["root"](next2, rule, options2);
      }
      if (context.length === 1) {
        return (elem) => equals(context[0], elem) && next2(elem);
      }
      return (elem) => context.includes(elem) && next2(elem);
    },
    hover: dynamicStatePseudo("isHovered"),
    visited: dynamicStatePseudo("isVisited"),
    active: dynamicStatePseudo("isActive")
  };
  function dynamicStatePseudo(name) {
    return function dynamicPseudo(next2, _rule, { adapter: adapter3 }) {
      const func = adapter3[name];
      if (typeof func !== "function") {
        return import_boolbase3.default.falseFunc;
      }
      return function active(elem) {
        return func(elem) && next2(elem);
      };
    };
  }

  // node_modules/css-select/lib/esm/pseudo-selectors/pseudos.js
  var pseudos = {
    empty(elem, { adapter: adapter3 }) {
      return !adapter3.getChildren(elem).some((elem2) => (
        // FIXME: `getText` call is potentially expensive.
        adapter3.isTag(elem2) || adapter3.getText(elem2) !== ""
      ));
    },
    "first-child"(elem, { adapter: adapter3, equals }) {
      if (adapter3.prevElementSibling) {
        return adapter3.prevElementSibling(elem) == null;
      }
      const firstChild = adapter3.getSiblings(elem).find((elem2) => adapter3.isTag(elem2));
      return firstChild != null && equals(elem, firstChild);
    },
    "last-child"(elem, { adapter: adapter3, equals }) {
      const siblings2 = adapter3.getSiblings(elem);
      for (let i3 = siblings2.length - 1; i3 >= 0; i3--) {
        if (equals(elem, siblings2[i3]))
          return true;
        if (adapter3.isTag(siblings2[i3]))
          break;
      }
      return false;
    },
    "first-of-type"(elem, { adapter: adapter3, equals }) {
      const siblings2 = adapter3.getSiblings(elem);
      const elemName = adapter3.getName(elem);
      for (let i3 = 0; i3 < siblings2.length; i3++) {
        const currentSibling = siblings2[i3];
        if (equals(elem, currentSibling))
          return true;
        if (adapter3.isTag(currentSibling) && adapter3.getName(currentSibling) === elemName) {
          break;
        }
      }
      return false;
    },
    "last-of-type"(elem, { adapter: adapter3, equals }) {
      const siblings2 = adapter3.getSiblings(elem);
      const elemName = adapter3.getName(elem);
      for (let i3 = siblings2.length - 1; i3 >= 0; i3--) {
        const currentSibling = siblings2[i3];
        if (equals(elem, currentSibling))
          return true;
        if (adapter3.isTag(currentSibling) && adapter3.getName(currentSibling) === elemName) {
          break;
        }
      }
      return false;
    },
    "only-of-type"(elem, { adapter: adapter3, equals }) {
      const elemName = adapter3.getName(elem);
      return adapter3.getSiblings(elem).every((sibling) => equals(elem, sibling) || !adapter3.isTag(sibling) || adapter3.getName(sibling) !== elemName);
    },
    "only-child"(elem, { adapter: adapter3, equals }) {
      return adapter3.getSiblings(elem).every((sibling) => equals(elem, sibling) || !adapter3.isTag(sibling));
    }
  };
  function verifyPseudoArgs(func, name, subselect, argIndex) {
    if (subselect === null) {
      if (func.length > argIndex) {
        throw new Error(`Pseudo-class :${name} requires an argument`);
      }
    } else if (func.length === argIndex) {
      throw new Error(`Pseudo-class :${name} doesn't have any arguments`);
    }
  }

  // node_modules/css-select/lib/esm/pseudo-selectors/aliases.js
  var aliases = {
    // Links
    "any-link": ":is(a, area, link)[href]",
    link: ":any-link:not(:visited)",
    // Forms
    // https://html.spec.whatwg.org/multipage/scripting.html#disabled-elements
    disabled: `:is(
        :is(button, input, select, textarea, optgroup, option)[disabled],
        optgroup[disabled] > option,
        fieldset[disabled]:not(fieldset[disabled] legend:first-of-type *)
    )`,
    enabled: ":not(:disabled)",
    checked: ":is(:is(input[type=radio], input[type=checkbox])[checked], option:selected)",
    required: ":is(input, select, textarea)[required]",
    optional: ":is(input, select, textarea):not([required])",
    // JQuery extensions
    // https://html.spec.whatwg.org/multipage/form-elements.html#concept-option-selectedness
    selected: "option:is([selected], select:not([multiple]):not(:has(> option[selected])) > :first-of-type)",
    checkbox: "[type=checkbox]",
    file: "[type=file]",
    password: "[type=password]",
    radio: "[type=radio]",
    reset: "[type=reset]",
    image: "[type=image]",
    submit: "[type=submit]",
    parent: ":not(:empty)",
    header: ":is(h1, h2, h3, h4, h5, h6)",
    button: ":is(button, input[type=button])",
    input: ":is(input, textarea, select, button)",
    text: "input:is(:not([type!='']), [type=text])"
  };

  // node_modules/css-select/lib/esm/pseudo-selectors/subselects.js
  var import_boolbase4 = __toESM(require_boolbase(), 1);
  var PLACEHOLDER_ELEMENT = {};
  function ensureIsTag(next2, adapter3) {
    if (next2 === import_boolbase4.default.falseFunc)
      return import_boolbase4.default.falseFunc;
    return (elem) => adapter3.isTag(elem) && next2(elem);
  }
  function getNextSiblings(elem, adapter3) {
    const siblings2 = adapter3.getSiblings(elem);
    if (siblings2.length <= 1)
      return [];
    const elemIndex = siblings2.indexOf(elem);
    if (elemIndex < 0 || elemIndex === siblings2.length - 1)
      return [];
    return siblings2.slice(elemIndex + 1).filter(adapter3.isTag);
  }
  function copyOptions(options2) {
    return {
      xmlMode: !!options2.xmlMode,
      lowerCaseAttributeNames: !!options2.lowerCaseAttributeNames,
      lowerCaseTags: !!options2.lowerCaseTags,
      quirksMode: !!options2.quirksMode,
      cacheResults: !!options2.cacheResults,
      pseudos: options2.pseudos,
      adapter: options2.adapter,
      equals: options2.equals
    };
  }
  var is = (next2, token, options2, context, compileToken2) => {
    const func = compileToken2(token, copyOptions(options2), context);
    return func === import_boolbase4.default.trueFunc ? next2 : func === import_boolbase4.default.falseFunc ? import_boolbase4.default.falseFunc : (elem) => func(elem) && next2(elem);
  };
  var subselects = {
    is,
    /**
     * `:matches` and `:where` are aliases for `:is`.
     */
    matches: is,
    where: is,
    not(next2, token, options2, context, compileToken2) {
      const func = compileToken2(token, copyOptions(options2), context);
      return func === import_boolbase4.default.falseFunc ? next2 : func === import_boolbase4.default.trueFunc ? import_boolbase4.default.falseFunc : (elem) => !func(elem) && next2(elem);
    },
    has(next2, subselect, options2, _context, compileToken2) {
      const { adapter: adapter3 } = options2;
      const opts = copyOptions(options2);
      opts.relativeSelector = true;
      const context = subselect.some((s2) => s2.some(isTraversal2)) ? (
        // Used as a placeholder. Will be replaced with the actual element.
        [PLACEHOLDER_ELEMENT]
      ) : void 0;
      const compiled = compileToken2(subselect, opts, context);
      if (compiled === import_boolbase4.default.falseFunc)
        return import_boolbase4.default.falseFunc;
      const hasElement = ensureIsTag(compiled, adapter3);
      if (context && compiled !== import_boolbase4.default.trueFunc) {
        const { shouldTestNextSiblings = false } = compiled;
        return (elem) => {
          if (!next2(elem))
            return false;
          context[0] = elem;
          const childs = adapter3.getChildren(elem);
          const nextElements = shouldTestNextSiblings ? [...childs, ...getNextSiblings(elem, adapter3)] : childs;
          return adapter3.existsOne(hasElement, nextElements);
        };
      }
      return (elem) => next2(elem) && adapter3.existsOne(hasElement, adapter3.getChildren(elem));
    }
  };

  // node_modules/css-select/lib/esm/pseudo-selectors/index.js
  function compilePseudoSelector(next2, selector, options2, context, compileToken2) {
    var _a2;
    const { name, data: data2 } = selector;
    if (Array.isArray(data2)) {
      if (!(name in subselects)) {
        throw new Error(`Unknown pseudo-class :${name}(${data2})`);
      }
      return subselects[name](next2, data2, options2, context, compileToken2);
    }
    const userPseudo = (_a2 = options2.pseudos) === null || _a2 === void 0 ? void 0 : _a2[name];
    const stringPseudo = typeof userPseudo === "string" ? userPseudo : aliases[name];
    if (typeof stringPseudo === "string") {
      if (data2 != null) {
        throw new Error(`Pseudo ${name} doesn't have any arguments`);
      }
      const alias = parse(stringPseudo);
      return subselects["is"](next2, alias, options2, context, compileToken2);
    }
    if (typeof userPseudo === "function") {
      verifyPseudoArgs(userPseudo, name, data2, 1);
      return (elem) => userPseudo(elem, data2) && next2(elem);
    }
    if (name in filters) {
      return filters[name](next2, data2, options2, context);
    }
    if (name in pseudos) {
      const pseudo = pseudos[name];
      verifyPseudoArgs(pseudo, name, data2, 2);
      return (elem) => pseudo(elem, options2, data2) && next2(elem);
    }
    throw new Error(`Unknown pseudo-class :${name}`);
  }

  // node_modules/css-select/lib/esm/general.js
  function getElementParent(node, adapter3) {
    const parent2 = adapter3.getParent(node);
    if (parent2 && adapter3.isTag(parent2)) {
      return parent2;
    }
    return null;
  }
  function compileGeneralSelector(next2, selector, options2, context, compileToken2) {
    const { adapter: adapter3, equals } = options2;
    switch (selector.type) {
      case SelectorType.PseudoElement: {
        throw new Error("Pseudo-elements are not supported by css-select");
      }
      case SelectorType.ColumnCombinator: {
        throw new Error("Column combinators are not yet supported by css-select");
      }
      case SelectorType.Attribute: {
        if (selector.namespace != null) {
          throw new Error("Namespaced attributes are not yet supported by css-select");
        }
        if (!options2.xmlMode || options2.lowerCaseAttributeNames) {
          selector.name = selector.name.toLowerCase();
        }
        return attributeRules[selector.action](next2, selector, options2);
      }
      case SelectorType.Pseudo: {
        return compilePseudoSelector(next2, selector, options2, context, compileToken2);
      }
      case SelectorType.Tag: {
        if (selector.namespace != null) {
          throw new Error("Namespaced tag names are not yet supported by css-select");
        }
        let { name } = selector;
        if (!options2.xmlMode || options2.lowerCaseTags) {
          name = name.toLowerCase();
        }
        return function tag(elem) {
          return adapter3.getName(elem) === name && next2(elem);
        };
      }
      case SelectorType.Descendant: {
        if (options2.cacheResults === false || typeof WeakSet === "undefined") {
          return function descendant(elem) {
            let current = elem;
            while (current = getElementParent(current, adapter3)) {
              if (next2(current)) {
                return true;
              }
            }
            return false;
          };
        }
        const isFalseCache = /* @__PURE__ */ new WeakSet();
        return function cachedDescendant(elem) {
          let current = elem;
          while (current = getElementParent(current, adapter3)) {
            if (!isFalseCache.has(current)) {
              if (adapter3.isTag(current) && next2(current)) {
                return true;
              }
              isFalseCache.add(current);
            }
          }
          return false;
        };
      }
      case "_flexibleDescendant": {
        return function flexibleDescendant(elem) {
          let current = elem;
          do {
            if (next2(current))
              return true;
          } while (current = getElementParent(current, adapter3));
          return false;
        };
      }
      case SelectorType.Parent: {
        return function parent2(elem) {
          return adapter3.getChildren(elem).some((elem2) => adapter3.isTag(elem2) && next2(elem2));
        };
      }
      case SelectorType.Child: {
        return function child(elem) {
          const parent2 = adapter3.getParent(elem);
          return parent2 != null && adapter3.isTag(parent2) && next2(parent2);
        };
      }
      case SelectorType.Sibling: {
        return function sibling(elem) {
          const siblings2 = adapter3.getSiblings(elem);
          for (let i3 = 0; i3 < siblings2.length; i3++) {
            const currentSibling = siblings2[i3];
            if (equals(elem, currentSibling))
              break;
            if (adapter3.isTag(currentSibling) && next2(currentSibling)) {
              return true;
            }
          }
          return false;
        };
      }
      case SelectorType.Adjacent: {
        if (adapter3.prevElementSibling) {
          return function adjacent(elem) {
            const previous = adapter3.prevElementSibling(elem);
            return previous != null && next2(previous);
          };
        }
        return function adjacent(elem) {
          const siblings2 = adapter3.getSiblings(elem);
          let lastElement;
          for (let i3 = 0; i3 < siblings2.length; i3++) {
            const currentSibling = siblings2[i3];
            if (equals(elem, currentSibling))
              break;
            if (adapter3.isTag(currentSibling)) {
              lastElement = currentSibling;
            }
          }
          return !!lastElement && next2(lastElement);
        };
      }
      case SelectorType.Universal: {
        if (selector.namespace != null && selector.namespace !== "*") {
          throw new Error("Namespaced universal selectors are not yet supported by css-select");
        }
        return next2;
      }
    }
  }

  // node_modules/css-select/lib/esm/compile.js
  function compile2(selector, options2, context) {
    const next2 = compileUnsafe(selector, options2, context);
    return ensureIsTag(next2, options2.adapter);
  }
  function compileUnsafe(selector, options2, context) {
    const token = typeof selector === "string" ? parse(selector) : selector;
    return compileToken(token, options2, context);
  }
  function includesScopePseudo(t3) {
    return t3.type === SelectorType.Pseudo && (t3.name === "scope" || Array.isArray(t3.data) && t3.data.some((data2) => data2.some(includesScopePseudo)));
  }
  var DESCENDANT_TOKEN = { type: SelectorType.Descendant };
  var FLEXIBLE_DESCENDANT_TOKEN = {
    type: "_flexibleDescendant"
  };
  var SCOPE_TOKEN = {
    type: SelectorType.Pseudo,
    name: "scope",
    data: null
  };
  function absolutize(token, { adapter: adapter3 }, context) {
    const hasContext = !!(context === null || context === void 0 ? void 0 : context.every((e3) => {
      const parent2 = adapter3.isTag(e3) && adapter3.getParent(e3);
      return e3 === PLACEHOLDER_ELEMENT || parent2 && adapter3.isTag(parent2);
    }));
    for (const t3 of token) {
      if (t3.length > 0 && isTraversal2(t3[0]) && t3[0].type !== SelectorType.Descendant) {
      } else if (hasContext && !t3.some(includesScopePseudo)) {
        t3.unshift(DESCENDANT_TOKEN);
      } else {
        continue;
      }
      t3.unshift(SCOPE_TOKEN);
    }
  }
  function compileToken(token, options2, context) {
    var _a2;
    token.forEach(sortByProcedure);
    context = (_a2 = options2.context) !== null && _a2 !== void 0 ? _a2 : context;
    const isArrayContext = Array.isArray(context);
    const finalContext = context && (Array.isArray(context) ? context : [context]);
    if (options2.relativeSelector !== false) {
      absolutize(token, options2, finalContext);
    } else if (token.some((t3) => t3.length > 0 && isTraversal2(t3[0]))) {
      throw new Error("Relative selectors are not allowed when the `relativeSelector` option is disabled");
    }
    let shouldTestNextSiblings = false;
    const query2 = token.map((rules) => {
      if (rules.length >= 2) {
        const [first2, second] = rules;
        if (first2.type !== SelectorType.Pseudo || first2.name !== "scope") {
        } else if (isArrayContext && second.type === SelectorType.Descendant) {
          rules[1] = FLEXIBLE_DESCENDANT_TOKEN;
        } else if (second.type === SelectorType.Adjacent || second.type === SelectorType.Sibling) {
          shouldTestNextSiblings = true;
        }
      }
      return compileRules(rules, options2, finalContext);
    }).reduce(reduceRules, import_boolbase5.default.falseFunc);
    query2.shouldTestNextSiblings = shouldTestNextSiblings;
    return query2;
  }
  function compileRules(rules, options2, context) {
    var _a2;
    return rules.reduce((previous, rule) => previous === import_boolbase5.default.falseFunc ? import_boolbase5.default.falseFunc : compileGeneralSelector(previous, rule, options2, context, compileToken), (_a2 = options2.rootFunc) !== null && _a2 !== void 0 ? _a2 : import_boolbase5.default.trueFunc);
  }
  function reduceRules(a3, b3) {
    if (b3 === import_boolbase5.default.falseFunc || a3 === import_boolbase5.default.trueFunc) {
      return a3;
    }
    if (a3 === import_boolbase5.default.falseFunc || b3 === import_boolbase5.default.trueFunc) {
      return b3;
    }
    return function combine(elem) {
      return a3(elem) || b3(elem);
    };
  }

  // node_modules/css-select/lib/esm/index.js
  var defaultEquals = (a3, b3) => a3 === b3;
  var defaultOptions = {
    adapter: esm_exports2,
    equals: defaultEquals
  };
  function convertOptionFormats(options2) {
    var _a2, _b, _c, _d;
    const opts = options2 !== null && options2 !== void 0 ? options2 : defaultOptions;
    (_a2 = opts.adapter) !== null && _a2 !== void 0 ? _a2 : opts.adapter = esm_exports2;
    (_b = opts.equals) !== null && _b !== void 0 ? _b : opts.equals = (_d = (_c = opts.adapter) === null || _c === void 0 ? void 0 : _c.equals) !== null && _d !== void 0 ? _d : defaultEquals;
    return opts;
  }
  function wrapCompile(func) {
    return function addAdapter(selector, options2, context) {
      const opts = convertOptionFormats(options2);
      return func(selector, opts, context);
    };
  }
  var compile3 = wrapCompile(compile2);
  var _compileUnsafe = wrapCompile(compileUnsafe);
  var _compileToken = wrapCompile(compileToken);
  function getSelectorFunc(searchFunc) {
    return function select2(query2, elements, options2) {
      const opts = convertOptionFormats(options2);
      if (typeof query2 !== "function") {
        query2 = compileUnsafe(query2, opts, elements);
      }
      const filteredElements = prepareContext(elements, opts.adapter, query2.shouldTestNextSiblings);
      return searchFunc(query2, filteredElements, opts);
    };
  }
  function prepareContext(elems, adapter3, shouldTestNextSiblings = false) {
    if (shouldTestNextSiblings) {
      elems = appendNextSiblings(elems, adapter3);
    }
    return Array.isArray(elems) ? adapter3.removeSubsets(elems) : adapter3.getChildren(elems);
  }
  function appendNextSiblings(elem, adapter3) {
    const elems = Array.isArray(elem) ? elem.slice(0) : [elem];
    const elemsLength = elems.length;
    for (let i3 = 0; i3 < elemsLength; i3++) {
      const nextSiblings = getNextSiblings(elems[i3], adapter3);
      elems.push(...nextSiblings);
    }
    return elems;
  }
  var selectAll = getSelectorFunc((query2, elems, options2) => query2 === import_boolbase6.default.falseFunc || !elems || elems.length === 0 ? [] : options2.adapter.findAll(query2, elems));
  var selectOne = getSelectorFunc((query2, elems, options2) => query2 === import_boolbase6.default.falseFunc || !elems || elems.length === 0 ? null : options2.adapter.findOne(query2, elems));
  function is2(elem, query2, options2) {
    const opts = convertOptionFormats(options2);
    return (typeof query2 === "function" ? query2 : compile2(query2, opts))(elem);
  }

  // node_modules/cheerio-select/lib/esm/index.js
  var boolbase7 = __toESM(require_boolbase(), 1);

  // node_modules/cheerio-select/lib/esm/positionals.js
  var filterNames = /* @__PURE__ */ new Set([
    "first",
    "last",
    "eq",
    "gt",
    "nth",
    "lt",
    "even",
    "odd"
  ]);
  function isFilter(s2) {
    if (s2.type !== "pseudo")
      return false;
    if (filterNames.has(s2.name))
      return true;
    if (s2.name === "not" && Array.isArray(s2.data)) {
      return s2.data.some((s3) => s3.some(isFilter));
    }
    return false;
  }
  function getLimit(filter4, data2, partLimit) {
    const num = data2 != null ? parseInt(data2, 10) : NaN;
    switch (filter4) {
      case "first":
        return 1;
      case "nth":
      case "eq":
        return isFinite(num) ? num >= 0 ? num + 1 : Infinity : 0;
      case "lt":
        return isFinite(num) ? num >= 0 ? Math.min(num, partLimit) : Infinity : 0;
      case "gt":
        return isFinite(num) ? Infinity : 0;
      case "odd":
        return 2 * partLimit;
      case "even":
        return 2 * partLimit - 1;
      case "last":
      case "not":
        return Infinity;
    }
  }

  // node_modules/cheerio-select/lib/esm/helpers.js
  function getDocumentRoot(node) {
    while (node.parent)
      node = node.parent;
    return node;
  }
  function groupSelectors(selectors) {
    const filteredSelectors = [];
    const plainSelectors = [];
    for (const selector of selectors) {
      if (selector.some(isFilter)) {
        filteredSelectors.push(selector);
      } else {
        plainSelectors.push(selector);
      }
    }
    return [plainSelectors, filteredSelectors];
  }

  // node_modules/cheerio-select/lib/esm/index.js
  var UNIVERSAL_SELECTOR = {
    type: SelectorType.Universal,
    namespace: null
  };
  var SCOPE_PSEUDO = {
    type: SelectorType.Pseudo,
    name: "scope",
    data: null
  };
  function is3(element, selector, options2 = {}) {
    return some([element], selector, options2);
  }
  function some(elements, selector, options2 = {}) {
    if (typeof selector === "function")
      return elements.some(selector);
    const [plain, filtered] = groupSelectors(parse(selector));
    return plain.length > 0 && elements.some(_compileToken(plain, options2)) || filtered.some((sel) => filterBySelector(sel, elements, options2).length > 0);
  }
  function filterByPosition(filter4, elems, data2, options2) {
    const num = typeof data2 === "string" ? parseInt(data2, 10) : NaN;
    switch (filter4) {
      case "first":
      case "lt":
        return elems;
      case "last":
        return elems.length > 0 ? [elems[elems.length - 1]] : elems;
      case "nth":
      case "eq":
        return isFinite(num) && Math.abs(num) < elems.length ? [num < 0 ? elems[elems.length + num] : elems[num]] : [];
      case "gt":
        return isFinite(num) ? elems.slice(num + 1) : [];
      case "even":
        return elems.filter((_2, i3) => i3 % 2 === 0);
      case "odd":
        return elems.filter((_2, i3) => i3 % 2 === 1);
      case "not": {
        const filtered = new Set(filterParsed(data2, elems, options2));
        return elems.filter((e3) => !filtered.has(e3));
      }
    }
  }
  function filter2(selector, elements, options2 = {}) {
    return filterParsed(parse(selector), elements, options2);
  }
  function filterParsed(selector, elements, options2) {
    if (elements.length === 0)
      return [];
    const [plainSelectors, filteredSelectors] = groupSelectors(selector);
    let found;
    if (plainSelectors.length) {
      const filtered = filterElements(elements, plainSelectors, options2);
      if (filteredSelectors.length === 0) {
        return filtered;
      }
      if (filtered.length) {
        found = new Set(filtered);
      }
    }
    for (let i3 = 0; i3 < filteredSelectors.length && (found === null || found === void 0 ? void 0 : found.size) !== elements.length; i3++) {
      const filteredSelector = filteredSelectors[i3];
      const missing = found ? elements.filter((e3) => isTag2(e3) && !found.has(e3)) : elements;
      if (missing.length === 0)
        break;
      const filtered = filterBySelector(filteredSelector, elements, options2);
      if (filtered.length) {
        if (!found) {
          if (i3 === filteredSelectors.length - 1) {
            return filtered;
          }
          found = new Set(filtered);
        } else {
          filtered.forEach((el) => found.add(el));
        }
      }
    }
    return typeof found !== "undefined" ? found.size === elements.length ? elements : (
      // Filter elements to preserve order
      elements.filter((el) => found.has(el))
    ) : [];
  }
  function filterBySelector(selector, elements, options2) {
    var _a2;
    if (selector.some(isTraversal)) {
      const root4 = (_a2 = options2.root) !== null && _a2 !== void 0 ? _a2 : getDocumentRoot(elements[0]);
      const opts = { ...options2, context: elements, relativeSelector: false };
      selector.push(SCOPE_PSEUDO);
      return findFilterElements(root4, selector, opts, true, elements.length);
    }
    return findFilterElements(elements, selector, options2, false, elements.length);
  }
  function select(selector, root4, options2 = {}, limit = Infinity) {
    if (typeof selector === "function") {
      return find2(root4, selector);
    }
    const [plain, filtered] = groupSelectors(parse(selector));
    const results = filtered.map((sel) => findFilterElements(root4, sel, options2, true, limit));
    if (plain.length) {
      results.push(findElements(root4, plain, options2, limit));
    }
    if (results.length === 0) {
      return [];
    }
    if (results.length === 1) {
      return results[0];
    }
    return uniqueSort(results.reduce((a3, b3) => [...a3, ...b3]));
  }
  function findFilterElements(root4, selector, options2, queryForSelector, totalLimit) {
    const filterIndex = selector.findIndex(isFilter);
    const sub = selector.slice(0, filterIndex);
    const filter4 = selector[filterIndex];
    const partLimit = selector.length - 1 === filterIndex ? totalLimit : Infinity;
    const limit = getLimit(filter4.name, filter4.data, partLimit);
    if (limit === 0)
      return [];
    const elemsNoLimit = sub.length === 0 && !Array.isArray(root4) ? getChildren(root4).filter(isTag2) : sub.length === 0 ? (Array.isArray(root4) ? root4 : [root4]).filter(isTag2) : queryForSelector || sub.some(isTraversal) ? findElements(root4, [sub], options2, limit) : filterElements(root4, [sub], options2);
    const elems = elemsNoLimit.slice(0, limit);
    let result = filterByPosition(filter4.name, elems, filter4.data, options2);
    if (result.length === 0 || selector.length === filterIndex + 1) {
      return result;
    }
    const remainingSelector = selector.slice(filterIndex + 1);
    const remainingHasTraversal = remainingSelector.some(isTraversal);
    if (remainingHasTraversal) {
      if (isTraversal(remainingSelector[0])) {
        const { type } = remainingSelector[0];
        if (type === SelectorType.Sibling || type === SelectorType.Adjacent) {
          result = prepareContext(result, esm_exports2, true);
        }
        remainingSelector.unshift(UNIVERSAL_SELECTOR);
      }
      options2 = {
        ...options2,
        // Avoid absolutizing the selector
        relativeSelector: false,
        /*
         * Add a custom root func, to make sure traversals don't match elements
         * that aren't a part of the considered tree.
         */
        rootFunc: (el) => result.includes(el)
      };
    } else if (options2.rootFunc && options2.rootFunc !== boolbase7.trueFunc) {
      options2 = { ...options2, rootFunc: boolbase7.trueFunc };
    }
    return remainingSelector.some(isFilter) ? findFilterElements(result, remainingSelector, options2, false, totalLimit) : remainingHasTraversal ? (
      // Query existing elements to resolve traversal.
      findElements(result, [remainingSelector], options2, totalLimit)
    ) : (
      // If we don't have any more traversals, simply filter elements.
      filterElements(result, [remainingSelector], options2)
    );
  }
  function findElements(root4, sel, options2, limit) {
    const query2 = _compileToken(sel, options2, root4);
    return find2(root4, query2, limit);
  }
  function find2(root4, query2, limit = Infinity) {
    const elems = prepareContext(root4, esm_exports2, query2.shouldTestNextSiblings);
    return find((node) => isTag2(node) && query2(node), elems, true, limit);
  }
  function filterElements(elements, sel, options2) {
    const els = (Array.isArray(elements) ? elements : [elements]).filter(isTag2);
    if (els.length === 0)
      return els;
    const query2 = _compileToken(sel, options2);
    return query2 === boolbase7.trueFunc ? els : els.filter(query2);
  }

  // node_modules/cheerio/lib/esm/api/traversing.js
  var reSiblingSelector = /^\s*[~+]/;
  function find3(selectorOrHaystack) {
    var _a2;
    if (!selectorOrHaystack) {
      return this._make([]);
    }
    const context = this.toArray();
    if (typeof selectorOrHaystack !== "string") {
      const haystack = isCheerio(selectorOrHaystack) ? selectorOrHaystack.toArray() : [selectorOrHaystack];
      return this._make(haystack.filter((elem) => context.some((node) => contains(node, elem))));
    }
    const elems = reSiblingSelector.test(selectorOrHaystack) ? context : this.children().toArray();
    const options2 = {
      context,
      root: (_a2 = this._root) === null || _a2 === void 0 ? void 0 : _a2[0],
      // Pass options that are recognized by `cheerio-select`
      xmlMode: this.options.xmlMode,
      lowerCaseTags: this.options.lowerCaseTags,
      lowerCaseAttributeNames: this.options.lowerCaseAttributeNames,
      pseudos: this.options.pseudos,
      quirksMode: this.options.quirksMode
    };
    return this._make(select(selectorOrHaystack, elems, options2));
  }
  function _getMatcher(matchMap) {
    return function(fn, ...postFns) {
      return function(selector) {
        var _a2;
        let matched = matchMap(fn, this);
        if (selector) {
          matched = filterArray(matched, selector, this.options.xmlMode, (_a2 = this._root) === null || _a2 === void 0 ? void 0 : _a2[0]);
        }
        return this._make(
          // Post processing is only necessary if there is more than one element.
          this.length > 1 && matched.length > 1 ? postFns.reduce((elems, fn2) => fn2(elems), matched) : matched
        );
      };
    };
  }
  var _matcher = _getMatcher((fn, elems) => {
    const ret = [];
    for (let i3 = 0; i3 < elems.length; i3++) {
      const value = fn(elems[i3]);
      ret.push(value);
    }
    return new Array().concat(...ret);
  });
  var _singleMatcher = _getMatcher((fn, elems) => {
    const ret = [];
    for (let i3 = 0; i3 < elems.length; i3++) {
      const value = fn(elems[i3]);
      if (value !== null) {
        ret.push(value);
      }
    }
    return ret;
  });
  function _matchUntil(nextElem, ...postFns) {
    let matches2 = null;
    const innerMatcher = _getMatcher((nextElem2, elems) => {
      const matched = [];
      domEach(elems, (elem) => {
        for (let next2; next2 = nextElem2(elem); elem = next2) {
          if (matches2 === null || matches2 === void 0 ? void 0 : matches2(next2, matched.length))
            break;
          matched.push(next2);
        }
      });
      return matched;
    })(nextElem, ...postFns);
    return function(selector, filterSelector) {
      matches2 = typeof selector === "string" ? (elem) => is3(elem, selector, this.options) : selector ? getFilterFn(selector) : null;
      const ret = innerMatcher.call(this, filterSelector);
      matches2 = null;
      return ret;
    };
  }
  function _removeDuplicates(elems) {
    return Array.from(new Set(elems));
  }
  var parent = _singleMatcher(({ parent: parent2 }) => parent2 && !isDocument(parent2) ? parent2 : null, _removeDuplicates);
  var parents = _matcher((elem) => {
    const matched = [];
    while (elem.parent && !isDocument(elem.parent)) {
      matched.push(elem.parent);
      elem = elem.parent;
    }
    return matched;
  }, uniqueSort, (elems) => elems.reverse());
  var parentsUntil = _matchUntil(({ parent: parent2 }) => parent2 && !isDocument(parent2) ? parent2 : null, uniqueSort, (elems) => elems.reverse());
  function closest(selector) {
    var _a2;
    const set = [];
    if (!selector) {
      return this._make(set);
    }
    const selectOpts = {
      xmlMode: this.options.xmlMode,
      root: (_a2 = this._root) === null || _a2 === void 0 ? void 0 : _a2[0]
    };
    const selectFn = typeof selector === "string" ? (elem) => is3(elem, selector, selectOpts) : getFilterFn(selector);
    domEach(this, (elem) => {
      while (elem && isTag2(elem)) {
        if (selectFn(elem, 0)) {
          if (!set.includes(elem)) {
            set.push(elem);
          }
          break;
        }
        elem = elem.parent;
      }
    });
    return this._make(set);
  }
  var next = _singleMatcher((elem) => nextElementSibling(elem));
  var nextAll = _matcher((elem) => {
    const matched = [];
    while (elem.next) {
      elem = elem.next;
      if (isTag2(elem))
        matched.push(elem);
    }
    return matched;
  }, _removeDuplicates);
  var nextUntil = _matchUntil((el) => nextElementSibling(el), _removeDuplicates);
  var prev = _singleMatcher((elem) => prevElementSibling(elem));
  var prevAll = _matcher((elem) => {
    const matched = [];
    while (elem.prev) {
      elem = elem.prev;
      if (isTag2(elem))
        matched.push(elem);
    }
    return matched;
  }, _removeDuplicates);
  var prevUntil = _matchUntil((el) => prevElementSibling(el), _removeDuplicates);
  var siblings = _matcher((elem) => getSiblings(elem).filter((el) => isTag2(el) && el !== elem), uniqueSort);
  var children = _matcher((elem) => getChildren(elem).filter(isTag2), _removeDuplicates);
  function contents() {
    const elems = this.toArray().reduce((newElems, elem) => hasChildren(elem) ? newElems.concat(elem.children) : newElems, []);
    return this._make(elems);
  }
  function each(fn) {
    let i3 = 0;
    const len = this.length;
    while (i3 < len && fn.call(this[i3], i3, this[i3]) !== false)
      ++i3;
    return this;
  }
  function map(fn) {
    let elems = [];
    for (let i3 = 0; i3 < this.length; i3++) {
      const el = this[i3];
      const val2 = fn.call(el, i3, el);
      if (val2 != null) {
        elems = elems.concat(val2);
      }
    }
    return this._make(elems);
  }
  function getFilterFn(match) {
    if (typeof match === "function") {
      return (el, i3) => match.call(el, i3, el);
    }
    if (isCheerio(match)) {
      return (el) => Array.prototype.includes.call(match, el);
    }
    return function(el) {
      return match === el;
    };
  }
  function filter3(match) {
    var _a2;
    return this._make(filterArray(this.toArray(), match, this.options.xmlMode, (_a2 = this._root) === null || _a2 === void 0 ? void 0 : _a2[0]));
  }
  function filterArray(nodes, match, xmlMode, root4) {
    return typeof match === "string" ? filter2(match, nodes, { xmlMode, root: root4 }) : nodes.filter(getFilterFn(match));
  }
  function is4(selector) {
    const nodes = this.toArray();
    return typeof selector === "string" ? some(nodes.filter(isTag2), selector, this.options) : selector ? nodes.some(getFilterFn(selector)) : false;
  }
  function not(match) {
    let nodes = this.toArray();
    if (typeof match === "string") {
      const matches2 = new Set(filter2(match, nodes, this.options));
      nodes = nodes.filter((el) => !matches2.has(el));
    } else {
      const filterFn = getFilterFn(match);
      nodes = nodes.filter((el, i3) => !filterFn(el, i3));
    }
    return this._make(nodes);
  }
  function has(selectorOrHaystack) {
    return this.filter(typeof selectorOrHaystack === "string" ? (
      // Using the `:has` selector here short-circuits searches.
      `:has(${selectorOrHaystack})`
    ) : (_2, el) => this._make(el).find(selectorOrHaystack).length > 0);
  }
  function first() {
    return this.length > 1 ? this._make(this[0]) : this;
  }
  function last() {
    return this.length > 0 ? this._make(this[this.length - 1]) : this;
  }
  function eq2(i3) {
    var _a2;
    i3 = +i3;
    if (i3 === 0 && this.length <= 1)
      return this;
    if (i3 < 0)
      i3 = this.length + i3;
    return this._make((_a2 = this[i3]) !== null && _a2 !== void 0 ? _a2 : []);
  }
  function get(i3) {
    if (i3 == null) {
      return this.toArray();
    }
    return this[i3 < 0 ? this.length + i3 : i3];
  }
  function toArray() {
    return Array.prototype.slice.call(this);
  }
  function index(selectorOrNeedle) {
    let $haystack;
    let needle;
    if (selectorOrNeedle == null) {
      $haystack = this.parent().children();
      needle = this[0];
    } else if (typeof selectorOrNeedle === "string") {
      $haystack = this._make(selectorOrNeedle);
      needle = this[0];
    } else {
      $haystack = this;
      needle = isCheerio(selectorOrNeedle) ? selectorOrNeedle[0] : selectorOrNeedle;
    }
    return Array.prototype.indexOf.call($haystack, needle);
  }
  function slice(start, end2) {
    return this._make(Array.prototype.slice.call(this, start, end2));
  }
  function end() {
    var _a2;
    return (_a2 = this.prevObject) !== null && _a2 !== void 0 ? _a2 : this._make([]);
  }
  function add(other, context) {
    const selection = this._make(other, context);
    const contents2 = uniqueSort([...this.get(), ...selection.get()]);
    return this._make(contents2);
  }
  function addBack(selector) {
    return this.prevObject ? this.add(selector ? this.prevObject.filter(selector) : this.prevObject) : this;
  }

  // node_modules/cheerio/lib/esm/api/manipulation.js
  var manipulation_exports = {};
  __export(manipulation_exports, {
    _makeDomArray: () => _makeDomArray,
    after: () => after,
    append: () => append2,
    appendTo: () => appendTo,
    before: () => before,
    clone: () => clone,
    empty: () => empty,
    html: () => html2,
    insertAfter: () => insertAfter,
    insertBefore: () => insertBefore,
    prepend: () => prepend2,
    prependTo: () => prependTo,
    remove: () => remove,
    replaceWith: () => replaceWith,
    text: () => text2,
    toString: () => toString,
    unwrap: () => unwrap,
    wrap: () => wrap,
    wrapAll: () => wrapAll,
    wrapInner: () => wrapInner
  });

  // node_modules/cheerio/lib/esm/parse.js
  function getParse(parser) {
    return function parse8(content, options2, isDocument2, context) {
      if (typeof Buffer !== "undefined" && Buffer.isBuffer(content)) {
        content = content.toString();
      }
      if (typeof content === "string") {
        return parser(content, options2, isDocument2, context);
      }
      const doc = content;
      if (!Array.isArray(doc) && isDocument(doc)) {
        return doc;
      }
      const root4 = new Document([]);
      update(doc, root4);
      return root4;
    };
  }
  function update(newChilds, parent2) {
    const arr = Array.isArray(newChilds) ? newChilds : [newChilds];
    if (parent2) {
      parent2.children = arr;
    } else {
      parent2 = null;
    }
    for (let i3 = 0; i3 < arr.length; i3++) {
      const node = arr[i3];
      if (node.parent && node.parent.children !== arr) {
        removeElement(node);
      }
      if (parent2) {
        node.prev = arr[i3 - 1] || null;
        node.next = arr[i3 + 1] || null;
      } else {
        node.prev = node.next = null;
      }
      node.parent = parent2;
    }
    return parent2;
  }

  // node_modules/cheerio/lib/esm/api/manipulation.js
  function _makeDomArray(elem, clone2) {
    if (elem == null) {
      return [];
    }
    if (isCheerio(elem)) {
      return clone2 ? cloneDom(elem.get()) : elem.get();
    }
    if (Array.isArray(elem)) {
      return elem.reduce((newElems, el) => newElems.concat(this._makeDomArray(el, clone2)), []);
    }
    if (typeof elem === "string") {
      return this._parse(elem, this.options, false, null).children;
    }
    return clone2 ? cloneDom([elem]) : [elem];
  }
  function _insert(concatenator) {
    return function(...elems) {
      const lastIdx = this.length - 1;
      return domEach(this, (el, i3) => {
        if (!hasChildren(el))
          return;
        const domSrc = typeof elems[0] === "function" ? elems[0].call(el, i3, this._render(el.children)) : elems;
        const dom = this._makeDomArray(domSrc, i3 < lastIdx);
        concatenator(dom, el.children, el);
      });
    };
  }
  function uniqueSplice(array, spliceIdx, spliceCount, newElems, parent2) {
    var _a2, _b;
    const spliceArgs = [
      spliceIdx,
      spliceCount,
      ...newElems
    ];
    const prev2 = spliceIdx === 0 ? null : array[spliceIdx - 1];
    const next2 = spliceIdx + spliceCount >= array.length ? null : array[spliceIdx + spliceCount];
    for (let idx = 0; idx < newElems.length; ++idx) {
      const node = newElems[idx];
      const oldParent = node.parent;
      if (oldParent) {
        const oldSiblings = oldParent.children;
        const prevIdx = oldSiblings.indexOf(node);
        if (prevIdx > -1) {
          oldParent.children.splice(prevIdx, 1);
          if (parent2 === oldParent && spliceIdx > prevIdx) {
            spliceArgs[0]--;
          }
        }
      }
      node.parent = parent2;
      if (node.prev) {
        node.prev.next = (_a2 = node.next) !== null && _a2 !== void 0 ? _a2 : null;
      }
      if (node.next) {
        node.next.prev = (_b = node.prev) !== null && _b !== void 0 ? _b : null;
      }
      node.prev = idx === 0 ? prev2 : newElems[idx - 1];
      node.next = idx === newElems.length - 1 ? next2 : newElems[idx + 1];
    }
    if (prev2) {
      prev2.next = newElems[0];
    }
    if (next2) {
      next2.prev = newElems[newElems.length - 1];
    }
    return array.splice(...spliceArgs);
  }
  function appendTo(target) {
    const appendTarget = isCheerio(target) ? target : this._make(target);
    appendTarget.append(this);
    return this;
  }
  function prependTo(target) {
    const prependTarget = isCheerio(target) ? target : this._make(target);
    prependTarget.prepend(this);
    return this;
  }
  var append2 = _insert((dom, children2, parent2) => {
    uniqueSplice(children2, children2.length, 0, dom, parent2);
  });
  var prepend2 = _insert((dom, children2, parent2) => {
    uniqueSplice(children2, 0, 0, dom, parent2);
  });
  function _wrap(insert2) {
    return function(wrapper) {
      const lastIdx = this.length - 1;
      const lastParent = this.parents().last();
      for (let i3 = 0; i3 < this.length; i3++) {
        const el = this[i3];
        const wrap2 = typeof wrapper === "function" ? wrapper.call(el, i3, el) : typeof wrapper === "string" && !isHtml(wrapper) ? lastParent.find(wrapper).clone() : wrapper;
        const [wrapperDom] = this._makeDomArray(wrap2, i3 < lastIdx);
        if (!wrapperDom || !hasChildren(wrapperDom))
          continue;
        let elInsertLocation = wrapperDom;
        let j3 = 0;
        while (j3 < elInsertLocation.children.length) {
          const child = elInsertLocation.children[j3];
          if (isTag2(child)) {
            elInsertLocation = child;
            j3 = 0;
          } else {
            j3++;
          }
        }
        insert2(el, elInsertLocation, [wrapperDom]);
      }
      return this;
    };
  }
  var wrap = _wrap((el, elInsertLocation, wrapperDom) => {
    const { parent: parent2 } = el;
    if (!parent2)
      return;
    const siblings2 = parent2.children;
    const index2 = siblings2.indexOf(el);
    update([el], elInsertLocation);
    uniqueSplice(siblings2, index2, 0, wrapperDom, parent2);
  });
  var wrapInner = _wrap((el, elInsertLocation, wrapperDom) => {
    if (!hasChildren(el))
      return;
    update(el.children, elInsertLocation);
    update(wrapperDom, el);
  });
  function unwrap(selector) {
    this.parent(selector).not("body").each((_2, el) => {
      this._make(el).replaceWith(el.children);
    });
    return this;
  }
  function wrapAll(wrapper) {
    const el = this[0];
    if (el) {
      const wrap2 = this._make(typeof wrapper === "function" ? wrapper.call(el, 0, el) : wrapper).insertBefore(el);
      let elInsertLocation;
      for (let i3 = 0; i3 < wrap2.length; i3++) {
        if (wrap2[i3].type === "tag")
          elInsertLocation = wrap2[i3];
      }
      let j3 = 0;
      while (elInsertLocation && j3 < elInsertLocation.children.length) {
        const child = elInsertLocation.children[j3];
        if (child.type === "tag") {
          elInsertLocation = child;
          j3 = 0;
        } else {
          j3++;
        }
      }
      if (elInsertLocation)
        this._make(elInsertLocation).append(this);
    }
    return this;
  }
  function after(...elems) {
    const lastIdx = this.length - 1;
    return domEach(this, (el, i3) => {
      const { parent: parent2 } = el;
      if (!hasChildren(el) || !parent2) {
        return;
      }
      const siblings2 = parent2.children;
      const index2 = siblings2.indexOf(el);
      if (index2 < 0)
        return;
      const domSrc = typeof elems[0] === "function" ? elems[0].call(el, i3, this._render(el.children)) : elems;
      const dom = this._makeDomArray(domSrc, i3 < lastIdx);
      uniqueSplice(siblings2, index2 + 1, 0, dom, parent2);
    });
  }
  function insertAfter(target) {
    if (typeof target === "string") {
      target = this._make(target);
    }
    this.remove();
    const clones = [];
    this._makeDomArray(target).forEach((el) => {
      const clonedSelf = this.clone().toArray();
      const { parent: parent2 } = el;
      if (!parent2) {
        return;
      }
      const siblings2 = parent2.children;
      const index2 = siblings2.indexOf(el);
      if (index2 < 0)
        return;
      uniqueSplice(siblings2, index2 + 1, 0, clonedSelf, parent2);
      clones.push(...clonedSelf);
    });
    return this._make(clones);
  }
  function before(...elems) {
    const lastIdx = this.length - 1;
    return domEach(this, (el, i3) => {
      const { parent: parent2 } = el;
      if (!hasChildren(el) || !parent2) {
        return;
      }
      const siblings2 = parent2.children;
      const index2 = siblings2.indexOf(el);
      if (index2 < 0)
        return;
      const domSrc = typeof elems[0] === "function" ? elems[0].call(el, i3, this._render(el.children)) : elems;
      const dom = this._makeDomArray(domSrc, i3 < lastIdx);
      uniqueSplice(siblings2, index2, 0, dom, parent2);
    });
  }
  function insertBefore(target) {
    const targetArr = this._make(target);
    this.remove();
    const clones = [];
    domEach(targetArr, (el) => {
      const clonedSelf = this.clone().toArray();
      const { parent: parent2 } = el;
      if (!parent2) {
        return;
      }
      const siblings2 = parent2.children;
      const index2 = siblings2.indexOf(el);
      if (index2 < 0)
        return;
      uniqueSplice(siblings2, index2, 0, clonedSelf, parent2);
      clones.push(...clonedSelf);
    });
    return this._make(clones);
  }
  function remove(selector) {
    const elems = selector ? this.filter(selector) : this;
    domEach(elems, (el) => {
      removeElement(el);
      el.prev = el.next = el.parent = null;
    });
    return this;
  }
  function replaceWith(content) {
    return domEach(this, (el, i3) => {
      const { parent: parent2 } = el;
      if (!parent2) {
        return;
      }
      const siblings2 = parent2.children;
      const cont = typeof content === "function" ? content.call(el, i3, el) : content;
      const dom = this._makeDomArray(cont);
      update(dom, null);
      const index2 = siblings2.indexOf(el);
      uniqueSplice(siblings2, index2, 1, dom, parent2);
      if (!dom.includes(el)) {
        el.parent = el.prev = el.next = null;
      }
    });
  }
  function empty() {
    return domEach(this, (el) => {
      if (!hasChildren(el))
        return;
      el.children.forEach((child) => {
        child.next = child.prev = child.parent = null;
      });
      el.children.length = 0;
    });
  }
  function html2(str) {
    if (str === void 0) {
      const el = this[0];
      if (!el || !hasChildren(el))
        return null;
      return this._render(el.children);
    }
    return domEach(this, (el) => {
      if (!hasChildren(el))
        return;
      el.children.forEach((child) => {
        child.next = child.prev = child.parent = null;
      });
      const content = isCheerio(str) ? str.toArray() : this._parse(`${str}`, this.options, false, el).children;
      update(content, el);
    });
  }
  function toString() {
    return this._render(this);
  }
  function text2(str) {
    if (str === void 0) {
      return text(this);
    }
    if (typeof str === "function") {
      return domEach(this, (el, i3) => this._make(el).text(str.call(el, i3, text([el]))));
    }
    return domEach(this, (el) => {
      if (!hasChildren(el))
        return;
      el.children.forEach((child) => {
        child.next = child.prev = child.parent = null;
      });
      const textNode = new Text2(`${str}`);
      update(textNode, el);
    });
  }
  function clone() {
    return this._make(cloneDom(this.get()));
  }

  // node_modules/cheerio/lib/esm/api/css.js
  var css_exports = {};
  __export(css_exports, {
    css: () => css
  });
  function css(prop3, val2) {
    if (prop3 != null && val2 != null || // When `prop` is a "plain" object
    typeof prop3 === "object" && !Array.isArray(prop3)) {
      return domEach(this, (el, i3) => {
        if (isTag2(el)) {
          setCss(el, prop3, val2, i3);
        }
      });
    }
    if (this.length === 0) {
      return void 0;
    }
    return getCss(this[0], prop3);
  }
  function setCss(el, prop3, value, idx) {
    if (typeof prop3 === "string") {
      const styles = getCss(el);
      const val2 = typeof value === "function" ? value.call(el, idx, styles[prop3]) : value;
      if (val2 === "") {
        delete styles[prop3];
      } else if (val2 != null) {
        styles[prop3] = val2;
      }
      el.attribs["style"] = stringify(styles);
    } else if (typeof prop3 === "object") {
      Object.keys(prop3).forEach((k3, i3) => {
        setCss(el, k3, prop3[k3], i3);
      });
    }
  }
  function getCss(el, prop3) {
    if (!el || !isTag2(el))
      return;
    const styles = parse3(el.attribs["style"]);
    if (typeof prop3 === "string") {
      return styles[prop3];
    }
    if (Array.isArray(prop3)) {
      const newStyles = {};
      prop3.forEach((item) => {
        if (styles[item] != null) {
          newStyles[item] = styles[item];
        }
      });
      return newStyles;
    }
    return styles;
  }
  function stringify(obj) {
    return Object.keys(obj).reduce((str, prop3) => `${str}${str ? " " : ""}${prop3}: ${obj[prop3]};`, "");
  }
  function parse3(styles) {
    styles = (styles || "").trim();
    if (!styles)
      return {};
    const obj = {};
    let key2;
    for (const str of styles.split(";")) {
      const n2 = str.indexOf(":");
      if (n2 < 1 || n2 === str.length - 1) {
        const trimmed = str.trimEnd();
        if (trimmed.length > 0 && key2 !== void 0) {
          obj[key2] += `;${trimmed}`;
        }
      } else {
        key2 = str.slice(0, n2).trim();
        obj[key2] = str.slice(n2 + 1).trim();
      }
    }
    return obj;
  }

  // node_modules/cheerio/lib/esm/api/forms.js
  var forms_exports = {};
  __export(forms_exports, {
    serialize: () => serialize,
    serializeArray: () => serializeArray
  });
  var submittableSelector = "input,select,textarea,keygen";
  var r20 = /%20/g;
  var rCRLF = /\r?\n/g;
  function serialize() {
    const arr = this.serializeArray();
    const retArr = arr.map((data2) => `${encodeURIComponent(data2.name)}=${encodeURIComponent(data2.value)}`);
    return retArr.join("&").replace(r20, "+");
  }
  function serializeArray() {
    return this.map((_2, elem) => {
      const $elem = this._make(elem);
      if (isTag2(elem) && elem.name === "form") {
        return $elem.find(submittableSelector).toArray();
      }
      return $elem.filter(submittableSelector).toArray();
    }).filter(
      // Verify elements have a name (`attr.name`) and are not disabled (`:enabled`)
      '[name!=""]:enabled:not(:submit, :button, :image, :reset, :file):matches([checked], :not(:checkbox, :radio))'
      // Convert each of the elements to its value(s)
    ).map((_2, elem) => {
      var _a2;
      const $elem = this._make(elem);
      const name = $elem.attr("name");
      const value = (_a2 = $elem.val()) !== null && _a2 !== void 0 ? _a2 : "";
      if (Array.isArray(value)) {
        return value.map((val2) => (
          /*
           * We trim replace any line endings (e.g. `\r` or `\r\n` with `\r\n`) to guarantee consistency across platforms
           * These can occur inside of `<textarea>'s`
           */
          { name, value: val2.replace(rCRLF, "\r\n") }
        ));
      }
      return { name, value: value.replace(rCRLF, "\r\n") };
    }).toArray();
  }

  // node_modules/cheerio/lib/esm/cheerio.js
  var Cheerio = class {
    /**
     * Instance of cheerio. Methods are specified in the modules. Usage of this
     * constructor is not recommended. Please use `$.load` instead.
     *
     * @private
     * @param elements - The new selection.
     * @param root - Sets the root node.
     * @param options - Options for the instance.
     */
    constructor(elements, root4, options2) {
      this.length = 0;
      this.options = options2;
      this._root = root4;
      if (elements) {
        for (let idx = 0; idx < elements.length; idx++) {
          this[idx] = elements[idx];
        }
        this.length = elements.length;
      }
    }
  };
  Cheerio.prototype.cheerio = "[cheerio object]";
  Cheerio.prototype.splice = Array.prototype.splice;
  Cheerio.prototype[Symbol.iterator] = Array.prototype[Symbol.iterator];
  Object.assign(Cheerio.prototype, attributes_exports, traversing_exports, manipulation_exports, css_exports, forms_exports);

  // node_modules/cheerio/lib/esm/load.js
  function getLoad(parse8, render3) {
    return function load2(content, options2, isDocument2 = true) {
      if (content == null) {
        throw new Error("cheerio.load() expects a string");
      }
      const internalOpts = { ...options_default, ...flatten(options2) };
      const initialRoot = parse8(content, internalOpts, isDocument2, null);
      class LoadedCheerio extends Cheerio {
        _make(selector, context) {
          const cheerio = initialize(selector, context);
          cheerio.prevObject = this;
          return cheerio;
        }
        _parse(content2, options3, isDocument3, context) {
          return parse8(content2, options3, isDocument3, context);
        }
        _render(dom) {
          return render3(dom, this.options);
        }
      }
      function initialize(selector, context, root4 = initialRoot, opts) {
        if (selector && isCheerio(selector))
          return selector;
        const options3 = {
          ...internalOpts,
          ...flatten(opts)
        };
        const r3 = typeof root4 === "string" ? [parse8(root4, options3, false, null)] : "length" in root4 ? root4 : [root4];
        const rootInstance = isCheerio(r3) ? r3 : new LoadedCheerio(r3, null, options3);
        rootInstance._root = rootInstance;
        if (!selector) {
          return new LoadedCheerio(void 0, rootInstance, options3);
        }
        const elements = typeof selector === "string" && isHtml(selector) ? (
          // $(<html>)
          parse8(selector, options3, false, null).children
        ) : isNode(selector) ? (
          // $(dom)
          [selector]
        ) : Array.isArray(selector) ? (
          // $([dom])
          selector
        ) : void 0;
        const instance = new LoadedCheerio(elements, rootInstance, options3);
        if (elements) {
          return instance;
        }
        if (typeof selector !== "string") {
          throw new Error("Unexpected type of selector");
        }
        let search = selector;
        const searchContext = !context ? (
          // If we don't have a context, maybe we have a root, from loading
          rootInstance
        ) : typeof context === "string" ? isHtml(context) ? (
          // $('li', '<ul>...</ul>')
          new LoadedCheerio([parse8(context, options3, false, null)], rootInstance, options3)
        ) : (
          // $('li', 'ul')
          (search = `${context} ${search}`, rootInstance)
        ) : isCheerio(context) ? (
          // $('li', $)
          context
        ) : (
          // $('li', node), $('li', [nodes])
          new LoadedCheerio(Array.isArray(context) ? context : [context], rootInstance, options3)
        );
        if (!searchContext)
          return instance;
        return searchContext.find(search);
      }
      Object.assign(initialize, static_exports, {
        load: load2,
        // `_root` and `_options` are used in static methods.
        _root: initialRoot,
        _options: internalOpts,
        // Add `fn` for plugins
        fn: LoadedCheerio.prototype,
        // Add the prototype here to maintain `instanceof` behavior.
        prototype: LoadedCheerio.prototype
      });
      return initialize;
    };
  }
  function isNode(obj) {
    return !!obj.name || obj.type === "root" || obj.type === "text" || obj.type === "comment";
  }

  // node_modules/parse5/dist/common/unicode.js
  var UNDEFINED_CODE_POINTS = /* @__PURE__ */ new Set([
    65534,
    65535,
    131070,
    131071,
    196606,
    196607,
    262142,
    262143,
    327678,
    327679,
    393214,
    393215,
    458750,
    458751,
    524286,
    524287,
    589822,
    589823,
    655358,
    655359,
    720894,
    720895,
    786430,
    786431,
    851966,
    851967,
    917502,
    917503,
    983038,
    983039,
    1048574,
    1048575,
    1114110,
    1114111
  ]);
  var REPLACEMENT_CHARACTER = "\uFFFD";
  var CODE_POINTS;
  (function(CODE_POINTS2) {
    CODE_POINTS2[CODE_POINTS2["EOF"] = -1] = "EOF";
    CODE_POINTS2[CODE_POINTS2["NULL"] = 0] = "NULL";
    CODE_POINTS2[CODE_POINTS2["TABULATION"] = 9] = "TABULATION";
    CODE_POINTS2[CODE_POINTS2["CARRIAGE_RETURN"] = 13] = "CARRIAGE_RETURN";
    CODE_POINTS2[CODE_POINTS2["LINE_FEED"] = 10] = "LINE_FEED";
    CODE_POINTS2[CODE_POINTS2["FORM_FEED"] = 12] = "FORM_FEED";
    CODE_POINTS2[CODE_POINTS2["SPACE"] = 32] = "SPACE";
    CODE_POINTS2[CODE_POINTS2["EXCLAMATION_MARK"] = 33] = "EXCLAMATION_MARK";
    CODE_POINTS2[CODE_POINTS2["QUOTATION_MARK"] = 34] = "QUOTATION_MARK";
    CODE_POINTS2[CODE_POINTS2["NUMBER_SIGN"] = 35] = "NUMBER_SIGN";
    CODE_POINTS2[CODE_POINTS2["AMPERSAND"] = 38] = "AMPERSAND";
    CODE_POINTS2[CODE_POINTS2["APOSTROPHE"] = 39] = "APOSTROPHE";
    CODE_POINTS2[CODE_POINTS2["HYPHEN_MINUS"] = 45] = "HYPHEN_MINUS";
    CODE_POINTS2[CODE_POINTS2["SOLIDUS"] = 47] = "SOLIDUS";
    CODE_POINTS2[CODE_POINTS2["DIGIT_0"] = 48] = "DIGIT_0";
    CODE_POINTS2[CODE_POINTS2["DIGIT_9"] = 57] = "DIGIT_9";
    CODE_POINTS2[CODE_POINTS2["SEMICOLON"] = 59] = "SEMICOLON";
    CODE_POINTS2[CODE_POINTS2["LESS_THAN_SIGN"] = 60] = "LESS_THAN_SIGN";
    CODE_POINTS2[CODE_POINTS2["EQUALS_SIGN"] = 61] = "EQUALS_SIGN";
    CODE_POINTS2[CODE_POINTS2["GREATER_THAN_SIGN"] = 62] = "GREATER_THAN_SIGN";
    CODE_POINTS2[CODE_POINTS2["QUESTION_MARK"] = 63] = "QUESTION_MARK";
    CODE_POINTS2[CODE_POINTS2["LATIN_CAPITAL_A"] = 65] = "LATIN_CAPITAL_A";
    CODE_POINTS2[CODE_POINTS2["LATIN_CAPITAL_F"] = 70] = "LATIN_CAPITAL_F";
    CODE_POINTS2[CODE_POINTS2["LATIN_CAPITAL_X"] = 88] = "LATIN_CAPITAL_X";
    CODE_POINTS2[CODE_POINTS2["LATIN_CAPITAL_Z"] = 90] = "LATIN_CAPITAL_Z";
    CODE_POINTS2[CODE_POINTS2["RIGHT_SQUARE_BRACKET"] = 93] = "RIGHT_SQUARE_BRACKET";
    CODE_POINTS2[CODE_POINTS2["GRAVE_ACCENT"] = 96] = "GRAVE_ACCENT";
    CODE_POINTS2[CODE_POINTS2["LATIN_SMALL_A"] = 97] = "LATIN_SMALL_A";
    CODE_POINTS2[CODE_POINTS2["LATIN_SMALL_F"] = 102] = "LATIN_SMALL_F";
    CODE_POINTS2[CODE_POINTS2["LATIN_SMALL_X"] = 120] = "LATIN_SMALL_X";
    CODE_POINTS2[CODE_POINTS2["LATIN_SMALL_Z"] = 122] = "LATIN_SMALL_Z";
    CODE_POINTS2[CODE_POINTS2["REPLACEMENT_CHARACTER"] = 65533] = "REPLACEMENT_CHARACTER";
  })(CODE_POINTS = CODE_POINTS || (CODE_POINTS = {}));
  var SEQUENCES = {
    DASH_DASH: "--",
    CDATA_START: "[CDATA[",
    DOCTYPE: "doctype",
    SCRIPT: "script",
    PUBLIC: "public",
    SYSTEM: "system"
  };
  function isSurrogate(cp) {
    return cp >= 55296 && cp <= 57343;
  }
  function isSurrogatePair(cp) {
    return cp >= 56320 && cp <= 57343;
  }
  function getSurrogatePairCodePoint(cp1, cp2) {
    return (cp1 - 55296) * 1024 + 9216 + cp2;
  }
  function isControlCodePoint(cp) {
    return cp !== 32 && cp !== 10 && cp !== 13 && cp !== 9 && cp !== 12 && cp >= 1 && cp <= 31 || cp >= 127 && cp <= 159;
  }
  function isUndefinedCodePoint(cp) {
    return cp >= 64976 && cp <= 65007 || UNDEFINED_CODE_POINTS.has(cp);
  }

  // node_modules/parse5/dist/common/error-codes.js
  var ERR;
  (function(ERR2) {
    ERR2["controlCharacterInInputStream"] = "control-character-in-input-stream";
    ERR2["noncharacterInInputStream"] = "noncharacter-in-input-stream";
    ERR2["surrogateInInputStream"] = "surrogate-in-input-stream";
    ERR2["nonVoidHtmlElementStartTagWithTrailingSolidus"] = "non-void-html-element-start-tag-with-trailing-solidus";
    ERR2["endTagWithAttributes"] = "end-tag-with-attributes";
    ERR2["endTagWithTrailingSolidus"] = "end-tag-with-trailing-solidus";
    ERR2["unexpectedSolidusInTag"] = "unexpected-solidus-in-tag";
    ERR2["unexpectedNullCharacter"] = "unexpected-null-character";
    ERR2["unexpectedQuestionMarkInsteadOfTagName"] = "unexpected-question-mark-instead-of-tag-name";
    ERR2["invalidFirstCharacterOfTagName"] = "invalid-first-character-of-tag-name";
    ERR2["unexpectedEqualsSignBeforeAttributeName"] = "unexpected-equals-sign-before-attribute-name";
    ERR2["missingEndTagName"] = "missing-end-tag-name";
    ERR2["unexpectedCharacterInAttributeName"] = "unexpected-character-in-attribute-name";
    ERR2["unknownNamedCharacterReference"] = "unknown-named-character-reference";
    ERR2["missingSemicolonAfterCharacterReference"] = "missing-semicolon-after-character-reference";
    ERR2["unexpectedCharacterAfterDoctypeSystemIdentifier"] = "unexpected-character-after-doctype-system-identifier";
    ERR2["unexpectedCharacterInUnquotedAttributeValue"] = "unexpected-character-in-unquoted-attribute-value";
    ERR2["eofBeforeTagName"] = "eof-before-tag-name";
    ERR2["eofInTag"] = "eof-in-tag";
    ERR2["missingAttributeValue"] = "missing-attribute-value";
    ERR2["missingWhitespaceBetweenAttributes"] = "missing-whitespace-between-attributes";
    ERR2["missingWhitespaceAfterDoctypePublicKeyword"] = "missing-whitespace-after-doctype-public-keyword";
    ERR2["missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers"] = "missing-whitespace-between-doctype-public-and-system-identifiers";
    ERR2["missingWhitespaceAfterDoctypeSystemKeyword"] = "missing-whitespace-after-doctype-system-keyword";
    ERR2["missingQuoteBeforeDoctypePublicIdentifier"] = "missing-quote-before-doctype-public-identifier";
    ERR2["missingQuoteBeforeDoctypeSystemIdentifier"] = "missing-quote-before-doctype-system-identifier";
    ERR2["missingDoctypePublicIdentifier"] = "missing-doctype-public-identifier";
    ERR2["missingDoctypeSystemIdentifier"] = "missing-doctype-system-identifier";
    ERR2["abruptDoctypePublicIdentifier"] = "abrupt-doctype-public-identifier";
    ERR2["abruptDoctypeSystemIdentifier"] = "abrupt-doctype-system-identifier";
    ERR2["cdataInHtmlContent"] = "cdata-in-html-content";
    ERR2["incorrectlyOpenedComment"] = "incorrectly-opened-comment";
    ERR2["eofInScriptHtmlCommentLikeText"] = "eof-in-script-html-comment-like-text";
    ERR2["eofInDoctype"] = "eof-in-doctype";
    ERR2["nestedComment"] = "nested-comment";
    ERR2["abruptClosingOfEmptyComment"] = "abrupt-closing-of-empty-comment";
    ERR2["eofInComment"] = "eof-in-comment";
    ERR2["incorrectlyClosedComment"] = "incorrectly-closed-comment";
    ERR2["eofInCdata"] = "eof-in-cdata";
    ERR2["absenceOfDigitsInNumericCharacterReference"] = "absence-of-digits-in-numeric-character-reference";
    ERR2["nullCharacterReference"] = "null-character-reference";
    ERR2["surrogateCharacterReference"] = "surrogate-character-reference";
    ERR2["characterReferenceOutsideUnicodeRange"] = "character-reference-outside-unicode-range";
    ERR2["controlCharacterReference"] = "control-character-reference";
    ERR2["noncharacterCharacterReference"] = "noncharacter-character-reference";
    ERR2["missingWhitespaceBeforeDoctypeName"] = "missing-whitespace-before-doctype-name";
    ERR2["missingDoctypeName"] = "missing-doctype-name";
    ERR2["invalidCharacterSequenceAfterDoctypeName"] = "invalid-character-sequence-after-doctype-name";
    ERR2["duplicateAttribute"] = "duplicate-attribute";
    ERR2["nonConformingDoctype"] = "non-conforming-doctype";
    ERR2["missingDoctype"] = "missing-doctype";
    ERR2["misplacedDoctype"] = "misplaced-doctype";
    ERR2["endTagWithoutMatchingOpenElement"] = "end-tag-without-matching-open-element";
    ERR2["closingOfElementWithOpenChildElements"] = "closing-of-element-with-open-child-elements";
    ERR2["disallowedContentInNoscriptInHead"] = "disallowed-content-in-noscript-in-head";
    ERR2["openElementsLeftAfterEof"] = "open-elements-left-after-eof";
    ERR2["abandonedHeadElementChild"] = "abandoned-head-element-child";
    ERR2["misplacedStartTagForHeadElement"] = "misplaced-start-tag-for-head-element";
    ERR2["nestedNoscriptInHead"] = "nested-noscript-in-head";
    ERR2["eofInElementThatCanContainOnlyText"] = "eof-in-element-that-can-contain-only-text";
  })(ERR = ERR || (ERR = {}));

  // node_modules/parse5/dist/tokenizer/preprocessor.js
  var DEFAULT_BUFFER_WATERLINE = 1 << 16;
  var Preprocessor = class {
    constructor(handler4) {
      this.handler = handler4;
      this.html = "";
      this.pos = -1;
      this.lastGapPos = -2;
      this.gapStack = [];
      this.skipNextNewLine = false;
      this.lastChunkWritten = false;
      this.endOfChunkHit = false;
      this.bufferWaterline = DEFAULT_BUFFER_WATERLINE;
      this.isEol = false;
      this.lineStartPos = 0;
      this.droppedBufferSize = 0;
      this.line = 1;
      this.lastErrOffset = -1;
    }
    /** The column on the current line. If we just saw a gap (eg. a surrogate pair), return the index before. */
    get col() {
      return this.pos - this.lineStartPos + Number(this.lastGapPos !== this.pos);
    }
    get offset() {
      return this.droppedBufferSize + this.pos;
    }
    getError(code) {
      const { line, col, offset } = this;
      return {
        code,
        startLine: line,
        endLine: line,
        startCol: col,
        endCol: col,
        startOffset: offset,
        endOffset: offset
      };
    }
    _err(code) {
      if (this.handler.onParseError && this.lastErrOffset !== this.offset) {
        this.lastErrOffset = this.offset;
        this.handler.onParseError(this.getError(code));
      }
    }
    _addGap() {
      this.gapStack.push(this.lastGapPos);
      this.lastGapPos = this.pos;
    }
    _processSurrogate(cp) {
      if (this.pos !== this.html.length - 1) {
        const nextCp = this.html.charCodeAt(this.pos + 1);
        if (isSurrogatePair(nextCp)) {
          this.pos++;
          this._addGap();
          return getSurrogatePairCodePoint(cp, nextCp);
        }
      } else if (!this.lastChunkWritten) {
        this.endOfChunkHit = true;
        return CODE_POINTS.EOF;
      }
      this._err(ERR.surrogateInInputStream);
      return cp;
    }
    willDropParsedChunk() {
      return this.pos > this.bufferWaterline;
    }
    dropParsedChunk() {
      if (this.willDropParsedChunk()) {
        this.html = this.html.substring(this.pos);
        this.lineStartPos -= this.pos;
        this.droppedBufferSize += this.pos;
        this.pos = 0;
        this.lastGapPos = -2;
        this.gapStack.length = 0;
      }
    }
    write(chunk, isLastChunk) {
      if (this.html.length > 0) {
        this.html += chunk;
      } else {
        this.html = chunk;
      }
      this.endOfChunkHit = false;
      this.lastChunkWritten = isLastChunk;
    }
    insertHtmlAtCurrentPos(chunk) {
      this.html = this.html.substring(0, this.pos + 1) + chunk + this.html.substring(this.pos + 1);
      this.endOfChunkHit = false;
    }
    startsWith(pattern, caseSensitive) {
      if (this.pos + pattern.length > this.html.length) {
        this.endOfChunkHit = !this.lastChunkWritten;
        return false;
      }
      if (caseSensitive) {
        return this.html.startsWith(pattern, this.pos);
      }
      for (let i3 = 0; i3 < pattern.length; i3++) {
        const cp = this.html.charCodeAt(this.pos + i3) | 32;
        if (cp !== pattern.charCodeAt(i3)) {
          return false;
        }
      }
      return true;
    }
    peek(offset) {
      const pos = this.pos + offset;
      if (pos >= this.html.length) {
        this.endOfChunkHit = !this.lastChunkWritten;
        return CODE_POINTS.EOF;
      }
      const code = this.html.charCodeAt(pos);
      return code === CODE_POINTS.CARRIAGE_RETURN ? CODE_POINTS.LINE_FEED : code;
    }
    advance() {
      this.pos++;
      if (this.isEol) {
        this.isEol = false;
        this.line++;
        this.lineStartPos = this.pos;
      }
      if (this.pos >= this.html.length) {
        this.endOfChunkHit = !this.lastChunkWritten;
        return CODE_POINTS.EOF;
      }
      let cp = this.html.charCodeAt(this.pos);
      if (cp === CODE_POINTS.CARRIAGE_RETURN) {
        this.isEol = true;
        this.skipNextNewLine = true;
        return CODE_POINTS.LINE_FEED;
      }
      if (cp === CODE_POINTS.LINE_FEED) {
        this.isEol = true;
        if (this.skipNextNewLine) {
          this.line--;
          this.skipNextNewLine = false;
          this._addGap();
          return this.advance();
        }
      }
      this.skipNextNewLine = false;
      if (isSurrogate(cp)) {
        cp = this._processSurrogate(cp);
      }
      const isCommonValidRange = this.handler.onParseError === null || cp > 31 && cp < 127 || cp === CODE_POINTS.LINE_FEED || cp === CODE_POINTS.CARRIAGE_RETURN || cp > 159 && cp < 64976;
      if (!isCommonValidRange) {
        this._checkForProblematicCharacters(cp);
      }
      return cp;
    }
    _checkForProblematicCharacters(cp) {
      if (isControlCodePoint(cp)) {
        this._err(ERR.controlCharacterInInputStream);
      } else if (isUndefinedCodePoint(cp)) {
        this._err(ERR.noncharacterInInputStream);
      }
    }
    retreat(count) {
      this.pos -= count;
      while (this.pos < this.lastGapPos) {
        this.lastGapPos = this.gapStack.pop();
        this.pos--;
      }
      this.isEol = false;
    }
  };

  // node_modules/parse5/dist/common/token.js
  var TokenType;
  (function(TokenType2) {
    TokenType2[TokenType2["CHARACTER"] = 0] = "CHARACTER";
    TokenType2[TokenType2["NULL_CHARACTER"] = 1] = "NULL_CHARACTER";
    TokenType2[TokenType2["WHITESPACE_CHARACTER"] = 2] = "WHITESPACE_CHARACTER";
    TokenType2[TokenType2["START_TAG"] = 3] = "START_TAG";
    TokenType2[TokenType2["END_TAG"] = 4] = "END_TAG";
    TokenType2[TokenType2["COMMENT"] = 5] = "COMMENT";
    TokenType2[TokenType2["DOCTYPE"] = 6] = "DOCTYPE";
    TokenType2[TokenType2["EOF"] = 7] = "EOF";
    TokenType2[TokenType2["HIBERNATION"] = 8] = "HIBERNATION";
  })(TokenType = TokenType || (TokenType = {}));
  function getTokenAttr(token, attrName) {
    for (let i3 = token.attrs.length - 1; i3 >= 0; i3--) {
      if (token.attrs[i3].name === attrName) {
        return token.attrs[i3].value;
      }
    }
    return null;
  }

  // node_modules/parse5/dist/common/html.js
  var html_exports = {};
  __export(html_exports, {
    ATTRS: () => ATTRS,
    DOCUMENT_MODE: () => DOCUMENT_MODE,
    NS: () => NS,
    SPECIAL_ELEMENTS: () => SPECIAL_ELEMENTS,
    TAG_ID: () => TAG_ID,
    TAG_NAMES: () => TAG_NAMES,
    getTagID: () => getTagID,
    hasUnescapedText: () => hasUnescapedText,
    isNumberedHeader: () => isNumberedHeader
  });
  var NS;
  (function(NS2) {
    NS2["HTML"] = "http://www.w3.org/1999/xhtml";
    NS2["MATHML"] = "http://www.w3.org/1998/Math/MathML";
    NS2["SVG"] = "http://www.w3.org/2000/svg";
    NS2["XLINK"] = "http://www.w3.org/1999/xlink";
    NS2["XML"] = "http://www.w3.org/XML/1998/namespace";
    NS2["XMLNS"] = "http://www.w3.org/2000/xmlns/";
  })(NS = NS || (NS = {}));
  var ATTRS;
  (function(ATTRS2) {
    ATTRS2["TYPE"] = "type";
    ATTRS2["ACTION"] = "action";
    ATTRS2["ENCODING"] = "encoding";
    ATTRS2["PROMPT"] = "prompt";
    ATTRS2["NAME"] = "name";
    ATTRS2["COLOR"] = "color";
    ATTRS2["FACE"] = "face";
    ATTRS2["SIZE"] = "size";
  })(ATTRS = ATTRS || (ATTRS = {}));
  var DOCUMENT_MODE;
  (function(DOCUMENT_MODE2) {
    DOCUMENT_MODE2["NO_QUIRKS"] = "no-quirks";
    DOCUMENT_MODE2["QUIRKS"] = "quirks";
    DOCUMENT_MODE2["LIMITED_QUIRKS"] = "limited-quirks";
  })(DOCUMENT_MODE = DOCUMENT_MODE || (DOCUMENT_MODE = {}));
  var TAG_NAMES;
  (function(TAG_NAMES2) {
    TAG_NAMES2["A"] = "a";
    TAG_NAMES2["ADDRESS"] = "address";
    TAG_NAMES2["ANNOTATION_XML"] = "annotation-xml";
    TAG_NAMES2["APPLET"] = "applet";
    TAG_NAMES2["AREA"] = "area";
    TAG_NAMES2["ARTICLE"] = "article";
    TAG_NAMES2["ASIDE"] = "aside";
    TAG_NAMES2["B"] = "b";
    TAG_NAMES2["BASE"] = "base";
    TAG_NAMES2["BASEFONT"] = "basefont";
    TAG_NAMES2["BGSOUND"] = "bgsound";
    TAG_NAMES2["BIG"] = "big";
    TAG_NAMES2["BLOCKQUOTE"] = "blockquote";
    TAG_NAMES2["BODY"] = "body";
    TAG_NAMES2["BR"] = "br";
    TAG_NAMES2["BUTTON"] = "button";
    TAG_NAMES2["CAPTION"] = "caption";
    TAG_NAMES2["CENTER"] = "center";
    TAG_NAMES2["CODE"] = "code";
    TAG_NAMES2["COL"] = "col";
    TAG_NAMES2["COLGROUP"] = "colgroup";
    TAG_NAMES2["DD"] = "dd";
    TAG_NAMES2["DESC"] = "desc";
    TAG_NAMES2["DETAILS"] = "details";
    TAG_NAMES2["DIALOG"] = "dialog";
    TAG_NAMES2["DIR"] = "dir";
    TAG_NAMES2["DIV"] = "div";
    TAG_NAMES2["DL"] = "dl";
    TAG_NAMES2["DT"] = "dt";
    TAG_NAMES2["EM"] = "em";
    TAG_NAMES2["EMBED"] = "embed";
    TAG_NAMES2["FIELDSET"] = "fieldset";
    TAG_NAMES2["FIGCAPTION"] = "figcaption";
    TAG_NAMES2["FIGURE"] = "figure";
    TAG_NAMES2["FONT"] = "font";
    TAG_NAMES2["FOOTER"] = "footer";
    TAG_NAMES2["FOREIGN_OBJECT"] = "foreignObject";
    TAG_NAMES2["FORM"] = "form";
    TAG_NAMES2["FRAME"] = "frame";
    TAG_NAMES2["FRAMESET"] = "frameset";
    TAG_NAMES2["H1"] = "h1";
    TAG_NAMES2["H2"] = "h2";
    TAG_NAMES2["H3"] = "h3";
    TAG_NAMES2["H4"] = "h4";
    TAG_NAMES2["H5"] = "h5";
    TAG_NAMES2["H6"] = "h6";
    TAG_NAMES2["HEAD"] = "head";
    TAG_NAMES2["HEADER"] = "header";
    TAG_NAMES2["HGROUP"] = "hgroup";
    TAG_NAMES2["HR"] = "hr";
    TAG_NAMES2["HTML"] = "html";
    TAG_NAMES2["I"] = "i";
    TAG_NAMES2["IMG"] = "img";
    TAG_NAMES2["IMAGE"] = "image";
    TAG_NAMES2["INPUT"] = "input";
    TAG_NAMES2["IFRAME"] = "iframe";
    TAG_NAMES2["KEYGEN"] = "keygen";
    TAG_NAMES2["LABEL"] = "label";
    TAG_NAMES2["LI"] = "li";
    TAG_NAMES2["LINK"] = "link";
    TAG_NAMES2["LISTING"] = "listing";
    TAG_NAMES2["MAIN"] = "main";
    TAG_NAMES2["MALIGNMARK"] = "malignmark";
    TAG_NAMES2["MARQUEE"] = "marquee";
    TAG_NAMES2["MATH"] = "math";
    TAG_NAMES2["MENU"] = "menu";
    TAG_NAMES2["META"] = "meta";
    TAG_NAMES2["MGLYPH"] = "mglyph";
    TAG_NAMES2["MI"] = "mi";
    TAG_NAMES2["MO"] = "mo";
    TAG_NAMES2["MN"] = "mn";
    TAG_NAMES2["MS"] = "ms";
    TAG_NAMES2["MTEXT"] = "mtext";
    TAG_NAMES2["NAV"] = "nav";
    TAG_NAMES2["NOBR"] = "nobr";
    TAG_NAMES2["NOFRAMES"] = "noframes";
    TAG_NAMES2["NOEMBED"] = "noembed";
    TAG_NAMES2["NOSCRIPT"] = "noscript";
    TAG_NAMES2["OBJECT"] = "object";
    TAG_NAMES2["OL"] = "ol";
    TAG_NAMES2["OPTGROUP"] = "optgroup";
    TAG_NAMES2["OPTION"] = "option";
    TAG_NAMES2["P"] = "p";
    TAG_NAMES2["PARAM"] = "param";
    TAG_NAMES2["PLAINTEXT"] = "plaintext";
    TAG_NAMES2["PRE"] = "pre";
    TAG_NAMES2["RB"] = "rb";
    TAG_NAMES2["RP"] = "rp";
    TAG_NAMES2["RT"] = "rt";
    TAG_NAMES2["RTC"] = "rtc";
    TAG_NAMES2["RUBY"] = "ruby";
    TAG_NAMES2["S"] = "s";
    TAG_NAMES2["SCRIPT"] = "script";
    TAG_NAMES2["SECTION"] = "section";
    TAG_NAMES2["SELECT"] = "select";
    TAG_NAMES2["SOURCE"] = "source";
    TAG_NAMES2["SMALL"] = "small";
    TAG_NAMES2["SPAN"] = "span";
    TAG_NAMES2["STRIKE"] = "strike";
    TAG_NAMES2["STRONG"] = "strong";
    TAG_NAMES2["STYLE"] = "style";
    TAG_NAMES2["SUB"] = "sub";
    TAG_NAMES2["SUMMARY"] = "summary";
    TAG_NAMES2["SUP"] = "sup";
    TAG_NAMES2["TABLE"] = "table";
    TAG_NAMES2["TBODY"] = "tbody";
    TAG_NAMES2["TEMPLATE"] = "template";
    TAG_NAMES2["TEXTAREA"] = "textarea";
    TAG_NAMES2["TFOOT"] = "tfoot";
    TAG_NAMES2["TD"] = "td";
    TAG_NAMES2["TH"] = "th";
    TAG_NAMES2["THEAD"] = "thead";
    TAG_NAMES2["TITLE"] = "title";
    TAG_NAMES2["TR"] = "tr";
    TAG_NAMES2["TRACK"] = "track";
    TAG_NAMES2["TT"] = "tt";
    TAG_NAMES2["U"] = "u";
    TAG_NAMES2["UL"] = "ul";
    TAG_NAMES2["SVG"] = "svg";
    TAG_NAMES2["VAR"] = "var";
    TAG_NAMES2["WBR"] = "wbr";
    TAG_NAMES2["XMP"] = "xmp";
  })(TAG_NAMES = TAG_NAMES || (TAG_NAMES = {}));
  var TAG_ID;
  (function(TAG_ID2) {
    TAG_ID2[TAG_ID2["UNKNOWN"] = 0] = "UNKNOWN";
    TAG_ID2[TAG_ID2["A"] = 1] = "A";
    TAG_ID2[TAG_ID2["ADDRESS"] = 2] = "ADDRESS";
    TAG_ID2[TAG_ID2["ANNOTATION_XML"] = 3] = "ANNOTATION_XML";
    TAG_ID2[TAG_ID2["APPLET"] = 4] = "APPLET";
    TAG_ID2[TAG_ID2["AREA"] = 5] = "AREA";
    TAG_ID2[TAG_ID2["ARTICLE"] = 6] = "ARTICLE";
    TAG_ID2[TAG_ID2["ASIDE"] = 7] = "ASIDE";
    TAG_ID2[TAG_ID2["B"] = 8] = "B";
    TAG_ID2[TAG_ID2["BASE"] = 9] = "BASE";
    TAG_ID2[TAG_ID2["BASEFONT"] = 10] = "BASEFONT";
    TAG_ID2[TAG_ID2["BGSOUND"] = 11] = "BGSOUND";
    TAG_ID2[TAG_ID2["BIG"] = 12] = "BIG";
    TAG_ID2[TAG_ID2["BLOCKQUOTE"] = 13] = "BLOCKQUOTE";
    TAG_ID2[TAG_ID2["BODY"] = 14] = "BODY";
    TAG_ID2[TAG_ID2["BR"] = 15] = "BR";
    TAG_ID2[TAG_ID2["BUTTON"] = 16] = "BUTTON";
    TAG_ID2[TAG_ID2["CAPTION"] = 17] = "CAPTION";
    TAG_ID2[TAG_ID2["CENTER"] = 18] = "CENTER";
    TAG_ID2[TAG_ID2["CODE"] = 19] = "CODE";
    TAG_ID2[TAG_ID2["COL"] = 20] = "COL";
    TAG_ID2[TAG_ID2["COLGROUP"] = 21] = "COLGROUP";
    TAG_ID2[TAG_ID2["DD"] = 22] = "DD";
    TAG_ID2[TAG_ID2["DESC"] = 23] = "DESC";
    TAG_ID2[TAG_ID2["DETAILS"] = 24] = "DETAILS";
    TAG_ID2[TAG_ID2["DIALOG"] = 25] = "DIALOG";
    TAG_ID2[TAG_ID2["DIR"] = 26] = "DIR";
    TAG_ID2[TAG_ID2["DIV"] = 27] = "DIV";
    TAG_ID2[TAG_ID2["DL"] = 28] = "DL";
    TAG_ID2[TAG_ID2["DT"] = 29] = "DT";
    TAG_ID2[TAG_ID2["EM"] = 30] = "EM";
    TAG_ID2[TAG_ID2["EMBED"] = 31] = "EMBED";
    TAG_ID2[TAG_ID2["FIELDSET"] = 32] = "FIELDSET";
    TAG_ID2[TAG_ID2["FIGCAPTION"] = 33] = "FIGCAPTION";
    TAG_ID2[TAG_ID2["FIGURE"] = 34] = "FIGURE";
    TAG_ID2[TAG_ID2["FONT"] = 35] = "FONT";
    TAG_ID2[TAG_ID2["FOOTER"] = 36] = "FOOTER";
    TAG_ID2[TAG_ID2["FOREIGN_OBJECT"] = 37] = "FOREIGN_OBJECT";
    TAG_ID2[TAG_ID2["FORM"] = 38] = "FORM";
    TAG_ID2[TAG_ID2["FRAME"] = 39] = "FRAME";
    TAG_ID2[TAG_ID2["FRAMESET"] = 40] = "FRAMESET";
    TAG_ID2[TAG_ID2["H1"] = 41] = "H1";
    TAG_ID2[TAG_ID2["H2"] = 42] = "H2";
    TAG_ID2[TAG_ID2["H3"] = 43] = "H3";
    TAG_ID2[TAG_ID2["H4"] = 44] = "H4";
    TAG_ID2[TAG_ID2["H5"] = 45] = "H5";
    TAG_ID2[TAG_ID2["H6"] = 46] = "H6";
    TAG_ID2[TAG_ID2["HEAD"] = 47] = "HEAD";
    TAG_ID2[TAG_ID2["HEADER"] = 48] = "HEADER";
    TAG_ID2[TAG_ID2["HGROUP"] = 49] = "HGROUP";
    TAG_ID2[TAG_ID2["HR"] = 50] = "HR";
    TAG_ID2[TAG_ID2["HTML"] = 51] = "HTML";
    TAG_ID2[TAG_ID2["I"] = 52] = "I";
    TAG_ID2[TAG_ID2["IMG"] = 53] = "IMG";
    TAG_ID2[TAG_ID2["IMAGE"] = 54] = "IMAGE";
    TAG_ID2[TAG_ID2["INPUT"] = 55] = "INPUT";
    TAG_ID2[TAG_ID2["IFRAME"] = 56] = "IFRAME";
    TAG_ID2[TAG_ID2["KEYGEN"] = 57] = "KEYGEN";
    TAG_ID2[TAG_ID2["LABEL"] = 58] = "LABEL";
    TAG_ID2[TAG_ID2["LI"] = 59] = "LI";
    TAG_ID2[TAG_ID2["LINK"] = 60] = "LINK";
    TAG_ID2[TAG_ID2["LISTING"] = 61] = "LISTING";
    TAG_ID2[TAG_ID2["MAIN"] = 62] = "MAIN";
    TAG_ID2[TAG_ID2["MALIGNMARK"] = 63] = "MALIGNMARK";
    TAG_ID2[TAG_ID2["MARQUEE"] = 64] = "MARQUEE";
    TAG_ID2[TAG_ID2["MATH"] = 65] = "MATH";
    TAG_ID2[TAG_ID2["MENU"] = 66] = "MENU";
    TAG_ID2[TAG_ID2["META"] = 67] = "META";
    TAG_ID2[TAG_ID2["MGLYPH"] = 68] = "MGLYPH";
    TAG_ID2[TAG_ID2["MI"] = 69] = "MI";
    TAG_ID2[TAG_ID2["MO"] = 70] = "MO";
    TAG_ID2[TAG_ID2["MN"] = 71] = "MN";
    TAG_ID2[TAG_ID2["MS"] = 72] = "MS";
    TAG_ID2[TAG_ID2["MTEXT"] = 73] = "MTEXT";
    TAG_ID2[TAG_ID2["NAV"] = 74] = "NAV";
    TAG_ID2[TAG_ID2["NOBR"] = 75] = "NOBR";
    TAG_ID2[TAG_ID2["NOFRAMES"] = 76] = "NOFRAMES";
    TAG_ID2[TAG_ID2["NOEMBED"] = 77] = "NOEMBED";
    TAG_ID2[TAG_ID2["NOSCRIPT"] = 78] = "NOSCRIPT";
    TAG_ID2[TAG_ID2["OBJECT"] = 79] = "OBJECT";
    TAG_ID2[TAG_ID2["OL"] = 80] = "OL";
    TAG_ID2[TAG_ID2["OPTGROUP"] = 81] = "OPTGROUP";
    TAG_ID2[TAG_ID2["OPTION"] = 82] = "OPTION";
    TAG_ID2[TAG_ID2["P"] = 83] = "P";
    TAG_ID2[TAG_ID2["PARAM"] = 84] = "PARAM";
    TAG_ID2[TAG_ID2["PLAINTEXT"] = 85] = "PLAINTEXT";
    TAG_ID2[TAG_ID2["PRE"] = 86] = "PRE";
    TAG_ID2[TAG_ID2["RB"] = 87] = "RB";
    TAG_ID2[TAG_ID2["RP"] = 88] = "RP";
    TAG_ID2[TAG_ID2["RT"] = 89] = "RT";
    TAG_ID2[TAG_ID2["RTC"] = 90] = "RTC";
    TAG_ID2[TAG_ID2["RUBY"] = 91] = "RUBY";
    TAG_ID2[TAG_ID2["S"] = 92] = "S";
    TAG_ID2[TAG_ID2["SCRIPT"] = 93] = "SCRIPT";
    TAG_ID2[TAG_ID2["SECTION"] = 94] = "SECTION";
    TAG_ID2[TAG_ID2["SELECT"] = 95] = "SELECT";
    TAG_ID2[TAG_ID2["SOURCE"] = 96] = "SOURCE";
    TAG_ID2[TAG_ID2["SMALL"] = 97] = "SMALL";
    TAG_ID2[TAG_ID2["SPAN"] = 98] = "SPAN";
    TAG_ID2[TAG_ID2["STRIKE"] = 99] = "STRIKE";
    TAG_ID2[TAG_ID2["STRONG"] = 100] = "STRONG";
    TAG_ID2[TAG_ID2["STYLE"] = 101] = "STYLE";
    TAG_ID2[TAG_ID2["SUB"] = 102] = "SUB";
    TAG_ID2[TAG_ID2["SUMMARY"] = 103] = "SUMMARY";
    TAG_ID2[TAG_ID2["SUP"] = 104] = "SUP";
    TAG_ID2[TAG_ID2["TABLE"] = 105] = "TABLE";
    TAG_ID2[TAG_ID2["TBODY"] = 106] = "TBODY";
    TAG_ID2[TAG_ID2["TEMPLATE"] = 107] = "TEMPLATE";
    TAG_ID2[TAG_ID2["TEXTAREA"] = 108] = "TEXTAREA";
    TAG_ID2[TAG_ID2["TFOOT"] = 109] = "TFOOT";
    TAG_ID2[TAG_ID2["TD"] = 110] = "TD";
    TAG_ID2[TAG_ID2["TH"] = 111] = "TH";
    TAG_ID2[TAG_ID2["THEAD"] = 112] = "THEAD";
    TAG_ID2[TAG_ID2["TITLE"] = 113] = "TITLE";
    TAG_ID2[TAG_ID2["TR"] = 114] = "TR";
    TAG_ID2[TAG_ID2["TRACK"] = 115] = "TRACK";
    TAG_ID2[TAG_ID2["TT"] = 116] = "TT";
    TAG_ID2[TAG_ID2["U"] = 117] = "U";
    TAG_ID2[TAG_ID2["UL"] = 118] = "UL";
    TAG_ID2[TAG_ID2["SVG"] = 119] = "SVG";
    TAG_ID2[TAG_ID2["VAR"] = 120] = "VAR";
    TAG_ID2[TAG_ID2["WBR"] = 121] = "WBR";
    TAG_ID2[TAG_ID2["XMP"] = 122] = "XMP";
  })(TAG_ID = TAG_ID || (TAG_ID = {}));
  var TAG_NAME_TO_ID = /* @__PURE__ */ new Map([
    [TAG_NAMES.A, TAG_ID.A],
    [TAG_NAMES.ADDRESS, TAG_ID.ADDRESS],
    [TAG_NAMES.ANNOTATION_XML, TAG_ID.ANNOTATION_XML],
    [TAG_NAMES.APPLET, TAG_ID.APPLET],
    [TAG_NAMES.AREA, TAG_ID.AREA],
    [TAG_NAMES.ARTICLE, TAG_ID.ARTICLE],
    [TAG_NAMES.ASIDE, TAG_ID.ASIDE],
    [TAG_NAMES.B, TAG_ID.B],
    [TAG_NAMES.BASE, TAG_ID.BASE],
    [TAG_NAMES.BASEFONT, TAG_ID.BASEFONT],
    [TAG_NAMES.BGSOUND, TAG_ID.BGSOUND],
    [TAG_NAMES.BIG, TAG_ID.BIG],
    [TAG_NAMES.BLOCKQUOTE, TAG_ID.BLOCKQUOTE],
    [TAG_NAMES.BODY, TAG_ID.BODY],
    [TAG_NAMES.BR, TAG_ID.BR],
    [TAG_NAMES.BUTTON, TAG_ID.BUTTON],
    [TAG_NAMES.CAPTION, TAG_ID.CAPTION],
    [TAG_NAMES.CENTER, TAG_ID.CENTER],
    [TAG_NAMES.CODE, TAG_ID.CODE],
    [TAG_NAMES.COL, TAG_ID.COL],
    [TAG_NAMES.COLGROUP, TAG_ID.COLGROUP],
    [TAG_NAMES.DD, TAG_ID.DD],
    [TAG_NAMES.DESC, TAG_ID.DESC],
    [TAG_NAMES.DETAILS, TAG_ID.DETAILS],
    [TAG_NAMES.DIALOG, TAG_ID.DIALOG],
    [TAG_NAMES.DIR, TAG_ID.DIR],
    [TAG_NAMES.DIV, TAG_ID.DIV],
    [TAG_NAMES.DL, TAG_ID.DL],
    [TAG_NAMES.DT, TAG_ID.DT],
    [TAG_NAMES.EM, TAG_ID.EM],
    [TAG_NAMES.EMBED, TAG_ID.EMBED],
    [TAG_NAMES.FIELDSET, TAG_ID.FIELDSET],
    [TAG_NAMES.FIGCAPTION, TAG_ID.FIGCAPTION],
    [TAG_NAMES.FIGURE, TAG_ID.FIGURE],
    [TAG_NAMES.FONT, TAG_ID.FONT],
    [TAG_NAMES.FOOTER, TAG_ID.FOOTER],
    [TAG_NAMES.FOREIGN_OBJECT, TAG_ID.FOREIGN_OBJECT],
    [TAG_NAMES.FORM, TAG_ID.FORM],
    [TAG_NAMES.FRAME, TAG_ID.FRAME],
    [TAG_NAMES.FRAMESET, TAG_ID.FRAMESET],
    [TAG_NAMES.H1, TAG_ID.H1],
    [TAG_NAMES.H2, TAG_ID.H2],
    [TAG_NAMES.H3, TAG_ID.H3],
    [TAG_NAMES.H4, TAG_ID.H4],
    [TAG_NAMES.H5, TAG_ID.H5],
    [TAG_NAMES.H6, TAG_ID.H6],
    [TAG_NAMES.HEAD, TAG_ID.HEAD],
    [TAG_NAMES.HEADER, TAG_ID.HEADER],
    [TAG_NAMES.HGROUP, TAG_ID.HGROUP],
    [TAG_NAMES.HR, TAG_ID.HR],
    [TAG_NAMES.HTML, TAG_ID.HTML],
    [TAG_NAMES.I, TAG_ID.I],
    [TAG_NAMES.IMG, TAG_ID.IMG],
    [TAG_NAMES.IMAGE, TAG_ID.IMAGE],
    [TAG_NAMES.INPUT, TAG_ID.INPUT],
    [TAG_NAMES.IFRAME, TAG_ID.IFRAME],
    [TAG_NAMES.KEYGEN, TAG_ID.KEYGEN],
    [TAG_NAMES.LABEL, TAG_ID.LABEL],
    [TAG_NAMES.LI, TAG_ID.LI],
    [TAG_NAMES.LINK, TAG_ID.LINK],
    [TAG_NAMES.LISTING, TAG_ID.LISTING],
    [TAG_NAMES.MAIN, TAG_ID.MAIN],
    [TAG_NAMES.MALIGNMARK, TAG_ID.MALIGNMARK],
    [TAG_NAMES.MARQUEE, TAG_ID.MARQUEE],
    [TAG_NAMES.MATH, TAG_ID.MATH],
    [TAG_NAMES.MENU, TAG_ID.MENU],
    [TAG_NAMES.META, TAG_ID.META],
    [TAG_NAMES.MGLYPH, TAG_ID.MGLYPH],
    [TAG_NAMES.MI, TAG_ID.MI],
    [TAG_NAMES.MO, TAG_ID.MO],
    [TAG_NAMES.MN, TAG_ID.MN],
    [TAG_NAMES.MS, TAG_ID.MS],
    [TAG_NAMES.MTEXT, TAG_ID.MTEXT],
    [TAG_NAMES.NAV, TAG_ID.NAV],
    [TAG_NAMES.NOBR, TAG_ID.NOBR],
    [TAG_NAMES.NOFRAMES, TAG_ID.NOFRAMES],
    [TAG_NAMES.NOEMBED, TAG_ID.NOEMBED],
    [TAG_NAMES.NOSCRIPT, TAG_ID.NOSCRIPT],
    [TAG_NAMES.OBJECT, TAG_ID.OBJECT],
    [TAG_NAMES.OL, TAG_ID.OL],
    [TAG_NAMES.OPTGROUP, TAG_ID.OPTGROUP],
    [TAG_NAMES.OPTION, TAG_ID.OPTION],
    [TAG_NAMES.P, TAG_ID.P],
    [TAG_NAMES.PARAM, TAG_ID.PARAM],
    [TAG_NAMES.PLAINTEXT, TAG_ID.PLAINTEXT],
    [TAG_NAMES.PRE, TAG_ID.PRE],
    [TAG_NAMES.RB, TAG_ID.RB],
    [TAG_NAMES.RP, TAG_ID.RP],
    [TAG_NAMES.RT, TAG_ID.RT],
    [TAG_NAMES.RTC, TAG_ID.RTC],
    [TAG_NAMES.RUBY, TAG_ID.RUBY],
    [TAG_NAMES.S, TAG_ID.S],
    [TAG_NAMES.SCRIPT, TAG_ID.SCRIPT],
    [TAG_NAMES.SECTION, TAG_ID.SECTION],
    [TAG_NAMES.SELECT, TAG_ID.SELECT],
    [TAG_NAMES.SOURCE, TAG_ID.SOURCE],
    [TAG_NAMES.SMALL, TAG_ID.SMALL],
    [TAG_NAMES.SPAN, TAG_ID.SPAN],
    [TAG_NAMES.STRIKE, TAG_ID.STRIKE],
    [TAG_NAMES.STRONG, TAG_ID.STRONG],
    [TAG_NAMES.STYLE, TAG_ID.STYLE],
    [TAG_NAMES.SUB, TAG_ID.SUB],
    [TAG_NAMES.SUMMARY, TAG_ID.SUMMARY],
    [TAG_NAMES.SUP, TAG_ID.SUP],
    [TAG_NAMES.TABLE, TAG_ID.TABLE],
    [TAG_NAMES.TBODY, TAG_ID.TBODY],
    [TAG_NAMES.TEMPLATE, TAG_ID.TEMPLATE],
    [TAG_NAMES.TEXTAREA, TAG_ID.TEXTAREA],
    [TAG_NAMES.TFOOT, TAG_ID.TFOOT],
    [TAG_NAMES.TD, TAG_ID.TD],
    [TAG_NAMES.TH, TAG_ID.TH],
    [TAG_NAMES.THEAD, TAG_ID.THEAD],
    [TAG_NAMES.TITLE, TAG_ID.TITLE],
    [TAG_NAMES.TR, TAG_ID.TR],
    [TAG_NAMES.TRACK, TAG_ID.TRACK],
    [TAG_NAMES.TT, TAG_ID.TT],
    [TAG_NAMES.U, TAG_ID.U],
    [TAG_NAMES.UL, TAG_ID.UL],
    [TAG_NAMES.SVG, TAG_ID.SVG],
    [TAG_NAMES.VAR, TAG_ID.VAR],
    [TAG_NAMES.WBR, TAG_ID.WBR],
    [TAG_NAMES.XMP, TAG_ID.XMP]
  ]);
  function getTagID(tagName18) {
    var _a2;
    return (_a2 = TAG_NAME_TO_ID.get(tagName18)) !== null && _a2 !== void 0 ? _a2 : TAG_ID.UNKNOWN;
  }
  var $2 = TAG_ID;
  var SPECIAL_ELEMENTS = {
    [NS.HTML]: /* @__PURE__ */ new Set([
      $2.ADDRESS,
      $2.APPLET,
      $2.AREA,
      $2.ARTICLE,
      $2.ASIDE,
      $2.BASE,
      $2.BASEFONT,
      $2.BGSOUND,
      $2.BLOCKQUOTE,
      $2.BODY,
      $2.BR,
      $2.BUTTON,
      $2.CAPTION,
      $2.CENTER,
      $2.COL,
      $2.COLGROUP,
      $2.DD,
      $2.DETAILS,
      $2.DIR,
      $2.DIV,
      $2.DL,
      $2.DT,
      $2.EMBED,
      $2.FIELDSET,
      $2.FIGCAPTION,
      $2.FIGURE,
      $2.FOOTER,
      $2.FORM,
      $2.FRAME,
      $2.FRAMESET,
      $2.H1,
      $2.H2,
      $2.H3,
      $2.H4,
      $2.H5,
      $2.H6,
      $2.HEAD,
      $2.HEADER,
      $2.HGROUP,
      $2.HR,
      $2.HTML,
      $2.IFRAME,
      $2.IMG,
      $2.INPUT,
      $2.LI,
      $2.LINK,
      $2.LISTING,
      $2.MAIN,
      $2.MARQUEE,
      $2.MENU,
      $2.META,
      $2.NAV,
      $2.NOEMBED,
      $2.NOFRAMES,
      $2.NOSCRIPT,
      $2.OBJECT,
      $2.OL,
      $2.P,
      $2.PARAM,
      $2.PLAINTEXT,
      $2.PRE,
      $2.SCRIPT,
      $2.SECTION,
      $2.SELECT,
      $2.SOURCE,
      $2.STYLE,
      $2.SUMMARY,
      $2.TABLE,
      $2.TBODY,
      $2.TD,
      $2.TEMPLATE,
      $2.TEXTAREA,
      $2.TFOOT,
      $2.TH,
      $2.THEAD,
      $2.TITLE,
      $2.TR,
      $2.TRACK,
      $2.UL,
      $2.WBR,
      $2.XMP
    ]),
    [NS.MATHML]: /* @__PURE__ */ new Set([$2.MI, $2.MO, $2.MN, $2.MS, $2.MTEXT, $2.ANNOTATION_XML]),
    [NS.SVG]: /* @__PURE__ */ new Set([$2.TITLE, $2.FOREIGN_OBJECT, $2.DESC]),
    [NS.XLINK]: /* @__PURE__ */ new Set(),
    [NS.XML]: /* @__PURE__ */ new Set(),
    [NS.XMLNS]: /* @__PURE__ */ new Set()
  };
  function isNumberedHeader(tn) {
    return tn === $2.H1 || tn === $2.H2 || tn === $2.H3 || tn === $2.H4 || tn === $2.H5 || tn === $2.H6;
  }
  var UNESCAPED_TEXT = /* @__PURE__ */ new Set([
    TAG_NAMES.STYLE,
    TAG_NAMES.SCRIPT,
    TAG_NAMES.XMP,
    TAG_NAMES.IFRAME,
    TAG_NAMES.NOEMBED,
    TAG_NAMES.NOFRAMES,
    TAG_NAMES.PLAINTEXT
  ]);
  function hasUnescapedText(tn, scriptingEnabled) {
    return UNESCAPED_TEXT.has(tn) || scriptingEnabled && tn === TAG_NAMES.NOSCRIPT;
  }

  // node_modules/parse5/dist/tokenizer/index.js
  var C1_CONTROLS_REFERENCE_REPLACEMENTS = /* @__PURE__ */ new Map([
    [128, 8364],
    [130, 8218],
    [131, 402],
    [132, 8222],
    [133, 8230],
    [134, 8224],
    [135, 8225],
    [136, 710],
    [137, 8240],
    [138, 352],
    [139, 8249],
    [140, 338],
    [142, 381],
    [145, 8216],
    [146, 8217],
    [147, 8220],
    [148, 8221],
    [149, 8226],
    [150, 8211],
    [151, 8212],
    [152, 732],
    [153, 8482],
    [154, 353],
    [155, 8250],
    [156, 339],
    [158, 382],
    [159, 376]
  ]);
  var State;
  (function(State3) {
    State3[State3["DATA"] = 0] = "DATA";
    State3[State3["RCDATA"] = 1] = "RCDATA";
    State3[State3["RAWTEXT"] = 2] = "RAWTEXT";
    State3[State3["SCRIPT_DATA"] = 3] = "SCRIPT_DATA";
    State3[State3["PLAINTEXT"] = 4] = "PLAINTEXT";
    State3[State3["TAG_OPEN"] = 5] = "TAG_OPEN";
    State3[State3["END_TAG_OPEN"] = 6] = "END_TAG_OPEN";
    State3[State3["TAG_NAME"] = 7] = "TAG_NAME";
    State3[State3["RCDATA_LESS_THAN_SIGN"] = 8] = "RCDATA_LESS_THAN_SIGN";
    State3[State3["RCDATA_END_TAG_OPEN"] = 9] = "RCDATA_END_TAG_OPEN";
    State3[State3["RCDATA_END_TAG_NAME"] = 10] = "RCDATA_END_TAG_NAME";
    State3[State3["RAWTEXT_LESS_THAN_SIGN"] = 11] = "RAWTEXT_LESS_THAN_SIGN";
    State3[State3["RAWTEXT_END_TAG_OPEN"] = 12] = "RAWTEXT_END_TAG_OPEN";
    State3[State3["RAWTEXT_END_TAG_NAME"] = 13] = "RAWTEXT_END_TAG_NAME";
    State3[State3["SCRIPT_DATA_LESS_THAN_SIGN"] = 14] = "SCRIPT_DATA_LESS_THAN_SIGN";
    State3[State3["SCRIPT_DATA_END_TAG_OPEN"] = 15] = "SCRIPT_DATA_END_TAG_OPEN";
    State3[State3["SCRIPT_DATA_END_TAG_NAME"] = 16] = "SCRIPT_DATA_END_TAG_NAME";
    State3[State3["SCRIPT_DATA_ESCAPE_START"] = 17] = "SCRIPT_DATA_ESCAPE_START";
    State3[State3["SCRIPT_DATA_ESCAPE_START_DASH"] = 18] = "SCRIPT_DATA_ESCAPE_START_DASH";
    State3[State3["SCRIPT_DATA_ESCAPED"] = 19] = "SCRIPT_DATA_ESCAPED";
    State3[State3["SCRIPT_DATA_ESCAPED_DASH"] = 20] = "SCRIPT_DATA_ESCAPED_DASH";
    State3[State3["SCRIPT_DATA_ESCAPED_DASH_DASH"] = 21] = "SCRIPT_DATA_ESCAPED_DASH_DASH";
    State3[State3["SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN"] = 22] = "SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN";
    State3[State3["SCRIPT_DATA_ESCAPED_END_TAG_OPEN"] = 23] = "SCRIPT_DATA_ESCAPED_END_TAG_OPEN";
    State3[State3["SCRIPT_DATA_ESCAPED_END_TAG_NAME"] = 24] = "SCRIPT_DATA_ESCAPED_END_TAG_NAME";
    State3[State3["SCRIPT_DATA_DOUBLE_ESCAPE_START"] = 25] = "SCRIPT_DATA_DOUBLE_ESCAPE_START";
    State3[State3["SCRIPT_DATA_DOUBLE_ESCAPED"] = 26] = "SCRIPT_DATA_DOUBLE_ESCAPED";
    State3[State3["SCRIPT_DATA_DOUBLE_ESCAPED_DASH"] = 27] = "SCRIPT_DATA_DOUBLE_ESCAPED_DASH";
    State3[State3["SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH"] = 28] = "SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH";
    State3[State3["SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN"] = 29] = "SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN";
    State3[State3["SCRIPT_DATA_DOUBLE_ESCAPE_END"] = 30] = "SCRIPT_DATA_DOUBLE_ESCAPE_END";
    State3[State3["BEFORE_ATTRIBUTE_NAME"] = 31] = "BEFORE_ATTRIBUTE_NAME";
    State3[State3["ATTRIBUTE_NAME"] = 32] = "ATTRIBUTE_NAME";
    State3[State3["AFTER_ATTRIBUTE_NAME"] = 33] = "AFTER_ATTRIBUTE_NAME";
    State3[State3["BEFORE_ATTRIBUTE_VALUE"] = 34] = "BEFORE_ATTRIBUTE_VALUE";
    State3[State3["ATTRIBUTE_VALUE_DOUBLE_QUOTED"] = 35] = "ATTRIBUTE_VALUE_DOUBLE_QUOTED";
    State3[State3["ATTRIBUTE_VALUE_SINGLE_QUOTED"] = 36] = "ATTRIBUTE_VALUE_SINGLE_QUOTED";
    State3[State3["ATTRIBUTE_VALUE_UNQUOTED"] = 37] = "ATTRIBUTE_VALUE_UNQUOTED";
    State3[State3["AFTER_ATTRIBUTE_VALUE_QUOTED"] = 38] = "AFTER_ATTRIBUTE_VALUE_QUOTED";
    State3[State3["SELF_CLOSING_START_TAG"] = 39] = "SELF_CLOSING_START_TAG";
    State3[State3["BOGUS_COMMENT"] = 40] = "BOGUS_COMMENT";
    State3[State3["MARKUP_DECLARATION_OPEN"] = 41] = "MARKUP_DECLARATION_OPEN";
    State3[State3["COMMENT_START"] = 42] = "COMMENT_START";
    State3[State3["COMMENT_START_DASH"] = 43] = "COMMENT_START_DASH";
    State3[State3["COMMENT"] = 44] = "COMMENT";
    State3[State3["COMMENT_LESS_THAN_SIGN"] = 45] = "COMMENT_LESS_THAN_SIGN";
    State3[State3["COMMENT_LESS_THAN_SIGN_BANG"] = 46] = "COMMENT_LESS_THAN_SIGN_BANG";
    State3[State3["COMMENT_LESS_THAN_SIGN_BANG_DASH"] = 47] = "COMMENT_LESS_THAN_SIGN_BANG_DASH";
    State3[State3["COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH"] = 48] = "COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH";
    State3[State3["COMMENT_END_DASH"] = 49] = "COMMENT_END_DASH";
    State3[State3["COMMENT_END"] = 50] = "COMMENT_END";
    State3[State3["COMMENT_END_BANG"] = 51] = "COMMENT_END_BANG";
    State3[State3["DOCTYPE"] = 52] = "DOCTYPE";
    State3[State3["BEFORE_DOCTYPE_NAME"] = 53] = "BEFORE_DOCTYPE_NAME";
    State3[State3["DOCTYPE_NAME"] = 54] = "DOCTYPE_NAME";
    State3[State3["AFTER_DOCTYPE_NAME"] = 55] = "AFTER_DOCTYPE_NAME";
    State3[State3["AFTER_DOCTYPE_PUBLIC_KEYWORD"] = 56] = "AFTER_DOCTYPE_PUBLIC_KEYWORD";
    State3[State3["BEFORE_DOCTYPE_PUBLIC_IDENTIFIER"] = 57] = "BEFORE_DOCTYPE_PUBLIC_IDENTIFIER";
    State3[State3["DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED"] = 58] = "DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED";
    State3[State3["DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED"] = 59] = "DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED";
    State3[State3["AFTER_DOCTYPE_PUBLIC_IDENTIFIER"] = 60] = "AFTER_DOCTYPE_PUBLIC_IDENTIFIER";
    State3[State3["BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS"] = 61] = "BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS";
    State3[State3["AFTER_DOCTYPE_SYSTEM_KEYWORD"] = 62] = "AFTER_DOCTYPE_SYSTEM_KEYWORD";
    State3[State3["BEFORE_DOCTYPE_SYSTEM_IDENTIFIER"] = 63] = "BEFORE_DOCTYPE_SYSTEM_IDENTIFIER";
    State3[State3["DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED"] = 64] = "DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED";
    State3[State3["DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED"] = 65] = "DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED";
    State3[State3["AFTER_DOCTYPE_SYSTEM_IDENTIFIER"] = 66] = "AFTER_DOCTYPE_SYSTEM_IDENTIFIER";
    State3[State3["BOGUS_DOCTYPE"] = 67] = "BOGUS_DOCTYPE";
    State3[State3["CDATA_SECTION"] = 68] = "CDATA_SECTION";
    State3[State3["CDATA_SECTION_BRACKET"] = 69] = "CDATA_SECTION_BRACKET";
    State3[State3["CDATA_SECTION_END"] = 70] = "CDATA_SECTION_END";
    State3[State3["CHARACTER_REFERENCE"] = 71] = "CHARACTER_REFERENCE";
    State3[State3["NAMED_CHARACTER_REFERENCE"] = 72] = "NAMED_CHARACTER_REFERENCE";
    State3[State3["AMBIGUOUS_AMPERSAND"] = 73] = "AMBIGUOUS_AMPERSAND";
    State3[State3["NUMERIC_CHARACTER_REFERENCE"] = 74] = "NUMERIC_CHARACTER_REFERENCE";
    State3[State3["HEXADEMICAL_CHARACTER_REFERENCE_START"] = 75] = "HEXADEMICAL_CHARACTER_REFERENCE_START";
    State3[State3["HEXADEMICAL_CHARACTER_REFERENCE"] = 76] = "HEXADEMICAL_CHARACTER_REFERENCE";
    State3[State3["DECIMAL_CHARACTER_REFERENCE"] = 77] = "DECIMAL_CHARACTER_REFERENCE";
    State3[State3["NUMERIC_CHARACTER_REFERENCE_END"] = 78] = "NUMERIC_CHARACTER_REFERENCE_END";
  })(State || (State = {}));
  var TokenizerMode = {
    DATA: State.DATA,
    RCDATA: State.RCDATA,
    RAWTEXT: State.RAWTEXT,
    SCRIPT_DATA: State.SCRIPT_DATA,
    PLAINTEXT: State.PLAINTEXT,
    CDATA_SECTION: State.CDATA_SECTION
  };
  function isAsciiDigit(cp) {
    return cp >= CODE_POINTS.DIGIT_0 && cp <= CODE_POINTS.DIGIT_9;
  }
  function isAsciiUpper(cp) {
    return cp >= CODE_POINTS.LATIN_CAPITAL_A && cp <= CODE_POINTS.LATIN_CAPITAL_Z;
  }
  function isAsciiLower(cp) {
    return cp >= CODE_POINTS.LATIN_SMALL_A && cp <= CODE_POINTS.LATIN_SMALL_Z;
  }
  function isAsciiLetter(cp) {
    return isAsciiLower(cp) || isAsciiUpper(cp);
  }
  function isAsciiAlphaNumeric(cp) {
    return isAsciiLetter(cp) || isAsciiDigit(cp);
  }
  function isAsciiUpperHexDigit(cp) {
    return cp >= CODE_POINTS.LATIN_CAPITAL_A && cp <= CODE_POINTS.LATIN_CAPITAL_F;
  }
  function isAsciiLowerHexDigit(cp) {
    return cp >= CODE_POINTS.LATIN_SMALL_A && cp <= CODE_POINTS.LATIN_SMALL_F;
  }
  function isAsciiHexDigit(cp) {
    return isAsciiDigit(cp) || isAsciiUpperHexDigit(cp) || isAsciiLowerHexDigit(cp);
  }
  function toAsciiLower(cp) {
    return cp + 32;
  }
  function isWhitespace2(cp) {
    return cp === CODE_POINTS.SPACE || cp === CODE_POINTS.LINE_FEED || cp === CODE_POINTS.TABULATION || cp === CODE_POINTS.FORM_FEED;
  }
  function isEntityInAttributeInvalidEnd(nextCp) {
    return nextCp === CODE_POINTS.EQUALS_SIGN || isAsciiAlphaNumeric(nextCp);
  }
  function isScriptDataDoubleEscapeSequenceEnd(cp) {
    return isWhitespace2(cp) || cp === CODE_POINTS.SOLIDUS || cp === CODE_POINTS.GREATER_THAN_SIGN;
  }
  var Tokenizer = class {
    constructor(options2, handler4) {
      this.options = options2;
      this.handler = handler4;
      this.paused = false;
      this.inLoop = false;
      this.inForeignNode = false;
      this.lastStartTagName = "";
      this.active = false;
      this.state = State.DATA;
      this.returnState = State.DATA;
      this.charRefCode = -1;
      this.consumedAfterSnapshot = -1;
      this.currentCharacterToken = null;
      this.currentToken = null;
      this.currentAttr = { name: "", value: "" };
      this.preprocessor = new Preprocessor(handler4);
      this.currentLocation = this.getCurrentLocation(-1);
    }
    //Errors
    _err(code) {
      var _a2, _b;
      (_b = (_a2 = this.handler).onParseError) === null || _b === void 0 ? void 0 : _b.call(_a2, this.preprocessor.getError(code));
    }
    // NOTE: `offset` may never run across line boundaries.
    getCurrentLocation(offset) {
      if (!this.options.sourceCodeLocationInfo) {
        return null;
      }
      return {
        startLine: this.preprocessor.line,
        startCol: this.preprocessor.col - offset,
        startOffset: this.preprocessor.offset - offset,
        endLine: -1,
        endCol: -1,
        endOffset: -1
      };
    }
    _runParsingLoop() {
      if (this.inLoop)
        return;
      this.inLoop = true;
      while (this.active && !this.paused) {
        this.consumedAfterSnapshot = 0;
        const cp = this._consume();
        if (!this._ensureHibernation()) {
          this._callState(cp);
        }
      }
      this.inLoop = false;
    }
    //API
    pause() {
      this.paused = true;
    }
    resume(writeCallback) {
      if (!this.paused) {
        throw new Error("Parser was already resumed");
      }
      this.paused = false;
      if (this.inLoop)
        return;
      this._runParsingLoop();
      if (!this.paused) {
        writeCallback === null || writeCallback === void 0 ? void 0 : writeCallback();
      }
    }
    write(chunk, isLastChunk, writeCallback) {
      this.active = true;
      this.preprocessor.write(chunk, isLastChunk);
      this._runParsingLoop();
      if (!this.paused) {
        writeCallback === null || writeCallback === void 0 ? void 0 : writeCallback();
      }
    }
    insertHtmlAtCurrentPos(chunk) {
      this.active = true;
      this.preprocessor.insertHtmlAtCurrentPos(chunk);
      this._runParsingLoop();
    }
    //Hibernation
    _ensureHibernation() {
      if (this.preprocessor.endOfChunkHit) {
        this._unconsume(this.consumedAfterSnapshot);
        this.active = false;
        return true;
      }
      return false;
    }
    //Consumption
    _consume() {
      this.consumedAfterSnapshot++;
      return this.preprocessor.advance();
    }
    _unconsume(count) {
      this.consumedAfterSnapshot -= count;
      this.preprocessor.retreat(count);
    }
    _reconsumeInState(state, cp) {
      this.state = state;
      this._callState(cp);
    }
    _advanceBy(count) {
      this.consumedAfterSnapshot += count;
      for (let i3 = 0; i3 < count; i3++) {
        this.preprocessor.advance();
      }
    }
    _consumeSequenceIfMatch(pattern, caseSensitive) {
      if (this.preprocessor.startsWith(pattern, caseSensitive)) {
        this._advanceBy(pattern.length - 1);
        return true;
      }
      return false;
    }
    //Token creation
    _createStartTagToken() {
      this.currentToken = {
        type: TokenType.START_TAG,
        tagName: "",
        tagID: TAG_ID.UNKNOWN,
        selfClosing: false,
        ackSelfClosing: false,
        attrs: [],
        location: this.getCurrentLocation(1)
      };
    }
    _createEndTagToken() {
      this.currentToken = {
        type: TokenType.END_TAG,
        tagName: "",
        tagID: TAG_ID.UNKNOWN,
        selfClosing: false,
        ackSelfClosing: false,
        attrs: [],
        location: this.getCurrentLocation(2)
      };
    }
    _createCommentToken(offset) {
      this.currentToken = {
        type: TokenType.COMMENT,
        data: "",
        location: this.getCurrentLocation(offset)
      };
    }
    _createDoctypeToken(initialName) {
      this.currentToken = {
        type: TokenType.DOCTYPE,
        name: initialName,
        forceQuirks: false,
        publicId: null,
        systemId: null,
        location: this.currentLocation
      };
    }
    _createCharacterToken(type, chars) {
      this.currentCharacterToken = {
        type,
        chars,
        location: this.currentLocation
      };
    }
    //Tag attributes
    _createAttr(attrNameFirstCh) {
      this.currentAttr = {
        name: attrNameFirstCh,
        value: ""
      };
      this.currentLocation = this.getCurrentLocation(0);
    }
    _leaveAttrName() {
      var _a2;
      var _b;
      const token = this.currentToken;
      if (getTokenAttr(token, this.currentAttr.name) === null) {
        token.attrs.push(this.currentAttr);
        if (token.location && this.currentLocation) {
          const attrLocations = (_a2 = (_b = token.location).attrs) !== null && _a2 !== void 0 ? _a2 : _b.attrs = /* @__PURE__ */ Object.create(null);
          attrLocations[this.currentAttr.name] = this.currentLocation;
          this._leaveAttrValue();
        }
      } else {
        this._err(ERR.duplicateAttribute);
      }
    }
    _leaveAttrValue() {
      if (this.currentLocation) {
        this.currentLocation.endLine = this.preprocessor.line;
        this.currentLocation.endCol = this.preprocessor.col;
        this.currentLocation.endOffset = this.preprocessor.offset;
      }
    }
    //Token emission
    prepareToken(ct) {
      this._emitCurrentCharacterToken(ct.location);
      this.currentToken = null;
      if (ct.location) {
        ct.location.endLine = this.preprocessor.line;
        ct.location.endCol = this.preprocessor.col + 1;
        ct.location.endOffset = this.preprocessor.offset + 1;
      }
      this.currentLocation = this.getCurrentLocation(-1);
    }
    emitCurrentTagToken() {
      const ct = this.currentToken;
      this.prepareToken(ct);
      ct.tagID = getTagID(ct.tagName);
      if (ct.type === TokenType.START_TAG) {
        this.lastStartTagName = ct.tagName;
        this.handler.onStartTag(ct);
      } else {
        if (ct.attrs.length > 0) {
          this._err(ERR.endTagWithAttributes);
        }
        if (ct.selfClosing) {
          this._err(ERR.endTagWithTrailingSolidus);
        }
        this.handler.onEndTag(ct);
      }
      this.preprocessor.dropParsedChunk();
    }
    emitCurrentComment(ct) {
      this.prepareToken(ct);
      this.handler.onComment(ct);
      this.preprocessor.dropParsedChunk();
    }
    emitCurrentDoctype(ct) {
      this.prepareToken(ct);
      this.handler.onDoctype(ct);
      this.preprocessor.dropParsedChunk();
    }
    _emitCurrentCharacterToken(nextLocation) {
      if (this.currentCharacterToken) {
        if (nextLocation && this.currentCharacterToken.location) {
          this.currentCharacterToken.location.endLine = nextLocation.startLine;
          this.currentCharacterToken.location.endCol = nextLocation.startCol;
          this.currentCharacterToken.location.endOffset = nextLocation.startOffset;
        }
        switch (this.currentCharacterToken.type) {
          case TokenType.CHARACTER: {
            this.handler.onCharacter(this.currentCharacterToken);
            break;
          }
          case TokenType.NULL_CHARACTER: {
            this.handler.onNullCharacter(this.currentCharacterToken);
            break;
          }
          case TokenType.WHITESPACE_CHARACTER: {
            this.handler.onWhitespaceCharacter(this.currentCharacterToken);
            break;
          }
        }
        this.currentCharacterToken = null;
      }
    }
    _emitEOFToken() {
      const location = this.getCurrentLocation(0);
      if (location) {
        location.endLine = location.startLine;
        location.endCol = location.startCol;
        location.endOffset = location.startOffset;
      }
      this._emitCurrentCharacterToken(location);
      this.handler.onEof({ type: TokenType.EOF, location });
      this.active = false;
    }
    //Characters emission
    //OPTIMIZATION: specification uses only one type of character tokens (one token per character).
    //This causes a huge memory overhead and a lot of unnecessary parser loops. parse5 uses 3 groups of characters.
    //If we have a sequence of characters that belong to the same group, the parser can process it
    //as a single solid character token.
    //So, there are 3 types of character tokens in parse5:
    //1)TokenType.NULL_CHARACTER - \u0000-character sequences (e.g. '\u0000\u0000\u0000')
    //2)TokenType.WHITESPACE_CHARACTER - any whitespace/new-line character sequences (e.g. '\n  \r\t   \f')
    //3)TokenType.CHARACTER - any character sequence which don't belong to groups 1 and 2 (e.g. 'abcdef1234@@#$%^')
    _appendCharToCurrentCharacterToken(type, ch) {
      if (this.currentCharacterToken) {
        if (this.currentCharacterToken.type !== type) {
          this.currentLocation = this.getCurrentLocation(0);
          this._emitCurrentCharacterToken(this.currentLocation);
          this.preprocessor.dropParsedChunk();
        } else {
          this.currentCharacterToken.chars += ch;
          return;
        }
      }
      this._createCharacterToken(type, ch);
    }
    _emitCodePoint(cp) {
      const type = isWhitespace2(cp) ? TokenType.WHITESPACE_CHARACTER : cp === CODE_POINTS.NULL ? TokenType.NULL_CHARACTER : TokenType.CHARACTER;
      this._appendCharToCurrentCharacterToken(type, String.fromCodePoint(cp));
    }
    //NOTE: used when we emit characters explicitly.
    //This is always for non-whitespace and non-null characters, which allows us to avoid additional checks.
    _emitChars(ch) {
      this._appendCharToCurrentCharacterToken(TokenType.CHARACTER, ch);
    }
    // Character reference helpers
    _matchNamedCharacterReference(cp) {
      let result = null;
      let excess = 0;
      let withoutSemicolon = false;
      for (let i3 = 0, current = decode_data_html_default[0]; i3 >= 0; cp = this._consume()) {
        i3 = determineBranch(decode_data_html_default, current, i3 + 1, cp);
        if (i3 < 0)
          break;
        excess += 1;
        current = decode_data_html_default[i3];
        const masked = current & BinTrieFlags.VALUE_LENGTH;
        if (masked) {
          const valueLength = (masked >> 14) - 1;
          if (cp !== CODE_POINTS.SEMICOLON && this._isCharacterReferenceInAttribute() && isEntityInAttributeInvalidEnd(this.preprocessor.peek(1))) {
            result = [CODE_POINTS.AMPERSAND];
            i3 += valueLength;
          } else {
            result = valueLength === 0 ? [decode_data_html_default[i3] & ~BinTrieFlags.VALUE_LENGTH] : valueLength === 1 ? [decode_data_html_default[++i3]] : [decode_data_html_default[++i3], decode_data_html_default[++i3]];
            excess = 0;
            withoutSemicolon = cp !== CODE_POINTS.SEMICOLON;
          }
          if (valueLength === 0) {
            this._consume();
            break;
          }
        }
      }
      this._unconsume(excess);
      if (withoutSemicolon && !this.preprocessor.endOfChunkHit) {
        this._err(ERR.missingSemicolonAfterCharacterReference);
      }
      this._unconsume(1);
      return result;
    }
    _isCharacterReferenceInAttribute() {
      return this.returnState === State.ATTRIBUTE_VALUE_DOUBLE_QUOTED || this.returnState === State.ATTRIBUTE_VALUE_SINGLE_QUOTED || this.returnState === State.ATTRIBUTE_VALUE_UNQUOTED;
    }
    _flushCodePointConsumedAsCharacterReference(cp) {
      if (this._isCharacterReferenceInAttribute()) {
        this.currentAttr.value += String.fromCodePoint(cp);
      } else {
        this._emitCodePoint(cp);
      }
    }
    // Calling states this way turns out to be much faster than any other approach.
    _callState(cp) {
      switch (this.state) {
        case State.DATA: {
          this._stateData(cp);
          break;
        }
        case State.RCDATA: {
          this._stateRcdata(cp);
          break;
        }
        case State.RAWTEXT: {
          this._stateRawtext(cp);
          break;
        }
        case State.SCRIPT_DATA: {
          this._stateScriptData(cp);
          break;
        }
        case State.PLAINTEXT: {
          this._statePlaintext(cp);
          break;
        }
        case State.TAG_OPEN: {
          this._stateTagOpen(cp);
          break;
        }
        case State.END_TAG_OPEN: {
          this._stateEndTagOpen(cp);
          break;
        }
        case State.TAG_NAME: {
          this._stateTagName(cp);
          break;
        }
        case State.RCDATA_LESS_THAN_SIGN: {
          this._stateRcdataLessThanSign(cp);
          break;
        }
        case State.RCDATA_END_TAG_OPEN: {
          this._stateRcdataEndTagOpen(cp);
          break;
        }
        case State.RCDATA_END_TAG_NAME: {
          this._stateRcdataEndTagName(cp);
          break;
        }
        case State.RAWTEXT_LESS_THAN_SIGN: {
          this._stateRawtextLessThanSign(cp);
          break;
        }
        case State.RAWTEXT_END_TAG_OPEN: {
          this._stateRawtextEndTagOpen(cp);
          break;
        }
        case State.RAWTEXT_END_TAG_NAME: {
          this._stateRawtextEndTagName(cp);
          break;
        }
        case State.SCRIPT_DATA_LESS_THAN_SIGN: {
          this._stateScriptDataLessThanSign(cp);
          break;
        }
        case State.SCRIPT_DATA_END_TAG_OPEN: {
          this._stateScriptDataEndTagOpen(cp);
          break;
        }
        case State.SCRIPT_DATA_END_TAG_NAME: {
          this._stateScriptDataEndTagName(cp);
          break;
        }
        case State.SCRIPT_DATA_ESCAPE_START: {
          this._stateScriptDataEscapeStart(cp);
          break;
        }
        case State.SCRIPT_DATA_ESCAPE_START_DASH: {
          this._stateScriptDataEscapeStartDash(cp);
          break;
        }
        case State.SCRIPT_DATA_ESCAPED: {
          this._stateScriptDataEscaped(cp);
          break;
        }
        case State.SCRIPT_DATA_ESCAPED_DASH: {
          this._stateScriptDataEscapedDash(cp);
          break;
        }
        case State.SCRIPT_DATA_ESCAPED_DASH_DASH: {
          this._stateScriptDataEscapedDashDash(cp);
          break;
        }
        case State.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN: {
          this._stateScriptDataEscapedLessThanSign(cp);
          break;
        }
        case State.SCRIPT_DATA_ESCAPED_END_TAG_OPEN: {
          this._stateScriptDataEscapedEndTagOpen(cp);
          break;
        }
        case State.SCRIPT_DATA_ESCAPED_END_TAG_NAME: {
          this._stateScriptDataEscapedEndTagName(cp);
          break;
        }
        case State.SCRIPT_DATA_DOUBLE_ESCAPE_START: {
          this._stateScriptDataDoubleEscapeStart(cp);
          break;
        }
        case State.SCRIPT_DATA_DOUBLE_ESCAPED: {
          this._stateScriptDataDoubleEscaped(cp);
          break;
        }
        case State.SCRIPT_DATA_DOUBLE_ESCAPED_DASH: {
          this._stateScriptDataDoubleEscapedDash(cp);
          break;
        }
        case State.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH: {
          this._stateScriptDataDoubleEscapedDashDash(cp);
          break;
        }
        case State.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN: {
          this._stateScriptDataDoubleEscapedLessThanSign(cp);
          break;
        }
        case State.SCRIPT_DATA_DOUBLE_ESCAPE_END: {
          this._stateScriptDataDoubleEscapeEnd(cp);
          break;
        }
        case State.BEFORE_ATTRIBUTE_NAME: {
          this._stateBeforeAttributeName(cp);
          break;
        }
        case State.ATTRIBUTE_NAME: {
          this._stateAttributeName(cp);
          break;
        }
        case State.AFTER_ATTRIBUTE_NAME: {
          this._stateAfterAttributeName(cp);
          break;
        }
        case State.BEFORE_ATTRIBUTE_VALUE: {
          this._stateBeforeAttributeValue(cp);
          break;
        }
        case State.ATTRIBUTE_VALUE_DOUBLE_QUOTED: {
          this._stateAttributeValueDoubleQuoted(cp);
          break;
        }
        case State.ATTRIBUTE_VALUE_SINGLE_QUOTED: {
          this._stateAttributeValueSingleQuoted(cp);
          break;
        }
        case State.ATTRIBUTE_VALUE_UNQUOTED: {
          this._stateAttributeValueUnquoted(cp);
          break;
        }
        case State.AFTER_ATTRIBUTE_VALUE_QUOTED: {
          this._stateAfterAttributeValueQuoted(cp);
          break;
        }
        case State.SELF_CLOSING_START_TAG: {
          this._stateSelfClosingStartTag(cp);
          break;
        }
        case State.BOGUS_COMMENT: {
          this._stateBogusComment(cp);
          break;
        }
        case State.MARKUP_DECLARATION_OPEN: {
          this._stateMarkupDeclarationOpen(cp);
          break;
        }
        case State.COMMENT_START: {
          this._stateCommentStart(cp);
          break;
        }
        case State.COMMENT_START_DASH: {
          this._stateCommentStartDash(cp);
          break;
        }
        case State.COMMENT: {
          this._stateComment(cp);
          break;
        }
        case State.COMMENT_LESS_THAN_SIGN: {
          this._stateCommentLessThanSign(cp);
          break;
        }
        case State.COMMENT_LESS_THAN_SIGN_BANG: {
          this._stateCommentLessThanSignBang(cp);
          break;
        }
        case State.COMMENT_LESS_THAN_SIGN_BANG_DASH: {
          this._stateCommentLessThanSignBangDash(cp);
          break;
        }
        case State.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH: {
          this._stateCommentLessThanSignBangDashDash(cp);
          break;
        }
        case State.COMMENT_END_DASH: {
          this._stateCommentEndDash(cp);
          break;
        }
        case State.COMMENT_END: {
          this._stateCommentEnd(cp);
          break;
        }
        case State.COMMENT_END_BANG: {
          this._stateCommentEndBang(cp);
          break;
        }
        case State.DOCTYPE: {
          this._stateDoctype(cp);
          break;
        }
        case State.BEFORE_DOCTYPE_NAME: {
          this._stateBeforeDoctypeName(cp);
          break;
        }
        case State.DOCTYPE_NAME: {
          this._stateDoctypeName(cp);
          break;
        }
        case State.AFTER_DOCTYPE_NAME: {
          this._stateAfterDoctypeName(cp);
          break;
        }
        case State.AFTER_DOCTYPE_PUBLIC_KEYWORD: {
          this._stateAfterDoctypePublicKeyword(cp);
          break;
        }
        case State.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER: {
          this._stateBeforeDoctypePublicIdentifier(cp);
          break;
        }
        case State.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED: {
          this._stateDoctypePublicIdentifierDoubleQuoted(cp);
          break;
        }
        case State.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED: {
          this._stateDoctypePublicIdentifierSingleQuoted(cp);
          break;
        }
        case State.AFTER_DOCTYPE_PUBLIC_IDENTIFIER: {
          this._stateAfterDoctypePublicIdentifier(cp);
          break;
        }
        case State.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS: {
          this._stateBetweenDoctypePublicAndSystemIdentifiers(cp);
          break;
        }
        case State.AFTER_DOCTYPE_SYSTEM_KEYWORD: {
          this._stateAfterDoctypeSystemKeyword(cp);
          break;
        }
        case State.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER: {
          this._stateBeforeDoctypeSystemIdentifier(cp);
          break;
        }
        case State.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED: {
          this._stateDoctypeSystemIdentifierDoubleQuoted(cp);
          break;
        }
        case State.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED: {
          this._stateDoctypeSystemIdentifierSingleQuoted(cp);
          break;
        }
        case State.AFTER_DOCTYPE_SYSTEM_IDENTIFIER: {
          this._stateAfterDoctypeSystemIdentifier(cp);
          break;
        }
        case State.BOGUS_DOCTYPE: {
          this._stateBogusDoctype(cp);
          break;
        }
        case State.CDATA_SECTION: {
          this._stateCdataSection(cp);
          break;
        }
        case State.CDATA_SECTION_BRACKET: {
          this._stateCdataSectionBracket(cp);
          break;
        }
        case State.CDATA_SECTION_END: {
          this._stateCdataSectionEnd(cp);
          break;
        }
        case State.CHARACTER_REFERENCE: {
          this._stateCharacterReference(cp);
          break;
        }
        case State.NAMED_CHARACTER_REFERENCE: {
          this._stateNamedCharacterReference(cp);
          break;
        }
        case State.AMBIGUOUS_AMPERSAND: {
          this._stateAmbiguousAmpersand(cp);
          break;
        }
        case State.NUMERIC_CHARACTER_REFERENCE: {
          this._stateNumericCharacterReference(cp);
          break;
        }
        case State.HEXADEMICAL_CHARACTER_REFERENCE_START: {
          this._stateHexademicalCharacterReferenceStart(cp);
          break;
        }
        case State.HEXADEMICAL_CHARACTER_REFERENCE: {
          this._stateHexademicalCharacterReference(cp);
          break;
        }
        case State.DECIMAL_CHARACTER_REFERENCE: {
          this._stateDecimalCharacterReference(cp);
          break;
        }
        case State.NUMERIC_CHARACTER_REFERENCE_END: {
          this._stateNumericCharacterReferenceEnd(cp);
          break;
        }
        default: {
          throw new Error("Unknown state");
        }
      }
    }
    // State machine
    // Data state
    //------------------------------------------------------------------
    _stateData(cp) {
      switch (cp) {
        case CODE_POINTS.LESS_THAN_SIGN: {
          this.state = State.TAG_OPEN;
          break;
        }
        case CODE_POINTS.AMPERSAND: {
          this.returnState = State.DATA;
          this.state = State.CHARACTER_REFERENCE;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this._emitCodePoint(cp);
          break;
        }
        case CODE_POINTS.EOF: {
          this._emitEOFToken();
          break;
        }
        default: {
          this._emitCodePoint(cp);
        }
      }
    }
    //  RCDATA state
    //------------------------------------------------------------------
    _stateRcdata(cp) {
      switch (cp) {
        case CODE_POINTS.AMPERSAND: {
          this.returnState = State.RCDATA;
          this.state = State.CHARACTER_REFERENCE;
          break;
        }
        case CODE_POINTS.LESS_THAN_SIGN: {
          this.state = State.RCDATA_LESS_THAN_SIGN;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this._emitChars(REPLACEMENT_CHARACTER);
          break;
        }
        case CODE_POINTS.EOF: {
          this._emitEOFToken();
          break;
        }
        default: {
          this._emitCodePoint(cp);
        }
      }
    }
    // RAWTEXT state
    //------------------------------------------------------------------
    _stateRawtext(cp) {
      switch (cp) {
        case CODE_POINTS.LESS_THAN_SIGN: {
          this.state = State.RAWTEXT_LESS_THAN_SIGN;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this._emitChars(REPLACEMENT_CHARACTER);
          break;
        }
        case CODE_POINTS.EOF: {
          this._emitEOFToken();
          break;
        }
        default: {
          this._emitCodePoint(cp);
        }
      }
    }
    // Script data state
    //------------------------------------------------------------------
    _stateScriptData(cp) {
      switch (cp) {
        case CODE_POINTS.LESS_THAN_SIGN: {
          this.state = State.SCRIPT_DATA_LESS_THAN_SIGN;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this._emitChars(REPLACEMENT_CHARACTER);
          break;
        }
        case CODE_POINTS.EOF: {
          this._emitEOFToken();
          break;
        }
        default: {
          this._emitCodePoint(cp);
        }
      }
    }
    // PLAINTEXT state
    //------------------------------------------------------------------
    _statePlaintext(cp) {
      switch (cp) {
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this._emitChars(REPLACEMENT_CHARACTER);
          break;
        }
        case CODE_POINTS.EOF: {
          this._emitEOFToken();
          break;
        }
        default: {
          this._emitCodePoint(cp);
        }
      }
    }
    // Tag open state
    //------------------------------------------------------------------
    _stateTagOpen(cp) {
      if (isAsciiLetter(cp)) {
        this._createStartTagToken();
        this.state = State.TAG_NAME;
        this._stateTagName(cp);
      } else
        switch (cp) {
          case CODE_POINTS.EXCLAMATION_MARK: {
            this.state = State.MARKUP_DECLARATION_OPEN;
            break;
          }
          case CODE_POINTS.SOLIDUS: {
            this.state = State.END_TAG_OPEN;
            break;
          }
          case CODE_POINTS.QUESTION_MARK: {
            this._err(ERR.unexpectedQuestionMarkInsteadOfTagName);
            this._createCommentToken(1);
            this.state = State.BOGUS_COMMENT;
            this._stateBogusComment(cp);
            break;
          }
          case CODE_POINTS.EOF: {
            this._err(ERR.eofBeforeTagName);
            this._emitChars("<");
            this._emitEOFToken();
            break;
          }
          default: {
            this._err(ERR.invalidFirstCharacterOfTagName);
            this._emitChars("<");
            this.state = State.DATA;
            this._stateData(cp);
          }
        }
    }
    // End tag open state
    //------------------------------------------------------------------
    _stateEndTagOpen(cp) {
      if (isAsciiLetter(cp)) {
        this._createEndTagToken();
        this.state = State.TAG_NAME;
        this._stateTagName(cp);
      } else
        switch (cp) {
          case CODE_POINTS.GREATER_THAN_SIGN: {
            this._err(ERR.missingEndTagName);
            this.state = State.DATA;
            break;
          }
          case CODE_POINTS.EOF: {
            this._err(ERR.eofBeforeTagName);
            this._emitChars("</");
            this._emitEOFToken();
            break;
          }
          default: {
            this._err(ERR.invalidFirstCharacterOfTagName);
            this._createCommentToken(2);
            this.state = State.BOGUS_COMMENT;
            this._stateBogusComment(cp);
          }
        }
    }
    // Tag name state
    //------------------------------------------------------------------
    _stateTagName(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          this.state = State.BEFORE_ATTRIBUTE_NAME;
          break;
        }
        case CODE_POINTS.SOLIDUS: {
          this.state = State.SELF_CLOSING_START_TAG;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.state = State.DATA;
          this.emitCurrentTagToken();
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          token.tagName += REPLACEMENT_CHARACTER;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInTag);
          this._emitEOFToken();
          break;
        }
        default: {
          token.tagName += String.fromCodePoint(isAsciiUpper(cp) ? toAsciiLower(cp) : cp);
        }
      }
    }
    // RCDATA less-than sign state
    //------------------------------------------------------------------
    _stateRcdataLessThanSign(cp) {
      if (cp === CODE_POINTS.SOLIDUS) {
        this.state = State.RCDATA_END_TAG_OPEN;
      } else {
        this._emitChars("<");
        this.state = State.RCDATA;
        this._stateRcdata(cp);
      }
    }
    // RCDATA end tag open state
    //------------------------------------------------------------------
    _stateRcdataEndTagOpen(cp) {
      if (isAsciiLetter(cp)) {
        this.state = State.RCDATA_END_TAG_NAME;
        this._stateRcdataEndTagName(cp);
      } else {
        this._emitChars("</");
        this.state = State.RCDATA;
        this._stateRcdata(cp);
      }
    }
    handleSpecialEndTag(_cp) {
      if (!this.preprocessor.startsWith(this.lastStartTagName, false)) {
        return !this._ensureHibernation();
      }
      this._createEndTagToken();
      const token = this.currentToken;
      token.tagName = this.lastStartTagName;
      const cp = this.preprocessor.peek(this.lastStartTagName.length);
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          this._advanceBy(this.lastStartTagName.length);
          this.state = State.BEFORE_ATTRIBUTE_NAME;
          return false;
        }
        case CODE_POINTS.SOLIDUS: {
          this._advanceBy(this.lastStartTagName.length);
          this.state = State.SELF_CLOSING_START_TAG;
          return false;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._advanceBy(this.lastStartTagName.length);
          this.emitCurrentTagToken();
          this.state = State.DATA;
          return false;
        }
        default: {
          return !this._ensureHibernation();
        }
      }
    }
    // RCDATA end tag name state
    //------------------------------------------------------------------
    _stateRcdataEndTagName(cp) {
      if (this.handleSpecialEndTag(cp)) {
        this._emitChars("</");
        this.state = State.RCDATA;
        this._stateRcdata(cp);
      }
    }
    // RAWTEXT less-than sign state
    //------------------------------------------------------------------
    _stateRawtextLessThanSign(cp) {
      if (cp === CODE_POINTS.SOLIDUS) {
        this.state = State.RAWTEXT_END_TAG_OPEN;
      } else {
        this._emitChars("<");
        this.state = State.RAWTEXT;
        this._stateRawtext(cp);
      }
    }
    // RAWTEXT end tag open state
    //------------------------------------------------------------------
    _stateRawtextEndTagOpen(cp) {
      if (isAsciiLetter(cp)) {
        this.state = State.RAWTEXT_END_TAG_NAME;
        this._stateRawtextEndTagName(cp);
      } else {
        this._emitChars("</");
        this.state = State.RAWTEXT;
        this._stateRawtext(cp);
      }
    }
    // RAWTEXT end tag name state
    //------------------------------------------------------------------
    _stateRawtextEndTagName(cp) {
      if (this.handleSpecialEndTag(cp)) {
        this._emitChars("</");
        this.state = State.RAWTEXT;
        this._stateRawtext(cp);
      }
    }
    // Script data less-than sign state
    //------------------------------------------------------------------
    _stateScriptDataLessThanSign(cp) {
      switch (cp) {
        case CODE_POINTS.SOLIDUS: {
          this.state = State.SCRIPT_DATA_END_TAG_OPEN;
          break;
        }
        case CODE_POINTS.EXCLAMATION_MARK: {
          this.state = State.SCRIPT_DATA_ESCAPE_START;
          this._emitChars("<!");
          break;
        }
        default: {
          this._emitChars("<");
          this.state = State.SCRIPT_DATA;
          this._stateScriptData(cp);
        }
      }
    }
    // Script data end tag open state
    //------------------------------------------------------------------
    _stateScriptDataEndTagOpen(cp) {
      if (isAsciiLetter(cp)) {
        this.state = State.SCRIPT_DATA_END_TAG_NAME;
        this._stateScriptDataEndTagName(cp);
      } else {
        this._emitChars("</");
        this.state = State.SCRIPT_DATA;
        this._stateScriptData(cp);
      }
    }
    // Script data end tag name state
    //------------------------------------------------------------------
    _stateScriptDataEndTagName(cp) {
      if (this.handleSpecialEndTag(cp)) {
        this._emitChars("</");
        this.state = State.SCRIPT_DATA;
        this._stateScriptData(cp);
      }
    }
    // Script data escape start state
    //------------------------------------------------------------------
    _stateScriptDataEscapeStart(cp) {
      if (cp === CODE_POINTS.HYPHEN_MINUS) {
        this.state = State.SCRIPT_DATA_ESCAPE_START_DASH;
        this._emitChars("-");
      } else {
        this.state = State.SCRIPT_DATA;
        this._stateScriptData(cp);
      }
    }
    // Script data escape start dash state
    //------------------------------------------------------------------
    _stateScriptDataEscapeStartDash(cp) {
      if (cp === CODE_POINTS.HYPHEN_MINUS) {
        this.state = State.SCRIPT_DATA_ESCAPED_DASH_DASH;
        this._emitChars("-");
      } else {
        this.state = State.SCRIPT_DATA;
        this._stateScriptData(cp);
      }
    }
    // Script data escaped state
    //------------------------------------------------------------------
    _stateScriptDataEscaped(cp) {
      switch (cp) {
        case CODE_POINTS.HYPHEN_MINUS: {
          this.state = State.SCRIPT_DATA_ESCAPED_DASH;
          this._emitChars("-");
          break;
        }
        case CODE_POINTS.LESS_THAN_SIGN: {
          this.state = State.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this._emitChars(REPLACEMENT_CHARACTER);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInScriptHtmlCommentLikeText);
          this._emitEOFToken();
          break;
        }
        default: {
          this._emitCodePoint(cp);
        }
      }
    }
    // Script data escaped dash state
    //------------------------------------------------------------------
    _stateScriptDataEscapedDash(cp) {
      switch (cp) {
        case CODE_POINTS.HYPHEN_MINUS: {
          this.state = State.SCRIPT_DATA_ESCAPED_DASH_DASH;
          this._emitChars("-");
          break;
        }
        case CODE_POINTS.LESS_THAN_SIGN: {
          this.state = State.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this.state = State.SCRIPT_DATA_ESCAPED;
          this._emitChars(REPLACEMENT_CHARACTER);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInScriptHtmlCommentLikeText);
          this._emitEOFToken();
          break;
        }
        default: {
          this.state = State.SCRIPT_DATA_ESCAPED;
          this._emitCodePoint(cp);
        }
      }
    }
    // Script data escaped dash dash state
    //------------------------------------------------------------------
    _stateScriptDataEscapedDashDash(cp) {
      switch (cp) {
        case CODE_POINTS.HYPHEN_MINUS: {
          this._emitChars("-");
          break;
        }
        case CODE_POINTS.LESS_THAN_SIGN: {
          this.state = State.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.state = State.SCRIPT_DATA;
          this._emitChars(">");
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this.state = State.SCRIPT_DATA_ESCAPED;
          this._emitChars(REPLACEMENT_CHARACTER);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInScriptHtmlCommentLikeText);
          this._emitEOFToken();
          break;
        }
        default: {
          this.state = State.SCRIPT_DATA_ESCAPED;
          this._emitCodePoint(cp);
        }
      }
    }
    // Script data escaped less-than sign state
    //------------------------------------------------------------------
    _stateScriptDataEscapedLessThanSign(cp) {
      if (cp === CODE_POINTS.SOLIDUS) {
        this.state = State.SCRIPT_DATA_ESCAPED_END_TAG_OPEN;
      } else if (isAsciiLetter(cp)) {
        this._emitChars("<");
        this.state = State.SCRIPT_DATA_DOUBLE_ESCAPE_START;
        this._stateScriptDataDoubleEscapeStart(cp);
      } else {
        this._emitChars("<");
        this.state = State.SCRIPT_DATA_ESCAPED;
        this._stateScriptDataEscaped(cp);
      }
    }
    // Script data escaped end tag open state
    //------------------------------------------------------------------
    _stateScriptDataEscapedEndTagOpen(cp) {
      if (isAsciiLetter(cp)) {
        this.state = State.SCRIPT_DATA_ESCAPED_END_TAG_NAME;
        this._stateScriptDataEscapedEndTagName(cp);
      } else {
        this._emitChars("</");
        this.state = State.SCRIPT_DATA_ESCAPED;
        this._stateScriptDataEscaped(cp);
      }
    }
    // Script data escaped end tag name state
    //------------------------------------------------------------------
    _stateScriptDataEscapedEndTagName(cp) {
      if (this.handleSpecialEndTag(cp)) {
        this._emitChars("</");
        this.state = State.SCRIPT_DATA_ESCAPED;
        this._stateScriptDataEscaped(cp);
      }
    }
    // Script data double escape start state
    //------------------------------------------------------------------
    _stateScriptDataDoubleEscapeStart(cp) {
      if (this.preprocessor.startsWith(SEQUENCES.SCRIPT, false) && isScriptDataDoubleEscapeSequenceEnd(this.preprocessor.peek(SEQUENCES.SCRIPT.length))) {
        this._emitCodePoint(cp);
        for (let i3 = 0; i3 < SEQUENCES.SCRIPT.length; i3++) {
          this._emitCodePoint(this._consume());
        }
        this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED;
      } else if (!this._ensureHibernation()) {
        this.state = State.SCRIPT_DATA_ESCAPED;
        this._stateScriptDataEscaped(cp);
      }
    }
    // Script data double escaped state
    //------------------------------------------------------------------
    _stateScriptDataDoubleEscaped(cp) {
      switch (cp) {
        case CODE_POINTS.HYPHEN_MINUS: {
          this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED_DASH;
          this._emitChars("-");
          break;
        }
        case CODE_POINTS.LESS_THAN_SIGN: {
          this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN;
          this._emitChars("<");
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this._emitChars(REPLACEMENT_CHARACTER);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInScriptHtmlCommentLikeText);
          this._emitEOFToken();
          break;
        }
        default: {
          this._emitCodePoint(cp);
        }
      }
    }
    // Script data double escaped dash state
    //------------------------------------------------------------------
    _stateScriptDataDoubleEscapedDash(cp) {
      switch (cp) {
        case CODE_POINTS.HYPHEN_MINUS: {
          this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH;
          this._emitChars("-");
          break;
        }
        case CODE_POINTS.LESS_THAN_SIGN: {
          this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN;
          this._emitChars("<");
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED;
          this._emitChars(REPLACEMENT_CHARACTER);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInScriptHtmlCommentLikeText);
          this._emitEOFToken();
          break;
        }
        default: {
          this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED;
          this._emitCodePoint(cp);
        }
      }
    }
    // Script data double escaped dash dash state
    //------------------------------------------------------------------
    _stateScriptDataDoubleEscapedDashDash(cp) {
      switch (cp) {
        case CODE_POINTS.HYPHEN_MINUS: {
          this._emitChars("-");
          break;
        }
        case CODE_POINTS.LESS_THAN_SIGN: {
          this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN;
          this._emitChars("<");
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.state = State.SCRIPT_DATA;
          this._emitChars(">");
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED;
          this._emitChars(REPLACEMENT_CHARACTER);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInScriptHtmlCommentLikeText);
          this._emitEOFToken();
          break;
        }
        default: {
          this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED;
          this._emitCodePoint(cp);
        }
      }
    }
    // Script data double escaped less-than sign state
    //------------------------------------------------------------------
    _stateScriptDataDoubleEscapedLessThanSign(cp) {
      if (cp === CODE_POINTS.SOLIDUS) {
        this.state = State.SCRIPT_DATA_DOUBLE_ESCAPE_END;
        this._emitChars("/");
      } else {
        this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED;
        this._stateScriptDataDoubleEscaped(cp);
      }
    }
    // Script data double escape end state
    //------------------------------------------------------------------
    _stateScriptDataDoubleEscapeEnd(cp) {
      if (this.preprocessor.startsWith(SEQUENCES.SCRIPT, false) && isScriptDataDoubleEscapeSequenceEnd(this.preprocessor.peek(SEQUENCES.SCRIPT.length))) {
        this._emitCodePoint(cp);
        for (let i3 = 0; i3 < SEQUENCES.SCRIPT.length; i3++) {
          this._emitCodePoint(this._consume());
        }
        this.state = State.SCRIPT_DATA_ESCAPED;
      } else if (!this._ensureHibernation()) {
        this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED;
        this._stateScriptDataDoubleEscaped(cp);
      }
    }
    // Before attribute name state
    //------------------------------------------------------------------
    _stateBeforeAttributeName(cp) {
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          break;
        }
        case CODE_POINTS.SOLIDUS:
        case CODE_POINTS.GREATER_THAN_SIGN:
        case CODE_POINTS.EOF: {
          this.state = State.AFTER_ATTRIBUTE_NAME;
          this._stateAfterAttributeName(cp);
          break;
        }
        case CODE_POINTS.EQUALS_SIGN: {
          this._err(ERR.unexpectedEqualsSignBeforeAttributeName);
          this._createAttr("=");
          this.state = State.ATTRIBUTE_NAME;
          break;
        }
        default: {
          this._createAttr("");
          this.state = State.ATTRIBUTE_NAME;
          this._stateAttributeName(cp);
        }
      }
    }
    // Attribute name state
    //------------------------------------------------------------------
    _stateAttributeName(cp) {
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED:
        case CODE_POINTS.SOLIDUS:
        case CODE_POINTS.GREATER_THAN_SIGN:
        case CODE_POINTS.EOF: {
          this._leaveAttrName();
          this.state = State.AFTER_ATTRIBUTE_NAME;
          this._stateAfterAttributeName(cp);
          break;
        }
        case CODE_POINTS.EQUALS_SIGN: {
          this._leaveAttrName();
          this.state = State.BEFORE_ATTRIBUTE_VALUE;
          break;
        }
        case CODE_POINTS.QUOTATION_MARK:
        case CODE_POINTS.APOSTROPHE:
        case CODE_POINTS.LESS_THAN_SIGN: {
          this._err(ERR.unexpectedCharacterInAttributeName);
          this.currentAttr.name += String.fromCodePoint(cp);
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this.currentAttr.name += REPLACEMENT_CHARACTER;
          break;
        }
        default: {
          this.currentAttr.name += String.fromCodePoint(isAsciiUpper(cp) ? toAsciiLower(cp) : cp);
        }
      }
    }
    // After attribute name state
    //------------------------------------------------------------------
    _stateAfterAttributeName(cp) {
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          break;
        }
        case CODE_POINTS.SOLIDUS: {
          this.state = State.SELF_CLOSING_START_TAG;
          break;
        }
        case CODE_POINTS.EQUALS_SIGN: {
          this.state = State.BEFORE_ATTRIBUTE_VALUE;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.state = State.DATA;
          this.emitCurrentTagToken();
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInTag);
          this._emitEOFToken();
          break;
        }
        default: {
          this._createAttr("");
          this.state = State.ATTRIBUTE_NAME;
          this._stateAttributeName(cp);
        }
      }
    }
    // Before attribute value state
    //------------------------------------------------------------------
    _stateBeforeAttributeValue(cp) {
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          break;
        }
        case CODE_POINTS.QUOTATION_MARK: {
          this.state = State.ATTRIBUTE_VALUE_DOUBLE_QUOTED;
          break;
        }
        case CODE_POINTS.APOSTROPHE: {
          this.state = State.ATTRIBUTE_VALUE_SINGLE_QUOTED;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._err(ERR.missingAttributeValue);
          this.state = State.DATA;
          this.emitCurrentTagToken();
          break;
        }
        default: {
          this.state = State.ATTRIBUTE_VALUE_UNQUOTED;
          this._stateAttributeValueUnquoted(cp);
        }
      }
    }
    // Attribute value (double-quoted) state
    //------------------------------------------------------------------
    _stateAttributeValueDoubleQuoted(cp) {
      switch (cp) {
        case CODE_POINTS.QUOTATION_MARK: {
          this.state = State.AFTER_ATTRIBUTE_VALUE_QUOTED;
          break;
        }
        case CODE_POINTS.AMPERSAND: {
          this.returnState = State.ATTRIBUTE_VALUE_DOUBLE_QUOTED;
          this.state = State.CHARACTER_REFERENCE;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this.currentAttr.value += REPLACEMENT_CHARACTER;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInTag);
          this._emitEOFToken();
          break;
        }
        default: {
          this.currentAttr.value += String.fromCodePoint(cp);
        }
      }
    }
    // Attribute value (single-quoted) state
    //------------------------------------------------------------------
    _stateAttributeValueSingleQuoted(cp) {
      switch (cp) {
        case CODE_POINTS.APOSTROPHE: {
          this.state = State.AFTER_ATTRIBUTE_VALUE_QUOTED;
          break;
        }
        case CODE_POINTS.AMPERSAND: {
          this.returnState = State.ATTRIBUTE_VALUE_SINGLE_QUOTED;
          this.state = State.CHARACTER_REFERENCE;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this.currentAttr.value += REPLACEMENT_CHARACTER;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInTag);
          this._emitEOFToken();
          break;
        }
        default: {
          this.currentAttr.value += String.fromCodePoint(cp);
        }
      }
    }
    // Attribute value (unquoted) state
    //------------------------------------------------------------------
    _stateAttributeValueUnquoted(cp) {
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          this._leaveAttrValue();
          this.state = State.BEFORE_ATTRIBUTE_NAME;
          break;
        }
        case CODE_POINTS.AMPERSAND: {
          this.returnState = State.ATTRIBUTE_VALUE_UNQUOTED;
          this.state = State.CHARACTER_REFERENCE;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._leaveAttrValue();
          this.state = State.DATA;
          this.emitCurrentTagToken();
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this.currentAttr.value += REPLACEMENT_CHARACTER;
          break;
        }
        case CODE_POINTS.QUOTATION_MARK:
        case CODE_POINTS.APOSTROPHE:
        case CODE_POINTS.LESS_THAN_SIGN:
        case CODE_POINTS.EQUALS_SIGN:
        case CODE_POINTS.GRAVE_ACCENT: {
          this._err(ERR.unexpectedCharacterInUnquotedAttributeValue);
          this.currentAttr.value += String.fromCodePoint(cp);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInTag);
          this._emitEOFToken();
          break;
        }
        default: {
          this.currentAttr.value += String.fromCodePoint(cp);
        }
      }
    }
    // After attribute value (quoted) state
    //------------------------------------------------------------------
    _stateAfterAttributeValueQuoted(cp) {
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          this._leaveAttrValue();
          this.state = State.BEFORE_ATTRIBUTE_NAME;
          break;
        }
        case CODE_POINTS.SOLIDUS: {
          this._leaveAttrValue();
          this.state = State.SELF_CLOSING_START_TAG;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._leaveAttrValue();
          this.state = State.DATA;
          this.emitCurrentTagToken();
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInTag);
          this._emitEOFToken();
          break;
        }
        default: {
          this._err(ERR.missingWhitespaceBetweenAttributes);
          this.state = State.BEFORE_ATTRIBUTE_NAME;
          this._stateBeforeAttributeName(cp);
        }
      }
    }
    // Self-closing start tag state
    //------------------------------------------------------------------
    _stateSelfClosingStartTag(cp) {
      switch (cp) {
        case CODE_POINTS.GREATER_THAN_SIGN: {
          const token = this.currentToken;
          token.selfClosing = true;
          this.state = State.DATA;
          this.emitCurrentTagToken();
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInTag);
          this._emitEOFToken();
          break;
        }
        default: {
          this._err(ERR.unexpectedSolidusInTag);
          this.state = State.BEFORE_ATTRIBUTE_NAME;
          this._stateBeforeAttributeName(cp);
        }
      }
    }
    // Bogus comment state
    //------------------------------------------------------------------
    _stateBogusComment(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.state = State.DATA;
          this.emitCurrentComment(token);
          break;
        }
        case CODE_POINTS.EOF: {
          this.emitCurrentComment(token);
          this._emitEOFToken();
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          token.data += REPLACEMENT_CHARACTER;
          break;
        }
        default: {
          token.data += String.fromCodePoint(cp);
        }
      }
    }
    // Markup declaration open state
    //------------------------------------------------------------------
    _stateMarkupDeclarationOpen(cp) {
      if (this._consumeSequenceIfMatch(SEQUENCES.DASH_DASH, true)) {
        this._createCommentToken(SEQUENCES.DASH_DASH.length + 1);
        this.state = State.COMMENT_START;
      } else if (this._consumeSequenceIfMatch(SEQUENCES.DOCTYPE, false)) {
        this.currentLocation = this.getCurrentLocation(SEQUENCES.DOCTYPE.length + 1);
        this.state = State.DOCTYPE;
      } else if (this._consumeSequenceIfMatch(SEQUENCES.CDATA_START, true)) {
        if (this.inForeignNode) {
          this.state = State.CDATA_SECTION;
        } else {
          this._err(ERR.cdataInHtmlContent);
          this._createCommentToken(SEQUENCES.CDATA_START.length + 1);
          this.currentToken.data = "[CDATA[";
          this.state = State.BOGUS_COMMENT;
        }
      } else if (!this._ensureHibernation()) {
        this._err(ERR.incorrectlyOpenedComment);
        this._createCommentToken(2);
        this.state = State.BOGUS_COMMENT;
        this._stateBogusComment(cp);
      }
    }
    // Comment start state
    //------------------------------------------------------------------
    _stateCommentStart(cp) {
      switch (cp) {
        case CODE_POINTS.HYPHEN_MINUS: {
          this.state = State.COMMENT_START_DASH;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._err(ERR.abruptClosingOfEmptyComment);
          this.state = State.DATA;
          const token = this.currentToken;
          this.emitCurrentComment(token);
          break;
        }
        default: {
          this.state = State.COMMENT;
          this._stateComment(cp);
        }
      }
    }
    // Comment start dash state
    //------------------------------------------------------------------
    _stateCommentStartDash(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.HYPHEN_MINUS: {
          this.state = State.COMMENT_END;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._err(ERR.abruptClosingOfEmptyComment);
          this.state = State.DATA;
          this.emitCurrentComment(token);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInComment);
          this.emitCurrentComment(token);
          this._emitEOFToken();
          break;
        }
        default: {
          token.data += "-";
          this.state = State.COMMENT;
          this._stateComment(cp);
        }
      }
    }
    // Comment state
    //------------------------------------------------------------------
    _stateComment(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.HYPHEN_MINUS: {
          this.state = State.COMMENT_END_DASH;
          break;
        }
        case CODE_POINTS.LESS_THAN_SIGN: {
          token.data += "<";
          this.state = State.COMMENT_LESS_THAN_SIGN;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          token.data += REPLACEMENT_CHARACTER;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInComment);
          this.emitCurrentComment(token);
          this._emitEOFToken();
          break;
        }
        default: {
          token.data += String.fromCodePoint(cp);
        }
      }
    }
    // Comment less-than sign state
    //------------------------------------------------------------------
    _stateCommentLessThanSign(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.EXCLAMATION_MARK: {
          token.data += "!";
          this.state = State.COMMENT_LESS_THAN_SIGN_BANG;
          break;
        }
        case CODE_POINTS.LESS_THAN_SIGN: {
          token.data += "<";
          break;
        }
        default: {
          this.state = State.COMMENT;
          this._stateComment(cp);
        }
      }
    }
    // Comment less-than sign bang state
    //------------------------------------------------------------------
    _stateCommentLessThanSignBang(cp) {
      if (cp === CODE_POINTS.HYPHEN_MINUS) {
        this.state = State.COMMENT_LESS_THAN_SIGN_BANG_DASH;
      } else {
        this.state = State.COMMENT;
        this._stateComment(cp);
      }
    }
    // Comment less-than sign bang dash state
    //------------------------------------------------------------------
    _stateCommentLessThanSignBangDash(cp) {
      if (cp === CODE_POINTS.HYPHEN_MINUS) {
        this.state = State.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH;
      } else {
        this.state = State.COMMENT_END_DASH;
        this._stateCommentEndDash(cp);
      }
    }
    // Comment less-than sign bang dash dash state
    //------------------------------------------------------------------
    _stateCommentLessThanSignBangDashDash(cp) {
      if (cp !== CODE_POINTS.GREATER_THAN_SIGN && cp !== CODE_POINTS.EOF) {
        this._err(ERR.nestedComment);
      }
      this.state = State.COMMENT_END;
      this._stateCommentEnd(cp);
    }
    // Comment end dash state
    //------------------------------------------------------------------
    _stateCommentEndDash(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.HYPHEN_MINUS: {
          this.state = State.COMMENT_END;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInComment);
          this.emitCurrentComment(token);
          this._emitEOFToken();
          break;
        }
        default: {
          token.data += "-";
          this.state = State.COMMENT;
          this._stateComment(cp);
        }
      }
    }
    // Comment end state
    //------------------------------------------------------------------
    _stateCommentEnd(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.state = State.DATA;
          this.emitCurrentComment(token);
          break;
        }
        case CODE_POINTS.EXCLAMATION_MARK: {
          this.state = State.COMMENT_END_BANG;
          break;
        }
        case CODE_POINTS.HYPHEN_MINUS: {
          token.data += "-";
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInComment);
          this.emitCurrentComment(token);
          this._emitEOFToken();
          break;
        }
        default: {
          token.data += "--";
          this.state = State.COMMENT;
          this._stateComment(cp);
        }
      }
    }
    // Comment end bang state
    //------------------------------------------------------------------
    _stateCommentEndBang(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.HYPHEN_MINUS: {
          token.data += "--!";
          this.state = State.COMMENT_END_DASH;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._err(ERR.incorrectlyClosedComment);
          this.state = State.DATA;
          this.emitCurrentComment(token);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInComment);
          this.emitCurrentComment(token);
          this._emitEOFToken();
          break;
        }
        default: {
          token.data += "--!";
          this.state = State.COMMENT;
          this._stateComment(cp);
        }
      }
    }
    // DOCTYPE state
    //------------------------------------------------------------------
    _stateDoctype(cp) {
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          this.state = State.BEFORE_DOCTYPE_NAME;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.state = State.BEFORE_DOCTYPE_NAME;
          this._stateBeforeDoctypeName(cp);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          this._createDoctypeToken(null);
          const token = this.currentToken;
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          this._err(ERR.missingWhitespaceBeforeDoctypeName);
          this.state = State.BEFORE_DOCTYPE_NAME;
          this._stateBeforeDoctypeName(cp);
        }
      }
    }
    // Before DOCTYPE name state
    //------------------------------------------------------------------
    _stateBeforeDoctypeName(cp) {
      if (isAsciiUpper(cp)) {
        this._createDoctypeToken(String.fromCharCode(toAsciiLower(cp)));
        this.state = State.DOCTYPE_NAME;
      } else
        switch (cp) {
          case CODE_POINTS.SPACE:
          case CODE_POINTS.LINE_FEED:
          case CODE_POINTS.TABULATION:
          case CODE_POINTS.FORM_FEED: {
            break;
          }
          case CODE_POINTS.NULL: {
            this._err(ERR.unexpectedNullCharacter);
            this._createDoctypeToken(REPLACEMENT_CHARACTER);
            this.state = State.DOCTYPE_NAME;
            break;
          }
          case CODE_POINTS.GREATER_THAN_SIGN: {
            this._err(ERR.missingDoctypeName);
            this._createDoctypeToken(null);
            const token = this.currentToken;
            token.forceQuirks = true;
            this.emitCurrentDoctype(token);
            this.state = State.DATA;
            break;
          }
          case CODE_POINTS.EOF: {
            this._err(ERR.eofInDoctype);
            this._createDoctypeToken(null);
            const token = this.currentToken;
            token.forceQuirks = true;
            this.emitCurrentDoctype(token);
            this._emitEOFToken();
            break;
          }
          default: {
            this._createDoctypeToken(String.fromCodePoint(cp));
            this.state = State.DOCTYPE_NAME;
          }
        }
    }
    // DOCTYPE name state
    //------------------------------------------------------------------
    _stateDoctypeName(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          this.state = State.AFTER_DOCTYPE_NAME;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.state = State.DATA;
          this.emitCurrentDoctype(token);
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          token.name += REPLACEMENT_CHARACTER;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          token.name += String.fromCodePoint(isAsciiUpper(cp) ? toAsciiLower(cp) : cp);
        }
      }
    }
    // After DOCTYPE name state
    //------------------------------------------------------------------
    _stateAfterDoctypeName(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.state = State.DATA;
          this.emitCurrentDoctype(token);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          if (this._consumeSequenceIfMatch(SEQUENCES.PUBLIC, false)) {
            this.state = State.AFTER_DOCTYPE_PUBLIC_KEYWORD;
          } else if (this._consumeSequenceIfMatch(SEQUENCES.SYSTEM, false)) {
            this.state = State.AFTER_DOCTYPE_SYSTEM_KEYWORD;
          } else if (!this._ensureHibernation()) {
            this._err(ERR.invalidCharacterSequenceAfterDoctypeName);
            token.forceQuirks = true;
            this.state = State.BOGUS_DOCTYPE;
            this._stateBogusDoctype(cp);
          }
        }
      }
    }
    // After DOCTYPE public keyword state
    //------------------------------------------------------------------
    _stateAfterDoctypePublicKeyword(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          this.state = State.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER;
          break;
        }
        case CODE_POINTS.QUOTATION_MARK: {
          this._err(ERR.missingWhitespaceAfterDoctypePublicKeyword);
          token.publicId = "";
          this.state = State.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED;
          break;
        }
        case CODE_POINTS.APOSTROPHE: {
          this._err(ERR.missingWhitespaceAfterDoctypePublicKeyword);
          token.publicId = "";
          this.state = State.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._err(ERR.missingDoctypePublicIdentifier);
          token.forceQuirks = true;
          this.state = State.DATA;
          this.emitCurrentDoctype(token);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          this._err(ERR.missingQuoteBeforeDoctypePublicIdentifier);
          token.forceQuirks = true;
          this.state = State.BOGUS_DOCTYPE;
          this._stateBogusDoctype(cp);
        }
      }
    }
    // Before DOCTYPE public identifier state
    //------------------------------------------------------------------
    _stateBeforeDoctypePublicIdentifier(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          break;
        }
        case CODE_POINTS.QUOTATION_MARK: {
          token.publicId = "";
          this.state = State.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED;
          break;
        }
        case CODE_POINTS.APOSTROPHE: {
          token.publicId = "";
          this.state = State.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._err(ERR.missingDoctypePublicIdentifier);
          token.forceQuirks = true;
          this.state = State.DATA;
          this.emitCurrentDoctype(token);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          this._err(ERR.missingQuoteBeforeDoctypePublicIdentifier);
          token.forceQuirks = true;
          this.state = State.BOGUS_DOCTYPE;
          this._stateBogusDoctype(cp);
        }
      }
    }
    // DOCTYPE public identifier (double-quoted) state
    //------------------------------------------------------------------
    _stateDoctypePublicIdentifierDoubleQuoted(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.QUOTATION_MARK: {
          this.state = State.AFTER_DOCTYPE_PUBLIC_IDENTIFIER;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          token.publicId += REPLACEMENT_CHARACTER;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._err(ERR.abruptDoctypePublicIdentifier);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this.state = State.DATA;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          token.publicId += String.fromCodePoint(cp);
        }
      }
    }
    // DOCTYPE public identifier (single-quoted) state
    //------------------------------------------------------------------
    _stateDoctypePublicIdentifierSingleQuoted(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.APOSTROPHE: {
          this.state = State.AFTER_DOCTYPE_PUBLIC_IDENTIFIER;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          token.publicId += REPLACEMENT_CHARACTER;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._err(ERR.abruptDoctypePublicIdentifier);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this.state = State.DATA;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          token.publicId += String.fromCodePoint(cp);
        }
      }
    }
    // After DOCTYPE public identifier state
    //------------------------------------------------------------------
    _stateAfterDoctypePublicIdentifier(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          this.state = State.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.state = State.DATA;
          this.emitCurrentDoctype(token);
          break;
        }
        case CODE_POINTS.QUOTATION_MARK: {
          this._err(ERR.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers);
          token.systemId = "";
          this.state = State.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
          break;
        }
        case CODE_POINTS.APOSTROPHE: {
          this._err(ERR.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers);
          token.systemId = "";
          this.state = State.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          this._err(ERR.missingQuoteBeforeDoctypeSystemIdentifier);
          token.forceQuirks = true;
          this.state = State.BOGUS_DOCTYPE;
          this._stateBogusDoctype(cp);
        }
      }
    }
    // Between DOCTYPE public and system identifiers state
    //------------------------------------------------------------------
    _stateBetweenDoctypePublicAndSystemIdentifiers(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.emitCurrentDoctype(token);
          this.state = State.DATA;
          break;
        }
        case CODE_POINTS.QUOTATION_MARK: {
          token.systemId = "";
          this.state = State.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
          break;
        }
        case CODE_POINTS.APOSTROPHE: {
          token.systemId = "";
          this.state = State.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          this._err(ERR.missingQuoteBeforeDoctypeSystemIdentifier);
          token.forceQuirks = true;
          this.state = State.BOGUS_DOCTYPE;
          this._stateBogusDoctype(cp);
        }
      }
    }
    // After DOCTYPE system keyword state
    //------------------------------------------------------------------
    _stateAfterDoctypeSystemKeyword(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          this.state = State.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER;
          break;
        }
        case CODE_POINTS.QUOTATION_MARK: {
          this._err(ERR.missingWhitespaceAfterDoctypeSystemKeyword);
          token.systemId = "";
          this.state = State.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
          break;
        }
        case CODE_POINTS.APOSTROPHE: {
          this._err(ERR.missingWhitespaceAfterDoctypeSystemKeyword);
          token.systemId = "";
          this.state = State.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._err(ERR.missingDoctypeSystemIdentifier);
          token.forceQuirks = true;
          this.state = State.DATA;
          this.emitCurrentDoctype(token);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          this._err(ERR.missingQuoteBeforeDoctypeSystemIdentifier);
          token.forceQuirks = true;
          this.state = State.BOGUS_DOCTYPE;
          this._stateBogusDoctype(cp);
        }
      }
    }
    // Before DOCTYPE system identifier state
    //------------------------------------------------------------------
    _stateBeforeDoctypeSystemIdentifier(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          break;
        }
        case CODE_POINTS.QUOTATION_MARK: {
          token.systemId = "";
          this.state = State.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
          break;
        }
        case CODE_POINTS.APOSTROPHE: {
          token.systemId = "";
          this.state = State.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._err(ERR.missingDoctypeSystemIdentifier);
          token.forceQuirks = true;
          this.state = State.DATA;
          this.emitCurrentDoctype(token);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          this._err(ERR.missingQuoteBeforeDoctypeSystemIdentifier);
          token.forceQuirks = true;
          this.state = State.BOGUS_DOCTYPE;
          this._stateBogusDoctype(cp);
        }
      }
    }
    // DOCTYPE system identifier (double-quoted) state
    //------------------------------------------------------------------
    _stateDoctypeSystemIdentifierDoubleQuoted(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.QUOTATION_MARK: {
          this.state = State.AFTER_DOCTYPE_SYSTEM_IDENTIFIER;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          token.systemId += REPLACEMENT_CHARACTER;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._err(ERR.abruptDoctypeSystemIdentifier);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this.state = State.DATA;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          token.systemId += String.fromCodePoint(cp);
        }
      }
    }
    // DOCTYPE system identifier (single-quoted) state
    //------------------------------------------------------------------
    _stateDoctypeSystemIdentifierSingleQuoted(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.APOSTROPHE: {
          this.state = State.AFTER_DOCTYPE_SYSTEM_IDENTIFIER;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          token.systemId += REPLACEMENT_CHARACTER;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._err(ERR.abruptDoctypeSystemIdentifier);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this.state = State.DATA;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          token.systemId += String.fromCodePoint(cp);
        }
      }
    }
    // After DOCTYPE system identifier state
    //------------------------------------------------------------------
    _stateAfterDoctypeSystemIdentifier(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.emitCurrentDoctype(token);
          this.state = State.DATA;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          this._err(ERR.unexpectedCharacterAfterDoctypeSystemIdentifier);
          this.state = State.BOGUS_DOCTYPE;
          this._stateBogusDoctype(cp);
        }
      }
    }
    // Bogus DOCTYPE state
    //------------------------------------------------------------------
    _stateBogusDoctype(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.emitCurrentDoctype(token);
          this.state = State.DATA;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          break;
        }
        case CODE_POINTS.EOF: {
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default:
      }
    }
    // CDATA section state
    //------------------------------------------------------------------
    _stateCdataSection(cp) {
      switch (cp) {
        case CODE_POINTS.RIGHT_SQUARE_BRACKET: {
          this.state = State.CDATA_SECTION_BRACKET;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInCdata);
          this._emitEOFToken();
          break;
        }
        default: {
          this._emitCodePoint(cp);
        }
      }
    }
    // CDATA section bracket state
    //------------------------------------------------------------------
    _stateCdataSectionBracket(cp) {
      if (cp === CODE_POINTS.RIGHT_SQUARE_BRACKET) {
        this.state = State.CDATA_SECTION_END;
      } else {
        this._emitChars("]");
        this.state = State.CDATA_SECTION;
        this._stateCdataSection(cp);
      }
    }
    // CDATA section end state
    //------------------------------------------------------------------
    _stateCdataSectionEnd(cp) {
      switch (cp) {
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.state = State.DATA;
          break;
        }
        case CODE_POINTS.RIGHT_SQUARE_BRACKET: {
          this._emitChars("]");
          break;
        }
        default: {
          this._emitChars("]]");
          this.state = State.CDATA_SECTION;
          this._stateCdataSection(cp);
        }
      }
    }
    // Character reference state
    //------------------------------------------------------------------
    _stateCharacterReference(cp) {
      if (cp === CODE_POINTS.NUMBER_SIGN) {
        this.state = State.NUMERIC_CHARACTER_REFERENCE;
      } else if (isAsciiAlphaNumeric(cp)) {
        this.state = State.NAMED_CHARACTER_REFERENCE;
        this._stateNamedCharacterReference(cp);
      } else {
        this._flushCodePointConsumedAsCharacterReference(CODE_POINTS.AMPERSAND);
        this._reconsumeInState(this.returnState, cp);
      }
    }
    // Named character reference state
    //------------------------------------------------------------------
    _stateNamedCharacterReference(cp) {
      const matchResult = this._matchNamedCharacterReference(cp);
      if (this._ensureHibernation()) {
      } else if (matchResult) {
        for (let i3 = 0; i3 < matchResult.length; i3++) {
          this._flushCodePointConsumedAsCharacterReference(matchResult[i3]);
        }
        this.state = this.returnState;
      } else {
        this._flushCodePointConsumedAsCharacterReference(CODE_POINTS.AMPERSAND);
        this.state = State.AMBIGUOUS_AMPERSAND;
      }
    }
    // Ambiguos ampersand state
    //------------------------------------------------------------------
    _stateAmbiguousAmpersand(cp) {
      if (isAsciiAlphaNumeric(cp)) {
        this._flushCodePointConsumedAsCharacterReference(cp);
      } else {
        if (cp === CODE_POINTS.SEMICOLON) {
          this._err(ERR.unknownNamedCharacterReference);
        }
        this._reconsumeInState(this.returnState, cp);
      }
    }
    // Numeric character reference state
    //------------------------------------------------------------------
    _stateNumericCharacterReference(cp) {
      this.charRefCode = 0;
      if (cp === CODE_POINTS.LATIN_SMALL_X || cp === CODE_POINTS.LATIN_CAPITAL_X) {
        this.state = State.HEXADEMICAL_CHARACTER_REFERENCE_START;
      } else if (isAsciiDigit(cp)) {
        this.state = State.DECIMAL_CHARACTER_REFERENCE;
        this._stateDecimalCharacterReference(cp);
      } else {
        this._err(ERR.absenceOfDigitsInNumericCharacterReference);
        this._flushCodePointConsumedAsCharacterReference(CODE_POINTS.AMPERSAND);
        this._flushCodePointConsumedAsCharacterReference(CODE_POINTS.NUMBER_SIGN);
        this._reconsumeInState(this.returnState, cp);
      }
    }
    // Hexademical character reference start state
    //------------------------------------------------------------------
    _stateHexademicalCharacterReferenceStart(cp) {
      if (isAsciiHexDigit(cp)) {
        this.state = State.HEXADEMICAL_CHARACTER_REFERENCE;
        this._stateHexademicalCharacterReference(cp);
      } else {
        this._err(ERR.absenceOfDigitsInNumericCharacterReference);
        this._flushCodePointConsumedAsCharacterReference(CODE_POINTS.AMPERSAND);
        this._flushCodePointConsumedAsCharacterReference(CODE_POINTS.NUMBER_SIGN);
        this._unconsume(2);
        this.state = this.returnState;
      }
    }
    // Hexademical character reference state
    //------------------------------------------------------------------
    _stateHexademicalCharacterReference(cp) {
      if (isAsciiUpperHexDigit(cp)) {
        this.charRefCode = this.charRefCode * 16 + cp - 55;
      } else if (isAsciiLowerHexDigit(cp)) {
        this.charRefCode = this.charRefCode * 16 + cp - 87;
      } else if (isAsciiDigit(cp)) {
        this.charRefCode = this.charRefCode * 16 + cp - 48;
      } else if (cp === CODE_POINTS.SEMICOLON) {
        this.state = State.NUMERIC_CHARACTER_REFERENCE_END;
      } else {
        this._err(ERR.missingSemicolonAfterCharacterReference);
        this.state = State.NUMERIC_CHARACTER_REFERENCE_END;
        this._stateNumericCharacterReferenceEnd(cp);
      }
    }
    // Decimal character reference state
    //------------------------------------------------------------------
    _stateDecimalCharacterReference(cp) {
      if (isAsciiDigit(cp)) {
        this.charRefCode = this.charRefCode * 10 + cp - 48;
      } else if (cp === CODE_POINTS.SEMICOLON) {
        this.state = State.NUMERIC_CHARACTER_REFERENCE_END;
      } else {
        this._err(ERR.missingSemicolonAfterCharacterReference);
        this.state = State.NUMERIC_CHARACTER_REFERENCE_END;
        this._stateNumericCharacterReferenceEnd(cp);
      }
    }
    // Numeric character reference end state
    //------------------------------------------------------------------
    _stateNumericCharacterReferenceEnd(cp) {
      if (this.charRefCode === CODE_POINTS.NULL) {
        this._err(ERR.nullCharacterReference);
        this.charRefCode = CODE_POINTS.REPLACEMENT_CHARACTER;
      } else if (this.charRefCode > 1114111) {
        this._err(ERR.characterReferenceOutsideUnicodeRange);
        this.charRefCode = CODE_POINTS.REPLACEMENT_CHARACTER;
      } else if (isSurrogate(this.charRefCode)) {
        this._err(ERR.surrogateCharacterReference);
        this.charRefCode = CODE_POINTS.REPLACEMENT_CHARACTER;
      } else if (isUndefinedCodePoint(this.charRefCode)) {
        this._err(ERR.noncharacterCharacterReference);
      } else if (isControlCodePoint(this.charRefCode) || this.charRefCode === CODE_POINTS.CARRIAGE_RETURN) {
        this._err(ERR.controlCharacterReference);
        const replacement = C1_CONTROLS_REFERENCE_REPLACEMENTS.get(this.charRefCode);
        if (replacement !== void 0) {
          this.charRefCode = replacement;
        }
      }
      this._flushCodePointConsumedAsCharacterReference(this.charRefCode);
      this._reconsumeInState(this.returnState, cp);
    }
  };

  // node_modules/parse5/dist/parser/open-element-stack.js
  var IMPLICIT_END_TAG_REQUIRED = /* @__PURE__ */ new Set([TAG_ID.DD, TAG_ID.DT, TAG_ID.LI, TAG_ID.OPTGROUP, TAG_ID.OPTION, TAG_ID.P, TAG_ID.RB, TAG_ID.RP, TAG_ID.RT, TAG_ID.RTC]);
  var IMPLICIT_END_TAG_REQUIRED_THOROUGHLY = /* @__PURE__ */ new Set([
    ...IMPLICIT_END_TAG_REQUIRED,
    TAG_ID.CAPTION,
    TAG_ID.COLGROUP,
    TAG_ID.TBODY,
    TAG_ID.TD,
    TAG_ID.TFOOT,
    TAG_ID.TH,
    TAG_ID.THEAD,
    TAG_ID.TR
  ]);
  var SCOPING_ELEMENT_NS = /* @__PURE__ */ new Map([
    [TAG_ID.APPLET, NS.HTML],
    [TAG_ID.CAPTION, NS.HTML],
    [TAG_ID.HTML, NS.HTML],
    [TAG_ID.MARQUEE, NS.HTML],
    [TAG_ID.OBJECT, NS.HTML],
    [TAG_ID.TABLE, NS.HTML],
    [TAG_ID.TD, NS.HTML],
    [TAG_ID.TEMPLATE, NS.HTML],
    [TAG_ID.TH, NS.HTML],
    [TAG_ID.ANNOTATION_XML, NS.MATHML],
    [TAG_ID.MI, NS.MATHML],
    [TAG_ID.MN, NS.MATHML],
    [TAG_ID.MO, NS.MATHML],
    [TAG_ID.MS, NS.MATHML],
    [TAG_ID.MTEXT, NS.MATHML],
    [TAG_ID.DESC, NS.SVG],
    [TAG_ID.FOREIGN_OBJECT, NS.SVG],
    [TAG_ID.TITLE, NS.SVG]
  ]);
  var NAMED_HEADERS = [TAG_ID.H1, TAG_ID.H2, TAG_ID.H3, TAG_ID.H4, TAG_ID.H5, TAG_ID.H6];
  var TABLE_ROW_CONTEXT = [TAG_ID.TR, TAG_ID.TEMPLATE, TAG_ID.HTML];
  var TABLE_BODY_CONTEXT = [TAG_ID.TBODY, TAG_ID.TFOOT, TAG_ID.THEAD, TAG_ID.TEMPLATE, TAG_ID.HTML];
  var TABLE_CONTEXT = [TAG_ID.TABLE, TAG_ID.TEMPLATE, TAG_ID.HTML];
  var TABLE_CELLS = [TAG_ID.TD, TAG_ID.TH];
  var OpenElementStack = class {
    get currentTmplContentOrNode() {
      return this._isInTemplate() ? this.treeAdapter.getTemplateContent(this.current) : this.current;
    }
    constructor(document2, treeAdapter, handler4) {
      this.treeAdapter = treeAdapter;
      this.handler = handler4;
      this.items = [];
      this.tagIDs = [];
      this.stackTop = -1;
      this.tmplCount = 0;
      this.currentTagId = TAG_ID.UNKNOWN;
      this.current = document2;
    }
    //Index of element
    _indexOf(element) {
      return this.items.lastIndexOf(element, this.stackTop);
    }
    //Update current element
    _isInTemplate() {
      return this.currentTagId === TAG_ID.TEMPLATE && this.treeAdapter.getNamespaceURI(this.current) === NS.HTML;
    }
    _updateCurrentElement() {
      this.current = this.items[this.stackTop];
      this.currentTagId = this.tagIDs[this.stackTop];
    }
    //Mutations
    push(element, tagID) {
      this.stackTop++;
      this.items[this.stackTop] = element;
      this.current = element;
      this.tagIDs[this.stackTop] = tagID;
      this.currentTagId = tagID;
      if (this._isInTemplate()) {
        this.tmplCount++;
      }
      this.handler.onItemPush(element, tagID, true);
    }
    pop() {
      const popped = this.current;
      if (this.tmplCount > 0 && this._isInTemplate()) {
        this.tmplCount--;
      }
      this.stackTop--;
      this._updateCurrentElement();
      this.handler.onItemPop(popped, true);
    }
    replace(oldElement, newElement) {
      const idx = this._indexOf(oldElement);
      this.items[idx] = newElement;
      if (idx === this.stackTop) {
        this.current = newElement;
      }
    }
    insertAfter(referenceElement, newElement, newElementID) {
      const insertionIdx = this._indexOf(referenceElement) + 1;
      this.items.splice(insertionIdx, 0, newElement);
      this.tagIDs.splice(insertionIdx, 0, newElementID);
      this.stackTop++;
      if (insertionIdx === this.stackTop) {
        this._updateCurrentElement();
      }
      this.handler.onItemPush(this.current, this.currentTagId, insertionIdx === this.stackTop);
    }
    popUntilTagNamePopped(tagName18) {
      let targetIdx = this.stackTop + 1;
      do {
        targetIdx = this.tagIDs.lastIndexOf(tagName18, targetIdx - 1);
      } while (targetIdx > 0 && this.treeAdapter.getNamespaceURI(this.items[targetIdx]) !== NS.HTML);
      this.shortenToLength(targetIdx < 0 ? 0 : targetIdx);
    }
    shortenToLength(idx) {
      while (this.stackTop >= idx) {
        const popped = this.current;
        if (this.tmplCount > 0 && this._isInTemplate()) {
          this.tmplCount -= 1;
        }
        this.stackTop--;
        this._updateCurrentElement();
        this.handler.onItemPop(popped, this.stackTop < idx);
      }
    }
    popUntilElementPopped(element) {
      const idx = this._indexOf(element);
      this.shortenToLength(idx < 0 ? 0 : idx);
    }
    popUntilPopped(tagNames, targetNS) {
      const idx = this._indexOfTagNames(tagNames, targetNS);
      this.shortenToLength(idx < 0 ? 0 : idx);
    }
    popUntilNumberedHeaderPopped() {
      this.popUntilPopped(NAMED_HEADERS, NS.HTML);
    }
    popUntilTableCellPopped() {
      this.popUntilPopped(TABLE_CELLS, NS.HTML);
    }
    popAllUpToHtmlElement() {
      this.tmplCount = 0;
      this.shortenToLength(1);
    }
    _indexOfTagNames(tagNames, namespace) {
      for (let i3 = this.stackTop; i3 >= 0; i3--) {
        if (tagNames.includes(this.tagIDs[i3]) && this.treeAdapter.getNamespaceURI(this.items[i3]) === namespace) {
          return i3;
        }
      }
      return -1;
    }
    clearBackTo(tagNames, targetNS) {
      const idx = this._indexOfTagNames(tagNames, targetNS);
      this.shortenToLength(idx + 1);
    }
    clearBackToTableContext() {
      this.clearBackTo(TABLE_CONTEXT, NS.HTML);
    }
    clearBackToTableBodyContext() {
      this.clearBackTo(TABLE_BODY_CONTEXT, NS.HTML);
    }
    clearBackToTableRowContext() {
      this.clearBackTo(TABLE_ROW_CONTEXT, NS.HTML);
    }
    remove(element) {
      const idx = this._indexOf(element);
      if (idx >= 0) {
        if (idx === this.stackTop) {
          this.pop();
        } else {
          this.items.splice(idx, 1);
          this.tagIDs.splice(idx, 1);
          this.stackTop--;
          this._updateCurrentElement();
          this.handler.onItemPop(element, false);
        }
      }
    }
    //Search
    tryPeekProperlyNestedBodyElement() {
      return this.stackTop >= 1 && this.tagIDs[1] === TAG_ID.BODY ? this.items[1] : null;
    }
    contains(element) {
      return this._indexOf(element) > -1;
    }
    getCommonAncestor(element) {
      const elementIdx = this._indexOf(element) - 1;
      return elementIdx >= 0 ? this.items[elementIdx] : null;
    }
    isRootHtmlElementCurrent() {
      return this.stackTop === 0 && this.tagIDs[0] === TAG_ID.HTML;
    }
    //Element in scope
    hasInScope(tagName18) {
      for (let i3 = this.stackTop; i3 >= 0; i3--) {
        const tn = this.tagIDs[i3];
        const ns = this.treeAdapter.getNamespaceURI(this.items[i3]);
        if (tn === tagName18 && ns === NS.HTML) {
          return true;
        }
        if (SCOPING_ELEMENT_NS.get(tn) === ns) {
          return false;
        }
      }
      return true;
    }
    hasNumberedHeaderInScope() {
      for (let i3 = this.stackTop; i3 >= 0; i3--) {
        const tn = this.tagIDs[i3];
        const ns = this.treeAdapter.getNamespaceURI(this.items[i3]);
        if (isNumberedHeader(tn) && ns === NS.HTML) {
          return true;
        }
        if (SCOPING_ELEMENT_NS.get(tn) === ns) {
          return false;
        }
      }
      return true;
    }
    hasInListItemScope(tagName18) {
      for (let i3 = this.stackTop; i3 >= 0; i3--) {
        const tn = this.tagIDs[i3];
        const ns = this.treeAdapter.getNamespaceURI(this.items[i3]);
        if (tn === tagName18 && ns === NS.HTML) {
          return true;
        }
        if ((tn === TAG_ID.UL || tn === TAG_ID.OL) && ns === NS.HTML || SCOPING_ELEMENT_NS.get(tn) === ns) {
          return false;
        }
      }
      return true;
    }
    hasInButtonScope(tagName18) {
      for (let i3 = this.stackTop; i3 >= 0; i3--) {
        const tn = this.tagIDs[i3];
        const ns = this.treeAdapter.getNamespaceURI(this.items[i3]);
        if (tn === tagName18 && ns === NS.HTML) {
          return true;
        }
        if (tn === TAG_ID.BUTTON && ns === NS.HTML || SCOPING_ELEMENT_NS.get(tn) === ns) {
          return false;
        }
      }
      return true;
    }
    hasInTableScope(tagName18) {
      for (let i3 = this.stackTop; i3 >= 0; i3--) {
        const tn = this.tagIDs[i3];
        const ns = this.treeAdapter.getNamespaceURI(this.items[i3]);
        if (ns !== NS.HTML) {
          continue;
        }
        if (tn === tagName18) {
          return true;
        }
        if (tn === TAG_ID.TABLE || tn === TAG_ID.TEMPLATE || tn === TAG_ID.HTML) {
          return false;
        }
      }
      return true;
    }
    hasTableBodyContextInTableScope() {
      for (let i3 = this.stackTop; i3 >= 0; i3--) {
        const tn = this.tagIDs[i3];
        const ns = this.treeAdapter.getNamespaceURI(this.items[i3]);
        if (ns !== NS.HTML) {
          continue;
        }
        if (tn === TAG_ID.TBODY || tn === TAG_ID.THEAD || tn === TAG_ID.TFOOT) {
          return true;
        }
        if (tn === TAG_ID.TABLE || tn === TAG_ID.HTML) {
          return false;
        }
      }
      return true;
    }
    hasInSelectScope(tagName18) {
      for (let i3 = this.stackTop; i3 >= 0; i3--) {
        const tn = this.tagIDs[i3];
        const ns = this.treeAdapter.getNamespaceURI(this.items[i3]);
        if (ns !== NS.HTML) {
          continue;
        }
        if (tn === tagName18) {
          return true;
        }
        if (tn !== TAG_ID.OPTION && tn !== TAG_ID.OPTGROUP) {
          return false;
        }
      }
      return true;
    }
    //Implied end tags
    generateImpliedEndTags() {
      while (IMPLICIT_END_TAG_REQUIRED.has(this.currentTagId)) {
        this.pop();
      }
    }
    generateImpliedEndTagsThoroughly() {
      while (IMPLICIT_END_TAG_REQUIRED_THOROUGHLY.has(this.currentTagId)) {
        this.pop();
      }
    }
    generateImpliedEndTagsWithExclusion(exclusionId) {
      while (this.currentTagId !== exclusionId && IMPLICIT_END_TAG_REQUIRED_THOROUGHLY.has(this.currentTagId)) {
        this.pop();
      }
    }
  };

  // node_modules/parse5/dist/parser/formatting-element-list.js
  var NOAH_ARK_CAPACITY = 3;
  var EntryType;
  (function(EntryType2) {
    EntryType2[EntryType2["Marker"] = 0] = "Marker";
    EntryType2[EntryType2["Element"] = 1] = "Element";
  })(EntryType = EntryType || (EntryType = {}));
  var MARKER = { type: EntryType.Marker };
  var FormattingElementList = class {
    constructor(treeAdapter) {
      this.treeAdapter = treeAdapter;
      this.entries = [];
      this.bookmark = null;
    }
    //Noah Ark's condition
    //OPTIMIZATION: at first we try to find possible candidates for exclusion using
    //lightweight heuristics without thorough attributes check.
    _getNoahArkConditionCandidates(newElement, neAttrs) {
      const candidates = [];
      const neAttrsLength = neAttrs.length;
      const neTagName = this.treeAdapter.getTagName(newElement);
      const neNamespaceURI = this.treeAdapter.getNamespaceURI(newElement);
      for (let i3 = 0; i3 < this.entries.length; i3++) {
        const entry = this.entries[i3];
        if (entry.type === EntryType.Marker) {
          break;
        }
        const { element } = entry;
        if (this.treeAdapter.getTagName(element) === neTagName && this.treeAdapter.getNamespaceURI(element) === neNamespaceURI) {
          const elementAttrs = this.treeAdapter.getAttrList(element);
          if (elementAttrs.length === neAttrsLength) {
            candidates.push({ idx: i3, attrs: elementAttrs });
          }
        }
      }
      return candidates;
    }
    _ensureNoahArkCondition(newElement) {
      if (this.entries.length < NOAH_ARK_CAPACITY)
        return;
      const neAttrs = this.treeAdapter.getAttrList(newElement);
      const candidates = this._getNoahArkConditionCandidates(newElement, neAttrs);
      if (candidates.length < NOAH_ARK_CAPACITY)
        return;
      const neAttrsMap = new Map(neAttrs.map((neAttr) => [neAttr.name, neAttr.value]));
      let validCandidates = 0;
      for (let i3 = 0; i3 < candidates.length; i3++) {
        const candidate = candidates[i3];
        if (candidate.attrs.every((cAttr) => neAttrsMap.get(cAttr.name) === cAttr.value)) {
          validCandidates += 1;
          if (validCandidates >= NOAH_ARK_CAPACITY) {
            this.entries.splice(candidate.idx, 1);
          }
        }
      }
    }
    //Mutations
    insertMarker() {
      this.entries.unshift(MARKER);
    }
    pushElement(element, token) {
      this._ensureNoahArkCondition(element);
      this.entries.unshift({
        type: EntryType.Element,
        element,
        token
      });
    }
    insertElementAfterBookmark(element, token) {
      const bookmarkIdx = this.entries.indexOf(this.bookmark);
      this.entries.splice(bookmarkIdx, 0, {
        type: EntryType.Element,
        element,
        token
      });
    }
    removeEntry(entry) {
      const entryIndex = this.entries.indexOf(entry);
      if (entryIndex >= 0) {
        this.entries.splice(entryIndex, 1);
      }
    }
    /**
     * Clears the list of formatting elements up to the last marker.
     *
     * @see https://html.spec.whatwg.org/multipage/parsing.html#clear-the-list-of-active-formatting-elements-up-to-the-last-marker
     */
    clearToLastMarker() {
      const markerIdx = this.entries.indexOf(MARKER);
      if (markerIdx >= 0) {
        this.entries.splice(0, markerIdx + 1);
      } else {
        this.entries.length = 0;
      }
    }
    //Search
    getElementEntryInScopeWithTagName(tagName18) {
      const entry = this.entries.find((entry2) => entry2.type === EntryType.Marker || this.treeAdapter.getTagName(entry2.element) === tagName18);
      return entry && entry.type === EntryType.Element ? entry : null;
    }
    getElementEntry(element) {
      return this.entries.find((entry) => entry.type === EntryType.Element && entry.element === element);
    }
  };

  // node_modules/parse5/dist/tree-adapters/default.js
  function createTextNode(value) {
    return {
      nodeName: "#text",
      value,
      parentNode: null
    };
  }
  var defaultTreeAdapter = {
    //Node construction
    createDocument() {
      return {
        nodeName: "#document",
        mode: DOCUMENT_MODE.NO_QUIRKS,
        childNodes: []
      };
    },
    createDocumentFragment() {
      return {
        nodeName: "#document-fragment",
        childNodes: []
      };
    },
    createElement(tagName18, namespaceURI, attrs) {
      return {
        nodeName: tagName18,
        tagName: tagName18,
        attrs,
        namespaceURI,
        childNodes: [],
        parentNode: null
      };
    },
    createCommentNode(data2) {
      return {
        nodeName: "#comment",
        data: data2,
        parentNode: null
      };
    },
    //Tree mutation
    appendChild(parentNode, newNode) {
      parentNode.childNodes.push(newNode);
      newNode.parentNode = parentNode;
    },
    insertBefore(parentNode, newNode, referenceNode) {
      const insertionIdx = parentNode.childNodes.indexOf(referenceNode);
      parentNode.childNodes.splice(insertionIdx, 0, newNode);
      newNode.parentNode = parentNode;
    },
    setTemplateContent(templateElement, contentElement) {
      templateElement.content = contentElement;
    },
    getTemplateContent(templateElement) {
      return templateElement.content;
    },
    setDocumentType(document2, name, publicId, systemId) {
      const doctypeNode = document2.childNodes.find((node) => node.nodeName === "#documentType");
      if (doctypeNode) {
        doctypeNode.name = name;
        doctypeNode.publicId = publicId;
        doctypeNode.systemId = systemId;
      } else {
        const node = {
          nodeName: "#documentType",
          name,
          publicId,
          systemId,
          parentNode: null
        };
        defaultTreeAdapter.appendChild(document2, node);
      }
    },
    setDocumentMode(document2, mode) {
      document2.mode = mode;
    },
    getDocumentMode(document2) {
      return document2.mode;
    },
    detachNode(node) {
      if (node.parentNode) {
        const idx = node.parentNode.childNodes.indexOf(node);
        node.parentNode.childNodes.splice(idx, 1);
        node.parentNode = null;
      }
    },
    insertText(parentNode, text3) {
      if (parentNode.childNodes.length > 0) {
        const prevNode = parentNode.childNodes[parentNode.childNodes.length - 1];
        if (defaultTreeAdapter.isTextNode(prevNode)) {
          prevNode.value += text3;
          return;
        }
      }
      defaultTreeAdapter.appendChild(parentNode, createTextNode(text3));
    },
    insertTextBefore(parentNode, text3, referenceNode) {
      const prevNode = parentNode.childNodes[parentNode.childNodes.indexOf(referenceNode) - 1];
      if (prevNode && defaultTreeAdapter.isTextNode(prevNode)) {
        prevNode.value += text3;
      } else {
        defaultTreeAdapter.insertBefore(parentNode, createTextNode(text3), referenceNode);
      }
    },
    adoptAttributes(recipient, attrs) {
      const recipientAttrsMap = new Set(recipient.attrs.map((attr2) => attr2.name));
      for (let j3 = 0; j3 < attrs.length; j3++) {
        if (!recipientAttrsMap.has(attrs[j3].name)) {
          recipient.attrs.push(attrs[j3]);
        }
      }
    },
    //Tree traversing
    getFirstChild(node) {
      return node.childNodes[0];
    },
    getChildNodes(node) {
      return node.childNodes;
    },
    getParentNode(node) {
      return node.parentNode;
    },
    getAttrList(element) {
      return element.attrs;
    },
    //Node data
    getTagName(element) {
      return element.tagName;
    },
    getNamespaceURI(element) {
      return element.namespaceURI;
    },
    getTextNodeContent(textNode) {
      return textNode.value;
    },
    getCommentNodeContent(commentNode) {
      return commentNode.data;
    },
    getDocumentTypeNodeName(doctypeNode) {
      return doctypeNode.name;
    },
    getDocumentTypeNodePublicId(doctypeNode) {
      return doctypeNode.publicId;
    },
    getDocumentTypeNodeSystemId(doctypeNode) {
      return doctypeNode.systemId;
    },
    //Node types
    isTextNode(node) {
      return node.nodeName === "#text";
    },
    isCommentNode(node) {
      return node.nodeName === "#comment";
    },
    isDocumentTypeNode(node) {
      return node.nodeName === "#documentType";
    },
    isElementNode(node) {
      return Object.prototype.hasOwnProperty.call(node, "tagName");
    },
    // Source code location
    setNodeSourceCodeLocation(node, location) {
      node.sourceCodeLocation = location;
    },
    getNodeSourceCodeLocation(node) {
      return node.sourceCodeLocation;
    },
    updateNodeSourceCodeLocation(node, endLocation) {
      node.sourceCodeLocation = { ...node.sourceCodeLocation, ...endLocation };
    }
  };

  // node_modules/parse5/dist/common/doctype.js
  var VALID_DOCTYPE_NAME = "html";
  var VALID_SYSTEM_ID = "about:legacy-compat";
  var QUIRKS_MODE_SYSTEM_ID = "http://www.ibm.com/data/dtd/v11/ibmxhtml1-transitional.dtd";
  var QUIRKS_MODE_PUBLIC_ID_PREFIXES = [
    "+//silmaril//dtd html pro v0r11 19970101//",
    "-//as//dtd html 3.0 aswedit + extensions//",
    "-//advasoft ltd//dtd html 3.0 aswedit + extensions//",
    "-//ietf//dtd html 2.0 level 1//",
    "-//ietf//dtd html 2.0 level 2//",
    "-//ietf//dtd html 2.0 strict level 1//",
    "-//ietf//dtd html 2.0 strict level 2//",
    "-//ietf//dtd html 2.0 strict//",
    "-//ietf//dtd html 2.0//",
    "-//ietf//dtd html 2.1e//",
    "-//ietf//dtd html 3.0//",
    "-//ietf//dtd html 3.2 final//",
    "-//ietf//dtd html 3.2//",
    "-//ietf//dtd html 3//",
    "-//ietf//dtd html level 0//",
    "-//ietf//dtd html level 1//",
    "-//ietf//dtd html level 2//",
    "-//ietf//dtd html level 3//",
    "-//ietf//dtd html strict level 0//",
    "-//ietf//dtd html strict level 1//",
    "-//ietf//dtd html strict level 2//",
    "-//ietf//dtd html strict level 3//",
    "-//ietf//dtd html strict//",
    "-//ietf//dtd html//",
    "-//metrius//dtd metrius presentational//",
    "-//microsoft//dtd internet explorer 2.0 html strict//",
    "-//microsoft//dtd internet explorer 2.0 html//",
    "-//microsoft//dtd internet explorer 2.0 tables//",
    "-//microsoft//dtd internet explorer 3.0 html strict//",
    "-//microsoft//dtd internet explorer 3.0 html//",
    "-//microsoft//dtd internet explorer 3.0 tables//",
    "-//netscape comm. corp.//dtd html//",
    "-//netscape comm. corp.//dtd strict html//",
    "-//o'reilly and associates//dtd html 2.0//",
    "-//o'reilly and associates//dtd html extended 1.0//",
    "-//o'reilly and associates//dtd html extended relaxed 1.0//",
    "-//sq//dtd html 2.0 hotmetal + extensions//",
    "-//softquad software//dtd hotmetal pro 6.0::19990601::extensions to html 4.0//",
    "-//softquad//dtd hotmetal pro 4.0::19971010::extensions to html 4.0//",
    "-//spyglass//dtd html 2.0 extended//",
    "-//sun microsystems corp.//dtd hotjava html//",
    "-//sun microsystems corp.//dtd hotjava strict html//",
    "-//w3c//dtd html 3 1995-03-24//",
    "-//w3c//dtd html 3.2 draft//",
    "-//w3c//dtd html 3.2 final//",
    "-//w3c//dtd html 3.2//",
    "-//w3c//dtd html 3.2s draft//",
    "-//w3c//dtd html 4.0 frameset//",
    "-//w3c//dtd html 4.0 transitional//",
    "-//w3c//dtd html experimental 19960712//",
    "-//w3c//dtd html experimental 970421//",
    "-//w3c//dtd w3 html//",
    "-//w3o//dtd w3 html 3.0//",
    "-//webtechs//dtd mozilla html 2.0//",
    "-//webtechs//dtd mozilla html//"
  ];
  var QUIRKS_MODE_NO_SYSTEM_ID_PUBLIC_ID_PREFIXES = [
    ...QUIRKS_MODE_PUBLIC_ID_PREFIXES,
    "-//w3c//dtd html 4.01 frameset//",
    "-//w3c//dtd html 4.01 transitional//"
  ];
  var QUIRKS_MODE_PUBLIC_IDS = /* @__PURE__ */ new Set([
    "-//w3o//dtd w3 html strict 3.0//en//",
    "-/w3c/dtd html 4.0 transitional/en",
    "html"
  ]);
  var LIMITED_QUIRKS_PUBLIC_ID_PREFIXES = ["-//w3c//dtd xhtml 1.0 frameset//", "-//w3c//dtd xhtml 1.0 transitional//"];
  var LIMITED_QUIRKS_WITH_SYSTEM_ID_PUBLIC_ID_PREFIXES = [
    ...LIMITED_QUIRKS_PUBLIC_ID_PREFIXES,
    "-//w3c//dtd html 4.01 frameset//",
    "-//w3c//dtd html 4.01 transitional//"
  ];
  function hasPrefix(publicId, prefixes) {
    return prefixes.some((prefix) => publicId.startsWith(prefix));
  }
  function isConforming(token) {
    return token.name === VALID_DOCTYPE_NAME && token.publicId === null && (token.systemId === null || token.systemId === VALID_SYSTEM_ID);
  }
  function getDocumentMode(token) {
    if (token.name !== VALID_DOCTYPE_NAME) {
      return DOCUMENT_MODE.QUIRKS;
    }
    const { systemId } = token;
    if (systemId && systemId.toLowerCase() === QUIRKS_MODE_SYSTEM_ID) {
      return DOCUMENT_MODE.QUIRKS;
    }
    let { publicId } = token;
    if (publicId !== null) {
      publicId = publicId.toLowerCase();
      if (QUIRKS_MODE_PUBLIC_IDS.has(publicId)) {
        return DOCUMENT_MODE.QUIRKS;
      }
      let prefixes = systemId === null ? QUIRKS_MODE_NO_SYSTEM_ID_PUBLIC_ID_PREFIXES : QUIRKS_MODE_PUBLIC_ID_PREFIXES;
      if (hasPrefix(publicId, prefixes)) {
        return DOCUMENT_MODE.QUIRKS;
      }
      prefixes = systemId === null ? LIMITED_QUIRKS_PUBLIC_ID_PREFIXES : LIMITED_QUIRKS_WITH_SYSTEM_ID_PUBLIC_ID_PREFIXES;
      if (hasPrefix(publicId, prefixes)) {
        return DOCUMENT_MODE.LIMITED_QUIRKS;
      }
    }
    return DOCUMENT_MODE.NO_QUIRKS;
  }

  // node_modules/parse5/dist/common/foreign-content.js
  var MIME_TYPES = {
    TEXT_HTML: "text/html",
    APPLICATION_XML: "application/xhtml+xml"
  };
  var DEFINITION_URL_ATTR = "definitionurl";
  var ADJUSTED_DEFINITION_URL_ATTR = "definitionURL";
  var SVG_ATTRS_ADJUSTMENT_MAP = new Map([
    "attributeName",
    "attributeType",
    "baseFrequency",
    "baseProfile",
    "calcMode",
    "clipPathUnits",
    "diffuseConstant",
    "edgeMode",
    "filterUnits",
    "glyphRef",
    "gradientTransform",
    "gradientUnits",
    "kernelMatrix",
    "kernelUnitLength",
    "keyPoints",
    "keySplines",
    "keyTimes",
    "lengthAdjust",
    "limitingConeAngle",
    "markerHeight",
    "markerUnits",
    "markerWidth",
    "maskContentUnits",
    "maskUnits",
    "numOctaves",
    "pathLength",
    "patternContentUnits",
    "patternTransform",
    "patternUnits",
    "pointsAtX",
    "pointsAtY",
    "pointsAtZ",
    "preserveAlpha",
    "preserveAspectRatio",
    "primitiveUnits",
    "refX",
    "refY",
    "repeatCount",
    "repeatDur",
    "requiredExtensions",
    "requiredFeatures",
    "specularConstant",
    "specularExponent",
    "spreadMethod",
    "startOffset",
    "stdDeviation",
    "stitchTiles",
    "surfaceScale",
    "systemLanguage",
    "tableValues",
    "targetX",
    "targetY",
    "textLength",
    "viewBox",
    "viewTarget",
    "xChannelSelector",
    "yChannelSelector",
    "zoomAndPan"
  ].map((attr2) => [attr2.toLowerCase(), attr2]));
  var XML_ATTRS_ADJUSTMENT_MAP = /* @__PURE__ */ new Map([
    ["xlink:actuate", { prefix: "xlink", name: "actuate", namespace: NS.XLINK }],
    ["xlink:arcrole", { prefix: "xlink", name: "arcrole", namespace: NS.XLINK }],
    ["xlink:href", { prefix: "xlink", name: "href", namespace: NS.XLINK }],
    ["xlink:role", { prefix: "xlink", name: "role", namespace: NS.XLINK }],
    ["xlink:show", { prefix: "xlink", name: "show", namespace: NS.XLINK }],
    ["xlink:title", { prefix: "xlink", name: "title", namespace: NS.XLINK }],
    ["xlink:type", { prefix: "xlink", name: "type", namespace: NS.XLINK }],
    ["xml:base", { prefix: "xml", name: "base", namespace: NS.XML }],
    ["xml:lang", { prefix: "xml", name: "lang", namespace: NS.XML }],
    ["xml:space", { prefix: "xml", name: "space", namespace: NS.XML }],
    ["xmlns", { prefix: "", name: "xmlns", namespace: NS.XMLNS }],
    ["xmlns:xlink", { prefix: "xmlns", name: "xlink", namespace: NS.XMLNS }]
  ]);
  var SVG_TAG_NAMES_ADJUSTMENT_MAP = new Map([
    "altGlyph",
    "altGlyphDef",
    "altGlyphItem",
    "animateColor",
    "animateMotion",
    "animateTransform",
    "clipPath",
    "feBlend",
    "feColorMatrix",
    "feComponentTransfer",
    "feComposite",
    "feConvolveMatrix",
    "feDiffuseLighting",
    "feDisplacementMap",
    "feDistantLight",
    "feFlood",
    "feFuncA",
    "feFuncB",
    "feFuncG",
    "feFuncR",
    "feGaussianBlur",
    "feImage",
    "feMerge",
    "feMergeNode",
    "feMorphology",
    "feOffset",
    "fePointLight",
    "feSpecularLighting",
    "feSpotLight",
    "feTile",
    "feTurbulence",
    "foreignObject",
    "glyphRef",
    "linearGradient",
    "radialGradient",
    "textPath"
  ].map((tn) => [tn.toLowerCase(), tn]));
  var EXITS_FOREIGN_CONTENT = /* @__PURE__ */ new Set([
    TAG_ID.B,
    TAG_ID.BIG,
    TAG_ID.BLOCKQUOTE,
    TAG_ID.BODY,
    TAG_ID.BR,
    TAG_ID.CENTER,
    TAG_ID.CODE,
    TAG_ID.DD,
    TAG_ID.DIV,
    TAG_ID.DL,
    TAG_ID.DT,
    TAG_ID.EM,
    TAG_ID.EMBED,
    TAG_ID.H1,
    TAG_ID.H2,
    TAG_ID.H3,
    TAG_ID.H4,
    TAG_ID.H5,
    TAG_ID.H6,
    TAG_ID.HEAD,
    TAG_ID.HR,
    TAG_ID.I,
    TAG_ID.IMG,
    TAG_ID.LI,
    TAG_ID.LISTING,
    TAG_ID.MENU,
    TAG_ID.META,
    TAG_ID.NOBR,
    TAG_ID.OL,
    TAG_ID.P,
    TAG_ID.PRE,
    TAG_ID.RUBY,
    TAG_ID.S,
    TAG_ID.SMALL,
    TAG_ID.SPAN,
    TAG_ID.STRONG,
    TAG_ID.STRIKE,
    TAG_ID.SUB,
    TAG_ID.SUP,
    TAG_ID.TABLE,
    TAG_ID.TT,
    TAG_ID.U,
    TAG_ID.UL,
    TAG_ID.VAR
  ]);
  function causesExit(startTagToken) {
    const tn = startTagToken.tagID;
    const isFontWithAttrs = tn === TAG_ID.FONT && startTagToken.attrs.some(({ name }) => name === ATTRS.COLOR || name === ATTRS.SIZE || name === ATTRS.FACE);
    return isFontWithAttrs || EXITS_FOREIGN_CONTENT.has(tn);
  }
  function adjustTokenMathMLAttrs(token) {
    for (let i3 = 0; i3 < token.attrs.length; i3++) {
      if (token.attrs[i3].name === DEFINITION_URL_ATTR) {
        token.attrs[i3].name = ADJUSTED_DEFINITION_URL_ATTR;
        break;
      }
    }
  }
  function adjustTokenSVGAttrs(token) {
    for (let i3 = 0; i3 < token.attrs.length; i3++) {
      const adjustedAttrName = SVG_ATTRS_ADJUSTMENT_MAP.get(token.attrs[i3].name);
      if (adjustedAttrName != null) {
        token.attrs[i3].name = adjustedAttrName;
      }
    }
  }
  function adjustTokenXMLAttrs(token) {
    for (let i3 = 0; i3 < token.attrs.length; i3++) {
      const adjustedAttrEntry = XML_ATTRS_ADJUSTMENT_MAP.get(token.attrs[i3].name);
      if (adjustedAttrEntry) {
        token.attrs[i3].prefix = adjustedAttrEntry.prefix;
        token.attrs[i3].name = adjustedAttrEntry.name;
        token.attrs[i3].namespace = adjustedAttrEntry.namespace;
      }
    }
  }
  function adjustTokenSVGTagName(token) {
    const adjustedTagName = SVG_TAG_NAMES_ADJUSTMENT_MAP.get(token.tagName);
    if (adjustedTagName != null) {
      token.tagName = adjustedTagName;
      token.tagID = getTagID(token.tagName);
    }
  }
  function isMathMLTextIntegrationPoint(tn, ns) {
    return ns === NS.MATHML && (tn === TAG_ID.MI || tn === TAG_ID.MO || tn === TAG_ID.MN || tn === TAG_ID.MS || tn === TAG_ID.MTEXT);
  }
  function isHtmlIntegrationPoint(tn, ns, attrs) {
    if (ns === NS.MATHML && tn === TAG_ID.ANNOTATION_XML) {
      for (let i3 = 0; i3 < attrs.length; i3++) {
        if (attrs[i3].name === ATTRS.ENCODING) {
          const value = attrs[i3].value.toLowerCase();
          return value === MIME_TYPES.TEXT_HTML || value === MIME_TYPES.APPLICATION_XML;
        }
      }
    }
    return ns === NS.SVG && (tn === TAG_ID.FOREIGN_OBJECT || tn === TAG_ID.DESC || tn === TAG_ID.TITLE);
  }
  function isIntegrationPoint(tn, ns, attrs, foreignNS) {
    return (!foreignNS || foreignNS === NS.HTML) && isHtmlIntegrationPoint(tn, ns, attrs) || (!foreignNS || foreignNS === NS.MATHML) && isMathMLTextIntegrationPoint(tn, ns);
  }

  // node_modules/parse5/dist/parser/index.js
  var HIDDEN_INPUT_TYPE = "hidden";
  var AA_OUTER_LOOP_ITER = 8;
  var AA_INNER_LOOP_ITER = 3;
  var InsertionMode;
  (function(InsertionMode2) {
    InsertionMode2[InsertionMode2["INITIAL"] = 0] = "INITIAL";
    InsertionMode2[InsertionMode2["BEFORE_HTML"] = 1] = "BEFORE_HTML";
    InsertionMode2[InsertionMode2["BEFORE_HEAD"] = 2] = "BEFORE_HEAD";
    InsertionMode2[InsertionMode2["IN_HEAD"] = 3] = "IN_HEAD";
    InsertionMode2[InsertionMode2["IN_HEAD_NO_SCRIPT"] = 4] = "IN_HEAD_NO_SCRIPT";
    InsertionMode2[InsertionMode2["AFTER_HEAD"] = 5] = "AFTER_HEAD";
    InsertionMode2[InsertionMode2["IN_BODY"] = 6] = "IN_BODY";
    InsertionMode2[InsertionMode2["TEXT"] = 7] = "TEXT";
    InsertionMode2[InsertionMode2["IN_TABLE"] = 8] = "IN_TABLE";
    InsertionMode2[InsertionMode2["IN_TABLE_TEXT"] = 9] = "IN_TABLE_TEXT";
    InsertionMode2[InsertionMode2["IN_CAPTION"] = 10] = "IN_CAPTION";
    InsertionMode2[InsertionMode2["IN_COLUMN_GROUP"] = 11] = "IN_COLUMN_GROUP";
    InsertionMode2[InsertionMode2["IN_TABLE_BODY"] = 12] = "IN_TABLE_BODY";
    InsertionMode2[InsertionMode2["IN_ROW"] = 13] = "IN_ROW";
    InsertionMode2[InsertionMode2["IN_CELL"] = 14] = "IN_CELL";
    InsertionMode2[InsertionMode2["IN_SELECT"] = 15] = "IN_SELECT";
    InsertionMode2[InsertionMode2["IN_SELECT_IN_TABLE"] = 16] = "IN_SELECT_IN_TABLE";
    InsertionMode2[InsertionMode2["IN_TEMPLATE"] = 17] = "IN_TEMPLATE";
    InsertionMode2[InsertionMode2["AFTER_BODY"] = 18] = "AFTER_BODY";
    InsertionMode2[InsertionMode2["IN_FRAMESET"] = 19] = "IN_FRAMESET";
    InsertionMode2[InsertionMode2["AFTER_FRAMESET"] = 20] = "AFTER_FRAMESET";
    InsertionMode2[InsertionMode2["AFTER_AFTER_BODY"] = 21] = "AFTER_AFTER_BODY";
    InsertionMode2[InsertionMode2["AFTER_AFTER_FRAMESET"] = 22] = "AFTER_AFTER_FRAMESET";
  })(InsertionMode || (InsertionMode = {}));
  var BASE_LOC = {
    startLine: -1,
    startCol: -1,
    startOffset: -1,
    endLine: -1,
    endCol: -1,
    endOffset: -1
  };
  var TABLE_STRUCTURE_TAGS = /* @__PURE__ */ new Set([TAG_ID.TABLE, TAG_ID.TBODY, TAG_ID.TFOOT, TAG_ID.THEAD, TAG_ID.TR]);
  var defaultParserOptions = {
    scriptingEnabled: true,
    sourceCodeLocationInfo: false,
    treeAdapter: defaultTreeAdapter,
    onParseError: null
  };
  var Parser = class {
    constructor(options2, document2, fragmentContext = null, scriptHandler = null) {
      this.fragmentContext = fragmentContext;
      this.scriptHandler = scriptHandler;
      this.currentToken = null;
      this.stopped = false;
      this.insertionMode = InsertionMode.INITIAL;
      this.originalInsertionMode = InsertionMode.INITIAL;
      this.headElement = null;
      this.formElement = null;
      this.currentNotInHTML = false;
      this.tmplInsertionModeStack = [];
      this.pendingCharacterTokens = [];
      this.hasNonWhitespacePendingCharacterToken = false;
      this.framesetOk = true;
      this.skipNextNewLine = false;
      this.fosterParentingEnabled = false;
      this.options = {
        ...defaultParserOptions,
        ...options2
      };
      this.treeAdapter = this.options.treeAdapter;
      this.onParseError = this.options.onParseError;
      if (this.onParseError) {
        this.options.sourceCodeLocationInfo = true;
      }
      this.document = document2 !== null && document2 !== void 0 ? document2 : this.treeAdapter.createDocument();
      this.tokenizer = new Tokenizer(this.options, this);
      this.activeFormattingElements = new FormattingElementList(this.treeAdapter);
      this.fragmentContextID = fragmentContext ? getTagID(this.treeAdapter.getTagName(fragmentContext)) : TAG_ID.UNKNOWN;
      this._setContextModes(fragmentContext !== null && fragmentContext !== void 0 ? fragmentContext : this.document, this.fragmentContextID);
      this.openElements = new OpenElementStack(this.document, this.treeAdapter, this);
    }
    // API
    static parse(html3, options2) {
      const parser = new this(options2);
      parser.tokenizer.write(html3, true);
      return parser.document;
    }
    static getFragmentParser(fragmentContext, options2) {
      const opts = {
        ...defaultParserOptions,
        ...options2
      };
      fragmentContext !== null && fragmentContext !== void 0 ? fragmentContext : fragmentContext = opts.treeAdapter.createElement(TAG_NAMES.TEMPLATE, NS.HTML, []);
      const documentMock = opts.treeAdapter.createElement("documentmock", NS.HTML, []);
      const parser = new this(opts, documentMock, fragmentContext);
      if (parser.fragmentContextID === TAG_ID.TEMPLATE) {
        parser.tmplInsertionModeStack.unshift(InsertionMode.IN_TEMPLATE);
      }
      parser._initTokenizerForFragmentParsing();
      parser._insertFakeRootElement();
      parser._resetInsertionMode();
      parser._findFormInFragmentContext();
      return parser;
    }
    getFragment() {
      const rootElement = this.treeAdapter.getFirstChild(this.document);
      const fragment = this.treeAdapter.createDocumentFragment();
      this._adoptNodes(rootElement, fragment);
      return fragment;
    }
    //Errors
    _err(token, code, beforeToken) {
      var _a2;
      if (!this.onParseError)
        return;
      const loc = (_a2 = token.location) !== null && _a2 !== void 0 ? _a2 : BASE_LOC;
      const err = {
        code,
        startLine: loc.startLine,
        startCol: loc.startCol,
        startOffset: loc.startOffset,
        endLine: beforeToken ? loc.startLine : loc.endLine,
        endCol: beforeToken ? loc.startCol : loc.endCol,
        endOffset: beforeToken ? loc.startOffset : loc.endOffset
      };
      this.onParseError(err);
    }
    //Stack events
    onItemPush(node, tid, isTop) {
      var _a2, _b;
      (_b = (_a2 = this.treeAdapter).onItemPush) === null || _b === void 0 ? void 0 : _b.call(_a2, node);
      if (isTop && this.openElements.stackTop > 0)
        this._setContextModes(node, tid);
    }
    onItemPop(node, isTop) {
      var _a2, _b;
      if (this.options.sourceCodeLocationInfo) {
        this._setEndLocation(node, this.currentToken);
      }
      (_b = (_a2 = this.treeAdapter).onItemPop) === null || _b === void 0 ? void 0 : _b.call(_a2, node, this.openElements.current);
      if (isTop) {
        let current;
        let currentTagId;
        if (this.openElements.stackTop === 0 && this.fragmentContext) {
          current = this.fragmentContext;
          currentTagId = this.fragmentContextID;
        } else {
          ({ current, currentTagId } = this.openElements);
        }
        this._setContextModes(current, currentTagId);
      }
    }
    _setContextModes(current, tid) {
      const isHTML = current === this.document || this.treeAdapter.getNamespaceURI(current) === NS.HTML;
      this.currentNotInHTML = !isHTML;
      this.tokenizer.inForeignNode = !isHTML && !this._isIntegrationPoint(tid, current);
    }
    _switchToTextParsing(currentToken, nextTokenizerState) {
      this._insertElement(currentToken, NS.HTML);
      this.tokenizer.state = nextTokenizerState;
      this.originalInsertionMode = this.insertionMode;
      this.insertionMode = InsertionMode.TEXT;
    }
    switchToPlaintextParsing() {
      this.insertionMode = InsertionMode.TEXT;
      this.originalInsertionMode = InsertionMode.IN_BODY;
      this.tokenizer.state = TokenizerMode.PLAINTEXT;
    }
    //Fragment parsing
    _getAdjustedCurrentElement() {
      return this.openElements.stackTop === 0 && this.fragmentContext ? this.fragmentContext : this.openElements.current;
    }
    _findFormInFragmentContext() {
      let node = this.fragmentContext;
      while (node) {
        if (this.treeAdapter.getTagName(node) === TAG_NAMES.FORM) {
          this.formElement = node;
          break;
        }
        node = this.treeAdapter.getParentNode(node);
      }
    }
    _initTokenizerForFragmentParsing() {
      if (!this.fragmentContext || this.treeAdapter.getNamespaceURI(this.fragmentContext) !== NS.HTML) {
        return;
      }
      switch (this.fragmentContextID) {
        case TAG_ID.TITLE:
        case TAG_ID.TEXTAREA: {
          this.tokenizer.state = TokenizerMode.RCDATA;
          break;
        }
        case TAG_ID.STYLE:
        case TAG_ID.XMP:
        case TAG_ID.IFRAME:
        case TAG_ID.NOEMBED:
        case TAG_ID.NOFRAMES:
        case TAG_ID.NOSCRIPT: {
          this.tokenizer.state = TokenizerMode.RAWTEXT;
          break;
        }
        case TAG_ID.SCRIPT: {
          this.tokenizer.state = TokenizerMode.SCRIPT_DATA;
          break;
        }
        case TAG_ID.PLAINTEXT: {
          this.tokenizer.state = TokenizerMode.PLAINTEXT;
          break;
        }
        default:
      }
    }
    //Tree mutation
    _setDocumentType(token) {
      const name = token.name || "";
      const publicId = token.publicId || "";
      const systemId = token.systemId || "";
      this.treeAdapter.setDocumentType(this.document, name, publicId, systemId);
      if (token.location) {
        const documentChildren = this.treeAdapter.getChildNodes(this.document);
        const docTypeNode = documentChildren.find((node) => this.treeAdapter.isDocumentTypeNode(node));
        if (docTypeNode) {
          this.treeAdapter.setNodeSourceCodeLocation(docTypeNode, token.location);
        }
      }
    }
    _attachElementToTree(element, location) {
      if (this.options.sourceCodeLocationInfo) {
        const loc = location && {
          ...location,
          startTag: location
        };
        this.treeAdapter.setNodeSourceCodeLocation(element, loc);
      }
      if (this._shouldFosterParentOnInsertion()) {
        this._fosterParentElement(element);
      } else {
        const parent2 = this.openElements.currentTmplContentOrNode;
        this.treeAdapter.appendChild(parent2, element);
      }
    }
    _appendElement(token, namespaceURI) {
      const element = this.treeAdapter.createElement(token.tagName, namespaceURI, token.attrs);
      this._attachElementToTree(element, token.location);
    }
    _insertElement(token, namespaceURI) {
      const element = this.treeAdapter.createElement(token.tagName, namespaceURI, token.attrs);
      this._attachElementToTree(element, token.location);
      this.openElements.push(element, token.tagID);
    }
    _insertFakeElement(tagName18, tagID) {
      const element = this.treeAdapter.createElement(tagName18, NS.HTML, []);
      this._attachElementToTree(element, null);
      this.openElements.push(element, tagID);
    }
    _insertTemplate(token) {
      const tmpl = this.treeAdapter.createElement(token.tagName, NS.HTML, token.attrs);
      const content = this.treeAdapter.createDocumentFragment();
      this.treeAdapter.setTemplateContent(tmpl, content);
      this._attachElementToTree(tmpl, token.location);
      this.openElements.push(tmpl, token.tagID);
      if (this.options.sourceCodeLocationInfo)
        this.treeAdapter.setNodeSourceCodeLocation(content, null);
    }
    _insertFakeRootElement() {
      const element = this.treeAdapter.createElement(TAG_NAMES.HTML, NS.HTML, []);
      if (this.options.sourceCodeLocationInfo)
        this.treeAdapter.setNodeSourceCodeLocation(element, null);
      this.treeAdapter.appendChild(this.openElements.current, element);
      this.openElements.push(element, TAG_ID.HTML);
    }
    _appendCommentNode(token, parent2) {
      const commentNode = this.treeAdapter.createCommentNode(token.data);
      this.treeAdapter.appendChild(parent2, commentNode);
      if (this.options.sourceCodeLocationInfo) {
        this.treeAdapter.setNodeSourceCodeLocation(commentNode, token.location);
      }
    }
    _insertCharacters(token) {
      let parent2;
      let beforeElement;
      if (this._shouldFosterParentOnInsertion()) {
        ({ parent: parent2, beforeElement } = this._findFosterParentingLocation());
        if (beforeElement) {
          this.treeAdapter.insertTextBefore(parent2, token.chars, beforeElement);
        } else {
          this.treeAdapter.insertText(parent2, token.chars);
        }
      } else {
        parent2 = this.openElements.currentTmplContentOrNode;
        this.treeAdapter.insertText(parent2, token.chars);
      }
      if (!token.location)
        return;
      const siblings2 = this.treeAdapter.getChildNodes(parent2);
      const textNodeIdx = beforeElement ? siblings2.lastIndexOf(beforeElement) : siblings2.length;
      const textNode = siblings2[textNodeIdx - 1];
      const tnLoc = this.treeAdapter.getNodeSourceCodeLocation(textNode);
      if (tnLoc) {
        const { endLine, endCol, endOffset } = token.location;
        this.treeAdapter.updateNodeSourceCodeLocation(textNode, { endLine, endCol, endOffset });
      } else if (this.options.sourceCodeLocationInfo) {
        this.treeAdapter.setNodeSourceCodeLocation(textNode, token.location);
      }
    }
    _adoptNodes(donor, recipient) {
      for (let child = this.treeAdapter.getFirstChild(donor); child; child = this.treeAdapter.getFirstChild(donor)) {
        this.treeAdapter.detachNode(child);
        this.treeAdapter.appendChild(recipient, child);
      }
    }
    _setEndLocation(element, closingToken) {
      if (this.treeAdapter.getNodeSourceCodeLocation(element) && closingToken.location) {
        const ctLoc = closingToken.location;
        const tn = this.treeAdapter.getTagName(element);
        const endLoc = (
          // NOTE: For cases like <p> <p> </p> - First 'p' closes without a closing
          // tag and for cases like <td> <p> </td> - 'p' closes without a closing tag.
          closingToken.type === TokenType.END_TAG && tn === closingToken.tagName ? {
            endTag: { ...ctLoc },
            endLine: ctLoc.endLine,
            endCol: ctLoc.endCol,
            endOffset: ctLoc.endOffset
          } : {
            endLine: ctLoc.startLine,
            endCol: ctLoc.startCol,
            endOffset: ctLoc.startOffset
          }
        );
        this.treeAdapter.updateNodeSourceCodeLocation(element, endLoc);
      }
    }
    //Token processing
    shouldProcessStartTagTokenInForeignContent(token) {
      if (!this.currentNotInHTML)
        return false;
      let current;
      let currentTagId;
      if (this.openElements.stackTop === 0 && this.fragmentContext) {
        current = this.fragmentContext;
        currentTagId = this.fragmentContextID;
      } else {
        ({ current, currentTagId } = this.openElements);
      }
      if (token.tagID === TAG_ID.SVG && this.treeAdapter.getTagName(current) === TAG_NAMES.ANNOTATION_XML && this.treeAdapter.getNamespaceURI(current) === NS.MATHML) {
        return false;
      }
      return (
        // Check that `current` is not an integration point for HTML or MathML elements.
        this.tokenizer.inForeignNode || // If it _is_ an integration point, then we might have to check that it is not an HTML
        // integration point.
        (token.tagID === TAG_ID.MGLYPH || token.tagID === TAG_ID.MALIGNMARK) && !this._isIntegrationPoint(currentTagId, current, NS.HTML)
      );
    }
    _processToken(token) {
      switch (token.type) {
        case TokenType.CHARACTER: {
          this.onCharacter(token);
          break;
        }
        case TokenType.NULL_CHARACTER: {
          this.onNullCharacter(token);
          break;
        }
        case TokenType.COMMENT: {
          this.onComment(token);
          break;
        }
        case TokenType.DOCTYPE: {
          this.onDoctype(token);
          break;
        }
        case TokenType.START_TAG: {
          this._processStartTag(token);
          break;
        }
        case TokenType.END_TAG: {
          this.onEndTag(token);
          break;
        }
        case TokenType.EOF: {
          this.onEof(token);
          break;
        }
        case TokenType.WHITESPACE_CHARACTER: {
          this.onWhitespaceCharacter(token);
          break;
        }
      }
    }
    //Integration points
    _isIntegrationPoint(tid, element, foreignNS) {
      const ns = this.treeAdapter.getNamespaceURI(element);
      const attrs = this.treeAdapter.getAttrList(element);
      return isIntegrationPoint(tid, ns, attrs, foreignNS);
    }
    //Active formatting elements reconstruction
    _reconstructActiveFormattingElements() {
      const listLength = this.activeFormattingElements.entries.length;
      if (listLength) {
        const endIndex = this.activeFormattingElements.entries.findIndex((entry) => entry.type === EntryType.Marker || this.openElements.contains(entry.element));
        const unopenIdx = endIndex < 0 ? listLength - 1 : endIndex - 1;
        for (let i3 = unopenIdx; i3 >= 0; i3--) {
          const entry = this.activeFormattingElements.entries[i3];
          this._insertElement(entry.token, this.treeAdapter.getNamespaceURI(entry.element));
          entry.element = this.openElements.current;
        }
      }
    }
    //Close elements
    _closeTableCell() {
      this.openElements.generateImpliedEndTags();
      this.openElements.popUntilTableCellPopped();
      this.activeFormattingElements.clearToLastMarker();
      this.insertionMode = InsertionMode.IN_ROW;
    }
    _closePElement() {
      this.openElements.generateImpliedEndTagsWithExclusion(TAG_ID.P);
      this.openElements.popUntilTagNamePopped(TAG_ID.P);
    }
    //Insertion modes
    _resetInsertionMode() {
      for (let i3 = this.openElements.stackTop; i3 >= 0; i3--) {
        switch (i3 === 0 && this.fragmentContext ? this.fragmentContextID : this.openElements.tagIDs[i3]) {
          case TAG_ID.TR: {
            this.insertionMode = InsertionMode.IN_ROW;
            return;
          }
          case TAG_ID.TBODY:
          case TAG_ID.THEAD:
          case TAG_ID.TFOOT: {
            this.insertionMode = InsertionMode.IN_TABLE_BODY;
            return;
          }
          case TAG_ID.CAPTION: {
            this.insertionMode = InsertionMode.IN_CAPTION;
            return;
          }
          case TAG_ID.COLGROUP: {
            this.insertionMode = InsertionMode.IN_COLUMN_GROUP;
            return;
          }
          case TAG_ID.TABLE: {
            this.insertionMode = InsertionMode.IN_TABLE;
            return;
          }
          case TAG_ID.BODY: {
            this.insertionMode = InsertionMode.IN_BODY;
            return;
          }
          case TAG_ID.FRAMESET: {
            this.insertionMode = InsertionMode.IN_FRAMESET;
            return;
          }
          case TAG_ID.SELECT: {
            this._resetInsertionModeForSelect(i3);
            return;
          }
          case TAG_ID.TEMPLATE: {
            this.insertionMode = this.tmplInsertionModeStack[0];
            return;
          }
          case TAG_ID.HTML: {
            this.insertionMode = this.headElement ? InsertionMode.AFTER_HEAD : InsertionMode.BEFORE_HEAD;
            return;
          }
          case TAG_ID.TD:
          case TAG_ID.TH: {
            if (i3 > 0) {
              this.insertionMode = InsertionMode.IN_CELL;
              return;
            }
            break;
          }
          case TAG_ID.HEAD: {
            if (i3 > 0) {
              this.insertionMode = InsertionMode.IN_HEAD;
              return;
            }
            break;
          }
        }
      }
      this.insertionMode = InsertionMode.IN_BODY;
    }
    _resetInsertionModeForSelect(selectIdx) {
      if (selectIdx > 0) {
        for (let i3 = selectIdx - 1; i3 > 0; i3--) {
          const tn = this.openElements.tagIDs[i3];
          if (tn === TAG_ID.TEMPLATE) {
            break;
          } else if (tn === TAG_ID.TABLE) {
            this.insertionMode = InsertionMode.IN_SELECT_IN_TABLE;
            return;
          }
        }
      }
      this.insertionMode = InsertionMode.IN_SELECT;
    }
    //Foster parenting
    _isElementCausesFosterParenting(tn) {
      return TABLE_STRUCTURE_TAGS.has(tn);
    }
    _shouldFosterParentOnInsertion() {
      return this.fosterParentingEnabled && this._isElementCausesFosterParenting(this.openElements.currentTagId);
    }
    _findFosterParentingLocation() {
      for (let i3 = this.openElements.stackTop; i3 >= 0; i3--) {
        const openElement = this.openElements.items[i3];
        switch (this.openElements.tagIDs[i3]) {
          case TAG_ID.TEMPLATE: {
            if (this.treeAdapter.getNamespaceURI(openElement) === NS.HTML) {
              return { parent: this.treeAdapter.getTemplateContent(openElement), beforeElement: null };
            }
            break;
          }
          case TAG_ID.TABLE: {
            const parent2 = this.treeAdapter.getParentNode(openElement);
            if (parent2) {
              return { parent: parent2, beforeElement: openElement };
            }
            return { parent: this.openElements.items[i3 - 1], beforeElement: null };
          }
          default:
        }
      }
      return { parent: this.openElements.items[0], beforeElement: null };
    }
    _fosterParentElement(element) {
      const location = this._findFosterParentingLocation();
      if (location.beforeElement) {
        this.treeAdapter.insertBefore(location.parent, element, location.beforeElement);
      } else {
        this.treeAdapter.appendChild(location.parent, element);
      }
    }
    //Special elements
    _isSpecialElement(element, id) {
      const ns = this.treeAdapter.getNamespaceURI(element);
      return SPECIAL_ELEMENTS[ns].has(id);
    }
    onCharacter(token) {
      this.skipNextNewLine = false;
      if (this.tokenizer.inForeignNode) {
        characterInForeignContent(this, token);
        return;
      }
      switch (this.insertionMode) {
        case InsertionMode.INITIAL: {
          tokenInInitialMode(this, token);
          break;
        }
        case InsertionMode.BEFORE_HTML: {
          tokenBeforeHtml(this, token);
          break;
        }
        case InsertionMode.BEFORE_HEAD: {
          tokenBeforeHead(this, token);
          break;
        }
        case InsertionMode.IN_HEAD: {
          tokenInHead(this, token);
          break;
        }
        case InsertionMode.IN_HEAD_NO_SCRIPT: {
          tokenInHeadNoScript(this, token);
          break;
        }
        case InsertionMode.AFTER_HEAD: {
          tokenAfterHead(this, token);
          break;
        }
        case InsertionMode.IN_BODY:
        case InsertionMode.IN_CAPTION:
        case InsertionMode.IN_CELL:
        case InsertionMode.IN_TEMPLATE: {
          characterInBody(this, token);
          break;
        }
        case InsertionMode.TEXT:
        case InsertionMode.IN_SELECT:
        case InsertionMode.IN_SELECT_IN_TABLE: {
          this._insertCharacters(token);
          break;
        }
        case InsertionMode.IN_TABLE:
        case InsertionMode.IN_TABLE_BODY:
        case InsertionMode.IN_ROW: {
          characterInTable(this, token);
          break;
        }
        case InsertionMode.IN_TABLE_TEXT: {
          characterInTableText(this, token);
          break;
        }
        case InsertionMode.IN_COLUMN_GROUP: {
          tokenInColumnGroup(this, token);
          break;
        }
        case InsertionMode.AFTER_BODY: {
          tokenAfterBody(this, token);
          break;
        }
        case InsertionMode.AFTER_AFTER_BODY: {
          tokenAfterAfterBody(this, token);
          break;
        }
        default:
      }
    }
    onNullCharacter(token) {
      this.skipNextNewLine = false;
      if (this.tokenizer.inForeignNode) {
        nullCharacterInForeignContent(this, token);
        return;
      }
      switch (this.insertionMode) {
        case InsertionMode.INITIAL: {
          tokenInInitialMode(this, token);
          break;
        }
        case InsertionMode.BEFORE_HTML: {
          tokenBeforeHtml(this, token);
          break;
        }
        case InsertionMode.BEFORE_HEAD: {
          tokenBeforeHead(this, token);
          break;
        }
        case InsertionMode.IN_HEAD: {
          tokenInHead(this, token);
          break;
        }
        case InsertionMode.IN_HEAD_NO_SCRIPT: {
          tokenInHeadNoScript(this, token);
          break;
        }
        case InsertionMode.AFTER_HEAD: {
          tokenAfterHead(this, token);
          break;
        }
        case InsertionMode.TEXT: {
          this._insertCharacters(token);
          break;
        }
        case InsertionMode.IN_TABLE:
        case InsertionMode.IN_TABLE_BODY:
        case InsertionMode.IN_ROW: {
          characterInTable(this, token);
          break;
        }
        case InsertionMode.IN_COLUMN_GROUP: {
          tokenInColumnGroup(this, token);
          break;
        }
        case InsertionMode.AFTER_BODY: {
          tokenAfterBody(this, token);
          break;
        }
        case InsertionMode.AFTER_AFTER_BODY: {
          tokenAfterAfterBody(this, token);
          break;
        }
        default:
      }
    }
    onComment(token) {
      this.skipNextNewLine = false;
      if (this.currentNotInHTML) {
        appendComment(this, token);
        return;
      }
      switch (this.insertionMode) {
        case InsertionMode.INITIAL:
        case InsertionMode.BEFORE_HTML:
        case InsertionMode.BEFORE_HEAD:
        case InsertionMode.IN_HEAD:
        case InsertionMode.IN_HEAD_NO_SCRIPT:
        case InsertionMode.AFTER_HEAD:
        case InsertionMode.IN_BODY:
        case InsertionMode.IN_TABLE:
        case InsertionMode.IN_CAPTION:
        case InsertionMode.IN_COLUMN_GROUP:
        case InsertionMode.IN_TABLE_BODY:
        case InsertionMode.IN_ROW:
        case InsertionMode.IN_CELL:
        case InsertionMode.IN_SELECT:
        case InsertionMode.IN_SELECT_IN_TABLE:
        case InsertionMode.IN_TEMPLATE:
        case InsertionMode.IN_FRAMESET:
        case InsertionMode.AFTER_FRAMESET: {
          appendComment(this, token);
          break;
        }
        case InsertionMode.IN_TABLE_TEXT: {
          tokenInTableText(this, token);
          break;
        }
        case InsertionMode.AFTER_BODY: {
          appendCommentToRootHtmlElement(this, token);
          break;
        }
        case InsertionMode.AFTER_AFTER_BODY:
        case InsertionMode.AFTER_AFTER_FRAMESET: {
          appendCommentToDocument(this, token);
          break;
        }
        default:
      }
    }
    onDoctype(token) {
      this.skipNextNewLine = false;
      switch (this.insertionMode) {
        case InsertionMode.INITIAL: {
          doctypeInInitialMode(this, token);
          break;
        }
        case InsertionMode.BEFORE_HEAD:
        case InsertionMode.IN_HEAD:
        case InsertionMode.IN_HEAD_NO_SCRIPT:
        case InsertionMode.AFTER_HEAD: {
          this._err(token, ERR.misplacedDoctype);
          break;
        }
        case InsertionMode.IN_TABLE_TEXT: {
          tokenInTableText(this, token);
          break;
        }
        default:
      }
    }
    onStartTag(token) {
      this.skipNextNewLine = false;
      this.currentToken = token;
      this._processStartTag(token);
      if (token.selfClosing && !token.ackSelfClosing) {
        this._err(token, ERR.nonVoidHtmlElementStartTagWithTrailingSolidus);
      }
    }
    /**
     * Processes a given start tag.
     *
     * `onStartTag` checks if a self-closing tag was recognized. When a token
     * is moved inbetween multiple insertion modes, this check for self-closing
     * could lead to false positives. To avoid this, `_processStartTag` is used
     * for nested calls.
     *
     * @param token The token to process.
     */
    _processStartTag(token) {
      if (this.shouldProcessStartTagTokenInForeignContent(token)) {
        startTagInForeignContent(this, token);
      } else {
        this._startTagOutsideForeignContent(token);
      }
    }
    _startTagOutsideForeignContent(token) {
      switch (this.insertionMode) {
        case InsertionMode.INITIAL: {
          tokenInInitialMode(this, token);
          break;
        }
        case InsertionMode.BEFORE_HTML: {
          startTagBeforeHtml(this, token);
          break;
        }
        case InsertionMode.BEFORE_HEAD: {
          startTagBeforeHead(this, token);
          break;
        }
        case InsertionMode.IN_HEAD: {
          startTagInHead(this, token);
          break;
        }
        case InsertionMode.IN_HEAD_NO_SCRIPT: {
          startTagInHeadNoScript(this, token);
          break;
        }
        case InsertionMode.AFTER_HEAD: {
          startTagAfterHead(this, token);
          break;
        }
        case InsertionMode.IN_BODY: {
          startTagInBody(this, token);
          break;
        }
        case InsertionMode.IN_TABLE: {
          startTagInTable(this, token);
          break;
        }
        case InsertionMode.IN_TABLE_TEXT: {
          tokenInTableText(this, token);
          break;
        }
        case InsertionMode.IN_CAPTION: {
          startTagInCaption(this, token);
          break;
        }
        case InsertionMode.IN_COLUMN_GROUP: {
          startTagInColumnGroup(this, token);
          break;
        }
        case InsertionMode.IN_TABLE_BODY: {
          startTagInTableBody(this, token);
          break;
        }
        case InsertionMode.IN_ROW: {
          startTagInRow(this, token);
          break;
        }
        case InsertionMode.IN_CELL: {
          startTagInCell(this, token);
          break;
        }
        case InsertionMode.IN_SELECT: {
          startTagInSelect(this, token);
          break;
        }
        case InsertionMode.IN_SELECT_IN_TABLE: {
          startTagInSelectInTable(this, token);
          break;
        }
        case InsertionMode.IN_TEMPLATE: {
          startTagInTemplate(this, token);
          break;
        }
        case InsertionMode.AFTER_BODY: {
          startTagAfterBody(this, token);
          break;
        }
        case InsertionMode.IN_FRAMESET: {
          startTagInFrameset(this, token);
          break;
        }
        case InsertionMode.AFTER_FRAMESET: {
          startTagAfterFrameset(this, token);
          break;
        }
        case InsertionMode.AFTER_AFTER_BODY: {
          startTagAfterAfterBody(this, token);
          break;
        }
        case InsertionMode.AFTER_AFTER_FRAMESET: {
          startTagAfterAfterFrameset(this, token);
          break;
        }
        default:
      }
    }
    onEndTag(token) {
      this.skipNextNewLine = false;
      this.currentToken = token;
      if (this.currentNotInHTML) {
        endTagInForeignContent(this, token);
      } else {
        this._endTagOutsideForeignContent(token);
      }
    }
    _endTagOutsideForeignContent(token) {
      switch (this.insertionMode) {
        case InsertionMode.INITIAL: {
          tokenInInitialMode(this, token);
          break;
        }
        case InsertionMode.BEFORE_HTML: {
          endTagBeforeHtml(this, token);
          break;
        }
        case InsertionMode.BEFORE_HEAD: {
          endTagBeforeHead(this, token);
          break;
        }
        case InsertionMode.IN_HEAD: {
          endTagInHead(this, token);
          break;
        }
        case InsertionMode.IN_HEAD_NO_SCRIPT: {
          endTagInHeadNoScript(this, token);
          break;
        }
        case InsertionMode.AFTER_HEAD: {
          endTagAfterHead(this, token);
          break;
        }
        case InsertionMode.IN_BODY: {
          endTagInBody(this, token);
          break;
        }
        case InsertionMode.TEXT: {
          endTagInText(this, token);
          break;
        }
        case InsertionMode.IN_TABLE: {
          endTagInTable(this, token);
          break;
        }
        case InsertionMode.IN_TABLE_TEXT: {
          tokenInTableText(this, token);
          break;
        }
        case InsertionMode.IN_CAPTION: {
          endTagInCaption(this, token);
          break;
        }
        case InsertionMode.IN_COLUMN_GROUP: {
          endTagInColumnGroup(this, token);
          break;
        }
        case InsertionMode.IN_TABLE_BODY: {
          endTagInTableBody(this, token);
          break;
        }
        case InsertionMode.IN_ROW: {
          endTagInRow(this, token);
          break;
        }
        case InsertionMode.IN_CELL: {
          endTagInCell(this, token);
          break;
        }
        case InsertionMode.IN_SELECT: {
          endTagInSelect(this, token);
          break;
        }
        case InsertionMode.IN_SELECT_IN_TABLE: {
          endTagInSelectInTable(this, token);
          break;
        }
        case InsertionMode.IN_TEMPLATE: {
          endTagInTemplate(this, token);
          break;
        }
        case InsertionMode.AFTER_BODY: {
          endTagAfterBody(this, token);
          break;
        }
        case InsertionMode.IN_FRAMESET: {
          endTagInFrameset(this, token);
          break;
        }
        case InsertionMode.AFTER_FRAMESET: {
          endTagAfterFrameset(this, token);
          break;
        }
        case InsertionMode.AFTER_AFTER_BODY: {
          tokenAfterAfterBody(this, token);
          break;
        }
        default:
      }
    }
    onEof(token) {
      switch (this.insertionMode) {
        case InsertionMode.INITIAL: {
          tokenInInitialMode(this, token);
          break;
        }
        case InsertionMode.BEFORE_HTML: {
          tokenBeforeHtml(this, token);
          break;
        }
        case InsertionMode.BEFORE_HEAD: {
          tokenBeforeHead(this, token);
          break;
        }
        case InsertionMode.IN_HEAD: {
          tokenInHead(this, token);
          break;
        }
        case InsertionMode.IN_HEAD_NO_SCRIPT: {
          tokenInHeadNoScript(this, token);
          break;
        }
        case InsertionMode.AFTER_HEAD: {
          tokenAfterHead(this, token);
          break;
        }
        case InsertionMode.IN_BODY:
        case InsertionMode.IN_TABLE:
        case InsertionMode.IN_CAPTION:
        case InsertionMode.IN_COLUMN_GROUP:
        case InsertionMode.IN_TABLE_BODY:
        case InsertionMode.IN_ROW:
        case InsertionMode.IN_CELL:
        case InsertionMode.IN_SELECT:
        case InsertionMode.IN_SELECT_IN_TABLE: {
          eofInBody(this, token);
          break;
        }
        case InsertionMode.TEXT: {
          eofInText(this, token);
          break;
        }
        case InsertionMode.IN_TABLE_TEXT: {
          tokenInTableText(this, token);
          break;
        }
        case InsertionMode.IN_TEMPLATE: {
          eofInTemplate(this, token);
          break;
        }
        case InsertionMode.AFTER_BODY:
        case InsertionMode.IN_FRAMESET:
        case InsertionMode.AFTER_FRAMESET:
        case InsertionMode.AFTER_AFTER_BODY:
        case InsertionMode.AFTER_AFTER_FRAMESET: {
          stopParsing(this, token);
          break;
        }
        default:
      }
    }
    onWhitespaceCharacter(token) {
      if (this.skipNextNewLine) {
        this.skipNextNewLine = false;
        if (token.chars.charCodeAt(0) === CODE_POINTS.LINE_FEED) {
          if (token.chars.length === 1) {
            return;
          }
          token.chars = token.chars.substr(1);
        }
      }
      if (this.tokenizer.inForeignNode) {
        this._insertCharacters(token);
        return;
      }
      switch (this.insertionMode) {
        case InsertionMode.IN_HEAD:
        case InsertionMode.IN_HEAD_NO_SCRIPT:
        case InsertionMode.AFTER_HEAD:
        case InsertionMode.TEXT:
        case InsertionMode.IN_COLUMN_GROUP:
        case InsertionMode.IN_SELECT:
        case InsertionMode.IN_SELECT_IN_TABLE:
        case InsertionMode.IN_FRAMESET:
        case InsertionMode.AFTER_FRAMESET: {
          this._insertCharacters(token);
          break;
        }
        case InsertionMode.IN_BODY:
        case InsertionMode.IN_CAPTION:
        case InsertionMode.IN_CELL:
        case InsertionMode.IN_TEMPLATE:
        case InsertionMode.AFTER_BODY:
        case InsertionMode.AFTER_AFTER_BODY:
        case InsertionMode.AFTER_AFTER_FRAMESET: {
          whitespaceCharacterInBody(this, token);
          break;
        }
        case InsertionMode.IN_TABLE:
        case InsertionMode.IN_TABLE_BODY:
        case InsertionMode.IN_ROW: {
          characterInTable(this, token);
          break;
        }
        case InsertionMode.IN_TABLE_TEXT: {
          whitespaceCharacterInTableText(this, token);
          break;
        }
        default:
      }
    }
  };
  function aaObtainFormattingElementEntry(p3, token) {
    let formattingElementEntry = p3.activeFormattingElements.getElementEntryInScopeWithTagName(token.tagName);
    if (formattingElementEntry) {
      if (!p3.openElements.contains(formattingElementEntry.element)) {
        p3.activeFormattingElements.removeEntry(formattingElementEntry);
        formattingElementEntry = null;
      } else if (!p3.openElements.hasInScope(token.tagID)) {
        formattingElementEntry = null;
      }
    } else {
      genericEndTagInBody(p3, token);
    }
    return formattingElementEntry;
  }
  function aaObtainFurthestBlock(p3, formattingElementEntry) {
    let furthestBlock = null;
    let idx = p3.openElements.stackTop;
    for (; idx >= 0; idx--) {
      const element = p3.openElements.items[idx];
      if (element === formattingElementEntry.element) {
        break;
      }
      if (p3._isSpecialElement(element, p3.openElements.tagIDs[idx])) {
        furthestBlock = element;
      }
    }
    if (!furthestBlock) {
      p3.openElements.shortenToLength(idx < 0 ? 0 : idx);
      p3.activeFormattingElements.removeEntry(formattingElementEntry);
    }
    return furthestBlock;
  }
  function aaInnerLoop(p3, furthestBlock, formattingElement) {
    let lastElement = furthestBlock;
    let nextElement = p3.openElements.getCommonAncestor(furthestBlock);
    for (let i3 = 0, element = nextElement; element !== formattingElement; i3++, element = nextElement) {
      nextElement = p3.openElements.getCommonAncestor(element);
      const elementEntry = p3.activeFormattingElements.getElementEntry(element);
      const counterOverflow = elementEntry && i3 >= AA_INNER_LOOP_ITER;
      const shouldRemoveFromOpenElements = !elementEntry || counterOverflow;
      if (shouldRemoveFromOpenElements) {
        if (counterOverflow) {
          p3.activeFormattingElements.removeEntry(elementEntry);
        }
        p3.openElements.remove(element);
      } else {
        element = aaRecreateElementFromEntry(p3, elementEntry);
        if (lastElement === furthestBlock) {
          p3.activeFormattingElements.bookmark = elementEntry;
        }
        p3.treeAdapter.detachNode(lastElement);
        p3.treeAdapter.appendChild(element, lastElement);
        lastElement = element;
      }
    }
    return lastElement;
  }
  function aaRecreateElementFromEntry(p3, elementEntry) {
    const ns = p3.treeAdapter.getNamespaceURI(elementEntry.element);
    const newElement = p3.treeAdapter.createElement(elementEntry.token.tagName, ns, elementEntry.token.attrs);
    p3.openElements.replace(elementEntry.element, newElement);
    elementEntry.element = newElement;
    return newElement;
  }
  function aaInsertLastNodeInCommonAncestor(p3, commonAncestor, lastElement) {
    const tn = p3.treeAdapter.getTagName(commonAncestor);
    const tid = getTagID(tn);
    if (p3._isElementCausesFosterParenting(tid)) {
      p3._fosterParentElement(lastElement);
    } else {
      const ns = p3.treeAdapter.getNamespaceURI(commonAncestor);
      if (tid === TAG_ID.TEMPLATE && ns === NS.HTML) {
        commonAncestor = p3.treeAdapter.getTemplateContent(commonAncestor);
      }
      p3.treeAdapter.appendChild(commonAncestor, lastElement);
    }
  }
  function aaReplaceFormattingElement(p3, furthestBlock, formattingElementEntry) {
    const ns = p3.treeAdapter.getNamespaceURI(formattingElementEntry.element);
    const { token } = formattingElementEntry;
    const newElement = p3.treeAdapter.createElement(token.tagName, ns, token.attrs);
    p3._adoptNodes(furthestBlock, newElement);
    p3.treeAdapter.appendChild(furthestBlock, newElement);
    p3.activeFormattingElements.insertElementAfterBookmark(newElement, token);
    p3.activeFormattingElements.removeEntry(formattingElementEntry);
    p3.openElements.remove(formattingElementEntry.element);
    p3.openElements.insertAfter(furthestBlock, newElement, token.tagID);
  }
  function callAdoptionAgency(p3, token) {
    for (let i3 = 0; i3 < AA_OUTER_LOOP_ITER; i3++) {
      const formattingElementEntry = aaObtainFormattingElementEntry(p3, token);
      if (!formattingElementEntry) {
        break;
      }
      const furthestBlock = aaObtainFurthestBlock(p3, formattingElementEntry);
      if (!furthestBlock) {
        break;
      }
      p3.activeFormattingElements.bookmark = formattingElementEntry;
      const lastElement = aaInnerLoop(p3, furthestBlock, formattingElementEntry.element);
      const commonAncestor = p3.openElements.getCommonAncestor(formattingElementEntry.element);
      p3.treeAdapter.detachNode(lastElement);
      if (commonAncestor)
        aaInsertLastNodeInCommonAncestor(p3, commonAncestor, lastElement);
      aaReplaceFormattingElement(p3, furthestBlock, formattingElementEntry);
    }
  }
  function appendComment(p3, token) {
    p3._appendCommentNode(token, p3.openElements.currentTmplContentOrNode);
  }
  function appendCommentToRootHtmlElement(p3, token) {
    p3._appendCommentNode(token, p3.openElements.items[0]);
  }
  function appendCommentToDocument(p3, token) {
    p3._appendCommentNode(token, p3.document);
  }
  function stopParsing(p3, token) {
    p3.stopped = true;
    if (token.location) {
      const target = p3.fragmentContext ? 0 : 2;
      for (let i3 = p3.openElements.stackTop; i3 >= target; i3--) {
        p3._setEndLocation(p3.openElements.items[i3], token);
      }
      if (!p3.fragmentContext && p3.openElements.stackTop >= 0) {
        const htmlElement = p3.openElements.items[0];
        const htmlLocation = p3.treeAdapter.getNodeSourceCodeLocation(htmlElement);
        if (htmlLocation && !htmlLocation.endTag) {
          p3._setEndLocation(htmlElement, token);
          if (p3.openElements.stackTop >= 1) {
            const bodyElement = p3.openElements.items[1];
            const bodyLocation = p3.treeAdapter.getNodeSourceCodeLocation(bodyElement);
            if (bodyLocation && !bodyLocation.endTag) {
              p3._setEndLocation(bodyElement, token);
            }
          }
        }
      }
    }
  }
  function doctypeInInitialMode(p3, token) {
    p3._setDocumentType(token);
    const mode = token.forceQuirks ? DOCUMENT_MODE.QUIRKS : getDocumentMode(token);
    if (!isConforming(token)) {
      p3._err(token, ERR.nonConformingDoctype);
    }
    p3.treeAdapter.setDocumentMode(p3.document, mode);
    p3.insertionMode = InsertionMode.BEFORE_HTML;
  }
  function tokenInInitialMode(p3, token) {
    p3._err(token, ERR.missingDoctype, true);
    p3.treeAdapter.setDocumentMode(p3.document, DOCUMENT_MODE.QUIRKS);
    p3.insertionMode = InsertionMode.BEFORE_HTML;
    p3._processToken(token);
  }
  function startTagBeforeHtml(p3, token) {
    if (token.tagID === TAG_ID.HTML) {
      p3._insertElement(token, NS.HTML);
      p3.insertionMode = InsertionMode.BEFORE_HEAD;
    } else {
      tokenBeforeHtml(p3, token);
    }
  }
  function endTagBeforeHtml(p3, token) {
    const tn = token.tagID;
    if (tn === TAG_ID.HTML || tn === TAG_ID.HEAD || tn === TAG_ID.BODY || tn === TAG_ID.BR) {
      tokenBeforeHtml(p3, token);
    }
  }
  function tokenBeforeHtml(p3, token) {
    p3._insertFakeRootElement();
    p3.insertionMode = InsertionMode.BEFORE_HEAD;
    p3._processToken(token);
  }
  function startTagBeforeHead(p3, token) {
    switch (token.tagID) {
      case TAG_ID.HTML: {
        startTagInBody(p3, token);
        break;
      }
      case TAG_ID.HEAD: {
        p3._insertElement(token, NS.HTML);
        p3.headElement = p3.openElements.current;
        p3.insertionMode = InsertionMode.IN_HEAD;
        break;
      }
      default: {
        tokenBeforeHead(p3, token);
      }
    }
  }
  function endTagBeforeHead(p3, token) {
    const tn = token.tagID;
    if (tn === TAG_ID.HEAD || tn === TAG_ID.BODY || tn === TAG_ID.HTML || tn === TAG_ID.BR) {
      tokenBeforeHead(p3, token);
    } else {
      p3._err(token, ERR.endTagWithoutMatchingOpenElement);
    }
  }
  function tokenBeforeHead(p3, token) {
    p3._insertFakeElement(TAG_NAMES.HEAD, TAG_ID.HEAD);
    p3.headElement = p3.openElements.current;
    p3.insertionMode = InsertionMode.IN_HEAD;
    p3._processToken(token);
  }
  function startTagInHead(p3, token) {
    switch (token.tagID) {
      case TAG_ID.HTML: {
        startTagInBody(p3, token);
        break;
      }
      case TAG_ID.BASE:
      case TAG_ID.BASEFONT:
      case TAG_ID.BGSOUND:
      case TAG_ID.LINK:
      case TAG_ID.META: {
        p3._appendElement(token, NS.HTML);
        token.ackSelfClosing = true;
        break;
      }
      case TAG_ID.TITLE: {
        p3._switchToTextParsing(token, TokenizerMode.RCDATA);
        break;
      }
      case TAG_ID.NOSCRIPT: {
        if (p3.options.scriptingEnabled) {
          p3._switchToTextParsing(token, TokenizerMode.RAWTEXT);
        } else {
          p3._insertElement(token, NS.HTML);
          p3.insertionMode = InsertionMode.IN_HEAD_NO_SCRIPT;
        }
        break;
      }
      case TAG_ID.NOFRAMES:
      case TAG_ID.STYLE: {
        p3._switchToTextParsing(token, TokenizerMode.RAWTEXT);
        break;
      }
      case TAG_ID.SCRIPT: {
        p3._switchToTextParsing(token, TokenizerMode.SCRIPT_DATA);
        break;
      }
      case TAG_ID.TEMPLATE: {
        p3._insertTemplate(token);
        p3.activeFormattingElements.insertMarker();
        p3.framesetOk = false;
        p3.insertionMode = InsertionMode.IN_TEMPLATE;
        p3.tmplInsertionModeStack.unshift(InsertionMode.IN_TEMPLATE);
        break;
      }
      case TAG_ID.HEAD: {
        p3._err(token, ERR.misplacedStartTagForHeadElement);
        break;
      }
      default: {
        tokenInHead(p3, token);
      }
    }
  }
  function endTagInHead(p3, token) {
    switch (token.tagID) {
      case TAG_ID.HEAD: {
        p3.openElements.pop();
        p3.insertionMode = InsertionMode.AFTER_HEAD;
        break;
      }
      case TAG_ID.BODY:
      case TAG_ID.BR:
      case TAG_ID.HTML: {
        tokenInHead(p3, token);
        break;
      }
      case TAG_ID.TEMPLATE: {
        templateEndTagInHead(p3, token);
        break;
      }
      default: {
        p3._err(token, ERR.endTagWithoutMatchingOpenElement);
      }
    }
  }
  function templateEndTagInHead(p3, token) {
    if (p3.openElements.tmplCount > 0) {
      p3.openElements.generateImpliedEndTagsThoroughly();
      if (p3.openElements.currentTagId !== TAG_ID.TEMPLATE) {
        p3._err(token, ERR.closingOfElementWithOpenChildElements);
      }
      p3.openElements.popUntilTagNamePopped(TAG_ID.TEMPLATE);
      p3.activeFormattingElements.clearToLastMarker();
      p3.tmplInsertionModeStack.shift();
      p3._resetInsertionMode();
    } else {
      p3._err(token, ERR.endTagWithoutMatchingOpenElement);
    }
  }
  function tokenInHead(p3, token) {
    p3.openElements.pop();
    p3.insertionMode = InsertionMode.AFTER_HEAD;
    p3._processToken(token);
  }
  function startTagInHeadNoScript(p3, token) {
    switch (token.tagID) {
      case TAG_ID.HTML: {
        startTagInBody(p3, token);
        break;
      }
      case TAG_ID.BASEFONT:
      case TAG_ID.BGSOUND:
      case TAG_ID.HEAD:
      case TAG_ID.LINK:
      case TAG_ID.META:
      case TAG_ID.NOFRAMES:
      case TAG_ID.STYLE: {
        startTagInHead(p3, token);
        break;
      }
      case TAG_ID.NOSCRIPT: {
        p3._err(token, ERR.nestedNoscriptInHead);
        break;
      }
      default: {
        tokenInHeadNoScript(p3, token);
      }
    }
  }
  function endTagInHeadNoScript(p3, token) {
    switch (token.tagID) {
      case TAG_ID.NOSCRIPT: {
        p3.openElements.pop();
        p3.insertionMode = InsertionMode.IN_HEAD;
        break;
      }
      case TAG_ID.BR: {
        tokenInHeadNoScript(p3, token);
        break;
      }
      default: {
        p3._err(token, ERR.endTagWithoutMatchingOpenElement);
      }
    }
  }
  function tokenInHeadNoScript(p3, token) {
    const errCode = token.type === TokenType.EOF ? ERR.openElementsLeftAfterEof : ERR.disallowedContentInNoscriptInHead;
    p3._err(token, errCode);
    p3.openElements.pop();
    p3.insertionMode = InsertionMode.IN_HEAD;
    p3._processToken(token);
  }
  function startTagAfterHead(p3, token) {
    switch (token.tagID) {
      case TAG_ID.HTML: {
        startTagInBody(p3, token);
        break;
      }
      case TAG_ID.BODY: {
        p3._insertElement(token, NS.HTML);
        p3.framesetOk = false;
        p3.insertionMode = InsertionMode.IN_BODY;
        break;
      }
      case TAG_ID.FRAMESET: {
        p3._insertElement(token, NS.HTML);
        p3.insertionMode = InsertionMode.IN_FRAMESET;
        break;
      }
      case TAG_ID.BASE:
      case TAG_ID.BASEFONT:
      case TAG_ID.BGSOUND:
      case TAG_ID.LINK:
      case TAG_ID.META:
      case TAG_ID.NOFRAMES:
      case TAG_ID.SCRIPT:
      case TAG_ID.STYLE:
      case TAG_ID.TEMPLATE:
      case TAG_ID.TITLE: {
        p3._err(token, ERR.abandonedHeadElementChild);
        p3.openElements.push(p3.headElement, TAG_ID.HEAD);
        startTagInHead(p3, token);
        p3.openElements.remove(p3.headElement);
        break;
      }
      case TAG_ID.HEAD: {
        p3._err(token, ERR.misplacedStartTagForHeadElement);
        break;
      }
      default: {
        tokenAfterHead(p3, token);
      }
    }
  }
  function endTagAfterHead(p3, token) {
    switch (token.tagID) {
      case TAG_ID.BODY:
      case TAG_ID.HTML:
      case TAG_ID.BR: {
        tokenAfterHead(p3, token);
        break;
      }
      case TAG_ID.TEMPLATE: {
        templateEndTagInHead(p3, token);
        break;
      }
      default: {
        p3._err(token, ERR.endTagWithoutMatchingOpenElement);
      }
    }
  }
  function tokenAfterHead(p3, token) {
    p3._insertFakeElement(TAG_NAMES.BODY, TAG_ID.BODY);
    p3.insertionMode = InsertionMode.IN_BODY;
    modeInBody(p3, token);
  }
  function modeInBody(p3, token) {
    switch (token.type) {
      case TokenType.CHARACTER: {
        characterInBody(p3, token);
        break;
      }
      case TokenType.WHITESPACE_CHARACTER: {
        whitespaceCharacterInBody(p3, token);
        break;
      }
      case TokenType.COMMENT: {
        appendComment(p3, token);
        break;
      }
      case TokenType.START_TAG: {
        startTagInBody(p3, token);
        break;
      }
      case TokenType.END_TAG: {
        endTagInBody(p3, token);
        break;
      }
      case TokenType.EOF: {
        eofInBody(p3, token);
        break;
      }
      default:
    }
  }
  function whitespaceCharacterInBody(p3, token) {
    p3._reconstructActiveFormattingElements();
    p3._insertCharacters(token);
  }
  function characterInBody(p3, token) {
    p3._reconstructActiveFormattingElements();
    p3._insertCharacters(token);
    p3.framesetOk = false;
  }
  function htmlStartTagInBody(p3, token) {
    if (p3.openElements.tmplCount === 0) {
      p3.treeAdapter.adoptAttributes(p3.openElements.items[0], token.attrs);
    }
  }
  function bodyStartTagInBody(p3, token) {
    const bodyElement = p3.openElements.tryPeekProperlyNestedBodyElement();
    if (bodyElement && p3.openElements.tmplCount === 0) {
      p3.framesetOk = false;
      p3.treeAdapter.adoptAttributes(bodyElement, token.attrs);
    }
  }
  function framesetStartTagInBody(p3, token) {
    const bodyElement = p3.openElements.tryPeekProperlyNestedBodyElement();
    if (p3.framesetOk && bodyElement) {
      p3.treeAdapter.detachNode(bodyElement);
      p3.openElements.popAllUpToHtmlElement();
      p3._insertElement(token, NS.HTML);
      p3.insertionMode = InsertionMode.IN_FRAMESET;
    }
  }
  function addressStartTagInBody(p3, token) {
    if (p3.openElements.hasInButtonScope(TAG_ID.P)) {
      p3._closePElement();
    }
    p3._insertElement(token, NS.HTML);
  }
  function numberedHeaderStartTagInBody(p3, token) {
    if (p3.openElements.hasInButtonScope(TAG_ID.P)) {
      p3._closePElement();
    }
    if (isNumberedHeader(p3.openElements.currentTagId)) {
      p3.openElements.pop();
    }
    p3._insertElement(token, NS.HTML);
  }
  function preStartTagInBody(p3, token) {
    if (p3.openElements.hasInButtonScope(TAG_ID.P)) {
      p3._closePElement();
    }
    p3._insertElement(token, NS.HTML);
    p3.skipNextNewLine = true;
    p3.framesetOk = false;
  }
  function formStartTagInBody(p3, token) {
    const inTemplate = p3.openElements.tmplCount > 0;
    if (!p3.formElement || inTemplate) {
      if (p3.openElements.hasInButtonScope(TAG_ID.P)) {
        p3._closePElement();
      }
      p3._insertElement(token, NS.HTML);
      if (!inTemplate) {
        p3.formElement = p3.openElements.current;
      }
    }
  }
  function listItemStartTagInBody(p3, token) {
    p3.framesetOk = false;
    const tn = token.tagID;
    for (let i3 = p3.openElements.stackTop; i3 >= 0; i3--) {
      const elementId = p3.openElements.tagIDs[i3];
      if (tn === TAG_ID.LI && elementId === TAG_ID.LI || (tn === TAG_ID.DD || tn === TAG_ID.DT) && (elementId === TAG_ID.DD || elementId === TAG_ID.DT)) {
        p3.openElements.generateImpliedEndTagsWithExclusion(elementId);
        p3.openElements.popUntilTagNamePopped(elementId);
        break;
      }
      if (elementId !== TAG_ID.ADDRESS && elementId !== TAG_ID.DIV && elementId !== TAG_ID.P && p3._isSpecialElement(p3.openElements.items[i3], elementId)) {
        break;
      }
    }
    if (p3.openElements.hasInButtonScope(TAG_ID.P)) {
      p3._closePElement();
    }
    p3._insertElement(token, NS.HTML);
  }
  function plaintextStartTagInBody(p3, token) {
    if (p3.openElements.hasInButtonScope(TAG_ID.P)) {
      p3._closePElement();
    }
    p3._insertElement(token, NS.HTML);
    p3.tokenizer.state = TokenizerMode.PLAINTEXT;
  }
  function buttonStartTagInBody(p3, token) {
    if (p3.openElements.hasInScope(TAG_ID.BUTTON)) {
      p3.openElements.generateImpliedEndTags();
      p3.openElements.popUntilTagNamePopped(TAG_ID.BUTTON);
    }
    p3._reconstructActiveFormattingElements();
    p3._insertElement(token, NS.HTML);
    p3.framesetOk = false;
  }
  function aStartTagInBody(p3, token) {
    const activeElementEntry = p3.activeFormattingElements.getElementEntryInScopeWithTagName(TAG_NAMES.A);
    if (activeElementEntry) {
      callAdoptionAgency(p3, token);
      p3.openElements.remove(activeElementEntry.element);
      p3.activeFormattingElements.removeEntry(activeElementEntry);
    }
    p3._reconstructActiveFormattingElements();
    p3._insertElement(token, NS.HTML);
    p3.activeFormattingElements.pushElement(p3.openElements.current, token);
  }
  function bStartTagInBody(p3, token) {
    p3._reconstructActiveFormattingElements();
    p3._insertElement(token, NS.HTML);
    p3.activeFormattingElements.pushElement(p3.openElements.current, token);
  }
  function nobrStartTagInBody(p3, token) {
    p3._reconstructActiveFormattingElements();
    if (p3.openElements.hasInScope(TAG_ID.NOBR)) {
      callAdoptionAgency(p3, token);
      p3._reconstructActiveFormattingElements();
    }
    p3._insertElement(token, NS.HTML);
    p3.activeFormattingElements.pushElement(p3.openElements.current, token);
  }
  function appletStartTagInBody(p3, token) {
    p3._reconstructActiveFormattingElements();
    p3._insertElement(token, NS.HTML);
    p3.activeFormattingElements.insertMarker();
    p3.framesetOk = false;
  }
  function tableStartTagInBody(p3, token) {
    if (p3.treeAdapter.getDocumentMode(p3.document) !== DOCUMENT_MODE.QUIRKS && p3.openElements.hasInButtonScope(TAG_ID.P)) {
      p3._closePElement();
    }
    p3._insertElement(token, NS.HTML);
    p3.framesetOk = false;
    p3.insertionMode = InsertionMode.IN_TABLE;
  }
  function areaStartTagInBody(p3, token) {
    p3._reconstructActiveFormattingElements();
    p3._appendElement(token, NS.HTML);
    p3.framesetOk = false;
    token.ackSelfClosing = true;
  }
  function isHiddenInput(token) {
    const inputType = getTokenAttr(token, ATTRS.TYPE);
    return inputType != null && inputType.toLowerCase() === HIDDEN_INPUT_TYPE;
  }
  function inputStartTagInBody(p3, token) {
    p3._reconstructActiveFormattingElements();
    p3._appendElement(token, NS.HTML);
    if (!isHiddenInput(token)) {
      p3.framesetOk = false;
    }
    token.ackSelfClosing = true;
  }
  function paramStartTagInBody(p3, token) {
    p3._appendElement(token, NS.HTML);
    token.ackSelfClosing = true;
  }
  function hrStartTagInBody(p3, token) {
    if (p3.openElements.hasInButtonScope(TAG_ID.P)) {
      p3._closePElement();
    }
    p3._appendElement(token, NS.HTML);
    p3.framesetOk = false;
    token.ackSelfClosing = true;
  }
  function imageStartTagInBody(p3, token) {
    token.tagName = TAG_NAMES.IMG;
    token.tagID = TAG_ID.IMG;
    areaStartTagInBody(p3, token);
  }
  function textareaStartTagInBody(p3, token) {
    p3._insertElement(token, NS.HTML);
    p3.skipNextNewLine = true;
    p3.tokenizer.state = TokenizerMode.RCDATA;
    p3.originalInsertionMode = p3.insertionMode;
    p3.framesetOk = false;
    p3.insertionMode = InsertionMode.TEXT;
  }
  function xmpStartTagInBody(p3, token) {
    if (p3.openElements.hasInButtonScope(TAG_ID.P)) {
      p3._closePElement();
    }
    p3._reconstructActiveFormattingElements();
    p3.framesetOk = false;
    p3._switchToTextParsing(token, TokenizerMode.RAWTEXT);
  }
  function iframeStartTagInBody(p3, token) {
    p3.framesetOk = false;
    p3._switchToTextParsing(token, TokenizerMode.RAWTEXT);
  }
  function noembedStartTagInBody(p3, token) {
    p3._switchToTextParsing(token, TokenizerMode.RAWTEXT);
  }
  function selectStartTagInBody(p3, token) {
    p3._reconstructActiveFormattingElements();
    p3._insertElement(token, NS.HTML);
    p3.framesetOk = false;
    p3.insertionMode = p3.insertionMode === InsertionMode.IN_TABLE || p3.insertionMode === InsertionMode.IN_CAPTION || p3.insertionMode === InsertionMode.IN_TABLE_BODY || p3.insertionMode === InsertionMode.IN_ROW || p3.insertionMode === InsertionMode.IN_CELL ? InsertionMode.IN_SELECT_IN_TABLE : InsertionMode.IN_SELECT;
  }
  function optgroupStartTagInBody(p3, token) {
    if (p3.openElements.currentTagId === TAG_ID.OPTION) {
      p3.openElements.pop();
    }
    p3._reconstructActiveFormattingElements();
    p3._insertElement(token, NS.HTML);
  }
  function rbStartTagInBody(p3, token) {
    if (p3.openElements.hasInScope(TAG_ID.RUBY)) {
      p3.openElements.generateImpliedEndTags();
    }
    p3._insertElement(token, NS.HTML);
  }
  function rtStartTagInBody(p3, token) {
    if (p3.openElements.hasInScope(TAG_ID.RUBY)) {
      p3.openElements.generateImpliedEndTagsWithExclusion(TAG_ID.RTC);
    }
    p3._insertElement(token, NS.HTML);
  }
  function mathStartTagInBody(p3, token) {
    p3._reconstructActiveFormattingElements();
    adjustTokenMathMLAttrs(token);
    adjustTokenXMLAttrs(token);
    if (token.selfClosing) {
      p3._appendElement(token, NS.MATHML);
    } else {
      p3._insertElement(token, NS.MATHML);
    }
    token.ackSelfClosing = true;
  }
  function svgStartTagInBody(p3, token) {
    p3._reconstructActiveFormattingElements();
    adjustTokenSVGAttrs(token);
    adjustTokenXMLAttrs(token);
    if (token.selfClosing) {
      p3._appendElement(token, NS.SVG);
    } else {
      p3._insertElement(token, NS.SVG);
    }
    token.ackSelfClosing = true;
  }
  function genericStartTagInBody(p3, token) {
    p3._reconstructActiveFormattingElements();
    p3._insertElement(token, NS.HTML);
  }
  function startTagInBody(p3, token) {
    switch (token.tagID) {
      case TAG_ID.I:
      case TAG_ID.S:
      case TAG_ID.B:
      case TAG_ID.U:
      case TAG_ID.EM:
      case TAG_ID.TT:
      case TAG_ID.BIG:
      case TAG_ID.CODE:
      case TAG_ID.FONT:
      case TAG_ID.SMALL:
      case TAG_ID.STRIKE:
      case TAG_ID.STRONG: {
        bStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.A: {
        aStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.H1:
      case TAG_ID.H2:
      case TAG_ID.H3:
      case TAG_ID.H4:
      case TAG_ID.H5:
      case TAG_ID.H6: {
        numberedHeaderStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.P:
      case TAG_ID.DL:
      case TAG_ID.OL:
      case TAG_ID.UL:
      case TAG_ID.DIV:
      case TAG_ID.DIR:
      case TAG_ID.NAV:
      case TAG_ID.MAIN:
      case TAG_ID.MENU:
      case TAG_ID.ASIDE:
      case TAG_ID.CENTER:
      case TAG_ID.FIGURE:
      case TAG_ID.FOOTER:
      case TAG_ID.HEADER:
      case TAG_ID.HGROUP:
      case TAG_ID.DIALOG:
      case TAG_ID.DETAILS:
      case TAG_ID.ADDRESS:
      case TAG_ID.ARTICLE:
      case TAG_ID.SECTION:
      case TAG_ID.SUMMARY:
      case TAG_ID.FIELDSET:
      case TAG_ID.BLOCKQUOTE:
      case TAG_ID.FIGCAPTION: {
        addressStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.LI:
      case TAG_ID.DD:
      case TAG_ID.DT: {
        listItemStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.BR:
      case TAG_ID.IMG:
      case TAG_ID.WBR:
      case TAG_ID.AREA:
      case TAG_ID.EMBED:
      case TAG_ID.KEYGEN: {
        areaStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.HR: {
        hrStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.RB:
      case TAG_ID.RTC: {
        rbStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.RT:
      case TAG_ID.RP: {
        rtStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.PRE:
      case TAG_ID.LISTING: {
        preStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.XMP: {
        xmpStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.SVG: {
        svgStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.HTML: {
        htmlStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.BASE:
      case TAG_ID.LINK:
      case TAG_ID.META:
      case TAG_ID.STYLE:
      case TAG_ID.TITLE:
      case TAG_ID.SCRIPT:
      case TAG_ID.BGSOUND:
      case TAG_ID.BASEFONT:
      case TAG_ID.TEMPLATE: {
        startTagInHead(p3, token);
        break;
      }
      case TAG_ID.BODY: {
        bodyStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.FORM: {
        formStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.NOBR: {
        nobrStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.MATH: {
        mathStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.TABLE: {
        tableStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.INPUT: {
        inputStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.PARAM:
      case TAG_ID.TRACK:
      case TAG_ID.SOURCE: {
        paramStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.IMAGE: {
        imageStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.BUTTON: {
        buttonStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.APPLET:
      case TAG_ID.OBJECT:
      case TAG_ID.MARQUEE: {
        appletStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.IFRAME: {
        iframeStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.SELECT: {
        selectStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.OPTION:
      case TAG_ID.OPTGROUP: {
        optgroupStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.NOEMBED: {
        noembedStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.FRAMESET: {
        framesetStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.TEXTAREA: {
        textareaStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.NOSCRIPT: {
        if (p3.options.scriptingEnabled) {
          noembedStartTagInBody(p3, token);
        } else {
          genericStartTagInBody(p3, token);
        }
        break;
      }
      case TAG_ID.PLAINTEXT: {
        plaintextStartTagInBody(p3, token);
        break;
      }
      case TAG_ID.COL:
      case TAG_ID.TH:
      case TAG_ID.TD:
      case TAG_ID.TR:
      case TAG_ID.HEAD:
      case TAG_ID.FRAME:
      case TAG_ID.TBODY:
      case TAG_ID.TFOOT:
      case TAG_ID.THEAD:
      case TAG_ID.CAPTION:
      case TAG_ID.COLGROUP: {
        break;
      }
      default: {
        genericStartTagInBody(p3, token);
      }
    }
  }
  function bodyEndTagInBody(p3, token) {
    if (p3.openElements.hasInScope(TAG_ID.BODY)) {
      p3.insertionMode = InsertionMode.AFTER_BODY;
      if (p3.options.sourceCodeLocationInfo) {
        const bodyElement = p3.openElements.tryPeekProperlyNestedBodyElement();
        if (bodyElement) {
          p3._setEndLocation(bodyElement, token);
        }
      }
    }
  }
  function htmlEndTagInBody(p3, token) {
    if (p3.openElements.hasInScope(TAG_ID.BODY)) {
      p3.insertionMode = InsertionMode.AFTER_BODY;
      endTagAfterBody(p3, token);
    }
  }
  function addressEndTagInBody(p3, token) {
    const tn = token.tagID;
    if (p3.openElements.hasInScope(tn)) {
      p3.openElements.generateImpliedEndTags();
      p3.openElements.popUntilTagNamePopped(tn);
    }
  }
  function formEndTagInBody(p3) {
    const inTemplate = p3.openElements.tmplCount > 0;
    const { formElement } = p3;
    if (!inTemplate) {
      p3.formElement = null;
    }
    if ((formElement || inTemplate) && p3.openElements.hasInScope(TAG_ID.FORM)) {
      p3.openElements.generateImpliedEndTags();
      if (inTemplate) {
        p3.openElements.popUntilTagNamePopped(TAG_ID.FORM);
      } else if (formElement) {
        p3.openElements.remove(formElement);
      }
    }
  }
  function pEndTagInBody(p3) {
    if (!p3.openElements.hasInButtonScope(TAG_ID.P)) {
      p3._insertFakeElement(TAG_NAMES.P, TAG_ID.P);
    }
    p3._closePElement();
  }
  function liEndTagInBody(p3) {
    if (p3.openElements.hasInListItemScope(TAG_ID.LI)) {
      p3.openElements.generateImpliedEndTagsWithExclusion(TAG_ID.LI);
      p3.openElements.popUntilTagNamePopped(TAG_ID.LI);
    }
  }
  function ddEndTagInBody(p3, token) {
    const tn = token.tagID;
    if (p3.openElements.hasInScope(tn)) {
      p3.openElements.generateImpliedEndTagsWithExclusion(tn);
      p3.openElements.popUntilTagNamePopped(tn);
    }
  }
  function numberedHeaderEndTagInBody(p3) {
    if (p3.openElements.hasNumberedHeaderInScope()) {
      p3.openElements.generateImpliedEndTags();
      p3.openElements.popUntilNumberedHeaderPopped();
    }
  }
  function appletEndTagInBody(p3, token) {
    const tn = token.tagID;
    if (p3.openElements.hasInScope(tn)) {
      p3.openElements.generateImpliedEndTags();
      p3.openElements.popUntilTagNamePopped(tn);
      p3.activeFormattingElements.clearToLastMarker();
    }
  }
  function brEndTagInBody(p3) {
    p3._reconstructActiveFormattingElements();
    p3._insertFakeElement(TAG_NAMES.BR, TAG_ID.BR);
    p3.openElements.pop();
    p3.framesetOk = false;
  }
  function genericEndTagInBody(p3, token) {
    const tn = token.tagName;
    const tid = token.tagID;
    for (let i3 = p3.openElements.stackTop; i3 > 0; i3--) {
      const element = p3.openElements.items[i3];
      const elementId = p3.openElements.tagIDs[i3];
      if (tid === elementId && (tid !== TAG_ID.UNKNOWN || p3.treeAdapter.getTagName(element) === tn)) {
        p3.openElements.generateImpliedEndTagsWithExclusion(tid);
        if (p3.openElements.stackTop >= i3)
          p3.openElements.shortenToLength(i3);
        break;
      }
      if (p3._isSpecialElement(element, elementId)) {
        break;
      }
    }
  }
  function endTagInBody(p3, token) {
    switch (token.tagID) {
      case TAG_ID.A:
      case TAG_ID.B:
      case TAG_ID.I:
      case TAG_ID.S:
      case TAG_ID.U:
      case TAG_ID.EM:
      case TAG_ID.TT:
      case TAG_ID.BIG:
      case TAG_ID.CODE:
      case TAG_ID.FONT:
      case TAG_ID.NOBR:
      case TAG_ID.SMALL:
      case TAG_ID.STRIKE:
      case TAG_ID.STRONG: {
        callAdoptionAgency(p3, token);
        break;
      }
      case TAG_ID.P: {
        pEndTagInBody(p3);
        break;
      }
      case TAG_ID.DL:
      case TAG_ID.UL:
      case TAG_ID.OL:
      case TAG_ID.DIR:
      case TAG_ID.DIV:
      case TAG_ID.NAV:
      case TAG_ID.PRE:
      case TAG_ID.MAIN:
      case TAG_ID.MENU:
      case TAG_ID.ASIDE:
      case TAG_ID.BUTTON:
      case TAG_ID.CENTER:
      case TAG_ID.FIGURE:
      case TAG_ID.FOOTER:
      case TAG_ID.HEADER:
      case TAG_ID.HGROUP:
      case TAG_ID.DIALOG:
      case TAG_ID.ADDRESS:
      case TAG_ID.ARTICLE:
      case TAG_ID.DETAILS:
      case TAG_ID.SECTION:
      case TAG_ID.SUMMARY:
      case TAG_ID.LISTING:
      case TAG_ID.FIELDSET:
      case TAG_ID.BLOCKQUOTE:
      case TAG_ID.FIGCAPTION: {
        addressEndTagInBody(p3, token);
        break;
      }
      case TAG_ID.LI: {
        liEndTagInBody(p3);
        break;
      }
      case TAG_ID.DD:
      case TAG_ID.DT: {
        ddEndTagInBody(p3, token);
        break;
      }
      case TAG_ID.H1:
      case TAG_ID.H2:
      case TAG_ID.H3:
      case TAG_ID.H4:
      case TAG_ID.H5:
      case TAG_ID.H6: {
        numberedHeaderEndTagInBody(p3);
        break;
      }
      case TAG_ID.BR: {
        brEndTagInBody(p3);
        break;
      }
      case TAG_ID.BODY: {
        bodyEndTagInBody(p3, token);
        break;
      }
      case TAG_ID.HTML: {
        htmlEndTagInBody(p3, token);
        break;
      }
      case TAG_ID.FORM: {
        formEndTagInBody(p3);
        break;
      }
      case TAG_ID.APPLET:
      case TAG_ID.OBJECT:
      case TAG_ID.MARQUEE: {
        appletEndTagInBody(p3, token);
        break;
      }
      case TAG_ID.TEMPLATE: {
        templateEndTagInHead(p3, token);
        break;
      }
      default: {
        genericEndTagInBody(p3, token);
      }
    }
  }
  function eofInBody(p3, token) {
    if (p3.tmplInsertionModeStack.length > 0) {
      eofInTemplate(p3, token);
    } else {
      stopParsing(p3, token);
    }
  }
  function endTagInText(p3, token) {
    var _a2;
    if (token.tagID === TAG_ID.SCRIPT) {
      (_a2 = p3.scriptHandler) === null || _a2 === void 0 ? void 0 : _a2.call(p3, p3.openElements.current);
    }
    p3.openElements.pop();
    p3.insertionMode = p3.originalInsertionMode;
  }
  function eofInText(p3, token) {
    p3._err(token, ERR.eofInElementThatCanContainOnlyText);
    p3.openElements.pop();
    p3.insertionMode = p3.originalInsertionMode;
    p3.onEof(token);
  }
  function characterInTable(p3, token) {
    if (TABLE_STRUCTURE_TAGS.has(p3.openElements.currentTagId)) {
      p3.pendingCharacterTokens.length = 0;
      p3.hasNonWhitespacePendingCharacterToken = false;
      p3.originalInsertionMode = p3.insertionMode;
      p3.insertionMode = InsertionMode.IN_TABLE_TEXT;
      switch (token.type) {
        case TokenType.CHARACTER: {
          characterInTableText(p3, token);
          break;
        }
        case TokenType.WHITESPACE_CHARACTER: {
          whitespaceCharacterInTableText(p3, token);
          break;
        }
      }
    } else {
      tokenInTable(p3, token);
    }
  }
  function captionStartTagInTable(p3, token) {
    p3.openElements.clearBackToTableContext();
    p3.activeFormattingElements.insertMarker();
    p3._insertElement(token, NS.HTML);
    p3.insertionMode = InsertionMode.IN_CAPTION;
  }
  function colgroupStartTagInTable(p3, token) {
    p3.openElements.clearBackToTableContext();
    p3._insertElement(token, NS.HTML);
    p3.insertionMode = InsertionMode.IN_COLUMN_GROUP;
  }
  function colStartTagInTable(p3, token) {
    p3.openElements.clearBackToTableContext();
    p3._insertFakeElement(TAG_NAMES.COLGROUP, TAG_ID.COLGROUP);
    p3.insertionMode = InsertionMode.IN_COLUMN_GROUP;
    startTagInColumnGroup(p3, token);
  }
  function tbodyStartTagInTable(p3, token) {
    p3.openElements.clearBackToTableContext();
    p3._insertElement(token, NS.HTML);
    p3.insertionMode = InsertionMode.IN_TABLE_BODY;
  }
  function tdStartTagInTable(p3, token) {
    p3.openElements.clearBackToTableContext();
    p3._insertFakeElement(TAG_NAMES.TBODY, TAG_ID.TBODY);
    p3.insertionMode = InsertionMode.IN_TABLE_BODY;
    startTagInTableBody(p3, token);
  }
  function tableStartTagInTable(p3, token) {
    if (p3.openElements.hasInTableScope(TAG_ID.TABLE)) {
      p3.openElements.popUntilTagNamePopped(TAG_ID.TABLE);
      p3._resetInsertionMode();
      p3._processStartTag(token);
    }
  }
  function inputStartTagInTable(p3, token) {
    if (isHiddenInput(token)) {
      p3._appendElement(token, NS.HTML);
    } else {
      tokenInTable(p3, token);
    }
    token.ackSelfClosing = true;
  }
  function formStartTagInTable(p3, token) {
    if (!p3.formElement && p3.openElements.tmplCount === 0) {
      p3._insertElement(token, NS.HTML);
      p3.formElement = p3.openElements.current;
      p3.openElements.pop();
    }
  }
  function startTagInTable(p3, token) {
    switch (token.tagID) {
      case TAG_ID.TD:
      case TAG_ID.TH:
      case TAG_ID.TR: {
        tdStartTagInTable(p3, token);
        break;
      }
      case TAG_ID.STYLE:
      case TAG_ID.SCRIPT:
      case TAG_ID.TEMPLATE: {
        startTagInHead(p3, token);
        break;
      }
      case TAG_ID.COL: {
        colStartTagInTable(p3, token);
        break;
      }
      case TAG_ID.FORM: {
        formStartTagInTable(p3, token);
        break;
      }
      case TAG_ID.TABLE: {
        tableStartTagInTable(p3, token);
        break;
      }
      case TAG_ID.TBODY:
      case TAG_ID.TFOOT:
      case TAG_ID.THEAD: {
        tbodyStartTagInTable(p3, token);
        break;
      }
      case TAG_ID.INPUT: {
        inputStartTagInTable(p3, token);
        break;
      }
      case TAG_ID.CAPTION: {
        captionStartTagInTable(p3, token);
        break;
      }
      case TAG_ID.COLGROUP: {
        colgroupStartTagInTable(p3, token);
        break;
      }
      default: {
        tokenInTable(p3, token);
      }
    }
  }
  function endTagInTable(p3, token) {
    switch (token.tagID) {
      case TAG_ID.TABLE: {
        if (p3.openElements.hasInTableScope(TAG_ID.TABLE)) {
          p3.openElements.popUntilTagNamePopped(TAG_ID.TABLE);
          p3._resetInsertionMode();
        }
        break;
      }
      case TAG_ID.TEMPLATE: {
        templateEndTagInHead(p3, token);
        break;
      }
      case TAG_ID.BODY:
      case TAG_ID.CAPTION:
      case TAG_ID.COL:
      case TAG_ID.COLGROUP:
      case TAG_ID.HTML:
      case TAG_ID.TBODY:
      case TAG_ID.TD:
      case TAG_ID.TFOOT:
      case TAG_ID.TH:
      case TAG_ID.THEAD:
      case TAG_ID.TR: {
        break;
      }
      default: {
        tokenInTable(p3, token);
      }
    }
  }
  function tokenInTable(p3, token) {
    const savedFosterParentingState = p3.fosterParentingEnabled;
    p3.fosterParentingEnabled = true;
    modeInBody(p3, token);
    p3.fosterParentingEnabled = savedFosterParentingState;
  }
  function whitespaceCharacterInTableText(p3, token) {
    p3.pendingCharacterTokens.push(token);
  }
  function characterInTableText(p3, token) {
    p3.pendingCharacterTokens.push(token);
    p3.hasNonWhitespacePendingCharacterToken = true;
  }
  function tokenInTableText(p3, token) {
    let i3 = 0;
    if (p3.hasNonWhitespacePendingCharacterToken) {
      for (; i3 < p3.pendingCharacterTokens.length; i3++) {
        tokenInTable(p3, p3.pendingCharacterTokens[i3]);
      }
    } else {
      for (; i3 < p3.pendingCharacterTokens.length; i3++) {
        p3._insertCharacters(p3.pendingCharacterTokens[i3]);
      }
    }
    p3.insertionMode = p3.originalInsertionMode;
    p3._processToken(token);
  }
  var TABLE_VOID_ELEMENTS = /* @__PURE__ */ new Set([TAG_ID.CAPTION, TAG_ID.COL, TAG_ID.COLGROUP, TAG_ID.TBODY, TAG_ID.TD, TAG_ID.TFOOT, TAG_ID.TH, TAG_ID.THEAD, TAG_ID.TR]);
  function startTagInCaption(p3, token) {
    const tn = token.tagID;
    if (TABLE_VOID_ELEMENTS.has(tn)) {
      if (p3.openElements.hasInTableScope(TAG_ID.CAPTION)) {
        p3.openElements.generateImpliedEndTags();
        p3.openElements.popUntilTagNamePopped(TAG_ID.CAPTION);
        p3.activeFormattingElements.clearToLastMarker();
        p3.insertionMode = InsertionMode.IN_TABLE;
        startTagInTable(p3, token);
      }
    } else {
      startTagInBody(p3, token);
    }
  }
  function endTagInCaption(p3, token) {
    const tn = token.tagID;
    switch (tn) {
      case TAG_ID.CAPTION:
      case TAG_ID.TABLE: {
        if (p3.openElements.hasInTableScope(TAG_ID.CAPTION)) {
          p3.openElements.generateImpliedEndTags();
          p3.openElements.popUntilTagNamePopped(TAG_ID.CAPTION);
          p3.activeFormattingElements.clearToLastMarker();
          p3.insertionMode = InsertionMode.IN_TABLE;
          if (tn === TAG_ID.TABLE) {
            endTagInTable(p3, token);
          }
        }
        break;
      }
      case TAG_ID.BODY:
      case TAG_ID.COL:
      case TAG_ID.COLGROUP:
      case TAG_ID.HTML:
      case TAG_ID.TBODY:
      case TAG_ID.TD:
      case TAG_ID.TFOOT:
      case TAG_ID.TH:
      case TAG_ID.THEAD:
      case TAG_ID.TR: {
        break;
      }
      default: {
        endTagInBody(p3, token);
      }
    }
  }
  function startTagInColumnGroup(p3, token) {
    switch (token.tagID) {
      case TAG_ID.HTML: {
        startTagInBody(p3, token);
        break;
      }
      case TAG_ID.COL: {
        p3._appendElement(token, NS.HTML);
        token.ackSelfClosing = true;
        break;
      }
      case TAG_ID.TEMPLATE: {
        startTagInHead(p3, token);
        break;
      }
      default: {
        tokenInColumnGroup(p3, token);
      }
    }
  }
  function endTagInColumnGroup(p3, token) {
    switch (token.tagID) {
      case TAG_ID.COLGROUP: {
        if (p3.openElements.currentTagId === TAG_ID.COLGROUP) {
          p3.openElements.pop();
          p3.insertionMode = InsertionMode.IN_TABLE;
        }
        break;
      }
      case TAG_ID.TEMPLATE: {
        templateEndTagInHead(p3, token);
        break;
      }
      case TAG_ID.COL: {
        break;
      }
      default: {
        tokenInColumnGroup(p3, token);
      }
    }
  }
  function tokenInColumnGroup(p3, token) {
    if (p3.openElements.currentTagId === TAG_ID.COLGROUP) {
      p3.openElements.pop();
      p3.insertionMode = InsertionMode.IN_TABLE;
      p3._processToken(token);
    }
  }
  function startTagInTableBody(p3, token) {
    switch (token.tagID) {
      case TAG_ID.TR: {
        p3.openElements.clearBackToTableBodyContext();
        p3._insertElement(token, NS.HTML);
        p3.insertionMode = InsertionMode.IN_ROW;
        break;
      }
      case TAG_ID.TH:
      case TAG_ID.TD: {
        p3.openElements.clearBackToTableBodyContext();
        p3._insertFakeElement(TAG_NAMES.TR, TAG_ID.TR);
        p3.insertionMode = InsertionMode.IN_ROW;
        startTagInRow(p3, token);
        break;
      }
      case TAG_ID.CAPTION:
      case TAG_ID.COL:
      case TAG_ID.COLGROUP:
      case TAG_ID.TBODY:
      case TAG_ID.TFOOT:
      case TAG_ID.THEAD: {
        if (p3.openElements.hasTableBodyContextInTableScope()) {
          p3.openElements.clearBackToTableBodyContext();
          p3.openElements.pop();
          p3.insertionMode = InsertionMode.IN_TABLE;
          startTagInTable(p3, token);
        }
        break;
      }
      default: {
        startTagInTable(p3, token);
      }
    }
  }
  function endTagInTableBody(p3, token) {
    const tn = token.tagID;
    switch (token.tagID) {
      case TAG_ID.TBODY:
      case TAG_ID.TFOOT:
      case TAG_ID.THEAD: {
        if (p3.openElements.hasInTableScope(tn)) {
          p3.openElements.clearBackToTableBodyContext();
          p3.openElements.pop();
          p3.insertionMode = InsertionMode.IN_TABLE;
        }
        break;
      }
      case TAG_ID.TABLE: {
        if (p3.openElements.hasTableBodyContextInTableScope()) {
          p3.openElements.clearBackToTableBodyContext();
          p3.openElements.pop();
          p3.insertionMode = InsertionMode.IN_TABLE;
          endTagInTable(p3, token);
        }
        break;
      }
      case TAG_ID.BODY:
      case TAG_ID.CAPTION:
      case TAG_ID.COL:
      case TAG_ID.COLGROUP:
      case TAG_ID.HTML:
      case TAG_ID.TD:
      case TAG_ID.TH:
      case TAG_ID.TR: {
        break;
      }
      default: {
        endTagInTable(p3, token);
      }
    }
  }
  function startTagInRow(p3, token) {
    switch (token.tagID) {
      case TAG_ID.TH:
      case TAG_ID.TD: {
        p3.openElements.clearBackToTableRowContext();
        p3._insertElement(token, NS.HTML);
        p3.insertionMode = InsertionMode.IN_CELL;
        p3.activeFormattingElements.insertMarker();
        break;
      }
      case TAG_ID.CAPTION:
      case TAG_ID.COL:
      case TAG_ID.COLGROUP:
      case TAG_ID.TBODY:
      case TAG_ID.TFOOT:
      case TAG_ID.THEAD:
      case TAG_ID.TR: {
        if (p3.openElements.hasInTableScope(TAG_ID.TR)) {
          p3.openElements.clearBackToTableRowContext();
          p3.openElements.pop();
          p3.insertionMode = InsertionMode.IN_TABLE_BODY;
          startTagInTableBody(p3, token);
        }
        break;
      }
      default: {
        startTagInTable(p3, token);
      }
    }
  }
  function endTagInRow(p3, token) {
    switch (token.tagID) {
      case TAG_ID.TR: {
        if (p3.openElements.hasInTableScope(TAG_ID.TR)) {
          p3.openElements.clearBackToTableRowContext();
          p3.openElements.pop();
          p3.insertionMode = InsertionMode.IN_TABLE_BODY;
        }
        break;
      }
      case TAG_ID.TABLE: {
        if (p3.openElements.hasInTableScope(TAG_ID.TR)) {
          p3.openElements.clearBackToTableRowContext();
          p3.openElements.pop();
          p3.insertionMode = InsertionMode.IN_TABLE_BODY;
          endTagInTableBody(p3, token);
        }
        break;
      }
      case TAG_ID.TBODY:
      case TAG_ID.TFOOT:
      case TAG_ID.THEAD: {
        if (p3.openElements.hasInTableScope(token.tagID) || p3.openElements.hasInTableScope(TAG_ID.TR)) {
          p3.openElements.clearBackToTableRowContext();
          p3.openElements.pop();
          p3.insertionMode = InsertionMode.IN_TABLE_BODY;
          endTagInTableBody(p3, token);
        }
        break;
      }
      case TAG_ID.BODY:
      case TAG_ID.CAPTION:
      case TAG_ID.COL:
      case TAG_ID.COLGROUP:
      case TAG_ID.HTML:
      case TAG_ID.TD:
      case TAG_ID.TH: {
        break;
      }
      default: {
        endTagInTable(p3, token);
      }
    }
  }
  function startTagInCell(p3, token) {
    const tn = token.tagID;
    if (TABLE_VOID_ELEMENTS.has(tn)) {
      if (p3.openElements.hasInTableScope(TAG_ID.TD) || p3.openElements.hasInTableScope(TAG_ID.TH)) {
        p3._closeTableCell();
        startTagInRow(p3, token);
      }
    } else {
      startTagInBody(p3, token);
    }
  }
  function endTagInCell(p3, token) {
    const tn = token.tagID;
    switch (tn) {
      case TAG_ID.TD:
      case TAG_ID.TH: {
        if (p3.openElements.hasInTableScope(tn)) {
          p3.openElements.generateImpliedEndTags();
          p3.openElements.popUntilTagNamePopped(tn);
          p3.activeFormattingElements.clearToLastMarker();
          p3.insertionMode = InsertionMode.IN_ROW;
        }
        break;
      }
      case TAG_ID.TABLE:
      case TAG_ID.TBODY:
      case TAG_ID.TFOOT:
      case TAG_ID.THEAD:
      case TAG_ID.TR: {
        if (p3.openElements.hasInTableScope(tn)) {
          p3._closeTableCell();
          endTagInRow(p3, token);
        }
        break;
      }
      case TAG_ID.BODY:
      case TAG_ID.CAPTION:
      case TAG_ID.COL:
      case TAG_ID.COLGROUP:
      case TAG_ID.HTML: {
        break;
      }
      default: {
        endTagInBody(p3, token);
      }
    }
  }
  function startTagInSelect(p3, token) {
    switch (token.tagID) {
      case TAG_ID.HTML: {
        startTagInBody(p3, token);
        break;
      }
      case TAG_ID.OPTION: {
        if (p3.openElements.currentTagId === TAG_ID.OPTION) {
          p3.openElements.pop();
        }
        p3._insertElement(token, NS.HTML);
        break;
      }
      case TAG_ID.OPTGROUP: {
        if (p3.openElements.currentTagId === TAG_ID.OPTION) {
          p3.openElements.pop();
        }
        if (p3.openElements.currentTagId === TAG_ID.OPTGROUP) {
          p3.openElements.pop();
        }
        p3._insertElement(token, NS.HTML);
        break;
      }
      case TAG_ID.INPUT:
      case TAG_ID.KEYGEN:
      case TAG_ID.TEXTAREA:
      case TAG_ID.SELECT: {
        if (p3.openElements.hasInSelectScope(TAG_ID.SELECT)) {
          p3.openElements.popUntilTagNamePopped(TAG_ID.SELECT);
          p3._resetInsertionMode();
          if (token.tagID !== TAG_ID.SELECT) {
            p3._processStartTag(token);
          }
        }
        break;
      }
      case TAG_ID.SCRIPT:
      case TAG_ID.TEMPLATE: {
        startTagInHead(p3, token);
        break;
      }
      default:
    }
  }
  function endTagInSelect(p3, token) {
    switch (token.tagID) {
      case TAG_ID.OPTGROUP: {
        if (p3.openElements.stackTop > 0 && p3.openElements.currentTagId === TAG_ID.OPTION && p3.openElements.tagIDs[p3.openElements.stackTop - 1] === TAG_ID.OPTGROUP) {
          p3.openElements.pop();
        }
        if (p3.openElements.currentTagId === TAG_ID.OPTGROUP) {
          p3.openElements.pop();
        }
        break;
      }
      case TAG_ID.OPTION: {
        if (p3.openElements.currentTagId === TAG_ID.OPTION) {
          p3.openElements.pop();
        }
        break;
      }
      case TAG_ID.SELECT: {
        if (p3.openElements.hasInSelectScope(TAG_ID.SELECT)) {
          p3.openElements.popUntilTagNamePopped(TAG_ID.SELECT);
          p3._resetInsertionMode();
        }
        break;
      }
      case TAG_ID.TEMPLATE: {
        templateEndTagInHead(p3, token);
        break;
      }
      default:
    }
  }
  function startTagInSelectInTable(p3, token) {
    const tn = token.tagID;
    if (tn === TAG_ID.CAPTION || tn === TAG_ID.TABLE || tn === TAG_ID.TBODY || tn === TAG_ID.TFOOT || tn === TAG_ID.THEAD || tn === TAG_ID.TR || tn === TAG_ID.TD || tn === TAG_ID.TH) {
      p3.openElements.popUntilTagNamePopped(TAG_ID.SELECT);
      p3._resetInsertionMode();
      p3._processStartTag(token);
    } else {
      startTagInSelect(p3, token);
    }
  }
  function endTagInSelectInTable(p3, token) {
    const tn = token.tagID;
    if (tn === TAG_ID.CAPTION || tn === TAG_ID.TABLE || tn === TAG_ID.TBODY || tn === TAG_ID.TFOOT || tn === TAG_ID.THEAD || tn === TAG_ID.TR || tn === TAG_ID.TD || tn === TAG_ID.TH) {
      if (p3.openElements.hasInTableScope(tn)) {
        p3.openElements.popUntilTagNamePopped(TAG_ID.SELECT);
        p3._resetInsertionMode();
        p3.onEndTag(token);
      }
    } else {
      endTagInSelect(p3, token);
    }
  }
  function startTagInTemplate(p3, token) {
    switch (token.tagID) {
      case TAG_ID.BASE:
      case TAG_ID.BASEFONT:
      case TAG_ID.BGSOUND:
      case TAG_ID.LINK:
      case TAG_ID.META:
      case TAG_ID.NOFRAMES:
      case TAG_ID.SCRIPT:
      case TAG_ID.STYLE:
      case TAG_ID.TEMPLATE:
      case TAG_ID.TITLE: {
        startTagInHead(p3, token);
        break;
      }
      case TAG_ID.CAPTION:
      case TAG_ID.COLGROUP:
      case TAG_ID.TBODY:
      case TAG_ID.TFOOT:
      case TAG_ID.THEAD: {
        p3.tmplInsertionModeStack[0] = InsertionMode.IN_TABLE;
        p3.insertionMode = InsertionMode.IN_TABLE;
        startTagInTable(p3, token);
        break;
      }
      case TAG_ID.COL: {
        p3.tmplInsertionModeStack[0] = InsertionMode.IN_COLUMN_GROUP;
        p3.insertionMode = InsertionMode.IN_COLUMN_GROUP;
        startTagInColumnGroup(p3, token);
        break;
      }
      case TAG_ID.TR: {
        p3.tmplInsertionModeStack[0] = InsertionMode.IN_TABLE_BODY;
        p3.insertionMode = InsertionMode.IN_TABLE_BODY;
        startTagInTableBody(p3, token);
        break;
      }
      case TAG_ID.TD:
      case TAG_ID.TH: {
        p3.tmplInsertionModeStack[0] = InsertionMode.IN_ROW;
        p3.insertionMode = InsertionMode.IN_ROW;
        startTagInRow(p3, token);
        break;
      }
      default: {
        p3.tmplInsertionModeStack[0] = InsertionMode.IN_BODY;
        p3.insertionMode = InsertionMode.IN_BODY;
        startTagInBody(p3, token);
      }
    }
  }
  function endTagInTemplate(p3, token) {
    if (token.tagID === TAG_ID.TEMPLATE) {
      templateEndTagInHead(p3, token);
    }
  }
  function eofInTemplate(p3, token) {
    if (p3.openElements.tmplCount > 0) {
      p3.openElements.popUntilTagNamePopped(TAG_ID.TEMPLATE);
      p3.activeFormattingElements.clearToLastMarker();
      p3.tmplInsertionModeStack.shift();
      p3._resetInsertionMode();
      p3.onEof(token);
    } else {
      stopParsing(p3, token);
    }
  }
  function startTagAfterBody(p3, token) {
    if (token.tagID === TAG_ID.HTML) {
      startTagInBody(p3, token);
    } else {
      tokenAfterBody(p3, token);
    }
  }
  function endTagAfterBody(p3, token) {
    var _a2;
    if (token.tagID === TAG_ID.HTML) {
      if (!p3.fragmentContext) {
        p3.insertionMode = InsertionMode.AFTER_AFTER_BODY;
      }
      if (p3.options.sourceCodeLocationInfo && p3.openElements.tagIDs[0] === TAG_ID.HTML) {
        p3._setEndLocation(p3.openElements.items[0], token);
        const bodyElement = p3.openElements.items[1];
        if (bodyElement && !((_a2 = p3.treeAdapter.getNodeSourceCodeLocation(bodyElement)) === null || _a2 === void 0 ? void 0 : _a2.endTag)) {
          p3._setEndLocation(bodyElement, token);
        }
      }
    } else {
      tokenAfterBody(p3, token);
    }
  }
  function tokenAfterBody(p3, token) {
    p3.insertionMode = InsertionMode.IN_BODY;
    modeInBody(p3, token);
  }
  function startTagInFrameset(p3, token) {
    switch (token.tagID) {
      case TAG_ID.HTML: {
        startTagInBody(p3, token);
        break;
      }
      case TAG_ID.FRAMESET: {
        p3._insertElement(token, NS.HTML);
        break;
      }
      case TAG_ID.FRAME: {
        p3._appendElement(token, NS.HTML);
        token.ackSelfClosing = true;
        break;
      }
      case TAG_ID.NOFRAMES: {
        startTagInHead(p3, token);
        break;
      }
      default:
    }
  }
  function endTagInFrameset(p3, token) {
    if (token.tagID === TAG_ID.FRAMESET && !p3.openElements.isRootHtmlElementCurrent()) {
      p3.openElements.pop();
      if (!p3.fragmentContext && p3.openElements.currentTagId !== TAG_ID.FRAMESET) {
        p3.insertionMode = InsertionMode.AFTER_FRAMESET;
      }
    }
  }
  function startTagAfterFrameset(p3, token) {
    switch (token.tagID) {
      case TAG_ID.HTML: {
        startTagInBody(p3, token);
        break;
      }
      case TAG_ID.NOFRAMES: {
        startTagInHead(p3, token);
        break;
      }
      default:
    }
  }
  function endTagAfterFrameset(p3, token) {
    if (token.tagID === TAG_ID.HTML) {
      p3.insertionMode = InsertionMode.AFTER_AFTER_FRAMESET;
    }
  }
  function startTagAfterAfterBody(p3, token) {
    if (token.tagID === TAG_ID.HTML) {
      startTagInBody(p3, token);
    } else {
      tokenAfterAfterBody(p3, token);
    }
  }
  function tokenAfterAfterBody(p3, token) {
    p3.insertionMode = InsertionMode.IN_BODY;
    modeInBody(p3, token);
  }
  function startTagAfterAfterFrameset(p3, token) {
    switch (token.tagID) {
      case TAG_ID.HTML: {
        startTagInBody(p3, token);
        break;
      }
      case TAG_ID.NOFRAMES: {
        startTagInHead(p3, token);
        break;
      }
      default:
    }
  }
  function nullCharacterInForeignContent(p3, token) {
    token.chars = REPLACEMENT_CHARACTER;
    p3._insertCharacters(token);
  }
  function characterInForeignContent(p3, token) {
    p3._insertCharacters(token);
    p3.framesetOk = false;
  }
  function popUntilHtmlOrIntegrationPoint(p3) {
    while (p3.treeAdapter.getNamespaceURI(p3.openElements.current) !== NS.HTML && !p3._isIntegrationPoint(p3.openElements.currentTagId, p3.openElements.current)) {
      p3.openElements.pop();
    }
  }
  function startTagInForeignContent(p3, token) {
    if (causesExit(token)) {
      popUntilHtmlOrIntegrationPoint(p3);
      p3._startTagOutsideForeignContent(token);
    } else {
      const current = p3._getAdjustedCurrentElement();
      const currentNs = p3.treeAdapter.getNamespaceURI(current);
      if (currentNs === NS.MATHML) {
        adjustTokenMathMLAttrs(token);
      } else if (currentNs === NS.SVG) {
        adjustTokenSVGTagName(token);
        adjustTokenSVGAttrs(token);
      }
      adjustTokenXMLAttrs(token);
      if (token.selfClosing) {
        p3._appendElement(token, currentNs);
      } else {
        p3._insertElement(token, currentNs);
      }
      token.ackSelfClosing = true;
    }
  }
  function endTagInForeignContent(p3, token) {
    if (token.tagID === TAG_ID.P || token.tagID === TAG_ID.BR) {
      popUntilHtmlOrIntegrationPoint(p3);
      p3._endTagOutsideForeignContent(token);
      return;
    }
    for (let i3 = p3.openElements.stackTop; i3 > 0; i3--) {
      const element = p3.openElements.items[i3];
      if (p3.treeAdapter.getNamespaceURI(element) === NS.HTML) {
        p3._endTagOutsideForeignContent(token);
        break;
      }
      const tagName18 = p3.treeAdapter.getTagName(element);
      if (tagName18.toLowerCase() === token.tagName) {
        token.tagName = tagName18;
        p3.openElements.shortenToLength(i3);
        break;
      }
    }
  }

  // node_modules/parse5/dist/serializer/index.js
  var VOID_ELEMENTS = /* @__PURE__ */ new Set([
    TAG_NAMES.AREA,
    TAG_NAMES.BASE,
    TAG_NAMES.BASEFONT,
    TAG_NAMES.BGSOUND,
    TAG_NAMES.BR,
    TAG_NAMES.COL,
    TAG_NAMES.EMBED,
    TAG_NAMES.FRAME,
    TAG_NAMES.HR,
    TAG_NAMES.IMG,
    TAG_NAMES.INPUT,
    TAG_NAMES.KEYGEN,
    TAG_NAMES.LINK,
    TAG_NAMES.META,
    TAG_NAMES.PARAM,
    TAG_NAMES.SOURCE,
    TAG_NAMES.TRACK,
    TAG_NAMES.WBR
  ]);
  function isVoidElement(node, options2) {
    return options2.treeAdapter.isElementNode(node) && options2.treeAdapter.getNamespaceURI(node) === NS.HTML && VOID_ELEMENTS.has(options2.treeAdapter.getTagName(node));
  }
  var defaultOpts3 = { treeAdapter: defaultTreeAdapter, scriptingEnabled: true };
  function serializeOuter(node, options2) {
    const opts = { ...defaultOpts3, ...options2 };
    return serializeNode(node, opts);
  }
  function serializeChildNodes(parentNode, options2) {
    let html3 = "";
    const container = options2.treeAdapter.isElementNode(parentNode) && options2.treeAdapter.getTagName(parentNode) === TAG_NAMES.TEMPLATE && options2.treeAdapter.getNamespaceURI(parentNode) === NS.HTML ? options2.treeAdapter.getTemplateContent(parentNode) : parentNode;
    const childNodes = options2.treeAdapter.getChildNodes(container);
    if (childNodes) {
      for (const currentNode of childNodes) {
        html3 += serializeNode(currentNode, options2);
      }
    }
    return html3;
  }
  function serializeNode(node, options2) {
    if (options2.treeAdapter.isElementNode(node)) {
      return serializeElement(node, options2);
    }
    if (options2.treeAdapter.isTextNode(node)) {
      return serializeTextNode(node, options2);
    }
    if (options2.treeAdapter.isCommentNode(node)) {
      return serializeCommentNode(node, options2);
    }
    if (options2.treeAdapter.isDocumentTypeNode(node)) {
      return serializeDocumentTypeNode(node, options2);
    }
    return "";
  }
  function serializeElement(node, options2) {
    const tn = options2.treeAdapter.getTagName(node);
    return `<${tn}${serializeAttributes(node, options2)}>${isVoidElement(node, options2) ? "" : `${serializeChildNodes(node, options2)}</${tn}>`}`;
  }
  function serializeAttributes(node, { treeAdapter }) {
    let html3 = "";
    for (const attr2 of treeAdapter.getAttrList(node)) {
      html3 += " ";
      if (!attr2.namespace) {
        html3 += attr2.name;
      } else
        switch (attr2.namespace) {
          case NS.XML: {
            html3 += `xml:${attr2.name}`;
            break;
          }
          case NS.XMLNS: {
            if (attr2.name !== "xmlns") {
              html3 += "xmlns:";
            }
            html3 += attr2.name;
            break;
          }
          case NS.XLINK: {
            html3 += `xlink:${attr2.name}`;
            break;
          }
          default: {
            html3 += `${attr2.prefix}:${attr2.name}`;
          }
        }
      html3 += `="${escapeAttribute(attr2.value)}"`;
    }
    return html3;
  }
  function serializeTextNode(node, options2) {
    const { treeAdapter } = options2;
    const content = treeAdapter.getTextNodeContent(node);
    const parent2 = treeAdapter.getParentNode(node);
    const parentTn = parent2 && treeAdapter.isElementNode(parent2) && treeAdapter.getTagName(parent2);
    return parentTn && treeAdapter.getNamespaceURI(parent2) === NS.HTML && hasUnescapedText(parentTn, options2.scriptingEnabled) ? content : escapeText(content);
  }
  function serializeCommentNode(node, { treeAdapter }) {
    return `<!--${treeAdapter.getCommentNodeContent(node)}-->`;
  }
  function serializeDocumentTypeNode(node, { treeAdapter }) {
    return `<!DOCTYPE ${treeAdapter.getDocumentTypeNodeName(node)}>`;
  }

  // node_modules/parse5/dist/index.js
  function parse4(html3, options2) {
    return Parser.parse(html3, options2);
  }
  function parseFragment(fragmentContext, html3, options2) {
    if (typeof fragmentContext === "string") {
      options2 = html3;
      html3 = fragmentContext;
      fragmentContext = null;
    }
    const parser = Parser.getFragmentParser(fragmentContext, options2);
    parser.tokenizer.write(html3, true);
    return parser.getFragment();
  }

  // node_modules/parse5-htmlparser2-tree-adapter/dist/index.js
  function createTextNode2(value) {
    return new Text2(value);
  }
  function enquoteDoctypeId(id) {
    const quote = id.includes('"') ? "'" : '"';
    return quote + id + quote;
  }
  function serializeDoctypeContent(name, publicId, systemId) {
    let str = "!DOCTYPE ";
    if (name) {
      str += name;
    }
    if (publicId) {
      str += ` PUBLIC ${enquoteDoctypeId(publicId)}`;
    } else if (systemId) {
      str += " SYSTEM";
    }
    if (systemId) {
      str += ` ${enquoteDoctypeId(systemId)}`;
    }
    return str;
  }
  var adapter = {
    // Re-exports from domhandler
    isCommentNode: isComment,
    isElementNode: isTag2,
    isTextNode: isText,
    //Node construction
    createDocument() {
      const node = new Document([]);
      node["x-mode"] = html_exports.DOCUMENT_MODE.NO_QUIRKS;
      return node;
    },
    createDocumentFragment() {
      return new Document([]);
    },
    createElement(tagName18, namespaceURI, attrs) {
      const attribs = /* @__PURE__ */ Object.create(null);
      const attribsNamespace = /* @__PURE__ */ Object.create(null);
      const attribsPrefix = /* @__PURE__ */ Object.create(null);
      for (let i3 = 0; i3 < attrs.length; i3++) {
        const attrName = attrs[i3].name;
        attribs[attrName] = attrs[i3].value;
        attribsNamespace[attrName] = attrs[i3].namespace;
        attribsPrefix[attrName] = attrs[i3].prefix;
      }
      const node = new Element(tagName18, attribs, []);
      node.namespace = namespaceURI;
      node["x-attribsNamespace"] = attribsNamespace;
      node["x-attribsPrefix"] = attribsPrefix;
      return node;
    },
    createCommentNode(data2) {
      return new Comment2(data2);
    },
    //Tree mutation
    appendChild(parentNode, newNode) {
      const prev2 = parentNode.children[parentNode.children.length - 1];
      if (prev2) {
        prev2.next = newNode;
        newNode.prev = prev2;
      }
      parentNode.children.push(newNode);
      newNode.parent = parentNode;
    },
    insertBefore(parentNode, newNode, referenceNode) {
      const insertionIdx = parentNode.children.indexOf(referenceNode);
      const { prev: prev2 } = referenceNode;
      if (prev2) {
        prev2.next = newNode;
        newNode.prev = prev2;
      }
      referenceNode.prev = newNode;
      newNode.next = referenceNode;
      parentNode.children.splice(insertionIdx, 0, newNode);
      newNode.parent = parentNode;
    },
    setTemplateContent(templateElement, contentElement) {
      adapter.appendChild(templateElement, contentElement);
    },
    getTemplateContent(templateElement) {
      return templateElement.children[0];
    },
    setDocumentType(document2, name, publicId, systemId) {
      const data2 = serializeDoctypeContent(name, publicId, systemId);
      let doctypeNode = document2.children.find((node) => isDirective(node) && node.name === "!doctype");
      if (doctypeNode) {
        doctypeNode.data = data2 !== null && data2 !== void 0 ? data2 : null;
      } else {
        doctypeNode = new ProcessingInstruction("!doctype", data2);
        adapter.appendChild(document2, doctypeNode);
      }
      doctypeNode["x-name"] = name !== null && name !== void 0 ? name : void 0;
      doctypeNode["x-publicId"] = publicId !== null && publicId !== void 0 ? publicId : void 0;
      doctypeNode["x-systemId"] = systemId !== null && systemId !== void 0 ? systemId : void 0;
    },
    setDocumentMode(document2, mode) {
      document2["x-mode"] = mode;
    },
    getDocumentMode(document2) {
      return document2["x-mode"];
    },
    detachNode(node) {
      if (node.parent) {
        const idx = node.parent.children.indexOf(node);
        const { prev: prev2, next: next2 } = node;
        node.prev = null;
        node.next = null;
        if (prev2) {
          prev2.next = next2;
        }
        if (next2) {
          next2.prev = prev2;
        }
        node.parent.children.splice(idx, 1);
        node.parent = null;
      }
    },
    insertText(parentNode, text3) {
      const lastChild = parentNode.children[parentNode.children.length - 1];
      if (lastChild && isText(lastChild)) {
        lastChild.data += text3;
      } else {
        adapter.appendChild(parentNode, createTextNode2(text3));
      }
    },
    insertTextBefore(parentNode, text3, referenceNode) {
      const prevNode = parentNode.children[parentNode.children.indexOf(referenceNode) - 1];
      if (prevNode && isText(prevNode)) {
        prevNode.data += text3;
      } else {
        adapter.insertBefore(parentNode, createTextNode2(text3), referenceNode);
      }
    },
    adoptAttributes(recipient, attrs) {
      for (let i3 = 0; i3 < attrs.length; i3++) {
        const attrName = attrs[i3].name;
        if (typeof recipient.attribs[attrName] === "undefined") {
          recipient.attribs[attrName] = attrs[i3].value;
          recipient["x-attribsNamespace"][attrName] = attrs[i3].namespace;
          recipient["x-attribsPrefix"][attrName] = attrs[i3].prefix;
        }
      }
    },
    //Tree traversing
    getFirstChild(node) {
      return node.children[0];
    },
    getChildNodes(node) {
      return node.children;
    },
    getParentNode(node) {
      return node.parent;
    },
    getAttrList(element) {
      return element.attributes;
    },
    //Node data
    getTagName(element) {
      return element.name;
    },
    getNamespaceURI(element) {
      return element.namespace;
    },
    getTextNodeContent(textNode) {
      return textNode.data;
    },
    getCommentNodeContent(commentNode) {
      return commentNode.data;
    },
    getDocumentTypeNodeName(doctypeNode) {
      var _a2;
      return (_a2 = doctypeNode["x-name"]) !== null && _a2 !== void 0 ? _a2 : "";
    },
    getDocumentTypeNodePublicId(doctypeNode) {
      var _a2;
      return (_a2 = doctypeNode["x-publicId"]) !== null && _a2 !== void 0 ? _a2 : "";
    },
    getDocumentTypeNodeSystemId(doctypeNode) {
      var _a2;
      return (_a2 = doctypeNode["x-systemId"]) !== null && _a2 !== void 0 ? _a2 : "";
    },
    //Node types
    isDocumentTypeNode(node) {
      return isDirective(node) && node.name === "!doctype";
    },
    // Source code location
    setNodeSourceCodeLocation(node, location) {
      if (location) {
        node.startIndex = location.startOffset;
        node.endIndex = location.endOffset;
      }
      node.sourceCodeLocation = location;
    },
    getNodeSourceCodeLocation(node) {
      return node.sourceCodeLocation;
    },
    updateNodeSourceCodeLocation(node, endLocation) {
      if (endLocation.endOffset != null)
        node.endIndex = endLocation.endOffset;
      node.sourceCodeLocation = {
        ...node.sourceCodeLocation,
        ...endLocation
      };
    }
  };

  // node_modules/cheerio/lib/esm/parsers/parse5-adapter.js
  function parseWithParse5(content, options2, isDocument2, context) {
    const opts = {
      scriptingEnabled: typeof options2.scriptingEnabled === "boolean" ? options2.scriptingEnabled : true,
      treeAdapter: adapter,
      sourceCodeLocationInfo: options2.sourceCodeLocationInfo
    };
    return isDocument2 ? parse4(content, opts) : parseFragment(context, content, opts);
  }
  var renderOpts = { treeAdapter: adapter };
  function renderWithParse5(dom) {
    const nodes = "length" in dom ? dom : [dom];
    for (let index2 = 0; index2 < nodes.length; index2 += 1) {
      const node = nodes[index2];
      if (isDocument(node)) {
        Array.prototype.splice.call(nodes, index2, 1, ...node.children);
      }
    }
    let result = "";
    for (let index2 = 0; index2 < nodes.length; index2 += 1) {
      const node = nodes[index2];
      result += serializeOuter(node, renderOpts);
    }
    return result;
  }

  // node_modules/htmlparser2/lib/esm/index.js
  var esm_exports4 = {};
  __export(esm_exports4, {
    DefaultHandler: () => DomHandler,
    DomHandler: () => DomHandler,
    DomUtils: () => esm_exports2,
    ElementType: () => esm_exports,
    Parser: () => Parser2,
    Tokenizer: () => Tokenizer2,
    createDomStream: () => createDomStream,
    getFeed: () => getFeed,
    parseDOM: () => parseDOM,
    parseDocument: () => parseDocument,
    parseFeed: () => parseFeed
  });

  // node_modules/htmlparser2/lib/esm/Tokenizer.js
  var CharCodes2;
  (function(CharCodes3) {
    CharCodes3[CharCodes3["Tab"] = 9] = "Tab";
    CharCodes3[CharCodes3["NewLine"] = 10] = "NewLine";
    CharCodes3[CharCodes3["FormFeed"] = 12] = "FormFeed";
    CharCodes3[CharCodes3["CarriageReturn"] = 13] = "CarriageReturn";
    CharCodes3[CharCodes3["Space"] = 32] = "Space";
    CharCodes3[CharCodes3["ExclamationMark"] = 33] = "ExclamationMark";
    CharCodes3[CharCodes3["Num"] = 35] = "Num";
    CharCodes3[CharCodes3["Amp"] = 38] = "Amp";
    CharCodes3[CharCodes3["SingleQuote"] = 39] = "SingleQuote";
    CharCodes3[CharCodes3["DoubleQuote"] = 34] = "DoubleQuote";
    CharCodes3[CharCodes3["Dash"] = 45] = "Dash";
    CharCodes3[CharCodes3["Slash"] = 47] = "Slash";
    CharCodes3[CharCodes3["Zero"] = 48] = "Zero";
    CharCodes3[CharCodes3["Nine"] = 57] = "Nine";
    CharCodes3[CharCodes3["Semi"] = 59] = "Semi";
    CharCodes3[CharCodes3["Lt"] = 60] = "Lt";
    CharCodes3[CharCodes3["Eq"] = 61] = "Eq";
    CharCodes3[CharCodes3["Gt"] = 62] = "Gt";
    CharCodes3[CharCodes3["Questionmark"] = 63] = "Questionmark";
    CharCodes3[CharCodes3["UpperA"] = 65] = "UpperA";
    CharCodes3[CharCodes3["LowerA"] = 97] = "LowerA";
    CharCodes3[CharCodes3["UpperF"] = 70] = "UpperF";
    CharCodes3[CharCodes3["LowerF"] = 102] = "LowerF";
    CharCodes3[CharCodes3["UpperZ"] = 90] = "UpperZ";
    CharCodes3[CharCodes3["LowerZ"] = 122] = "LowerZ";
    CharCodes3[CharCodes3["LowerX"] = 120] = "LowerX";
    CharCodes3[CharCodes3["OpeningSquareBracket"] = 91] = "OpeningSquareBracket";
  })(CharCodes2 || (CharCodes2 = {}));
  var State2;
  (function(State3) {
    State3[State3["Text"] = 1] = "Text";
    State3[State3["BeforeTagName"] = 2] = "BeforeTagName";
    State3[State3["InTagName"] = 3] = "InTagName";
    State3[State3["InSelfClosingTag"] = 4] = "InSelfClosingTag";
    State3[State3["BeforeClosingTagName"] = 5] = "BeforeClosingTagName";
    State3[State3["InClosingTagName"] = 6] = "InClosingTagName";
    State3[State3["AfterClosingTagName"] = 7] = "AfterClosingTagName";
    State3[State3["BeforeAttributeName"] = 8] = "BeforeAttributeName";
    State3[State3["InAttributeName"] = 9] = "InAttributeName";
    State3[State3["AfterAttributeName"] = 10] = "AfterAttributeName";
    State3[State3["BeforeAttributeValue"] = 11] = "BeforeAttributeValue";
    State3[State3["InAttributeValueDq"] = 12] = "InAttributeValueDq";
    State3[State3["InAttributeValueSq"] = 13] = "InAttributeValueSq";
    State3[State3["InAttributeValueNq"] = 14] = "InAttributeValueNq";
    State3[State3["BeforeDeclaration"] = 15] = "BeforeDeclaration";
    State3[State3["InDeclaration"] = 16] = "InDeclaration";
    State3[State3["InProcessingInstruction"] = 17] = "InProcessingInstruction";
    State3[State3["BeforeComment"] = 18] = "BeforeComment";
    State3[State3["CDATASequence"] = 19] = "CDATASequence";
    State3[State3["InSpecialComment"] = 20] = "InSpecialComment";
    State3[State3["InCommentLike"] = 21] = "InCommentLike";
    State3[State3["BeforeSpecialS"] = 22] = "BeforeSpecialS";
    State3[State3["SpecialStartSequence"] = 23] = "SpecialStartSequence";
    State3[State3["InSpecialTag"] = 24] = "InSpecialTag";
    State3[State3["BeforeEntity"] = 25] = "BeforeEntity";
    State3[State3["BeforeNumericEntity"] = 26] = "BeforeNumericEntity";
    State3[State3["InNamedEntity"] = 27] = "InNamedEntity";
    State3[State3["InNumericEntity"] = 28] = "InNumericEntity";
    State3[State3["InHexEntity"] = 29] = "InHexEntity";
  })(State2 || (State2 = {}));
  function isWhitespace3(c3) {
    return c3 === CharCodes2.Space || c3 === CharCodes2.NewLine || c3 === CharCodes2.Tab || c3 === CharCodes2.FormFeed || c3 === CharCodes2.CarriageReturn;
  }
  function isEndOfTagSection(c3) {
    return c3 === CharCodes2.Slash || c3 === CharCodes2.Gt || isWhitespace3(c3);
  }
  function isNumber(c3) {
    return c3 >= CharCodes2.Zero && c3 <= CharCodes2.Nine;
  }
  function isASCIIAlpha(c3) {
    return c3 >= CharCodes2.LowerA && c3 <= CharCodes2.LowerZ || c3 >= CharCodes2.UpperA && c3 <= CharCodes2.UpperZ;
  }
  function isHexDigit(c3) {
    return c3 >= CharCodes2.UpperA && c3 <= CharCodes2.UpperF || c3 >= CharCodes2.LowerA && c3 <= CharCodes2.LowerF;
  }
  var QuoteType;
  (function(QuoteType2) {
    QuoteType2[QuoteType2["NoValue"] = 0] = "NoValue";
    QuoteType2[QuoteType2["Unquoted"] = 1] = "Unquoted";
    QuoteType2[QuoteType2["Single"] = 2] = "Single";
    QuoteType2[QuoteType2["Double"] = 3] = "Double";
  })(QuoteType || (QuoteType = {}));
  var Sequences = {
    Cdata: new Uint8Array([67, 68, 65, 84, 65, 91]),
    CdataEnd: new Uint8Array([93, 93, 62]),
    CommentEnd: new Uint8Array([45, 45, 62]),
    ScriptEnd: new Uint8Array([60, 47, 115, 99, 114, 105, 112, 116]),
    StyleEnd: new Uint8Array([60, 47, 115, 116, 121, 108, 101]),
    TitleEnd: new Uint8Array([60, 47, 116, 105, 116, 108, 101])
    // `</title`
  };
  var Tokenizer2 = class {
    constructor({ xmlMode = false, decodeEntities = true }, cbs) {
      this.cbs = cbs;
      this.state = State2.Text;
      this.buffer = "";
      this.sectionStart = 0;
      this.index = 0;
      this.baseState = State2.Text;
      this.isSpecial = false;
      this.running = true;
      this.offset = 0;
      this.sequenceIndex = 0;
      this.trieIndex = 0;
      this.trieCurrent = 0;
      this.entityResult = 0;
      this.entityExcess = 0;
      this.xmlMode = xmlMode;
      this.decodeEntities = decodeEntities;
      this.entityTrie = xmlMode ? decode_data_xml_default : decode_data_html_default;
    }
    reset() {
      this.state = State2.Text;
      this.buffer = "";
      this.sectionStart = 0;
      this.index = 0;
      this.baseState = State2.Text;
      this.currentSequence = void 0;
      this.running = true;
      this.offset = 0;
    }
    write(chunk) {
      this.offset += this.buffer.length;
      this.buffer = chunk;
      this.parse();
    }
    end() {
      if (this.running)
        this.finish();
    }
    pause() {
      this.running = false;
    }
    resume() {
      this.running = true;
      if (this.index < this.buffer.length + this.offset) {
        this.parse();
      }
    }
    /**
     * The current index within all of the written data.
     */
    getIndex() {
      return this.index;
    }
    /**
     * The start of the current section.
     */
    getSectionStart() {
      return this.sectionStart;
    }
    stateText(c3) {
      if (c3 === CharCodes2.Lt || !this.decodeEntities && this.fastForwardTo(CharCodes2.Lt)) {
        if (this.index > this.sectionStart) {
          this.cbs.ontext(this.sectionStart, this.index);
        }
        this.state = State2.BeforeTagName;
        this.sectionStart = this.index;
      } else if (this.decodeEntities && c3 === CharCodes2.Amp) {
        this.state = State2.BeforeEntity;
      }
    }
    stateSpecialStartSequence(c3) {
      const isEnd = this.sequenceIndex === this.currentSequence.length;
      const isMatch = isEnd ? (
        // If we are at the end of the sequence, make sure the tag name has ended
        isEndOfTagSection(c3)
      ) : (
        // Otherwise, do a case-insensitive comparison
        (c3 | 32) === this.currentSequence[this.sequenceIndex]
      );
      if (!isMatch) {
        this.isSpecial = false;
      } else if (!isEnd) {
        this.sequenceIndex++;
        return;
      }
      this.sequenceIndex = 0;
      this.state = State2.InTagName;
      this.stateInTagName(c3);
    }
    /** Look for an end tag. For <title> tags, also decode entities. */
    stateInSpecialTag(c3) {
      if (this.sequenceIndex === this.currentSequence.length) {
        if (c3 === CharCodes2.Gt || isWhitespace3(c3)) {
          const endOfText = this.index - this.currentSequence.length;
          if (this.sectionStart < endOfText) {
            const actualIndex = this.index;
            this.index = endOfText;
            this.cbs.ontext(this.sectionStart, endOfText);
            this.index = actualIndex;
          }
          this.isSpecial = false;
          this.sectionStart = endOfText + 2;
          this.stateInClosingTagName(c3);
          return;
        }
        this.sequenceIndex = 0;
      }
      if ((c3 | 32) === this.currentSequence[this.sequenceIndex]) {
        this.sequenceIndex += 1;
      } else if (this.sequenceIndex === 0) {
        if (this.currentSequence === Sequences.TitleEnd) {
          if (this.decodeEntities && c3 === CharCodes2.Amp) {
            this.state = State2.BeforeEntity;
          }
        } else if (this.fastForwardTo(CharCodes2.Lt)) {
          this.sequenceIndex = 1;
        }
      } else {
        this.sequenceIndex = Number(c3 === CharCodes2.Lt);
      }
    }
    stateCDATASequence(c3) {
      if (c3 === Sequences.Cdata[this.sequenceIndex]) {
        if (++this.sequenceIndex === Sequences.Cdata.length) {
          this.state = State2.InCommentLike;
          this.currentSequence = Sequences.CdataEnd;
          this.sequenceIndex = 0;
          this.sectionStart = this.index + 1;
        }
      } else {
        this.sequenceIndex = 0;
        this.state = State2.InDeclaration;
        this.stateInDeclaration(c3);
      }
    }
    /**
     * When we wait for one specific character, we can speed things up
     * by skipping through the buffer until we find it.
     *
     * @returns Whether the character was found.
     */
    fastForwardTo(c3) {
      while (++this.index < this.buffer.length + this.offset) {
        if (this.buffer.charCodeAt(this.index - this.offset) === c3) {
          return true;
        }
      }
      this.index = this.buffer.length + this.offset - 1;
      return false;
    }
    /**
     * Comments and CDATA end with `-->` and `]]>`.
     *
     * Their common qualities are:
     * - Their end sequences have a distinct character they start with.
     * - That character is then repeated, so we have to check multiple repeats.
     * - All characters but the start character of the sequence can be skipped.
     */
    stateInCommentLike(c3) {
      if (c3 === this.currentSequence[this.sequenceIndex]) {
        if (++this.sequenceIndex === this.currentSequence.length) {
          if (this.currentSequence === Sequences.CdataEnd) {
            this.cbs.oncdata(this.sectionStart, this.index, 2);
          } else {
            this.cbs.oncomment(this.sectionStart, this.index, 2);
          }
          this.sequenceIndex = 0;
          this.sectionStart = this.index + 1;
          this.state = State2.Text;
        }
      } else if (this.sequenceIndex === 0) {
        if (this.fastForwardTo(this.currentSequence[0])) {
          this.sequenceIndex = 1;
        }
      } else if (c3 !== this.currentSequence[this.sequenceIndex - 1]) {
        this.sequenceIndex = 0;
      }
    }
    /**
     * HTML only allows ASCII alpha characters (a-z and A-Z) at the beginning of a tag name.
     *
     * XML allows a lot more characters here (@see https://www.w3.org/TR/REC-xml/#NT-NameStartChar).
     * We allow anything that wouldn't end the tag.
     */
    isTagStartChar(c3) {
      return this.xmlMode ? !isEndOfTagSection(c3) : isASCIIAlpha(c3);
    }
    startSpecial(sequence, offset) {
      this.isSpecial = true;
      this.currentSequence = sequence;
      this.sequenceIndex = offset;
      this.state = State2.SpecialStartSequence;
    }
    stateBeforeTagName(c3) {
      if (c3 === CharCodes2.ExclamationMark) {
        this.state = State2.BeforeDeclaration;
        this.sectionStart = this.index + 1;
      } else if (c3 === CharCodes2.Questionmark) {
        this.state = State2.InProcessingInstruction;
        this.sectionStart = this.index + 1;
      } else if (this.isTagStartChar(c3)) {
        const lower = c3 | 32;
        this.sectionStart = this.index;
        if (!this.xmlMode && lower === Sequences.TitleEnd[2]) {
          this.startSpecial(Sequences.TitleEnd, 3);
        } else {
          this.state = !this.xmlMode && lower === Sequences.ScriptEnd[2] ? State2.BeforeSpecialS : State2.InTagName;
        }
      } else if (c3 === CharCodes2.Slash) {
        this.state = State2.BeforeClosingTagName;
      } else {
        this.state = State2.Text;
        this.stateText(c3);
      }
    }
    stateInTagName(c3) {
      if (isEndOfTagSection(c3)) {
        this.cbs.onopentagname(this.sectionStart, this.index);
        this.sectionStart = -1;
        this.state = State2.BeforeAttributeName;
        this.stateBeforeAttributeName(c3);
      }
    }
    stateBeforeClosingTagName(c3) {
      if (isWhitespace3(c3)) {
      } else if (c3 === CharCodes2.Gt) {
        this.state = State2.Text;
      } else {
        this.state = this.isTagStartChar(c3) ? State2.InClosingTagName : State2.InSpecialComment;
        this.sectionStart = this.index;
      }
    }
    stateInClosingTagName(c3) {
      if (c3 === CharCodes2.Gt || isWhitespace3(c3)) {
        this.cbs.onclosetag(this.sectionStart, this.index);
        this.sectionStart = -1;
        this.state = State2.AfterClosingTagName;
        this.stateAfterClosingTagName(c3);
      }
    }
    stateAfterClosingTagName(c3) {
      if (c3 === CharCodes2.Gt || this.fastForwardTo(CharCodes2.Gt)) {
        this.state = State2.Text;
        this.sectionStart = this.index + 1;
      }
    }
    stateBeforeAttributeName(c3) {
      if (c3 === CharCodes2.Gt) {
        this.cbs.onopentagend(this.index);
        if (this.isSpecial) {
          this.state = State2.InSpecialTag;
          this.sequenceIndex = 0;
        } else {
          this.state = State2.Text;
        }
        this.baseState = this.state;
        this.sectionStart = this.index + 1;
      } else if (c3 === CharCodes2.Slash) {
        this.state = State2.InSelfClosingTag;
      } else if (!isWhitespace3(c3)) {
        this.state = State2.InAttributeName;
        this.sectionStart = this.index;
      }
    }
    stateInSelfClosingTag(c3) {
      if (c3 === CharCodes2.Gt) {
        this.cbs.onselfclosingtag(this.index);
        this.state = State2.Text;
        this.baseState = State2.Text;
        this.sectionStart = this.index + 1;
        this.isSpecial = false;
      } else if (!isWhitespace3(c3)) {
        this.state = State2.BeforeAttributeName;
        this.stateBeforeAttributeName(c3);
      }
    }
    stateInAttributeName(c3) {
      if (c3 === CharCodes2.Eq || isEndOfTagSection(c3)) {
        this.cbs.onattribname(this.sectionStart, this.index);
        this.sectionStart = -1;
        this.state = State2.AfterAttributeName;
        this.stateAfterAttributeName(c3);
      }
    }
    stateAfterAttributeName(c3) {
      if (c3 === CharCodes2.Eq) {
        this.state = State2.BeforeAttributeValue;
      } else if (c3 === CharCodes2.Slash || c3 === CharCodes2.Gt) {
        this.cbs.onattribend(QuoteType.NoValue, this.index);
        this.state = State2.BeforeAttributeName;
        this.stateBeforeAttributeName(c3);
      } else if (!isWhitespace3(c3)) {
        this.cbs.onattribend(QuoteType.NoValue, this.index);
        this.state = State2.InAttributeName;
        this.sectionStart = this.index;
      }
    }
    stateBeforeAttributeValue(c3) {
      if (c3 === CharCodes2.DoubleQuote) {
        this.state = State2.InAttributeValueDq;
        this.sectionStart = this.index + 1;
      } else if (c3 === CharCodes2.SingleQuote) {
        this.state = State2.InAttributeValueSq;
        this.sectionStart = this.index + 1;
      } else if (!isWhitespace3(c3)) {
        this.sectionStart = this.index;
        this.state = State2.InAttributeValueNq;
        this.stateInAttributeValueNoQuotes(c3);
      }
    }
    handleInAttributeValue(c3, quote) {
      if (c3 === quote || !this.decodeEntities && this.fastForwardTo(quote)) {
        this.cbs.onattribdata(this.sectionStart, this.index);
        this.sectionStart = -1;
        this.cbs.onattribend(quote === CharCodes2.DoubleQuote ? QuoteType.Double : QuoteType.Single, this.index);
        this.state = State2.BeforeAttributeName;
      } else if (this.decodeEntities && c3 === CharCodes2.Amp) {
        this.baseState = this.state;
        this.state = State2.BeforeEntity;
      }
    }
    stateInAttributeValueDoubleQuotes(c3) {
      this.handleInAttributeValue(c3, CharCodes2.DoubleQuote);
    }
    stateInAttributeValueSingleQuotes(c3) {
      this.handleInAttributeValue(c3, CharCodes2.SingleQuote);
    }
    stateInAttributeValueNoQuotes(c3) {
      if (isWhitespace3(c3) || c3 === CharCodes2.Gt) {
        this.cbs.onattribdata(this.sectionStart, this.index);
        this.sectionStart = -1;
        this.cbs.onattribend(QuoteType.Unquoted, this.index);
        this.state = State2.BeforeAttributeName;
        this.stateBeforeAttributeName(c3);
      } else if (this.decodeEntities && c3 === CharCodes2.Amp) {
        this.baseState = this.state;
        this.state = State2.BeforeEntity;
      }
    }
    stateBeforeDeclaration(c3) {
      if (c3 === CharCodes2.OpeningSquareBracket) {
        this.state = State2.CDATASequence;
        this.sequenceIndex = 0;
      } else {
        this.state = c3 === CharCodes2.Dash ? State2.BeforeComment : State2.InDeclaration;
      }
    }
    stateInDeclaration(c3) {
      if (c3 === CharCodes2.Gt || this.fastForwardTo(CharCodes2.Gt)) {
        this.cbs.ondeclaration(this.sectionStart, this.index);
        this.state = State2.Text;
        this.sectionStart = this.index + 1;
      }
    }
    stateInProcessingInstruction(c3) {
      if (c3 === CharCodes2.Gt || this.fastForwardTo(CharCodes2.Gt)) {
        this.cbs.onprocessinginstruction(this.sectionStart, this.index);
        this.state = State2.Text;
        this.sectionStart = this.index + 1;
      }
    }
    stateBeforeComment(c3) {
      if (c3 === CharCodes2.Dash) {
        this.state = State2.InCommentLike;
        this.currentSequence = Sequences.CommentEnd;
        this.sequenceIndex = 2;
        this.sectionStart = this.index + 1;
      } else {
        this.state = State2.InDeclaration;
      }
    }
    stateInSpecialComment(c3) {
      if (c3 === CharCodes2.Gt || this.fastForwardTo(CharCodes2.Gt)) {
        this.cbs.oncomment(this.sectionStart, this.index, 0);
        this.state = State2.Text;
        this.sectionStart = this.index + 1;
      }
    }
    stateBeforeSpecialS(c3) {
      const lower = c3 | 32;
      if (lower === Sequences.ScriptEnd[3]) {
        this.startSpecial(Sequences.ScriptEnd, 4);
      } else if (lower === Sequences.StyleEnd[3]) {
        this.startSpecial(Sequences.StyleEnd, 4);
      } else {
        this.state = State2.InTagName;
        this.stateInTagName(c3);
      }
    }
    stateBeforeEntity(c3) {
      this.entityExcess = 1;
      this.entityResult = 0;
      if (c3 === CharCodes2.Num) {
        this.state = State2.BeforeNumericEntity;
      } else if (c3 === CharCodes2.Amp) {
      } else {
        this.trieIndex = 0;
        this.trieCurrent = this.entityTrie[0];
        this.state = State2.InNamedEntity;
        this.stateInNamedEntity(c3);
      }
    }
    stateInNamedEntity(c3) {
      this.entityExcess += 1;
      this.trieIndex = determineBranch(this.entityTrie, this.trieCurrent, this.trieIndex + 1, c3);
      if (this.trieIndex < 0) {
        this.emitNamedEntity();
        this.index--;
        return;
      }
      this.trieCurrent = this.entityTrie[this.trieIndex];
      const masked = this.trieCurrent & BinTrieFlags.VALUE_LENGTH;
      if (masked) {
        const valueLength = (masked >> 14) - 1;
        if (!this.allowLegacyEntity() && c3 !== CharCodes2.Semi) {
          this.trieIndex += valueLength;
        } else {
          const entityStart = this.index - this.entityExcess + 1;
          if (entityStart > this.sectionStart) {
            this.emitPartial(this.sectionStart, entityStart);
          }
          this.entityResult = this.trieIndex;
          this.trieIndex += valueLength;
          this.entityExcess = 0;
          this.sectionStart = this.index + 1;
          if (valueLength === 0) {
            this.emitNamedEntity();
          }
        }
      }
    }
    emitNamedEntity() {
      this.state = this.baseState;
      if (this.entityResult === 0) {
        return;
      }
      const valueLength = (this.entityTrie[this.entityResult] & BinTrieFlags.VALUE_LENGTH) >> 14;
      switch (valueLength) {
        case 1:
          this.emitCodePoint(this.entityTrie[this.entityResult] & ~BinTrieFlags.VALUE_LENGTH);
          break;
        case 2:
          this.emitCodePoint(this.entityTrie[this.entityResult + 1]);
          break;
        case 3: {
          this.emitCodePoint(this.entityTrie[this.entityResult + 1]);
          this.emitCodePoint(this.entityTrie[this.entityResult + 2]);
        }
      }
    }
    stateBeforeNumericEntity(c3) {
      if ((c3 | 32) === CharCodes2.LowerX) {
        this.entityExcess++;
        this.state = State2.InHexEntity;
      } else {
        this.state = State2.InNumericEntity;
        this.stateInNumericEntity(c3);
      }
    }
    emitNumericEntity(strict) {
      const entityStart = this.index - this.entityExcess - 1;
      const numberStart = entityStart + 2 + Number(this.state === State2.InHexEntity);
      if (numberStart !== this.index) {
        if (entityStart > this.sectionStart) {
          this.emitPartial(this.sectionStart, entityStart);
        }
        this.sectionStart = this.index + Number(strict);
        this.emitCodePoint(replaceCodePoint(this.entityResult));
      }
      this.state = this.baseState;
    }
    stateInNumericEntity(c3) {
      if (c3 === CharCodes2.Semi) {
        this.emitNumericEntity(true);
      } else if (isNumber(c3)) {
        this.entityResult = this.entityResult * 10 + (c3 - CharCodes2.Zero);
        this.entityExcess++;
      } else {
        if (this.allowLegacyEntity()) {
          this.emitNumericEntity(false);
        } else {
          this.state = this.baseState;
        }
        this.index--;
      }
    }
    stateInHexEntity(c3) {
      if (c3 === CharCodes2.Semi) {
        this.emitNumericEntity(true);
      } else if (isNumber(c3)) {
        this.entityResult = this.entityResult * 16 + (c3 - CharCodes2.Zero);
        this.entityExcess++;
      } else if (isHexDigit(c3)) {
        this.entityResult = this.entityResult * 16 + ((c3 | 32) - CharCodes2.LowerA + 10);
        this.entityExcess++;
      } else {
        if (this.allowLegacyEntity()) {
          this.emitNumericEntity(false);
        } else {
          this.state = this.baseState;
        }
        this.index--;
      }
    }
    allowLegacyEntity() {
      return !this.xmlMode && (this.baseState === State2.Text || this.baseState === State2.InSpecialTag);
    }
    /**
     * Remove data that has already been consumed from the buffer.
     */
    cleanup() {
      if (this.running && this.sectionStart !== this.index) {
        if (this.state === State2.Text || this.state === State2.InSpecialTag && this.sequenceIndex === 0) {
          this.cbs.ontext(this.sectionStart, this.index);
          this.sectionStart = this.index;
        } else if (this.state === State2.InAttributeValueDq || this.state === State2.InAttributeValueSq || this.state === State2.InAttributeValueNq) {
          this.cbs.onattribdata(this.sectionStart, this.index);
          this.sectionStart = this.index;
        }
      }
    }
    shouldContinue() {
      return this.index < this.buffer.length + this.offset && this.running;
    }
    /**
     * Iterates through the buffer, calling the function corresponding to the current state.
     *
     * States that are more likely to be hit are higher up, as a performance improvement.
     */
    parse() {
      while (this.shouldContinue()) {
        const c3 = this.buffer.charCodeAt(this.index - this.offset);
        if (this.state === State2.Text) {
          this.stateText(c3);
        } else if (this.state === State2.SpecialStartSequence) {
          this.stateSpecialStartSequence(c3);
        } else if (this.state === State2.InSpecialTag) {
          this.stateInSpecialTag(c3);
        } else if (this.state === State2.CDATASequence) {
          this.stateCDATASequence(c3);
        } else if (this.state === State2.InAttributeValueDq) {
          this.stateInAttributeValueDoubleQuotes(c3);
        } else if (this.state === State2.InAttributeName) {
          this.stateInAttributeName(c3);
        } else if (this.state === State2.InCommentLike) {
          this.stateInCommentLike(c3);
        } else if (this.state === State2.InSpecialComment) {
          this.stateInSpecialComment(c3);
        } else if (this.state === State2.BeforeAttributeName) {
          this.stateBeforeAttributeName(c3);
        } else if (this.state === State2.InTagName) {
          this.stateInTagName(c3);
        } else if (this.state === State2.InClosingTagName) {
          this.stateInClosingTagName(c3);
        } else if (this.state === State2.BeforeTagName) {
          this.stateBeforeTagName(c3);
        } else if (this.state === State2.AfterAttributeName) {
          this.stateAfterAttributeName(c3);
        } else if (this.state === State2.InAttributeValueSq) {
          this.stateInAttributeValueSingleQuotes(c3);
        } else if (this.state === State2.BeforeAttributeValue) {
          this.stateBeforeAttributeValue(c3);
        } else if (this.state === State2.BeforeClosingTagName) {
          this.stateBeforeClosingTagName(c3);
        } else if (this.state === State2.AfterClosingTagName) {
          this.stateAfterClosingTagName(c3);
        } else if (this.state === State2.BeforeSpecialS) {
          this.stateBeforeSpecialS(c3);
        } else if (this.state === State2.InAttributeValueNq) {
          this.stateInAttributeValueNoQuotes(c3);
        } else if (this.state === State2.InSelfClosingTag) {
          this.stateInSelfClosingTag(c3);
        } else if (this.state === State2.InDeclaration) {
          this.stateInDeclaration(c3);
        } else if (this.state === State2.BeforeDeclaration) {
          this.stateBeforeDeclaration(c3);
        } else if (this.state === State2.BeforeComment) {
          this.stateBeforeComment(c3);
        } else if (this.state === State2.InProcessingInstruction) {
          this.stateInProcessingInstruction(c3);
        } else if (this.state === State2.InNamedEntity) {
          this.stateInNamedEntity(c3);
        } else if (this.state === State2.BeforeEntity) {
          this.stateBeforeEntity(c3);
        } else if (this.state === State2.InHexEntity) {
          this.stateInHexEntity(c3);
        } else if (this.state === State2.InNumericEntity) {
          this.stateInNumericEntity(c3);
        } else {
          this.stateBeforeNumericEntity(c3);
        }
        this.index++;
      }
      this.cleanup();
    }
    finish() {
      if (this.state === State2.InNamedEntity) {
        this.emitNamedEntity();
      }
      if (this.sectionStart < this.index) {
        this.handleTrailingData();
      }
      this.cbs.onend();
    }
    /** Handle any trailing data. */
    handleTrailingData() {
      const endIndex = this.buffer.length + this.offset;
      if (this.state === State2.InCommentLike) {
        if (this.currentSequence === Sequences.CdataEnd) {
          this.cbs.oncdata(this.sectionStart, endIndex, 0);
        } else {
          this.cbs.oncomment(this.sectionStart, endIndex, 0);
        }
      } else if (this.state === State2.InNumericEntity && this.allowLegacyEntity()) {
        this.emitNumericEntity(false);
      } else if (this.state === State2.InHexEntity && this.allowLegacyEntity()) {
        this.emitNumericEntity(false);
      } else if (this.state === State2.InTagName || this.state === State2.BeforeAttributeName || this.state === State2.BeforeAttributeValue || this.state === State2.AfterAttributeName || this.state === State2.InAttributeName || this.state === State2.InAttributeValueSq || this.state === State2.InAttributeValueDq || this.state === State2.InAttributeValueNq || this.state === State2.InClosingTagName) {
      } else {
        this.cbs.ontext(this.sectionStart, endIndex);
      }
    }
    emitPartial(start, endIndex) {
      if (this.baseState !== State2.Text && this.baseState !== State2.InSpecialTag) {
        this.cbs.onattribdata(start, endIndex);
      } else {
        this.cbs.ontext(start, endIndex);
      }
    }
    emitCodePoint(cp) {
      if (this.baseState !== State2.Text && this.baseState !== State2.InSpecialTag) {
        this.cbs.onattribentity(cp);
      } else {
        this.cbs.ontextentity(cp);
      }
    }
  };

  // node_modules/htmlparser2/lib/esm/Parser.js
  var formTags = /* @__PURE__ */ new Set([
    "input",
    "option",
    "optgroup",
    "select",
    "button",
    "datalist",
    "textarea"
  ]);
  var pTag = /* @__PURE__ */ new Set(["p"]);
  var tableSectionTags = /* @__PURE__ */ new Set(["thead", "tbody"]);
  var ddtTags = /* @__PURE__ */ new Set(["dd", "dt"]);
  var rtpTags = /* @__PURE__ */ new Set(["rt", "rp"]);
  var openImpliesClose = /* @__PURE__ */ new Map([
    ["tr", /* @__PURE__ */ new Set(["tr", "th", "td"])],
    ["th", /* @__PURE__ */ new Set(["th"])],
    ["td", /* @__PURE__ */ new Set(["thead", "th", "td"])],
    ["body", /* @__PURE__ */ new Set(["head", "link", "script"])],
    ["li", /* @__PURE__ */ new Set(["li"])],
    ["p", pTag],
    ["h1", pTag],
    ["h2", pTag],
    ["h3", pTag],
    ["h4", pTag],
    ["h5", pTag],
    ["h6", pTag],
    ["select", formTags],
    ["input", formTags],
    ["output", formTags],
    ["button", formTags],
    ["datalist", formTags],
    ["textarea", formTags],
    ["option", /* @__PURE__ */ new Set(["option"])],
    ["optgroup", /* @__PURE__ */ new Set(["optgroup", "option"])],
    ["dd", ddtTags],
    ["dt", ddtTags],
    ["address", pTag],
    ["article", pTag],
    ["aside", pTag],
    ["blockquote", pTag],
    ["details", pTag],
    ["div", pTag],
    ["dl", pTag],
    ["fieldset", pTag],
    ["figcaption", pTag],
    ["figure", pTag],
    ["footer", pTag],
    ["form", pTag],
    ["header", pTag],
    ["hr", pTag],
    ["main", pTag],
    ["nav", pTag],
    ["ol", pTag],
    ["pre", pTag],
    ["section", pTag],
    ["table", pTag],
    ["ul", pTag],
    ["rt", rtpTags],
    ["rp", rtpTags],
    ["tbody", tableSectionTags],
    ["tfoot", tableSectionTags]
  ]);
  var voidElements = /* @__PURE__ */ new Set([
    "area",
    "base",
    "basefont",
    "br",
    "col",
    "command",
    "embed",
    "frame",
    "hr",
    "img",
    "input",
    "isindex",
    "keygen",
    "link",
    "meta",
    "param",
    "source",
    "track",
    "wbr"
  ]);
  var foreignContextElements = /* @__PURE__ */ new Set(["math", "svg"]);
  var htmlIntegrationElements = /* @__PURE__ */ new Set([
    "mi",
    "mo",
    "mn",
    "ms",
    "mtext",
    "annotation-xml",
    "foreignobject",
    "desc",
    "title"
  ]);
  var reNameEnd = /\s|\//;
  var Parser2 = class {
    constructor(cbs, options2 = {}) {
      var _a2, _b, _c, _d, _e;
      this.options = options2;
      this.startIndex = 0;
      this.endIndex = 0;
      this.openTagStart = 0;
      this.tagname = "";
      this.attribname = "";
      this.attribvalue = "";
      this.attribs = null;
      this.stack = [];
      this.foreignContext = [];
      this.buffers = [];
      this.bufferOffset = 0;
      this.writeIndex = 0;
      this.ended = false;
      this.cbs = cbs !== null && cbs !== void 0 ? cbs : {};
      this.lowerCaseTagNames = (_a2 = options2.lowerCaseTags) !== null && _a2 !== void 0 ? _a2 : !options2.xmlMode;
      this.lowerCaseAttributeNames = (_b = options2.lowerCaseAttributeNames) !== null && _b !== void 0 ? _b : !options2.xmlMode;
      this.tokenizer = new ((_c = options2.Tokenizer) !== null && _c !== void 0 ? _c : Tokenizer2)(this.options, this);
      (_e = (_d = this.cbs).onparserinit) === null || _e === void 0 ? void 0 : _e.call(_d, this);
    }
    // Tokenizer event handlers
    /** @internal */
    ontext(start, endIndex) {
      var _a2, _b;
      const data2 = this.getSlice(start, endIndex);
      this.endIndex = endIndex - 1;
      (_b = (_a2 = this.cbs).ontext) === null || _b === void 0 ? void 0 : _b.call(_a2, data2);
      this.startIndex = endIndex;
    }
    /** @internal */
    ontextentity(cp) {
      var _a2, _b;
      const idx = this.tokenizer.getSectionStart();
      this.endIndex = idx - 1;
      (_b = (_a2 = this.cbs).ontext) === null || _b === void 0 ? void 0 : _b.call(_a2, fromCodePoint(cp));
      this.startIndex = idx;
    }
    isVoidElement(name) {
      return !this.options.xmlMode && voidElements.has(name);
    }
    /** @internal */
    onopentagname(start, endIndex) {
      this.endIndex = endIndex;
      let name = this.getSlice(start, endIndex);
      if (this.lowerCaseTagNames) {
        name = name.toLowerCase();
      }
      this.emitOpenTag(name);
    }
    emitOpenTag(name) {
      var _a2, _b, _c, _d;
      this.openTagStart = this.startIndex;
      this.tagname = name;
      const impliesClose = !this.options.xmlMode && openImpliesClose.get(name);
      if (impliesClose) {
        while (this.stack.length > 0 && impliesClose.has(this.stack[this.stack.length - 1])) {
          const el = this.stack.pop();
          (_b = (_a2 = this.cbs).onclosetag) === null || _b === void 0 ? void 0 : _b.call(_a2, el, true);
        }
      }
      if (!this.isVoidElement(name)) {
        this.stack.push(name);
        if (foreignContextElements.has(name)) {
          this.foreignContext.push(true);
        } else if (htmlIntegrationElements.has(name)) {
          this.foreignContext.push(false);
        }
      }
      (_d = (_c = this.cbs).onopentagname) === null || _d === void 0 ? void 0 : _d.call(_c, name);
      if (this.cbs.onopentag)
        this.attribs = {};
    }
    endOpenTag(isImplied) {
      var _a2, _b;
      this.startIndex = this.openTagStart;
      if (this.attribs) {
        (_b = (_a2 = this.cbs).onopentag) === null || _b === void 0 ? void 0 : _b.call(_a2, this.tagname, this.attribs, isImplied);
        this.attribs = null;
      }
      if (this.cbs.onclosetag && this.isVoidElement(this.tagname)) {
        this.cbs.onclosetag(this.tagname, true);
      }
      this.tagname = "";
    }
    /** @internal */
    onopentagend(endIndex) {
      this.endIndex = endIndex;
      this.endOpenTag(false);
      this.startIndex = endIndex + 1;
    }
    /** @internal */
    onclosetag(start, endIndex) {
      var _a2, _b, _c, _d, _e, _f;
      this.endIndex = endIndex;
      let name = this.getSlice(start, endIndex);
      if (this.lowerCaseTagNames) {
        name = name.toLowerCase();
      }
      if (foreignContextElements.has(name) || htmlIntegrationElements.has(name)) {
        this.foreignContext.pop();
      }
      if (!this.isVoidElement(name)) {
        const pos = this.stack.lastIndexOf(name);
        if (pos !== -1) {
          if (this.cbs.onclosetag) {
            let count = this.stack.length - pos;
            while (count--) {
              this.cbs.onclosetag(this.stack.pop(), count !== 0);
            }
          } else
            this.stack.length = pos;
        } else if (!this.options.xmlMode && name === "p") {
          this.emitOpenTag("p");
          this.closeCurrentTag(true);
        }
      } else if (!this.options.xmlMode && name === "br") {
        (_b = (_a2 = this.cbs).onopentagname) === null || _b === void 0 ? void 0 : _b.call(_a2, "br");
        (_d = (_c = this.cbs).onopentag) === null || _d === void 0 ? void 0 : _d.call(_c, "br", {}, true);
        (_f = (_e = this.cbs).onclosetag) === null || _f === void 0 ? void 0 : _f.call(_e, "br", false);
      }
      this.startIndex = endIndex + 1;
    }
    /** @internal */
    onselfclosingtag(endIndex) {
      this.endIndex = endIndex;
      if (this.options.xmlMode || this.options.recognizeSelfClosing || this.foreignContext[this.foreignContext.length - 1]) {
        this.closeCurrentTag(false);
        this.startIndex = endIndex + 1;
      } else {
        this.onopentagend(endIndex);
      }
    }
    closeCurrentTag(isOpenImplied) {
      var _a2, _b;
      const name = this.tagname;
      this.endOpenTag(isOpenImplied);
      if (this.stack[this.stack.length - 1] === name) {
        (_b = (_a2 = this.cbs).onclosetag) === null || _b === void 0 ? void 0 : _b.call(_a2, name, !isOpenImplied);
        this.stack.pop();
      }
    }
    /** @internal */
    onattribname(start, endIndex) {
      this.startIndex = start;
      const name = this.getSlice(start, endIndex);
      this.attribname = this.lowerCaseAttributeNames ? name.toLowerCase() : name;
    }
    /** @internal */
    onattribdata(start, endIndex) {
      this.attribvalue += this.getSlice(start, endIndex);
    }
    /** @internal */
    onattribentity(cp) {
      this.attribvalue += fromCodePoint(cp);
    }
    /** @internal */
    onattribend(quote, endIndex) {
      var _a2, _b;
      this.endIndex = endIndex;
      (_b = (_a2 = this.cbs).onattribute) === null || _b === void 0 ? void 0 : _b.call(_a2, this.attribname, this.attribvalue, quote === QuoteType.Double ? '"' : quote === QuoteType.Single ? "'" : quote === QuoteType.NoValue ? void 0 : null);
      if (this.attribs && !Object.prototype.hasOwnProperty.call(this.attribs, this.attribname)) {
        this.attribs[this.attribname] = this.attribvalue;
      }
      this.attribvalue = "";
    }
    getInstructionName(value) {
      const idx = value.search(reNameEnd);
      let name = idx < 0 ? value : value.substr(0, idx);
      if (this.lowerCaseTagNames) {
        name = name.toLowerCase();
      }
      return name;
    }
    /** @internal */
    ondeclaration(start, endIndex) {
      this.endIndex = endIndex;
      const value = this.getSlice(start, endIndex);
      if (this.cbs.onprocessinginstruction) {
        const name = this.getInstructionName(value);
        this.cbs.onprocessinginstruction(`!${name}`, `!${value}`);
      }
      this.startIndex = endIndex + 1;
    }
    /** @internal */
    onprocessinginstruction(start, endIndex) {
      this.endIndex = endIndex;
      const value = this.getSlice(start, endIndex);
      if (this.cbs.onprocessinginstruction) {
        const name = this.getInstructionName(value);
        this.cbs.onprocessinginstruction(`?${name}`, `?${value}`);
      }
      this.startIndex = endIndex + 1;
    }
    /** @internal */
    oncomment(start, endIndex, offset) {
      var _a2, _b, _c, _d;
      this.endIndex = endIndex;
      (_b = (_a2 = this.cbs).oncomment) === null || _b === void 0 ? void 0 : _b.call(_a2, this.getSlice(start, endIndex - offset));
      (_d = (_c = this.cbs).oncommentend) === null || _d === void 0 ? void 0 : _d.call(_c);
      this.startIndex = endIndex + 1;
    }
    /** @internal */
    oncdata(start, endIndex, offset) {
      var _a2, _b, _c, _d, _e, _f, _g, _h, _j, _k;
      this.endIndex = endIndex;
      const value = this.getSlice(start, endIndex - offset);
      if (this.options.xmlMode || this.options.recognizeCDATA) {
        (_b = (_a2 = this.cbs).oncdatastart) === null || _b === void 0 ? void 0 : _b.call(_a2);
        (_d = (_c = this.cbs).ontext) === null || _d === void 0 ? void 0 : _d.call(_c, value);
        (_f = (_e = this.cbs).oncdataend) === null || _f === void 0 ? void 0 : _f.call(_e);
      } else {
        (_h = (_g = this.cbs).oncomment) === null || _h === void 0 ? void 0 : _h.call(_g, `[CDATA[${value}]]`);
        (_k = (_j = this.cbs).oncommentend) === null || _k === void 0 ? void 0 : _k.call(_j);
      }
      this.startIndex = endIndex + 1;
    }
    /** @internal */
    onend() {
      var _a2, _b;
      if (this.cbs.onclosetag) {
        this.endIndex = this.startIndex;
        for (let i3 = this.stack.length; i3 > 0; this.cbs.onclosetag(this.stack[--i3], true))
          ;
      }
      (_b = (_a2 = this.cbs).onend) === null || _b === void 0 ? void 0 : _b.call(_a2);
    }
    /**
     * Resets the parser to a blank state, ready to parse a new HTML document
     */
    reset() {
      var _a2, _b, _c, _d;
      (_b = (_a2 = this.cbs).onreset) === null || _b === void 0 ? void 0 : _b.call(_a2);
      this.tokenizer.reset();
      this.tagname = "";
      this.attribname = "";
      this.attribs = null;
      this.stack.length = 0;
      this.startIndex = 0;
      this.endIndex = 0;
      (_d = (_c = this.cbs).onparserinit) === null || _d === void 0 ? void 0 : _d.call(_c, this);
      this.buffers.length = 0;
      this.bufferOffset = 0;
      this.writeIndex = 0;
      this.ended = false;
    }
    /**
     * Resets the parser, then parses a complete document and
     * pushes it to the handler.
     *
     * @param data Document to parse.
     */
    parseComplete(data2) {
      this.reset();
      this.end(data2);
    }
    getSlice(start, end2) {
      while (start - this.bufferOffset >= this.buffers[0].length) {
        this.shiftBuffer();
      }
      let str = this.buffers[0].slice(start - this.bufferOffset, end2 - this.bufferOffset);
      while (end2 - this.bufferOffset > this.buffers[0].length) {
        this.shiftBuffer();
        str += this.buffers[0].slice(0, end2 - this.bufferOffset);
      }
      return str;
    }
    shiftBuffer() {
      this.bufferOffset += this.buffers[0].length;
      this.writeIndex--;
      this.buffers.shift();
    }
    /**
     * Parses a chunk of data and calls the corresponding callbacks.
     *
     * @param chunk Chunk to parse.
     */
    write(chunk) {
      var _a2, _b;
      if (this.ended) {
        (_b = (_a2 = this.cbs).onerror) === null || _b === void 0 ? void 0 : _b.call(_a2, new Error(".write() after done!"));
        return;
      }
      this.buffers.push(chunk);
      if (this.tokenizer.running) {
        this.tokenizer.write(chunk);
        this.writeIndex++;
      }
    }
    /**
     * Parses the end of the buffer and clears the stack, calls onend.
     *
     * @param chunk Optional final chunk to parse.
     */
    end(chunk) {
      var _a2, _b;
      if (this.ended) {
        (_b = (_a2 = this.cbs).onerror) === null || _b === void 0 ? void 0 : _b.call(_a2, Error(".end() after done!"));
        return;
      }
      if (chunk)
        this.write(chunk);
      this.ended = true;
      this.tokenizer.end();
    }
    /**
     * Pauses parsing. The parser won't emit events until `resume` is called.
     */
    pause() {
      this.tokenizer.pause();
    }
    /**
     * Resumes parsing after `pause` was called.
     */
    resume() {
      this.tokenizer.resume();
      while (this.tokenizer.running && this.writeIndex < this.buffers.length) {
        this.tokenizer.write(this.buffers[this.writeIndex++]);
      }
      if (this.ended)
        this.tokenizer.end();
    }
    /**
     * Alias of `write`, for backwards compatibility.
     *
     * @param chunk Chunk to parse.
     * @deprecated
     */
    parseChunk(chunk) {
      this.write(chunk);
    }
    /**
     * Alias of `end`, for backwards compatibility.
     *
     * @param chunk Optional final chunk to parse.
     * @deprecated
     */
    done(chunk) {
      this.end(chunk);
    }
  };

  // node_modules/htmlparser2/lib/esm/index.js
  function parseDocument(data2, options2) {
    const handler4 = new DomHandler(void 0, options2);
    new Parser2(handler4, options2).end(data2);
    return handler4.root;
  }
  function parseDOM(data2, options2) {
    return parseDocument(data2, options2).children;
  }
  function createDomStream(cb, options2, elementCb) {
    const handler4 = new DomHandler(cb, options2, elementCb);
    return new Parser2(handler4, options2);
  }
  function parseFeed(feed, options2 = { xmlMode: true }) {
    return getFeed(parseDOM(feed, options2));
  }

  // node_modules/cheerio/lib/esm/index.js
  var parse5 = getParse((content, options2, isDocument2, context) => options2.xmlMode || options2._useHtmlParser2 ? parseDocument(content, options2) : parseWithParse5(content, options2, isDocument2, context));
  var load = getLoad(parse5, (dom, options2) => options2.xmlMode || options2._useHtmlParser2 ? esm_default(dom, options2) : renderWithParse5(dom));
  var esm_default2 = load([]);
  var { contains: contains2 } = static_exports;
  var { merge: merge2 } = static_exports;
  var { parseHTML: parseHTML2 } = static_exports;
  var { root: root3 } = static_exports;

  // src/content-scripts/web_search.ts
  var import_webextension_polyfill5 = __toESM(require_browser_polyfill());
  var BASE_URL = "https://sg.search.yahoo.com/search";
  function extractRealUrl(url) {
    const match = url.match(/RU=([^/]+)/);
    if (match && match[1]) {
      return decodeURIComponent(match[1]);
    }
    return url;
  }
  function htmlToSearchResults(html3, numResults) {
    const $3 = esm_default2.load(html3);
    const results = [];
    const rightPanel = $3("#right .searchRightTop");
    if (rightPanel.length) {
      const rightPanelLink = rightPanel.find(".compText a").first();
      const rightPanelInfo = rightPanel.find(".compInfo li");
      const rightPanelInfoText = rightPanelInfo.map((_2, el) => $3(el).text().trim()).get().join("\n");
      results.push({
        title: rightPanelLink.text().trim(),
        body: `${rightPanel.find(".compText").text().trim()}${rightPanelInfoText ? `

${rightPanelInfoText}` : ""}`,
        url: extractRealUrl(rightPanelLink.attr("href") ?? "")
      });
    }
    $3('.algo-sr:not([class*="ad"])').slice(0, numResults).each((_2, el) => {
      const element = $3(el);
      const titleElement = element.find("h3.title a");
      results.push({
        title: titleElement.attr("aria-label") ?? "",
        body: element.find(".compText").text().trim(),
        url: extractRealUrl(titleElement.attr("href") ?? "")
      });
    });
    return results;
  }
  async function webSearch(search, numResults) {
    const response = await import_webextension_polyfill5.default.runtime.sendMessage({
      type: "get_search_results",
      search
    });
    let results;
    if (response.url.startsWith(BASE_URL)) {
      results = htmlToSearchResults(response.html, numResults);
    } else {
      const result = await import_webextension_polyfill5.default.runtime.sendMessage({
        type: "get_webpage_text",
        url: response.url,
        html: response.html
      });
      return [{
        title: result.title,
        body: result.body,
        url: response.url
      }];
    }
    return results;
  }

  // src/util/createShadowRoot.ts
  var import_webextension_polyfill6 = __toESM(require_browser_polyfill());
  async function createShadowRoot(pathToCSS) {
    const shadowRootDiv = document.createElement("div");
    const shadowRoot = shadowRootDiv.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = await fetch(import_webextension_polyfill6.default.runtime.getURL(pathToCSS)).then((response) => response.text());
    shadowRoot.append(style);
    return { shadowRootDiv, shadowRoot };
  }
  var createShadowRoot_default = createShadowRoot;

  // src/components/slashCommandsMenu.tsx
  var slashCommands = [
    {
      name: "/site:",
      description: localizationKeys.slashCommandsMenu.siteCommandDescription
    },
    {
      name: "/page:",
      description: localizationKeys.slashCommandsMenu.pageCommandDescription
    }
  ];
  var SlashCommandItem = (props) => {
    return /* @__PURE__ */ h(
      "div",
      {
        className: `flex-col p-3 gap-3 hover:bg-[#2A2B32] cursor-pointer text-white
                        ${props.active ? "bg-gray-800" : ""}`,
        onClick: () => props.onclick(props.command)
      },
      /* @__PURE__ */ h("div", { className: "flex flex-row items-center justify-between" }, /* @__PURE__ */ h("div", { className: "flex flex-col" }, /* @__PURE__ */ h("div", { className: "text-sm font-bold" }, props.command.name), /* @__PURE__ */ h("div", { className: "text-sm" }, getTranslation(props.command.description))), props.active ? icons.tabKey : null)
    );
  };
  function SlashCommandsMenu(props) {
    const [showMenu, setShowMenu] = p2(false);
    const [activeElementIndex, setActiveElementIndex] = p2(0);
    const [filter4, setFilter] = p2("");
    const [filteredCommands, setFilteredCommands] = p2(slashCommands);
    const onTextAreaInput = (e3) => updateFilter(e3);
    const onTextAreaKeyDown = (e3) => {
      if (!showMenu)
        return;
      if (e3.key === "ArrowUp") {
        e3.preventDefault();
        setActiveElementIndex((prevIndex) => Math.max(prevIndex - 1, 0));
      }
      if (e3.key === "ArrowDown") {
        e3.preventDefault();
        setActiveElementIndex((prevIndex) => Math.min(prevIndex + 1, filteredCommands.length - 1));
      }
      if (e3.key === "Tab") {
        e3.preventDefault();
        const command = filteredCommands[activeElementIndex];
        onCommandClick(command);
      }
      if (e3.key === "Enter") {
        e3.preventDefault();
        const command = filteredCommands[activeElementIndex];
        onCommandClick(command);
      }
    };
    function updateFilter(e3) {
      const text3 = e3.target.value;
      if (text3.startsWith("/")) {
        setFilter(text3);
      } else {
        setFilter("");
      }
      setActiveElementIndex(0);
    }
    const onCommandClick = (command) => {
      if (!command)
        return;
      setTextAreaValue(command.name, false);
      setShowMenu(false);
    };
    function setTextAreaValue(value, dispatchEvent = true) {
      if (!props.textarea)
        return;
      props.textarea.value = value;
      if (dispatchEvent)
        props.textarea.dispatchEvent(new Event("input", { bubbles: true }));
      props.textarea.focus();
    }
    h2(() => {
      props.textarea?.addEventListener("input", onTextAreaInput);
      props.textarea?.addEventListener("keydown", onTextAreaKeyDown);
      return function cleanup() {
        props.textarea?.removeEventListener("input", onTextAreaInput);
        props.textarea?.removeEventListener("keydown", onTextAreaKeyDown);
      };
    });
    h2(() => {
      if (filter4 === "") {
        setShowMenu(false);
        return;
      }
      getUserConfig().then((userConfig) => {
        const newFilteredCommands = slashCommands.filter((command) => command.name.startsWith(filter4));
        setFilteredCommands(newFilteredCommands);
        setShowMenu(userConfig.webAccess && newFilteredCommands.length > 0);
      });
    }, [filter4]);
    if (!showMenu)
      return null;
    return /* @__PURE__ */ h("ul", { className: `flex-col flex-1 overflow-y-auto border border-white/20 rounded-md bg-gray-900 shadow-[0_0_10px_rgba(0,0,0,0.10)]` }, /* @__PURE__ */ h("li", { className: "px-3 p-2 text-xs text-white b-2 border-b border-white/20" }, "WebChatGPT Commands"), filteredCommands.map((command) => {
      return /* @__PURE__ */ h("li", { key: command.name }, /* @__PURE__ */ h(
        SlashCommandItem,
        {
          command,
          onclick: onCommandClick,
          active: activeElementIndex === filteredCommands.indexOf(command)
        }
      ));
    }));
  }
  var slashCommandsMenu_default = SlashCommandsMenu;

  // src/content-scripts/api.ts
  var import_readability = __toESM(require_readability());

  // node_modules/linkedom/esm/shared/symbols.js
  var CHANGED = Symbol("changed");
  var CLASS_LIST = Symbol("classList");
  var CUSTOM_ELEMENTS = Symbol("CustomElements");
  var CONTENT = Symbol("content");
  var DATASET = Symbol("dataset");
  var DOCTYPE = Symbol("doctype");
  var DOM_PARSER = Symbol("DOMParser");
  var END = Symbol("end");
  var EVENT_TARGET = Symbol("EventTarget");
  var GLOBALS = Symbol("globals");
  var IMAGE = Symbol("image");
  var MIME = Symbol("mime");
  var MUTATION_OBSERVER = Symbol("MutationObserver");
  var NEXT = Symbol("next");
  var OWNER_ELEMENT = Symbol("ownerElement");
  var PREV = Symbol("prev");
  var PRIVATE = Symbol("private");
  var SHEET = Symbol("sheet");
  var START = Symbol("start");
  var STYLE = Symbol("style");
  var UPGRADE = Symbol("upgrade");
  var VALUE = Symbol("value");

  // node_modules/linkedom/esm/shared/constants.js
  var NODE_END = -1;
  var ELEMENT_NODE = 1;
  var ATTRIBUTE_NODE = 2;
  var TEXT_NODE = 3;
  var COMMENT_NODE = 8;
  var DOCUMENT_NODE = 9;
  var DOCUMENT_TYPE_NODE = 10;
  var DOCUMENT_FRAGMENT_NODE = 11;
  var BLOCK_ELEMENTS = /* @__PURE__ */ new Set(["ARTICLE", "ASIDE", "BLOCKQUOTE", "BODY", "BR", "BUTTON", "CANVAS", "CAPTION", "COL", "COLGROUP", "DD", "DIV", "DL", "DT", "EMBED", "FIELDSET", "FIGCAPTION", "FIGURE", "FOOTER", "FORM", "H1", "H2", "H3", "H4", "H5", "H6", "LI", "UL", "OL", "P"]);
  var SHOW_ALL = -1;
  var SHOW_ELEMENT = 1;
  var SHOW_TEXT = 4;
  var SHOW_COMMENT = 128;
  var DOCUMENT_POSITION_DISCONNECTED = 1;
  var DOCUMENT_POSITION_PRECEDING = 2;
  var DOCUMENT_POSITION_FOLLOWING = 4;
  var DOCUMENT_POSITION_CONTAINS = 8;
  var DOCUMENT_POSITION_CONTAINED_BY = 16;
  var DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC = 32;
  var SVG_NAMESPACE = "http://www.w3.org/2000/svg";

  // node_modules/linkedom/esm/shared/object.js
  var {
    assign,
    create,
    defineProperties,
    entries,
    getOwnPropertyDescriptors,
    keys,
    setPrototypeOf
  } = Object;

  // node_modules/linkedom/esm/shared/utils.js
  var $String = String;
  var getEnd = (node) => node.nodeType === ELEMENT_NODE ? node[END] : node;
  var ignoreCase = ({ ownerDocument }) => ownerDocument[MIME].ignoreCase;
  var knownAdjacent = (prev2, next2) => {
    prev2[NEXT] = next2;
    next2[PREV] = prev2;
  };
  var knownBoundaries = (prev2, current, next2) => {
    knownAdjacent(prev2, current);
    knownAdjacent(getEnd(current), next2);
  };
  var knownSegment = (prev2, start, end2, next2) => {
    knownAdjacent(prev2, start);
    knownAdjacent(getEnd(end2), next2);
  };
  var knownSiblings = (prev2, current, next2) => {
    knownAdjacent(prev2, current);
    knownAdjacent(current, next2);
  };
  var localCase = ({ localName, ownerDocument }) => {
    return ownerDocument[MIME].ignoreCase ? localName.toUpperCase() : localName;
  };
  var setAdjacent = (prev2, next2) => {
    if (prev2)
      prev2[NEXT] = next2;
    if (next2)
      next2[PREV] = prev2;
  };

  // node_modules/linkedom/esm/shared/shadow-roots.js
  var shadowRoots = /* @__PURE__ */ new WeakMap();

  // node_modules/linkedom/esm/interface/custom-element-registry.js
  var reactive = false;
  var Classes = /* @__PURE__ */ new WeakMap();
  var customElements = /* @__PURE__ */ new WeakMap();
  var attributeChangedCallback = (element, attributeName, oldValue, newValue) => {
    if (reactive && customElements.has(element) && element.attributeChangedCallback && element.constructor.observedAttributes.includes(attributeName)) {
      element.attributeChangedCallback(attributeName, oldValue, newValue);
    }
  };
  var createTrigger = (method, isConnected2) => (element) => {
    if (customElements.has(element)) {
      const info = customElements.get(element);
      if (info.connected !== isConnected2 && element.isConnected === isConnected2) {
        info.connected = isConnected2;
        if (method in element)
          element[method]();
      }
    }
  };
  var triggerConnected = createTrigger("connectedCallback", true);
  var connectedCallback = (element) => {
    if (reactive) {
      triggerConnected(element);
      if (shadowRoots.has(element))
        element = shadowRoots.get(element).shadowRoot;
      let { [NEXT]: next2, [END]: end2 } = element;
      while (next2 !== end2) {
        if (next2.nodeType === ELEMENT_NODE)
          triggerConnected(next2);
        next2 = next2[NEXT];
      }
    }
  };
  var triggerDisconnected = createTrigger("disconnectedCallback", false);
  var disconnectedCallback = (element) => {
    if (reactive) {
      triggerDisconnected(element);
      if (shadowRoots.has(element))
        element = shadowRoots.get(element).shadowRoot;
      let { [NEXT]: next2, [END]: end2 } = element;
      while (next2 !== end2) {
        if (next2.nodeType === ELEMENT_NODE)
          triggerDisconnected(next2);
        next2 = next2[NEXT];
      }
    }
  };
  var CustomElementRegistry = class {
    /**
     * @param {Document} ownerDocument
     */
    constructor(ownerDocument) {
      this.ownerDocument = ownerDocument;
      this.registry = /* @__PURE__ */ new Map();
      this.waiting = /* @__PURE__ */ new Map();
      this.active = false;
    }
    /**
     * @param {string} localName the custom element definition name
     * @param {Function} Class the custom element **Class** definition
     * @param {object?} options the optional object with an `extends` property
     */
    define(localName, Class, options2 = {}) {
      const { ownerDocument, registry, waiting } = this;
      if (registry.has(localName))
        throw new Error("unable to redefine " + localName);
      if (Classes.has(Class))
        throw new Error("unable to redefine the same class: " + Class);
      this.active = reactive = true;
      const { extends: extend } = options2;
      Classes.set(Class, {
        ownerDocument,
        options: { is: extend ? localName : "" },
        localName: extend || localName
      });
      const check = extend ? (element) => {
        return element.localName === extend && element.getAttribute("is") === localName;
      } : (element) => element.localName === localName;
      registry.set(localName, { Class, check });
      if (waiting.has(localName)) {
        for (const resolve of waiting.get(localName))
          resolve(Class);
        waiting.delete(localName);
      }
      ownerDocument.querySelectorAll(
        extend ? `${extend}[is="${localName}"]` : localName
      ).forEach(this.upgrade, this);
    }
    /**
     * @param {Element} element
     */
    upgrade(element) {
      if (customElements.has(element))
        return;
      const { ownerDocument, registry } = this;
      const ce = element.getAttribute("is") || element.localName;
      if (registry.has(ce)) {
        const { Class, check } = registry.get(ce);
        if (check(element)) {
          const { attributes: attributes2, isConnected: isConnected2 } = element;
          for (const attr2 of attributes2)
            element.removeAttributeNode(attr2);
          const values = entries(element);
          for (const [key2] of values)
            delete element[key2];
          setPrototypeOf(element, Class.prototype);
          ownerDocument[UPGRADE] = { element, values };
          new Class(ownerDocument, ce);
          customElements.set(element, { connected: isConnected2 });
          for (const attr2 of attributes2)
            element.setAttributeNode(attr2);
          if (isConnected2 && element.connectedCallback)
            element.connectedCallback();
        }
      }
    }
    /**
     * @param {string} localName the custom element definition name
     */
    whenDefined(localName) {
      const { registry, waiting } = this;
      return new Promise((resolve) => {
        if (registry.has(localName))
          resolve(registry.get(localName).Class);
        else {
          if (!waiting.has(localName))
            waiting.set(localName, []);
          waiting.get(localName).push(resolve);
        }
      });
    }
    /**
     * @param {string} localName the custom element definition name
     * @returns {Function?} the custom element **Class**, if any
     */
    get(localName) {
      const info = this.registry.get(localName);
      return info && info.Class;
    }
  };

  // node_modules/linkedom/esm/shared/parse-from-string.js
  var { Parser: Parser3 } = esm_exports4;
  var notParsing = true;
  var append3 = (self2, node, active) => {
    const end2 = self2[END];
    node.parentNode = self2;
    knownBoundaries(end2[PREV], node, end2);
    if (active && node.nodeType === ELEMENT_NODE)
      connectedCallback(node);
    return node;
  };
  var attribute = (element, end2, attribute2, value, active) => {
    attribute2[VALUE] = value;
    attribute2.ownerElement = element;
    knownSiblings(end2[PREV], attribute2, end2);
    if (attribute2.name === "class")
      element.className = value;
    if (active)
      attributeChangedCallback(element, attribute2.name, null, value);
  };
  var parseFromString = (document2, isHTML, markupLanguage) => {
    const { active, registry } = document2[CUSTOM_ELEMENTS];
    let node = document2;
    let ownerSVGElement = null;
    notParsing = false;
    const content = new Parser3({
      // <!DOCTYPE ...>
      onprocessinginstruction(name, data2) {
        if (name.toLowerCase() === "!doctype")
          document2.doctype = data2.slice(name.length).trim();
      },
      // <tagName>
      onopentag(name, attributes2) {
        let create3 = true;
        if (isHTML) {
          if (ownerSVGElement) {
            node = append3(node, document2.createElementNS(SVG_NAMESPACE, name), active);
            node.ownerSVGElement = ownerSVGElement;
            create3 = false;
          } else if (name === "svg" || name === "SVG") {
            ownerSVGElement = document2.createElementNS(SVG_NAMESPACE, name);
            node = append3(node, ownerSVGElement, active);
            create3 = false;
          } else if (active) {
            const ce = name.includes("-") ? name : attributes2.is || "";
            if (ce && registry.has(ce)) {
              const { Class } = registry.get(ce);
              node = append3(node, new Class(), active);
              delete attributes2.is;
              create3 = false;
            }
          }
        }
        if (create3)
          node = append3(node, document2.createElement(name), false);
        let end2 = node[END];
        for (const name2 of keys(attributes2))
          attribute(node, end2, document2.createAttribute(name2), attributes2[name2], active);
      },
      // #text, #comment
      oncomment(data2) {
        append3(node, document2.createComment(data2), active);
      },
      ontext(text3) {
        append3(node, document2.createTextNode(text3), active);
      },
      // </tagName>
      onclosetag() {
        if (isHTML && node === ownerSVGElement)
          ownerSVGElement = null;
        node = node.parentNode;
      }
    }, {
      lowerCaseAttributeNames: false,
      decodeEntities: true,
      xmlMode: !isHTML
    });
    content.write(markupLanguage);
    content.end();
    notParsing = true;
    return document2;
  };

  // node_modules/linkedom/esm/shared/register-html-class.js
  var htmlClasses = /* @__PURE__ */ new Map();
  var registerHTMLClass = (names, Class) => {
    for (const name of [].concat(names)) {
      htmlClasses.set(name, Class);
      htmlClasses.set(name.toUpperCase(), Class);
    }
  };

  // node_modules/linkedom/esm/interface/document.js
  var import_perf_hooks = __toESM(require_perf_hooks(), 1);

  // node_modules/linkedom/esm/shared/jsdon.js
  var loopSegment = ({ [NEXT]: next2, [END]: end2 }, json) => {
    while (next2 !== end2) {
      switch (next2.nodeType) {
        case ATTRIBUTE_NODE:
          attrAsJSON(next2, json);
          break;
        case TEXT_NODE:
        case COMMENT_NODE:
          characterDataAsJSON(next2, json);
          break;
        case ELEMENT_NODE:
          elementAsJSON(next2, json);
          next2 = getEnd(next2);
          break;
        case DOCUMENT_TYPE_NODE:
          documentTypeAsJSON(next2, json);
          break;
      }
      next2 = next2[NEXT];
    }
    const last2 = json.length - 1;
    const value = json[last2];
    if (typeof value === "number" && value < 0)
      json[last2] += NODE_END;
    else
      json.push(NODE_END);
  };
  var attrAsJSON = (attr2, json) => {
    json.push(ATTRIBUTE_NODE, attr2.name);
    const value = attr2[VALUE].trim();
    if (value)
      json.push(value);
  };
  var characterDataAsJSON = (node, json) => {
    const value = node[VALUE];
    if (value.trim())
      json.push(node.nodeType, value);
  };
  var nonElementAsJSON = (node, json) => {
    json.push(node.nodeType);
    loopSegment(node, json);
  };
  var documentTypeAsJSON = ({ name, publicId, systemId }, json) => {
    json.push(DOCUMENT_TYPE_NODE, name);
    if (publicId)
      json.push(publicId);
    if (systemId)
      json.push(systemId);
  };
  var elementAsJSON = (element, json) => {
    json.push(ELEMENT_NODE, element.localName);
    loopSegment(element, json);
  };

  // node_modules/linkedom/esm/interface/mutation-observer.js
  var createRecord = (type, target, addedNodes, removedNodes, attributeName, oldValue) => ({ type, target, addedNodes, removedNodes, attributeName, oldValue });
  var queueAttribute = (observer, target, attributeName, attributeFilter, attributeOldValue, oldValue) => {
    if (!attributeFilter || attributeFilter.includes(attributeName)) {
      const { callback, records, scheduled } = observer;
      records.push(createRecord(
        "attributes",
        target,
        [],
        [],
        attributeName,
        attributeOldValue ? oldValue : void 0
      ));
      if (!scheduled) {
        observer.scheduled = true;
        Promise.resolve().then(() => {
          observer.scheduled = false;
          callback(records.splice(0), observer);
        });
      }
    }
  };
  var attributeChangedCallback2 = (element, attributeName, oldValue) => {
    const { ownerDocument } = element;
    const { active, observers } = ownerDocument[MUTATION_OBSERVER];
    if (active) {
      for (const observer of observers) {
        for (const [
          target,
          {
            childList,
            subtree,
            attributes: attributes2,
            attributeFilter,
            attributeOldValue
          }
        ] of observer.nodes) {
          if (childList) {
            if (subtree && (target === ownerDocument || target.contains(element)) || !subtree && target.children.includes(element)) {
              queueAttribute(
                observer,
                element,
                attributeName,
                attributeFilter,
                attributeOldValue,
                oldValue
              );
              break;
            }
          } else if (attributes2 && target === element) {
            queueAttribute(
              observer,
              element,
              attributeName,
              attributeFilter,
              attributeOldValue,
              oldValue
            );
            break;
          }
        }
      }
    }
  };
  var moCallback = (element, parentNode) => {
    const { ownerDocument } = element;
    const { active, observers } = ownerDocument[MUTATION_OBSERVER];
    if (active) {
      for (const observer of observers) {
        for (const [target, { subtree, childList, characterData }] of observer.nodes) {
          if (childList) {
            if (parentNode && (target === parentNode || subtree && target.contains(parentNode)) || !parentNode && (subtree && (target === ownerDocument || target.contains(element)) || !subtree && target[characterData ? "childNodes" : "children"].includes(element))) {
              const { callback, records, scheduled } = observer;
              records.push(createRecord(
                "childList",
                target,
                parentNode ? [] : [element],
                parentNode ? [element] : []
              ));
              if (!scheduled) {
                observer.scheduled = true;
                Promise.resolve().then(() => {
                  observer.scheduled = false;
                  callback(records.splice(0), observer);
                });
              }
              break;
            }
          }
        }
      }
    }
  };
  var MutationObserverClass = class {
    constructor(ownerDocument) {
      const observers = /* @__PURE__ */ new Set();
      this.observers = observers;
      this.active = false;
      this.class = class MutationObserver {
        constructor(callback) {
          this.callback = callback;
          this.nodes = /* @__PURE__ */ new Map();
          this.records = [];
          this.scheduled = false;
        }
        disconnect() {
          this.records.splice(0);
          this.nodes.clear();
          observers.delete(this);
          ownerDocument[MUTATION_OBSERVER].active = !!observers.size;
        }
        /**
         * @param {Element} target
         * @param {MutationObserverInit} options
         */
        observe(target, options2 = {
          subtree: false,
          childList: false,
          attributes: false,
          attributeFilter: null,
          attributeOldValue: false,
          characterData: false
          // TODO: not implemented yet
          // characterDataOldValue: false
        }) {
          if ("attributeOldValue" in options2 || "attributeFilter" in options2)
            options2.attributes = true;
          options2.childList = !!options2.childList;
          options2.subtree = !!options2.subtree;
          this.nodes.set(target, options2);
          observers.add(this);
          ownerDocument[MUTATION_OBSERVER].active = true;
        }
        /**
         * @returns {MutationRecord[]}
         */
        takeRecords() {
          return this.records.splice(0);
        }
      };
    }
  };

  // node_modules/linkedom/esm/shared/attributes.js
  var emptyAttributes = /* @__PURE__ */ new Set([
    "allowfullscreen",
    "allowpaymentrequest",
    "async",
    "autofocus",
    "autoplay",
    "checked",
    "class",
    "contenteditable",
    "controls",
    "default",
    "defer",
    "disabled",
    "draggable",
    "formnovalidate",
    "hidden",
    "id",
    "ismap",
    "itemscope",
    "loop",
    "multiple",
    "muted",
    "nomodule",
    "novalidate",
    "open",
    "playsinline",
    "readonly",
    "required",
    "reversed",
    "selected",
    "style",
    "truespeed"
  ]);
  var setAttribute = (element, attribute2) => {
    const { [VALUE]: value, name } = attribute2;
    attribute2.ownerElement = element;
    knownSiblings(element, attribute2, element[NEXT]);
    if (name === "class")
      element.className = value;
    attributeChangedCallback2(element, name, null);
    attributeChangedCallback(element, name, null, value);
  };
  var removeAttribute2 = (element, attribute2) => {
    const { [VALUE]: value, name } = attribute2;
    knownAdjacent(attribute2[PREV], attribute2[NEXT]);
    attribute2.ownerElement = attribute2[PREV] = attribute2[NEXT] = null;
    if (name === "class")
      element[CLASS_LIST] = null;
    attributeChangedCallback2(element, name, value);
    attributeChangedCallback(element, name, value, null);
  };
  var booleanAttribute = {
    get(element, name) {
      return element.hasAttribute(name);
    },
    set(element, name, value) {
      if (value)
        element.setAttribute(name, "");
      else
        element.removeAttribute(name);
    }
  };
  var numericAttribute = {
    get(element, name) {
      return parseFloat(element.getAttribute(name) || 0);
    },
    set(element, name, value) {
      element.setAttribute(name, value);
    }
  };
  var stringAttribute = {
    get(element, name) {
      return element.getAttribute(name) || "";
    },
    set(element, name, value) {
      element.setAttribute(name, value);
    }
  };

  // node_modules/linkedom/esm/interface/event-target.js
  var wm = /* @__PURE__ */ new WeakMap();
  function dispatch(event, listener) {
    if (typeof listener === "function")
      listener.call(event.target, event);
    else
      listener.handleEvent(event);
    return event._stopImmediatePropagationFlag;
  }
  function invokeListeners({ currentTarget, target }) {
    const map2 = wm.get(currentTarget);
    if (map2 && map2.has(this.type)) {
      const listeners = map2.get(this.type);
      if (currentTarget === target) {
        this.eventPhase = this.AT_TARGET;
      } else {
        this.eventPhase = this.BUBBLING_PHASE;
      }
      this.currentTarget = currentTarget;
      this.target = target;
      for (const [listener, options2] of listeners) {
        if (options2 && options2.once)
          listeners.delete(listener);
        if (dispatch(this, listener))
          break;
      }
      delete this.currentTarget;
      delete this.target;
      return this.cancelBubble;
    }
  }
  var DOMEventTarget = class {
    constructor() {
      wm.set(this, /* @__PURE__ */ new Map());
    }
    /**
     * @protected
     */
    _getParent() {
      return null;
    }
    addEventListener(type, listener, options2) {
      const map2 = wm.get(this);
      if (!map2.has(type))
        map2.set(type, /* @__PURE__ */ new Map());
      map2.get(type).set(listener, options2);
    }
    removeEventListener(type, listener) {
      const map2 = wm.get(this);
      if (map2.has(type)) {
        const listeners = map2.get(type);
        if (listeners.delete(listener) && !listeners.size)
          map2.delete(type);
      }
    }
    dispatchEvent(event) {
      let node = this;
      event.eventPhase = event.CAPTURING_PHASE;
      while (node) {
        if (node.dispatchEvent)
          event._path.push({ currentTarget: node, target: this });
        node = event.bubbles && node._getParent && node._getParent();
      }
      event._path.some(invokeListeners, event);
      event._path = [];
      event.eventPhase = event.NONE;
      return !event.defaultPrevented;
    }
  };

  // node_modules/linkedom/esm/interface/node-list.js
  var NodeList = class extends Array {
    item(i3) {
      return i3 < this.length ? this[i3] : null;
    }
  };

  // node_modules/linkedom/esm/interface/node.js
  var getParentNodeCount = ({ parentNode }) => {
    let count = 0;
    while (parentNode) {
      count++;
      parentNode = parentNode.parentNode;
    }
    return count;
  };
  var Node2 = class extends DOMEventTarget {
    static get ELEMENT_NODE() {
      return ELEMENT_NODE;
    }
    static get ATTRIBUTE_NODE() {
      return ATTRIBUTE_NODE;
    }
    static get TEXT_NODE() {
      return TEXT_NODE;
    }
    static get COMMENT_NODE() {
      return COMMENT_NODE;
    }
    static get DOCUMENT_NODE() {
      return DOCUMENT_NODE;
    }
    static get DOCUMENT_FRAGMENT_NODE() {
      return DOCUMENT_FRAGMENT_NODE;
    }
    static get DOCUMENT_TYPE_NODE() {
      return DOCUMENT_TYPE_NODE;
    }
    constructor(ownerDocument, localName, nodeType) {
      super();
      this.ownerDocument = ownerDocument;
      this.localName = localName;
      this.nodeType = nodeType;
      this.parentNode = null;
      this[NEXT] = null;
      this[PREV] = null;
    }
    get ELEMENT_NODE() {
      return ELEMENT_NODE;
    }
    get ATTRIBUTE_NODE() {
      return ATTRIBUTE_NODE;
    }
    get TEXT_NODE() {
      return TEXT_NODE;
    }
    get COMMENT_NODE() {
      return COMMENT_NODE;
    }
    get DOCUMENT_NODE() {
      return DOCUMENT_NODE;
    }
    get DOCUMENT_FRAGMENT_NODE() {
      return DOCUMENT_FRAGMENT_NODE;
    }
    get DOCUMENT_TYPE_NODE() {
      return DOCUMENT_TYPE_NODE;
    }
    get baseURI() {
      const ownerDocument = this.nodeType === DOCUMENT_NODE ? this : this.ownerDocument;
      if (ownerDocument) {
        const base = ownerDocument.querySelector("base");
        if (base)
          return base.getAttribute("href");
        const { location } = ownerDocument.defaultView;
        if (location)
          return location.href;
      }
      return null;
    }
    /* c8 ignore start */
    // mixin: node
    get isConnected() {
      return false;
    }
    get nodeName() {
      return this.localName;
    }
    get parentElement() {
      return null;
    }
    get previousSibling() {
      return null;
    }
    get previousElementSibling() {
      return null;
    }
    get nextSibling() {
      return null;
    }
    get nextElementSibling() {
      return null;
    }
    get childNodes() {
      return new NodeList();
    }
    get firstChild() {
      return null;
    }
    get lastChild() {
      return null;
    }
    // default values
    get nodeValue() {
      return null;
    }
    set nodeValue(value) {
    }
    get textContent() {
      return null;
    }
    set textContent(value) {
    }
    normalize() {
    }
    cloneNode() {
      return null;
    }
    contains() {
      return false;
    }
    /**
     * Inserts a node before a reference node as a child of this parent node.
     * @param {Node} newNode The node to be inserted.
     * @param {Node} referenceNode The node before which newNode is inserted. If this is null, then newNode is inserted at the end of node's child nodes.
     * @returns The added child
     */
    // eslint-disable-next-line no-unused-vars
    insertBefore(newNode, referenceNode) {
      return newNode;
    }
    /**
     * Adds a node to the end of the list of children of this node.
     * @param {Node} child The node to append to the given parent node.
     * @returns The appended child.
     */
    appendChild(child) {
      return child;
    }
    /**
     * Replaces a child node within this node
     * @param {Node} newChild The new node to replace oldChild.
     * @param {Node} oldChild The child to be replaced.
     * @returns The replaced Node. This is the same node as oldChild.
     */
    replaceChild(newChild, oldChild) {
      return oldChild;
    }
    /**
     * Removes a child node from the DOM.
     * @param {Node} child A Node that is the child node to be removed from the DOM.
     * @returns The removed node.
     */
    removeChild(child) {
      return child;
    }
    toString() {
      return "";
    }
    /* c8 ignore stop */
    hasChildNodes() {
      return !!this.lastChild;
    }
    isSameNode(node) {
      return this === node;
    }
    // TODO: attributes?
    compareDocumentPosition(target) {
      let result = 0;
      if (this !== target) {
        let self2 = getParentNodeCount(this);
        let other = getParentNodeCount(target);
        if (self2 < other) {
          result += DOCUMENT_POSITION_FOLLOWING;
          if (this.contains(target))
            result += DOCUMENT_POSITION_CONTAINED_BY;
        } else if (other < self2) {
          result += DOCUMENT_POSITION_PRECEDING;
          if (target.contains(this))
            result += DOCUMENT_POSITION_CONTAINS;
        } else if (self2 && other) {
          const { childNodes } = this.parentNode;
          if (childNodes.indexOf(this) < childNodes.indexOf(target))
            result += DOCUMENT_POSITION_FOLLOWING;
          else
            result += DOCUMENT_POSITION_PRECEDING;
        }
        if (!self2 || !other) {
          result += DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC;
          result += DOCUMENT_POSITION_DISCONNECTED;
        }
      }
      return result;
    }
    isEqualNode(node) {
      if (this === node)
        return true;
      if (this.nodeType === node.nodeType) {
        switch (this.nodeType) {
          case DOCUMENT_NODE:
          case DOCUMENT_FRAGMENT_NODE: {
            const aNodes = this.childNodes;
            const bNodes = node.childNodes;
            return aNodes.length === bNodes.length && aNodes.every((node2, i3) => node2.isEqualNode(bNodes[i3]));
          }
        }
        return this.toString() === node.toString();
      }
      return false;
    }
    /**
     * @protected
     */
    _getParent() {
      return this.parentNode;
    }
    getRootNode() {
      let root4 = this;
      while (root4.parentNode)
        root4 = root4.parentNode;
      return root4.nodeType === DOCUMENT_NODE ? root4.documentElement : root4;
    }
  };

  // node_modules/linkedom/esm/interface/attr.js
  var QUOTE = /"/g;
  var Attr = class extends Node2 {
    constructor(ownerDocument, name, value = "") {
      super(ownerDocument, "#attribute", ATTRIBUTE_NODE);
      this.ownerElement = null;
      this.name = $String(name);
      this[VALUE] = $String(value);
      this[CHANGED] = false;
    }
    get value() {
      return this[VALUE];
    }
    set value(newValue) {
      const { [VALUE]: oldValue, name, ownerElement } = this;
      this[VALUE] = $String(newValue);
      this[CHANGED] = true;
      if (ownerElement) {
        attributeChangedCallback2(ownerElement, name, oldValue);
        attributeChangedCallback(ownerElement, name, oldValue, this[VALUE]);
      }
    }
    cloneNode() {
      const { ownerDocument, name, [VALUE]: value } = this;
      return new Attr(ownerDocument, name, value);
    }
    toString() {
      const { name, [VALUE]: value } = this;
      return emptyAttributes.has(name) && !value ? name : `${name}="${value.replace(QUOTE, "&quot;")}"`;
    }
    toJSON() {
      const json = [];
      attrAsJSON(this, json);
      return json;
    }
  };

  // node_modules/linkedom/esm/shared/node.js
  var isConnected = ({ ownerDocument, parentNode }) => {
    while (parentNode) {
      if (parentNode === ownerDocument)
        return true;
      parentNode = parentNode.parentNode || parentNode.host;
    }
    return false;
  };
  var parentElement = ({ parentNode }) => {
    if (parentNode) {
      switch (parentNode.nodeType) {
        case DOCUMENT_NODE:
        case DOCUMENT_FRAGMENT_NODE:
          return null;
      }
    }
    return parentNode;
  };
  var previousSibling = ({ [PREV]: prev2 }) => {
    switch (prev2 ? prev2.nodeType : 0) {
      case NODE_END:
        return prev2[START];
      case TEXT_NODE:
      case COMMENT_NODE:
        return prev2;
    }
    return null;
  };
  var nextSibling = (node) => {
    const next2 = getEnd(node)[NEXT];
    return next2 && (next2.nodeType === NODE_END ? null : next2);
  };

  // node_modules/linkedom/esm/mixin/non-document-type-child-node.js
  var nextElementSibling2 = (node) => {
    let next2 = nextSibling(node);
    while (next2 && next2.nodeType !== ELEMENT_NODE)
      next2 = nextSibling(next2);
    return next2;
  };
  var previousElementSibling = (node) => {
    let prev2 = previousSibling(node);
    while (prev2 && prev2.nodeType !== ELEMENT_NODE)
      prev2 = previousSibling(prev2);
    return prev2;
  };

  // node_modules/linkedom/esm/mixin/child-node.js
  var asFragment = (ownerDocument, nodes) => {
    const fragment = ownerDocument.createDocumentFragment();
    fragment.append(...nodes);
    return fragment;
  };
  var before2 = (node, nodes) => {
    const { ownerDocument, parentNode } = node;
    if (parentNode)
      parentNode.insertBefore(
        asFragment(ownerDocument, nodes),
        node
      );
  };
  var after2 = (node, nodes) => {
    const { ownerDocument, parentNode } = node;
    if (parentNode)
      parentNode.insertBefore(
        asFragment(ownerDocument, nodes),
        getEnd(node)[NEXT]
      );
  };
  var replaceWith2 = (node, nodes) => {
    const { ownerDocument, parentNode } = node;
    if (parentNode) {
      parentNode.insertBefore(
        asFragment(ownerDocument, nodes),
        node
      );
      node.remove();
    }
  };
  var remove2 = (prev2, current, next2) => {
    const { parentNode, nodeType } = current;
    if (prev2 || next2) {
      setAdjacent(prev2, next2);
      current[PREV] = null;
      getEnd(current)[NEXT] = null;
    }
    if (parentNode) {
      current.parentNode = null;
      moCallback(current, parentNode);
      if (nodeType === ELEMENT_NODE)
        disconnectedCallback(current);
    }
  };

  // node_modules/linkedom/esm/interface/character-data.js
  var CharacterData = class extends Node2 {
    constructor(ownerDocument, localName, nodeType, data2) {
      super(ownerDocument, localName, nodeType);
      this[VALUE] = $String(data2);
    }
    // <Mixins>
    get isConnected() {
      return isConnected(this);
    }
    get parentElement() {
      return parentElement(this);
    }
    get previousSibling() {
      return previousSibling(this);
    }
    get nextSibling() {
      return nextSibling(this);
    }
    get previousElementSibling() {
      return previousElementSibling(this);
    }
    get nextElementSibling() {
      return nextElementSibling2(this);
    }
    before(...nodes) {
      before2(this, nodes);
    }
    after(...nodes) {
      after2(this, nodes);
    }
    replaceWith(...nodes) {
      replaceWith2(this, nodes);
    }
    remove() {
      remove2(this[PREV], this, this[NEXT]);
    }
    // </Mixins>
    // CharacterData only
    /* c8 ignore start */
    get data() {
      return this[VALUE];
    }
    set data(value) {
      this[VALUE] = $String(value);
      moCallback(this, this.parentNode);
    }
    get nodeValue() {
      return this.data;
    }
    set nodeValue(value) {
      this.data = value;
    }
    get textContent() {
      return this.data;
    }
    set textContent(value) {
      this.data = value;
    }
    get length() {
      return this.data.length;
    }
    substringData(offset, count) {
      return this.data.substr(offset, count);
    }
    appendData(data2) {
      this.data += data2;
    }
    insertData(offset, data2) {
      const { data: t3 } = this;
      this.data = t3.slice(0, offset) + data2 + t3.slice(offset);
    }
    deleteData(offset, count) {
      const { data: t3 } = this;
      this.data = t3.slice(0, offset) + t3.slice(offset + count);
    }
    replaceData(offset, count, data2) {
      const { data: t3 } = this;
      this.data = t3.slice(0, offset) + data2 + t3.slice(offset + count);
    }
    /* c8 ignore stop */
    toJSON() {
      const json = [];
      characterDataAsJSON(this, json);
      return json;
    }
  };

  // node_modules/linkedom/esm/interface/comment.js
  var Comment3 = class extends CharacterData {
    constructor(ownerDocument, data2 = "") {
      super(ownerDocument, "#comment", COMMENT_NODE, data2);
    }
    cloneNode() {
      const { ownerDocument, [VALUE]: data2 } = this;
      return new Comment3(ownerDocument, data2);
    }
    toString() {
      return `<!--${this[VALUE]}-->`;
    }
  };

  // node_modules/linkedom/esm/shared/matches.js
  var { isArray: isArray2 } = Array;
  var isTag3 = ({ nodeType }) => nodeType === ELEMENT_NODE;
  var existsOne2 = (test, elements) => elements.some(
    (element) => isTag3(element) && (test(element) || existsOne2(test, getChildren2(element)))
  );
  var getAttributeValue2 = (element, name) => name === "class" ? element.classList.value : element.getAttribute(name);
  var getChildren2 = ({ childNodes }) => childNodes;
  var getName2 = (element) => {
    const { localName } = element;
    return ignoreCase(element) ? localName.toLowerCase() : localName;
  };
  var getParent2 = ({ parentNode }) => parentNode;
  var getSiblings2 = (element) => {
    const { parentNode } = element;
    return parentNode ? getChildren2(parentNode) : element;
  };
  var getText2 = (node) => {
    if (isArray2(node))
      return node.map(getText2).join("");
    if (isTag3(node))
      return getText2(getChildren2(node));
    if (node.nodeType === TEXT_NODE)
      return node.data;
    return "";
  };
  var hasAttrib2 = (element, name) => element.hasAttribute(name);
  var removeSubsets2 = (nodes) => {
    let { length } = nodes;
    while (length--) {
      const node = nodes[length];
      if (length && -1 < nodes.lastIndexOf(node, length - 1)) {
        nodes.splice(length, 1);
        continue;
      }
      for (let { parentNode } = node; parentNode; parentNode = parentNode.parentNode) {
        if (nodes.includes(parentNode)) {
          nodes.splice(length, 1);
          break;
        }
      }
    }
    return nodes;
  };
  var findAll2 = (test, nodes) => {
    const matches2 = [];
    for (const node of nodes) {
      if (isTag3(node)) {
        if (test(node))
          matches2.push(node);
        matches2.push(...findAll2(test, getChildren2(node)));
      }
    }
    return matches2;
  };
  var findOne2 = (test, nodes) => {
    for (let node of nodes)
      if (test(node) || (node = findOne2(test, getChildren2(node))))
        return node;
    return null;
  };
  var adapter2 = {
    isTag: isTag3,
    existsOne: existsOne2,
    getAttributeValue: getAttributeValue2,
    getChildren: getChildren2,
    getName: getName2,
    getParent: getParent2,
    getSiblings: getSiblings2,
    getText: getText2,
    hasAttrib: hasAttrib2,
    removeSubsets: removeSubsets2,
    findAll: findAll2,
    findOne: findOne2
  };
  var prepareMatch = (element, selectors) => compile3(
    selectors,
    {
      context: selectors.includes(":scope") ? element : void 0,
      xmlMode: !ignoreCase(element),
      adapter: adapter2
    }
  );
  var matches = (element, selectors) => is2(
    element,
    selectors,
    {
      strict: true,
      context: selectors.includes(":scope") ? element : void 0,
      xmlMode: !ignoreCase(element),
      adapter: adapter2
    }
  );

  // node_modules/linkedom/esm/shared/text-escaper.js
  var { replace } = "";
  var ca = /[<>&\xA0]/g;
  var esca = {
    "\xA0": "&nbsp;",
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;"
  };
  var pe = (m3) => esca[m3];
  var escape2 = (es) => replace.call(es, ca, pe);

  // node_modules/linkedom/esm/interface/text.js
  var Text3 = class extends CharacterData {
    constructor(ownerDocument, data2 = "") {
      super(ownerDocument, "#text", TEXT_NODE, data2);
    }
    get wholeText() {
      const text3 = [];
      let { previousSibling: previousSibling2, nextSibling: nextSibling2 } = this;
      while (previousSibling2) {
        if (previousSibling2.nodeType === TEXT_NODE)
          text3.unshift(previousSibling2[VALUE]);
        else
          break;
        previousSibling2 = previousSibling2.previousSibling;
      }
      text3.push(this[VALUE]);
      while (nextSibling2) {
        if (nextSibling2.nodeType === TEXT_NODE)
          text3.push(nextSibling2[VALUE]);
        else
          break;
        nextSibling2 = nextSibling2.nextSibling;
      }
      return text3.join("");
    }
    cloneNode() {
      const { ownerDocument, [VALUE]: data2 } = this;
      return new Text3(ownerDocument, data2);
    }
    toString() {
      return escape2(this[VALUE]);
    }
  };

  // node_modules/linkedom/esm/mixin/parent-node.js
  var isNode2 = (node) => node instanceof Node2;
  var insert = (parentNode, child, nodes) => {
    const { ownerDocument } = parentNode;
    for (const node of nodes)
      parentNode.insertBefore(
        isNode2(node) ? node : new Text3(ownerDocument, node),
        child
      );
  };
  var ParentNode = class extends Node2 {
    constructor(ownerDocument, localName, nodeType) {
      super(ownerDocument, localName, nodeType);
      this[PRIVATE] = null;
      this[NEXT] = this[END] = {
        [NEXT]: null,
        [PREV]: this,
        [START]: this,
        nodeType: NODE_END,
        ownerDocument: this.ownerDocument,
        parentNode: null
      };
    }
    get childNodes() {
      const childNodes = new NodeList();
      let { firstChild } = this;
      while (firstChild) {
        childNodes.push(firstChild);
        firstChild = nextSibling(firstChild);
      }
      return childNodes;
    }
    get children() {
      const children2 = new NodeList();
      let { firstElementChild } = this;
      while (firstElementChild) {
        children2.push(firstElementChild);
        firstElementChild = nextElementSibling2(firstElementChild);
      }
      return children2;
    }
    /**
     * @returns {NodeStruct | null}
     */
    get firstChild() {
      let { [NEXT]: next2, [END]: end2 } = this;
      while (next2.nodeType === ATTRIBUTE_NODE)
        next2 = next2[NEXT];
      return next2 === end2 ? null : next2;
    }
    /**
     * @returns {NodeStruct | null}
     */
    get firstElementChild() {
      let { firstChild } = this;
      while (firstChild) {
        if (firstChild.nodeType === ELEMENT_NODE)
          return firstChild;
        firstChild = nextSibling(firstChild);
      }
      return null;
    }
    get lastChild() {
      const prev2 = this[END][PREV];
      switch (prev2.nodeType) {
        case NODE_END:
          return prev2[START];
        case ATTRIBUTE_NODE:
          return null;
      }
      return prev2 === this ? null : prev2;
    }
    get lastElementChild() {
      let { lastChild } = this;
      while (lastChild) {
        if (lastChild.nodeType === ELEMENT_NODE)
          return lastChild;
        lastChild = previousSibling(lastChild);
      }
      return null;
    }
    get childElementCount() {
      return this.children.length;
    }
    prepend(...nodes) {
      insert(this, this.firstChild, nodes);
    }
    append(...nodes) {
      insert(this, this[END], nodes);
    }
    replaceChildren(...nodes) {
      let { [NEXT]: next2, [END]: end2 } = this;
      while (next2 !== end2 && next2.nodeType === ATTRIBUTE_NODE)
        next2 = next2[NEXT];
      while (next2 !== end2) {
        const after3 = getEnd(next2)[NEXT];
        next2.remove();
        next2 = after3;
      }
      if (nodes.length)
        insert(this, end2, nodes);
    }
    getElementsByClassName(className) {
      const elements = new NodeList();
      let { [NEXT]: next2, [END]: end2 } = this;
      while (next2 !== end2) {
        if (next2.nodeType === ELEMENT_NODE && next2.hasAttribute("class") && next2.classList.has(className))
          elements.push(next2);
        next2 = next2[NEXT];
      }
      return elements;
    }
    getElementsByTagName(tagName18) {
      const elements = new NodeList();
      let { [NEXT]: next2, [END]: end2 } = this;
      while (next2 !== end2) {
        if (next2.nodeType === ELEMENT_NODE && (next2.localName === tagName18 || localCase(next2) === tagName18))
          elements.push(next2);
        next2 = next2[NEXT];
      }
      return elements;
    }
    querySelector(selectors) {
      const matches2 = prepareMatch(this, selectors);
      let { [NEXT]: next2, [END]: end2 } = this;
      while (next2 !== end2) {
        if (next2.nodeType === ELEMENT_NODE && matches2(next2))
          return next2;
        next2 = next2[NEXT];
      }
      return null;
    }
    querySelectorAll(selectors) {
      const matches2 = prepareMatch(this, selectors);
      const elements = new NodeList();
      let { [NEXT]: next2, [END]: end2 } = this;
      while (next2 !== end2) {
        if (next2.nodeType === ELEMENT_NODE && matches2(next2))
          elements.push(next2);
        next2 = next2[NEXT];
      }
      return elements;
    }
    appendChild(node) {
      return this.insertBefore(node, this[END]);
    }
    contains(node) {
      let parentNode = node;
      while (parentNode && parentNode !== this)
        parentNode = parentNode.parentNode;
      return parentNode === this;
    }
    insertBefore(node, before3 = null) {
      if (node === before3)
        return node;
      if (node === this)
        throw new Error("unable to append a node to itself");
      const next2 = before3 || this[END];
      switch (node.nodeType) {
        case ELEMENT_NODE:
          node.remove();
          node.parentNode = this;
          knownBoundaries(next2[PREV], node, next2);
          moCallback(node, null);
          connectedCallback(node);
          break;
        case DOCUMENT_FRAGMENT_NODE: {
          let { [PRIVATE]: parentNode, firstChild, lastChild } = node;
          if (firstChild) {
            knownSegment(next2[PREV], firstChild, lastChild, next2);
            knownAdjacent(node, node[END]);
            if (parentNode)
              parentNode.replaceChildren();
            do {
              firstChild.parentNode = this;
              moCallback(firstChild, null);
              if (firstChild.nodeType === ELEMENT_NODE)
                connectedCallback(firstChild);
            } while (firstChild !== lastChild && (firstChild = nextSibling(firstChild)));
          }
          break;
        }
        case TEXT_NODE:
        case COMMENT_NODE:
          node.remove();
        default:
          node.parentNode = this;
          knownSiblings(next2[PREV], node, next2);
          moCallback(node, null);
          break;
      }
      return node;
    }
    normalize() {
      let { [NEXT]: next2, [END]: end2 } = this;
      while (next2 !== end2) {
        const { [NEXT]: $next, [PREV]: $prev, nodeType } = next2;
        if (nodeType === TEXT_NODE) {
          if (!next2[VALUE])
            next2.remove();
          else if ($prev && $prev.nodeType === TEXT_NODE) {
            $prev.textContent += next2.textContent;
            next2.remove();
          }
        }
        next2 = $next;
      }
    }
    removeChild(node) {
      if (node.parentNode !== this)
        throw new Error("node is not a child");
      node.remove();
      return node;
    }
    replaceChild(node, replaced) {
      const next2 = getEnd(replaced)[NEXT];
      replaced.remove();
      this.insertBefore(node, next2);
      return replaced;
    }
  };

  // node_modules/linkedom/esm/mixin/non-element-parent-node.js
  var NonElementParentNode = class extends ParentNode {
    getElementById(id) {
      let { [NEXT]: next2, [END]: end2 } = this;
      while (next2 !== end2) {
        if (next2.nodeType === ELEMENT_NODE && next2.id === id)
          return next2;
        next2 = next2[NEXT];
      }
      return null;
    }
    cloneNode(deep) {
      const { ownerDocument, constructor } = this;
      const nonEPN = new constructor(ownerDocument);
      if (deep) {
        const { [END]: end2 } = nonEPN;
        for (const node of this.childNodes)
          nonEPN.insertBefore(node.cloneNode(deep), end2);
      }
      return nonEPN;
    }
    toString() {
      const { childNodes, localName } = this;
      return `<${localName}>${childNodes.join("")}</${localName}>`;
    }
    toJSON() {
      const json = [];
      nonElementAsJSON(this, json);
      return json;
    }
  };

  // node_modules/linkedom/esm/interface/document-fragment.js
  var DocumentFragment = class extends NonElementParentNode {
    constructor(ownerDocument) {
      super(ownerDocument, "#document-fragment", DOCUMENT_FRAGMENT_NODE);
    }
  };

  // node_modules/linkedom/esm/interface/document-type.js
  var DocumentType = class extends Node2 {
    constructor(ownerDocument, name, publicId = "", systemId = "") {
      super(ownerDocument, "#document-type", DOCUMENT_TYPE_NODE);
      this.name = name;
      this.publicId = publicId;
      this.systemId = systemId;
    }
    cloneNode() {
      const { ownerDocument, name, publicId, systemId } = this;
      return new DocumentType(ownerDocument, name, publicId, systemId);
    }
    toString() {
      const { name, publicId, systemId } = this;
      const hasPublic = 0 < publicId.length;
      const str = [name];
      if (hasPublic)
        str.push("PUBLIC", `"${publicId}"`);
      if (systemId.length) {
        if (!hasPublic)
          str.push("SYSTEM");
        str.push(`"${systemId}"`);
      }
      return `<!DOCTYPE ${str.join(" ")}>`;
    }
    toJSON() {
      const json = [];
      documentTypeAsJSON(this, json);
      return json;
    }
  };

  // node_modules/linkedom/esm/mixin/inner-html.js
  var getInnerHtml = (node) => node.childNodes.join("");
  var setInnerHtml = (node, html3) => {
    const { ownerDocument } = node;
    const { constructor } = ownerDocument;
    const document2 = new constructor();
    document2[CUSTOM_ELEMENTS] = ownerDocument[CUSTOM_ELEMENTS];
    const { childNodes } = parseFromString(document2, ignoreCase(node), html3);
    node.replaceChildren(...childNodes.map(setOwnerDocument, ownerDocument));
  };
  function setOwnerDocument(node) {
    node.ownerDocument = this;
    switch (node.nodeType) {
      case ELEMENT_NODE:
      case DOCUMENT_FRAGMENT_NODE:
        node.childNodes.forEach(setOwnerDocument, this);
        break;
    }
    return node;
  }

  // node_modules/uhyphen/esm/index.js
  var esm_default3 = (camel) => camel.replace(/(([A-Z0-9])([A-Z0-9][a-z]))|(([a-z])([A-Z]))/g, "$2$5-$3$6").toLowerCase();

  // node_modules/linkedom/esm/dom/string-map.js
  var refs = /* @__PURE__ */ new WeakMap();
  var key = (name) => `data-${esm_default3(name)}`;
  var prop2 = (name) => name.slice(5).replace(/-([a-z])/g, (_2, $1) => $1.toUpperCase());
  var handler = {
    get(dataset, name) {
      if (name in dataset)
        return refs.get(dataset).getAttribute(key(name));
    },
    set(dataset, name, value) {
      dataset[name] = value;
      refs.get(dataset).setAttribute(key(name), value);
      return true;
    },
    deleteProperty(dataset, name) {
      if (name in dataset)
        refs.get(dataset).removeAttribute(key(name));
      return delete dataset[name];
    }
  };
  var DOMStringMap = class {
    /**
     * @param {Element} ref
     */
    constructor(ref) {
      for (const { name, value } of ref.attributes) {
        if (/^data-/.test(name))
          this[prop2(name)] = value;
      }
      refs.set(this, ref);
      return new Proxy(this, handler);
    }
  };
  setPrototypeOf(DOMStringMap.prototype, null);

  // node_modules/linkedom/esm/dom/token-list.js
  var { add: add2 } = Set.prototype;
  var addTokens = (self2, tokens) => {
    for (const token of tokens) {
      if (token)
        add2.call(self2, token);
    }
  };
  var update2 = ({ [OWNER_ELEMENT]: ownerElement, value }) => {
    const attribute2 = ownerElement.getAttributeNode("class");
    if (attribute2)
      attribute2.value = value;
    else
      setAttribute(
        ownerElement,
        new Attr(ownerElement.ownerDocument, "class", value)
      );
  };
  var DOMTokenList = class extends Set {
    constructor(ownerElement) {
      super();
      this[OWNER_ELEMENT] = ownerElement;
      const attribute2 = ownerElement.getAttributeNode("class");
      if (attribute2)
        addTokens(this, attribute2.value.split(/\s+/));
    }
    get length() {
      return this.size;
    }
    get value() {
      return [...this].join(" ");
    }
    /**
     * @param  {...string} tokens
     */
    add(...tokens) {
      addTokens(this, tokens);
      update2(this);
    }
    /**
     * @param {string} token
     */
    contains(token) {
      return this.has(token);
    }
    /**
     * @param  {...string} tokens
     */
    remove(...tokens) {
      for (const token of tokens)
        this.delete(token);
      update2(this);
    }
    /**
     * @param {string} token
     * @param {boolean?} force
     */
    toggle(token, force) {
      if (this.has(token)) {
        if (force)
          return true;
        this.delete(token);
        update2(this);
      } else if (force || arguments.length === 1) {
        super.add(token);
        update2(this);
        return true;
      }
      return false;
    }
    /**
     * @param {string} token
     * @param {string} newToken
     */
    replace(token, newToken) {
      if (this.has(token)) {
        this.delete(token);
        super.add(newToken);
        update2(this);
        return true;
      }
      return false;
    }
    /**
     * @param {string} token
     */
    supports() {
      return true;
    }
  };

  // node_modules/linkedom/esm/interface/css-style-declaration.js
  var refs2 = /* @__PURE__ */ new WeakMap();
  var getKeys = (style) => [...style.keys()].filter((key2) => key2 !== PRIVATE);
  var updateKeys = (style) => {
    const attr2 = refs2.get(style).getAttributeNode("style");
    if (!attr2 || attr2[CHANGED] || style.get(PRIVATE) !== attr2) {
      style.clear();
      if (attr2) {
        style.set(PRIVATE, attr2);
        for (const rule of attr2[VALUE].split(/\s*;\s*/)) {
          let [key2, ...rest] = rule.split(":");
          if (rest.length > 0) {
            key2 = key2.trim();
            const value = rest.join(":").trim();
            if (key2 && value)
              style.set(key2, value);
          }
        }
      }
    }
    return attr2;
  };
  var handler2 = {
    get(style, name) {
      if (name in prototype)
        return style[name];
      updateKeys(style);
      if (name === "length")
        return getKeys(style).length;
      if (/^\d+$/.test(name))
        return getKeys(style)[name];
      return style.get(esm_default3(name));
    },
    set(style, name, value) {
      if (name === "cssText")
        style[name] = value;
      else {
        let attr2 = updateKeys(style);
        if (value == null)
          style.delete(esm_default3(name));
        else
          style.set(esm_default3(name), value);
        if (!attr2) {
          const element = refs2.get(style);
          attr2 = element.ownerDocument.createAttribute("style");
          element.setAttributeNode(attr2);
          style.set(PRIVATE, attr2);
        }
        attr2[CHANGED] = false;
        attr2[VALUE] = style.toString();
      }
      return true;
    }
  };
  var CSSStyleDeclaration = class extends Map {
    constructor(element) {
      super();
      refs2.set(this, element);
      return new Proxy(this, handler2);
    }
    get cssText() {
      return this.toString();
    }
    set cssText(value) {
      refs2.get(this).setAttribute("style", value);
    }
    getPropertyValue(name) {
      const self2 = this[PRIVATE];
      return handler2.get(self2, name);
    }
    setProperty(name, value) {
      const self2 = this[PRIVATE];
      handler2.set(self2, name, value);
    }
    removeProperty(name) {
      const self2 = this[PRIVATE];
      handler2.set(self2, name, null);
    }
    [Symbol.iterator]() {
      const keys2 = getKeys(this[PRIVATE]);
      const { length } = keys2;
      let i3 = 0;
      return {
        next() {
          const done = i3 === length;
          return { done, value: done ? null : keys2[i3++] };
        }
      };
    }
    get [PRIVATE]() {
      return this;
    }
    toString() {
      const self2 = this[PRIVATE];
      updateKeys(self2);
      const cssText = [];
      self2.forEach(push, cssText);
      return cssText.join(";");
    }
  };
  var { prototype } = CSSStyleDeclaration;
  function push(value, key2) {
    if (key2 !== PRIVATE)
      this.push(`${key2}:${value}`);
  }

  // node_modules/linkedom/esm/interface/event.js
  var BUBBLING_PHASE = 3;
  var AT_TARGET = 2;
  var CAPTURING_PHASE = 1;
  var NONE = 0;
  var GlobalEvent = class {
    static get BUBBLING_PHASE() {
      return BUBBLING_PHASE;
    }
    static get AT_TARGET() {
      return AT_TARGET;
    }
    static get CAPTURING_PHASE() {
      return CAPTURING_PHASE;
    }
    static get NONE() {
      return NONE;
    }
    constructor(type, eventInitDict = {}) {
      this.type = type;
      this.bubbles = !!eventInitDict.bubbles;
      this.cancelBubble = false;
      this._stopImmediatePropagationFlag = false;
      this.cancelable = !!eventInitDict.cancelable;
      this.eventPhase = this.NONE;
      this.timeStamp = Date.now();
      this.defaultPrevented = false;
      this.originalTarget = null;
      this.returnValue = null;
      this.srcElement = null;
      this.target = null;
      this._path = [];
    }
    get BUBBLING_PHASE() {
      return BUBBLING_PHASE;
    }
    get AT_TARGET() {
      return AT_TARGET;
    }
    get CAPTURING_PHASE() {
      return CAPTURING_PHASE;
    }
    get NONE() {
      return NONE;
    }
    preventDefault() {
      this.defaultPrevented = true;
    }
    // simplified implementation, should be https://dom.spec.whatwg.org/#dom-event-composedpath
    composedPath() {
      return this._path;
    }
    stopPropagation() {
      this.cancelBubble = true;
    }
    stopImmediatePropagation() {
      this.stopPropagation();
      this._stopImmediatePropagationFlag = true;
    }
  };

  // node_modules/linkedom/esm/interface/named-node-map.js
  var NamedNodeMap = class extends Array {
    constructor(ownerElement) {
      super();
      this.ownerElement = ownerElement;
    }
    getNamedItem(name) {
      return this.ownerElement.getAttributeNode(name);
    }
    setNamedItem(attr2) {
      this.ownerElement.setAttributeNode(attr2);
      this.unshift(attr2);
    }
    removeNamedItem(name) {
      const item = this.getNamedItem(name);
      this.ownerElement.removeAttribute(name);
      this.splice(this.indexOf(item), 1);
    }
    item(index2) {
      return index2 < this.length ? this[index2] : null;
    }
    /* c8 ignore start */
    getNamedItemNS(_2, name) {
      return this.getNamedItem(name);
    }
    setNamedItemNS(_2, attr2) {
      return this.setNamedItem(attr2);
    }
    removeNamedItemNS(_2, name) {
      return this.removeNamedItem(name);
    }
    /* c8 ignore stop */
  };

  // node_modules/linkedom/esm/interface/shadow-root.js
  var ShadowRoot = class extends NonElementParentNode {
    constructor(host) {
      super(host.ownerDocument, "#shadow-root", DOCUMENT_FRAGMENT_NODE);
      this.host = host;
    }
    get innerHTML() {
      return getInnerHtml(this);
    }
    set innerHTML(html3) {
      setInnerHtml(this, html3);
    }
  };

  // node_modules/linkedom/esm/interface/element.js
  var attributesHandler = {
    get(target, key2) {
      return key2 in target ? target[key2] : target.find(({ name }) => name === key2);
    }
  };
  var create2 = (ownerDocument, element, localName) => {
    if ("ownerSVGElement" in element) {
      const svg = ownerDocument.createElementNS(SVG_NAMESPACE, localName);
      svg.ownerSVGElement = element.ownerSVGElement;
      return svg;
    }
    return ownerDocument.createElement(localName);
  };
  var isVoid = ({ localName, ownerDocument }) => {
    return ownerDocument[MIME].voidElements.test(localName);
  };
  var Element2 = class extends ParentNode {
    constructor(ownerDocument, localName) {
      super(ownerDocument, localName, ELEMENT_NODE);
      this[CLASS_LIST] = null;
      this[DATASET] = null;
      this[STYLE] = null;
    }
    // <Mixins>
    get isConnected() {
      return isConnected(this);
    }
    get parentElement() {
      return parentElement(this);
    }
    get previousSibling() {
      return previousSibling(this);
    }
    get nextSibling() {
      return nextSibling(this);
    }
    get namespaceURI() {
      return "http://www.w3.org/1999/xhtml";
    }
    get previousElementSibling() {
      return previousElementSibling(this);
    }
    get nextElementSibling() {
      return nextElementSibling2(this);
    }
    before(...nodes) {
      before2(this, nodes);
    }
    after(...nodes) {
      after2(this, nodes);
    }
    replaceWith(...nodes) {
      replaceWith2(this, nodes);
    }
    remove() {
      remove2(this[PREV], this, this[END][NEXT]);
    }
    // </Mixins>
    // <specialGetters>
    get id() {
      return stringAttribute.get(this, "id");
    }
    set id(value) {
      stringAttribute.set(this, "id", value);
    }
    get className() {
      return this.classList.value;
    }
    set className(value) {
      const { classList } = this;
      classList.clear();
      classList.add(...value.split(/\s+/));
    }
    get nodeName() {
      return localCase(this);
    }
    get tagName() {
      return localCase(this);
    }
    get classList() {
      return this[CLASS_LIST] || (this[CLASS_LIST] = new DOMTokenList(this));
    }
    get dataset() {
      return this[DATASET] || (this[DATASET] = new DOMStringMap(this));
    }
    get nonce() {
      return stringAttribute.get(this, "nonce");
    }
    set nonce(value) {
      stringAttribute.set(this, "nonce", value);
    }
    get style() {
      return this[STYLE] || (this[STYLE] = new CSSStyleDeclaration(this));
    }
    get tabIndex() {
      return numericAttribute.get(this, "tabindex") || -1;
    }
    set tabIndex(value) {
      numericAttribute.set(this, "tabindex", value);
    }
    // </specialGetters>
    // <contentRelated>
    get innerText() {
      const text3 = [];
      let { [NEXT]: next2, [END]: end2 } = this;
      while (next2 !== end2) {
        if (next2.nodeType === TEXT_NODE) {
          text3.push(next2.textContent.replace(/\s+/g, " "));
        } else if (text3.length && next2[NEXT] != end2 && BLOCK_ELEMENTS.has(next2.tagName)) {
          text3.push("\n");
        }
        next2 = next2[NEXT];
      }
      return text3.join("");
    }
    /**
     * @returns {String}
     */
    get textContent() {
      const text3 = [];
      let { [NEXT]: next2, [END]: end2 } = this;
      while (next2 !== end2) {
        if (next2.nodeType === TEXT_NODE)
          text3.push(next2.textContent);
        next2 = next2[NEXT];
      }
      return text3.join("");
    }
    set textContent(text3) {
      this.replaceChildren();
      if (text3)
        this.appendChild(new Text3(this.ownerDocument, text3));
    }
    get innerHTML() {
      return getInnerHtml(this);
    }
    set innerHTML(html3) {
      setInnerHtml(this, html3);
    }
    get outerHTML() {
      return this.toString();
    }
    set outerHTML(html3) {
      const template = this.ownerDocument.createElement("");
      template.innerHTML = html3;
      this.replaceWith(...template.childNodes);
    }
    // </contentRelated>
    // <attributes>
    get attributes() {
      const attributes2 = new NamedNodeMap(this);
      let next2 = this[NEXT];
      while (next2.nodeType === ATTRIBUTE_NODE) {
        attributes2.push(next2);
        next2 = next2[NEXT];
      }
      return new Proxy(attributes2, attributesHandler);
    }
    focus() {
      this.dispatchEvent(new GlobalEvent("focus"));
    }
    getAttribute(name) {
      if (name === "class")
        return this.className;
      const attribute2 = this.getAttributeNode(name);
      return attribute2 && attribute2.value;
    }
    getAttributeNode(name) {
      let next2 = this[NEXT];
      while (next2.nodeType === ATTRIBUTE_NODE) {
        if (next2.name === name)
          return next2;
        next2 = next2[NEXT];
      }
      return null;
    }
    getAttributeNames() {
      const attributes2 = new NodeList();
      let next2 = this[NEXT];
      while (next2.nodeType === ATTRIBUTE_NODE) {
        attributes2.push(next2.name);
        next2 = next2[NEXT];
      }
      return attributes2;
    }
    hasAttribute(name) {
      return !!this.getAttributeNode(name);
    }
    hasAttributes() {
      return this[NEXT].nodeType === ATTRIBUTE_NODE;
    }
    removeAttribute(name) {
      if (name === "class" && this[CLASS_LIST])
        this[CLASS_LIST].clear();
      let next2 = this[NEXT];
      while (next2.nodeType === ATTRIBUTE_NODE) {
        if (next2.name === name) {
          removeAttribute2(this, next2);
          return;
        }
        next2 = next2[NEXT];
      }
    }
    removeAttributeNode(attribute2) {
      let next2 = this[NEXT];
      while (next2.nodeType === ATTRIBUTE_NODE) {
        if (next2 === attribute2) {
          removeAttribute2(this, next2);
          return;
        }
        next2 = next2[NEXT];
      }
    }
    setAttribute(name, value) {
      if (name === "class")
        this.className = value;
      else {
        const attribute2 = this.getAttributeNode(name);
        if (attribute2)
          attribute2.value = value;
        else
          setAttribute(this, new Attr(this.ownerDocument, name, value));
      }
    }
    setAttributeNode(attribute2) {
      const { name } = attribute2;
      const previously = this.getAttributeNode(name);
      if (previously !== attribute2) {
        if (previously)
          this.removeAttributeNode(previously);
        const { ownerElement } = attribute2;
        if (ownerElement)
          ownerElement.removeAttributeNode(attribute2);
        setAttribute(this, attribute2);
      }
      return previously;
    }
    toggleAttribute(name, force) {
      if (this.hasAttribute(name)) {
        if (!force) {
          this.removeAttribute(name);
          return false;
        }
        return true;
      } else if (force || arguments.length === 1) {
        this.setAttribute(name, "");
        return true;
      }
      return false;
    }
    // </attributes>
    // <ShadowDOM>
    get shadowRoot() {
      if (shadowRoots.has(this)) {
        const { mode, shadowRoot } = shadowRoots.get(this);
        if (mode === "open")
          return shadowRoot;
      }
      return null;
    }
    attachShadow(init) {
      if (shadowRoots.has(this))
        throw new Error("operation not supported");
      const shadowRoot = new ShadowRoot(this);
      shadowRoot.append(...this.childNodes);
      shadowRoots.set(this, {
        mode: init.mode,
        shadowRoot
      });
      return shadowRoot;
    }
    // </ShadowDOM>
    // <selectors>
    matches(selectors) {
      return matches(this, selectors);
    }
    closest(selectors) {
      let parentElement2 = this;
      const matches2 = prepareMatch(parentElement2, selectors);
      while (parentElement2 && !matches2(parentElement2))
        parentElement2 = parentElement2.parentElement;
      return parentElement2;
    }
    // </selectors>
    // <insertAdjacent>
    insertAdjacentElement(position, element) {
      const { parentElement: parentElement2 } = this;
      switch (position) {
        case "beforebegin":
          if (parentElement2) {
            parentElement2.insertBefore(element, this);
            break;
          }
          return null;
        case "afterbegin":
          this.insertBefore(element, this.firstChild);
          break;
        case "beforeend":
          this.insertBefore(element, null);
          break;
        case "afterend":
          if (parentElement2) {
            parentElement2.insertBefore(element, this.nextSibling);
            break;
          }
          return null;
      }
      return element;
    }
    insertAdjacentHTML(position, html3) {
      const template = this.ownerDocument.createElement("template");
      template.innerHTML = html3;
      this.insertAdjacentElement(position, template.content);
    }
    insertAdjacentText(position, text3) {
      const node = this.ownerDocument.createTextNode(text3);
      this.insertAdjacentElement(position, node);
    }
    // </insertAdjacent>
    cloneNode(deep = false) {
      const { ownerDocument, localName } = this;
      const addNext = (next3) => {
        next3.parentNode = parentNode;
        knownAdjacent($next, next3);
        $next = next3;
      };
      const clone2 = create2(ownerDocument, this, localName);
      let parentNode = clone2, $next = clone2;
      let { [NEXT]: next2, [END]: prev2 } = this;
      while (next2 !== prev2 && (deep || next2.nodeType === ATTRIBUTE_NODE)) {
        switch (next2.nodeType) {
          case NODE_END:
            knownAdjacent($next, parentNode[END]);
            $next = parentNode[END];
            parentNode = parentNode.parentNode;
            break;
          case ELEMENT_NODE: {
            const node = create2(ownerDocument, next2, next2.localName);
            addNext(node);
            parentNode = node;
            break;
          }
          case ATTRIBUTE_NODE: {
            const attr2 = next2.cloneNode(deep);
            attr2.ownerElement = parentNode;
            addNext(attr2);
            break;
          }
          case TEXT_NODE:
          case COMMENT_NODE:
            addNext(next2.cloneNode(deep));
            break;
        }
        next2 = next2[NEXT];
      }
      knownAdjacent($next, clone2[END]);
      return clone2;
    }
    // <custom>
    toString() {
      const out = [];
      const { [END]: end2 } = this;
      let next2 = { [NEXT]: this };
      let isOpened = false;
      do {
        next2 = next2[NEXT];
        switch (next2.nodeType) {
          case ATTRIBUTE_NODE: {
            const attr2 = " " + next2;
            switch (attr2) {
              case " id":
              case " class":
              case " style":
                break;
              default:
                out.push(attr2);
            }
            break;
          }
          case NODE_END: {
            const start = next2[START];
            if (isOpened) {
              if ("ownerSVGElement" in start)
                out.push(" />");
              else if (isVoid(start))
                out.push(ignoreCase(start) ? ">" : " />");
              else
                out.push(`></${start.localName}>`);
              isOpened = false;
            } else
              out.push(`</${start.localName}>`);
            break;
          }
          case ELEMENT_NODE:
            if (isOpened)
              out.push(">");
            if (next2.toString !== this.toString) {
              out.push(next2.toString());
              next2 = next2[END];
              isOpened = false;
            } else {
              out.push(`<${next2.localName}`);
              isOpened = true;
            }
            break;
          case TEXT_NODE:
          case COMMENT_NODE:
            out.push((isOpened ? ">" : "") + next2);
            isOpened = false;
            break;
        }
      } while (next2 !== end2);
      return out.join("");
    }
    toJSON() {
      const json = [];
      elementAsJSON(this, json);
      return json;
    }
    // </custom>
    /* c8 ignore start */
    getAttributeNS(_2, name) {
      return this.getAttribute(name);
    }
    getElementsByTagNameNS(_2, name) {
      return this.getElementsByTagName(name);
    }
    hasAttributeNS(_2, name) {
      return this.hasAttribute(name);
    }
    removeAttributeNS(_2, name) {
      this.removeAttribute(name);
    }
    setAttributeNS(_2, name, value) {
      this.setAttribute(name, value);
    }
    setAttributeNodeNS(attr2) {
      return this.setAttributeNode(attr2);
    }
    /* c8 ignore stop */
  };

  // node_modules/linkedom/esm/svg/element.js
  var classNames = /* @__PURE__ */ new WeakMap();
  var handler3 = {
    get(target, name) {
      return target[name];
    },
    set(target, name, value) {
      target[name] = value;
      return true;
    }
  };
  var SVGElement = class extends Element2 {
    constructor(ownerDocument, localName, ownerSVGElement = null) {
      super(ownerDocument, localName);
      this.ownerSVGElement = ownerSVGElement;
    }
    get className() {
      if (!classNames.has(this))
        classNames.set(this, new Proxy({ baseVal: "", animVal: "" }, handler3));
      return classNames.get(this);
    }
    /* c8 ignore start */
    set className(value) {
      const { classList } = this;
      classList.clear();
      classList.add(...value.split(/\s+/));
    }
    /* c8 ignore stop */
    get namespaceURI() {
      return "http://www.w3.org/2000/svg";
    }
    getAttribute(name) {
      return name === "class" ? [...this.classList].join(" ") : super.getAttribute(name);
    }
    setAttribute(name, value) {
      if (name === "class")
        this.className = value;
      else if (name === "style") {
        const { className } = this;
        className.baseVal = className.animVal = value;
      }
      super.setAttribute(name, value);
    }
  };

  // node_modules/linkedom/esm/shared/facades.js
  var illegalConstructor = () => {
    throw new TypeError("Illegal constructor");
  };
  function Attr2() {
    illegalConstructor();
  }
  setPrototypeOf(Attr2, Attr);
  Attr2.prototype = Attr.prototype;
  function CharacterData2() {
    illegalConstructor();
  }
  setPrototypeOf(CharacterData2, CharacterData);
  CharacterData2.prototype = CharacterData.prototype;
  function Comment4() {
    illegalConstructor();
  }
  setPrototypeOf(Comment4, Comment3);
  Comment4.prototype = Comment3.prototype;
  function DocumentFragment2() {
    illegalConstructor();
  }
  setPrototypeOf(DocumentFragment2, DocumentFragment);
  DocumentFragment2.prototype = DocumentFragment.prototype;
  function DocumentType2() {
    illegalConstructor();
  }
  setPrototypeOf(DocumentType2, DocumentType);
  DocumentType2.prototype = DocumentType.prototype;
  function Element3() {
    illegalConstructor();
  }
  setPrototypeOf(Element3, Element2);
  Element3.prototype = Element2.prototype;
  function Node3() {
    illegalConstructor();
  }
  setPrototypeOf(Node3, Node2);
  Node3.prototype = Node2.prototype;
  function ShadowRoot2() {
    illegalConstructor();
  }
  setPrototypeOf(ShadowRoot2, ShadowRoot);
  ShadowRoot2.prototype = ShadowRoot.prototype;
  function Text4() {
    illegalConstructor();
  }
  setPrototypeOf(Text4, Text3);
  Text4.prototype = Text3.prototype;
  function SVGElement2() {
    illegalConstructor();
  }
  setPrototypeOf(SVGElement2, SVGElement);
  SVGElement2.prototype = SVGElement.prototype;
  var Facades = {
    Attr: Attr2,
    CharacterData: CharacterData2,
    Comment: Comment4,
    DocumentFragment: DocumentFragment2,
    DocumentType: DocumentType2,
    Element: Element3,
    Node: Node3,
    ShadowRoot: ShadowRoot2,
    Text: Text4,
    SVGElement: SVGElement2
  };

  // node_modules/linkedom/esm/html/element.js
  var Level0 = /* @__PURE__ */ new WeakMap();
  var level0 = {
    get(element, name) {
      return Level0.has(element) && Level0.get(element)[name] || null;
    },
    set(element, name, value) {
      if (!Level0.has(element))
        Level0.set(element, {});
      const handlers = Level0.get(element);
      const type = name.slice(2);
      if (handlers[name])
        element.removeEventListener(type, handlers[name], false);
      if (handlers[name] = value)
        element.addEventListener(type, value, false);
    }
  };
  var HTMLElement = class extends Element2 {
    static get observedAttributes() {
      return [];
    }
    constructor(ownerDocument = null, localName = "") {
      super(ownerDocument, localName);
      const ownerLess = !ownerDocument;
      let options2;
      if (ownerLess) {
        const { constructor: Class } = this;
        if (!Classes.has(Class))
          throw new Error("unable to initialize this Custom Element");
        ({ ownerDocument, localName, options: options2 } = Classes.get(Class));
      }
      if (ownerDocument[UPGRADE]) {
        const { element, values } = ownerDocument[UPGRADE];
        ownerDocument[UPGRADE] = null;
        for (const [key2, value] of values)
          element[key2] = value;
        return element;
      }
      if (ownerLess) {
        this.ownerDocument = this[END].ownerDocument = ownerDocument;
        this.localName = localName;
        customElements.set(this, { connected: false });
        if (options2.is)
          this.setAttribute("is", options2.is);
      }
    }
    /* c8 ignore start */
    /* TODO: what about these?
    offsetHeight
    offsetLeft
    offsetParent
    offsetTop
    offsetWidth
    */
    blur() {
      this.dispatchEvent(new GlobalEvent("blur"));
    }
    click() {
      this.dispatchEvent(new GlobalEvent("click"));
    }
    // Boolean getters
    get accessKeyLabel() {
      const { accessKey } = this;
      return accessKey && `Alt+Shift+${accessKey}`;
    }
    get isContentEditable() {
      return this.hasAttribute("contenteditable");
    }
    // Boolean Accessors
    get contentEditable() {
      return booleanAttribute.get(this, "contenteditable");
    }
    set contentEditable(value) {
      booleanAttribute.set(this, "contenteditable", value);
    }
    get draggable() {
      return booleanAttribute.get(this, "draggable");
    }
    set draggable(value) {
      booleanAttribute.set(this, "draggable", value);
    }
    get hidden() {
      return booleanAttribute.get(this, "hidden");
    }
    set hidden(value) {
      booleanAttribute.set(this, "hidden", value);
    }
    get spellcheck() {
      return booleanAttribute.get(this, "spellcheck");
    }
    set spellcheck(value) {
      booleanAttribute.set(this, "spellcheck", value);
    }
    // String Accessors
    get accessKey() {
      return stringAttribute.get(this, "accesskey");
    }
    set accessKey(value) {
      stringAttribute.set(this, "accesskey", value);
    }
    get dir() {
      return stringAttribute.get(this, "dir");
    }
    set dir(value) {
      stringAttribute.set(this, "dir", value);
    }
    get lang() {
      return stringAttribute.get(this, "lang");
    }
    set lang(value) {
      stringAttribute.set(this, "lang", value);
    }
    get title() {
      return stringAttribute.get(this, "title");
    }
    set title(value) {
      stringAttribute.set(this, "title", value);
    }
    // DOM Level 0
    get onabort() {
      return level0.get(this, "onabort");
    }
    set onabort(value) {
      level0.set(this, "onabort", value);
    }
    get onblur() {
      return level0.get(this, "onblur");
    }
    set onblur(value) {
      level0.set(this, "onblur", value);
    }
    get oncancel() {
      return level0.get(this, "oncancel");
    }
    set oncancel(value) {
      level0.set(this, "oncancel", value);
    }
    get oncanplay() {
      return level0.get(this, "oncanplay");
    }
    set oncanplay(value) {
      level0.set(this, "oncanplay", value);
    }
    get oncanplaythrough() {
      return level0.get(this, "oncanplaythrough");
    }
    set oncanplaythrough(value) {
      level0.set(this, "oncanplaythrough", value);
    }
    get onchange() {
      return level0.get(this, "onchange");
    }
    set onchange(value) {
      level0.set(this, "onchange", value);
    }
    get onclick() {
      return level0.get(this, "onclick");
    }
    set onclick(value) {
      level0.set(this, "onclick", value);
    }
    get onclose() {
      return level0.get(this, "onclose");
    }
    set onclose(value) {
      level0.set(this, "onclose", value);
    }
    get oncontextmenu() {
      return level0.get(this, "oncontextmenu");
    }
    set oncontextmenu(value) {
      level0.set(this, "oncontextmenu", value);
    }
    get oncuechange() {
      return level0.get(this, "oncuechange");
    }
    set oncuechange(value) {
      level0.set(this, "oncuechange", value);
    }
    get ondblclick() {
      return level0.get(this, "ondblclick");
    }
    set ondblclick(value) {
      level0.set(this, "ondblclick", value);
    }
    get ondrag() {
      return level0.get(this, "ondrag");
    }
    set ondrag(value) {
      level0.set(this, "ondrag", value);
    }
    get ondragend() {
      return level0.get(this, "ondragend");
    }
    set ondragend(value) {
      level0.set(this, "ondragend", value);
    }
    get ondragenter() {
      return level0.get(this, "ondragenter");
    }
    set ondragenter(value) {
      level0.set(this, "ondragenter", value);
    }
    get ondragleave() {
      return level0.get(this, "ondragleave");
    }
    set ondragleave(value) {
      level0.set(this, "ondragleave", value);
    }
    get ondragover() {
      return level0.get(this, "ondragover");
    }
    set ondragover(value) {
      level0.set(this, "ondragover", value);
    }
    get ondragstart() {
      return level0.get(this, "ondragstart");
    }
    set ondragstart(value) {
      level0.set(this, "ondragstart", value);
    }
    get ondrop() {
      return level0.get(this, "ondrop");
    }
    set ondrop(value) {
      level0.set(this, "ondrop", value);
    }
    get ondurationchange() {
      return level0.get(this, "ondurationchange");
    }
    set ondurationchange(value) {
      level0.set(this, "ondurationchange", value);
    }
    get onemptied() {
      return level0.get(this, "onemptied");
    }
    set onemptied(value) {
      level0.set(this, "onemptied", value);
    }
    get onended() {
      return level0.get(this, "onended");
    }
    set onended(value) {
      level0.set(this, "onended", value);
    }
    get onerror() {
      return level0.get(this, "onerror");
    }
    set onerror(value) {
      level0.set(this, "onerror", value);
    }
    get onfocus() {
      return level0.get(this, "onfocus");
    }
    set onfocus(value) {
      level0.set(this, "onfocus", value);
    }
    get oninput() {
      return level0.get(this, "oninput");
    }
    set oninput(value) {
      level0.set(this, "oninput", value);
    }
    get oninvalid() {
      return level0.get(this, "oninvalid");
    }
    set oninvalid(value) {
      level0.set(this, "oninvalid", value);
    }
    get onkeydown() {
      return level0.get(this, "onkeydown");
    }
    set onkeydown(value) {
      level0.set(this, "onkeydown", value);
    }
    get onkeypress() {
      return level0.get(this, "onkeypress");
    }
    set onkeypress(value) {
      level0.set(this, "onkeypress", value);
    }
    get onkeyup() {
      return level0.get(this, "onkeyup");
    }
    set onkeyup(value) {
      level0.set(this, "onkeyup", value);
    }
    get onload() {
      return level0.get(this, "onload");
    }
    set onload(value) {
      level0.set(this, "onload", value);
    }
    get onloadeddata() {
      return level0.get(this, "onloadeddata");
    }
    set onloadeddata(value) {
      level0.set(this, "onloadeddata", value);
    }
    get onloadedmetadata() {
      return level0.get(this, "onloadedmetadata");
    }
    set onloadedmetadata(value) {
      level0.set(this, "onloadedmetadata", value);
    }
    get onloadstart() {
      return level0.get(this, "onloadstart");
    }
    set onloadstart(value) {
      level0.set(this, "onloadstart", value);
    }
    get onmousedown() {
      return level0.get(this, "onmousedown");
    }
    set onmousedown(value) {
      level0.set(this, "onmousedown", value);
    }
    get onmouseenter() {
      return level0.get(this, "onmouseenter");
    }
    set onmouseenter(value) {
      level0.set(this, "onmouseenter", value);
    }
    get onmouseleave() {
      return level0.get(this, "onmouseleave");
    }
    set onmouseleave(value) {
      level0.set(this, "onmouseleave", value);
    }
    get onmousemove() {
      return level0.get(this, "onmousemove");
    }
    set onmousemove(value) {
      level0.set(this, "onmousemove", value);
    }
    get onmouseout() {
      return level0.get(this, "onmouseout");
    }
    set onmouseout(value) {
      level0.set(this, "onmouseout", value);
    }
    get onmouseover() {
      return level0.get(this, "onmouseover");
    }
    set onmouseover(value) {
      level0.set(this, "onmouseover", value);
    }
    get onmouseup() {
      return level0.get(this, "onmouseup");
    }
    set onmouseup(value) {
      level0.set(this, "onmouseup", value);
    }
    get onmousewheel() {
      return level0.get(this, "onmousewheel");
    }
    set onmousewheel(value) {
      level0.set(this, "onmousewheel", value);
    }
    get onpause() {
      return level0.get(this, "onpause");
    }
    set onpause(value) {
      level0.set(this, "onpause", value);
    }
    get onplay() {
      return level0.get(this, "onplay");
    }
    set onplay(value) {
      level0.set(this, "onplay", value);
    }
    get onplaying() {
      return level0.get(this, "onplaying");
    }
    set onplaying(value) {
      level0.set(this, "onplaying", value);
    }
    get onprogress() {
      return level0.get(this, "onprogress");
    }
    set onprogress(value) {
      level0.set(this, "onprogress", value);
    }
    get onratechange() {
      return level0.get(this, "onratechange");
    }
    set onratechange(value) {
      level0.set(this, "onratechange", value);
    }
    get onreset() {
      return level0.get(this, "onreset");
    }
    set onreset(value) {
      level0.set(this, "onreset", value);
    }
    get onresize() {
      return level0.get(this, "onresize");
    }
    set onresize(value) {
      level0.set(this, "onresize", value);
    }
    get onscroll() {
      return level0.get(this, "onscroll");
    }
    set onscroll(value) {
      level0.set(this, "onscroll", value);
    }
    get onseeked() {
      return level0.get(this, "onseeked");
    }
    set onseeked(value) {
      level0.set(this, "onseeked", value);
    }
    get onseeking() {
      return level0.get(this, "onseeking");
    }
    set onseeking(value) {
      level0.set(this, "onseeking", value);
    }
    get onselect() {
      return level0.get(this, "onselect");
    }
    set onselect(value) {
      level0.set(this, "onselect", value);
    }
    get onshow() {
      return level0.get(this, "onshow");
    }
    set onshow(value) {
      level0.set(this, "onshow", value);
    }
    get onstalled() {
      return level0.get(this, "onstalled");
    }
    set onstalled(value) {
      level0.set(this, "onstalled", value);
    }
    get onsubmit() {
      return level0.get(this, "onsubmit");
    }
    set onsubmit(value) {
      level0.set(this, "onsubmit", value);
    }
    get onsuspend() {
      return level0.get(this, "onsuspend");
    }
    set onsuspend(value) {
      level0.set(this, "onsuspend", value);
    }
    get ontimeupdate() {
      return level0.get(this, "ontimeupdate");
    }
    set ontimeupdate(value) {
      level0.set(this, "ontimeupdate", value);
    }
    get ontoggle() {
      return level0.get(this, "ontoggle");
    }
    set ontoggle(value) {
      level0.set(this, "ontoggle", value);
    }
    get onvolumechange() {
      return level0.get(this, "onvolumechange");
    }
    set onvolumechange(value) {
      level0.set(this, "onvolumechange", value);
    }
    get onwaiting() {
      return level0.get(this, "onwaiting");
    }
    set onwaiting(value) {
      level0.set(this, "onwaiting", value);
    }
    get onauxclick() {
      return level0.get(this, "onauxclick");
    }
    set onauxclick(value) {
      level0.set(this, "onauxclick", value);
    }
    get ongotpointercapture() {
      return level0.get(this, "ongotpointercapture");
    }
    set ongotpointercapture(value) {
      level0.set(this, "ongotpointercapture", value);
    }
    get onlostpointercapture() {
      return level0.get(this, "onlostpointercapture");
    }
    set onlostpointercapture(value) {
      level0.set(this, "onlostpointercapture", value);
    }
    get onpointercancel() {
      return level0.get(this, "onpointercancel");
    }
    set onpointercancel(value) {
      level0.set(this, "onpointercancel", value);
    }
    get onpointerdown() {
      return level0.get(this, "onpointerdown");
    }
    set onpointerdown(value) {
      level0.set(this, "onpointerdown", value);
    }
    get onpointerenter() {
      return level0.get(this, "onpointerenter");
    }
    set onpointerenter(value) {
      level0.set(this, "onpointerenter", value);
    }
    get onpointerleave() {
      return level0.get(this, "onpointerleave");
    }
    set onpointerleave(value) {
      level0.set(this, "onpointerleave", value);
    }
    get onpointermove() {
      return level0.get(this, "onpointermove");
    }
    set onpointermove(value) {
      level0.set(this, "onpointermove", value);
    }
    get onpointerout() {
      return level0.get(this, "onpointerout");
    }
    set onpointerout(value) {
      level0.set(this, "onpointerout", value);
    }
    get onpointerover() {
      return level0.get(this, "onpointerover");
    }
    set onpointerover(value) {
      level0.set(this, "onpointerover", value);
    }
    get onpointerup() {
      return level0.get(this, "onpointerup");
    }
    set onpointerup(value) {
      level0.set(this, "onpointerup", value);
    }
    /* c8 ignore stop */
  };

  // node_modules/linkedom/esm/html/template-element.js
  var tagName = "template";
  var HTMLTemplateElement = class extends HTMLElement {
    constructor(ownerDocument) {
      super(ownerDocument, tagName);
      const content = this.ownerDocument.createDocumentFragment();
      (this[CONTENT] = content)[PRIVATE] = this;
    }
    get content() {
      if (this.hasChildNodes() && !this[CONTENT].hasChildNodes()) {
        for (const node of this.childNodes)
          this[CONTENT].appendChild(node.cloneNode(true));
      }
      return this[CONTENT];
    }
  };
  registerHTMLClass(tagName, HTMLTemplateElement);

  // node_modules/linkedom/esm/html/html-element.js
  var HTMLHtmlElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "html") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/text-element.js
  var { toString: toString2 } = HTMLElement.prototype;
  var TextElement = class extends HTMLElement {
    get innerHTML() {
      return this.textContent;
    }
    set innerHTML(html3) {
      this.textContent = html3;
    }
    toString() {
      const outerHTML = toString2.call(this.cloneNode());
      return outerHTML.replace(/></, `>${this.textContent}<`);
    }
  };

  // node_modules/linkedom/esm/html/script-element.js
  var tagName2 = "script";
  var HTMLScriptElement = class extends TextElement {
    constructor(ownerDocument, localName = tagName2) {
      super(ownerDocument, localName);
    }
    get type() {
      return stringAttribute.get(this, "type");
    }
    set type(value) {
      stringAttribute.set(this, "type", value);
    }
    get src() {
      return stringAttribute.get(this, "src");
    }
    set src(value) {
      stringAttribute.set(this, "src", value);
    }
    get defer() {
      return booleanAttribute.get(this, "defer");
    }
    set defer(value) {
      booleanAttribute.set(this, "defer", value);
    }
    get crossOrigin() {
      return stringAttribute.get(this, "crossorigin");
    }
    set crossOrigin(value) {
      stringAttribute.set(this, "crossorigin", value);
    }
    get nomodule() {
      return booleanAttribute.get(this, "nomodule");
    }
    set nomodule(value) {
      booleanAttribute.set(this, "nomodule", value);
    }
    get referrerPolicy() {
      return stringAttribute.get(this, "referrerpolicy");
    }
    set referrerPolicy(value) {
      stringAttribute.set(this, "referrerpolicy", value);
    }
    get nonce() {
      return stringAttribute.get(this, "nonce");
    }
    set nonce(value) {
      stringAttribute.set(this, "nonce", value);
    }
    get async() {
      return booleanAttribute.get(this, "async");
    }
    set async(value) {
      booleanAttribute.set(this, "async", value);
    }
    get text() {
      return this.textContent;
    }
    set text(content) {
      this.textContent = content;
    }
  };
  registerHTMLClass(tagName2, HTMLScriptElement);

  // node_modules/linkedom/esm/html/frame-element.js
  var HTMLFrameElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "frame") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/i-frame-element.js
  var tagName3 = "iframe";
  var HTMLIFrameElement = class extends HTMLElement {
    constructor(ownerDocument, localName = tagName3) {
      super(ownerDocument, localName);
    }
    /* c8 ignore start */
    get src() {
      return stringAttribute.get(this, "src");
    }
    set src(value) {
      stringAttribute.set(this, "src", value);
    }
    get srcdoc() {
      return stringAttribute.get(this, "srcdoc");
    }
    set srcdoc(value) {
      stringAttribute.set(this, "srcdoc", value);
    }
    get name() {
      return stringAttribute.get(this, "name");
    }
    set name(value) {
      stringAttribute.set(this, "name", value);
    }
    get allow() {
      return stringAttribute.get(this, "allow");
    }
    set allow(value) {
      stringAttribute.set(this, "allow", value);
    }
    get allowFullscreen() {
      return booleanAttribute.get(this, "allowfullscreen");
    }
    set allowFullscreen(value) {
      booleanAttribute.set(this, "allowfullscreen", value);
    }
    get referrerPolicy() {
      return stringAttribute.get(this, "referrerpolicy");
    }
    set referrerPolicy(value) {
      stringAttribute.set(this, "referrerpolicy", value);
    }
    get loading() {
      return stringAttribute.get(this, "loading");
    }
    set loading(value) {
      stringAttribute.set(this, "loading", value);
    }
    /* c8 ignore stop */
  };
  registerHTMLClass(tagName3, HTMLIFrameElement);

  // node_modules/linkedom/esm/html/object-element.js
  var HTMLObjectElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "object") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/head-element.js
  var HTMLHeadElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "head") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/body-element.js
  var HTMLBodyElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "body") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/style-element.js
  var import_cssom = __toESM(require_lib(), 1);
  var tagName4 = "style";
  var HTMLStyleElement = class extends TextElement {
    constructor(ownerDocument, localName = tagName4) {
      super(ownerDocument, localName);
      this[SHEET] = null;
    }
    get sheet() {
      const sheet = this[SHEET];
      if (sheet !== null) {
        return sheet;
      }
      return this[SHEET] = (0, import_cssom.parse)(this.textContent);
    }
    get innerHTML() {
      return super.innerHTML || "";
    }
    set innerHTML(value) {
      super.textContent = value;
      this[SHEET] = null;
    }
    get innerText() {
      return super.innerText || "";
    }
    set innerText(value) {
      super.textContent = value;
      this[SHEET] = null;
    }
    get textContent() {
      return super.textContent || "";
    }
    set textContent(value) {
      super.textContent = value;
      this[SHEET] = null;
    }
  };
  registerHTMLClass(tagName4, HTMLStyleElement);

  // node_modules/linkedom/esm/html/time-element.js
  var HTMLTimeElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "time") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/field-set-element.js
  var HTMLFieldSetElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "fieldset") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/embed-element.js
  var HTMLEmbedElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "embed") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/hr-element.js
  var HTMLHRElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "hr") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/progress-element.js
  var HTMLProgressElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "progress") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/paragraph-element.js
  var HTMLParagraphElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "p") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/table-element.js
  var HTMLTableElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "table") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/frame-set-element.js
  var HTMLFrameSetElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "frameset") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/li-element.js
  var HTMLLIElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "li") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/base-element.js
  var HTMLBaseElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "base") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/data-list-element.js
  var HTMLDataListElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "datalist") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/input-element.js
  var tagName5 = "input";
  var HTMLInputElement = class extends HTMLElement {
    constructor(ownerDocument, localName = tagName5) {
      super(ownerDocument, localName);
    }
    /* c8 ignore start */
    get autofocus() {
      return booleanAttribute.get(this, "autofocus") || -1;
    }
    set autofocus(value) {
      booleanAttribute.set(this, "autofocus", value);
    }
    get disabled() {
      return booleanAttribute.get(this, "disabled");
    }
    set disabled(value) {
      booleanAttribute.set(this, "disabled", value);
    }
    get name() {
      return this.getAttribute("name");
    }
    set name(value) {
      this.setAttribute("name", value);
    }
    get placeholder() {
      return this.getAttribute("placeholder");
    }
    set placeholder(value) {
      this.setAttribute("placeholder", value);
    }
    get type() {
      return this.getAttribute("type");
    }
    set type(value) {
      this.setAttribute("type", value);
    }
    get value() {
      return stringAttribute.get(this, "value");
    }
    set value(value) {
      stringAttribute.set(this, "value", value);
    }
    /* c8 ignore stop */
  };
  registerHTMLClass(tagName5, HTMLInputElement);

  // node_modules/linkedom/esm/html/param-element.js
  var HTMLParamElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "param") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/media-element.js
  var HTMLMediaElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "media") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/audio-element.js
  var HTMLAudioElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "audio") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/heading-element.js
  var tagName6 = "h1";
  var HTMLHeadingElement = class extends HTMLElement {
    constructor(ownerDocument, localName = tagName6) {
      super(ownerDocument, localName);
    }
  };
  registerHTMLClass([tagName6, "h2", "h3", "h4", "h5", "h6"], HTMLHeadingElement);

  // node_modules/linkedom/esm/html/directory-element.js
  var HTMLDirectoryElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "dir") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/quote-element.js
  var HTMLQuoteElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "quote") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/canvas-element.js
  var import_canvas = __toESM(require_canvas(), 1);
  var { createCanvas } = import_canvas.default;
  var tagName7 = "canvas";
  var HTMLCanvasElement = class extends HTMLElement {
    constructor(ownerDocument, localName = tagName7) {
      super(ownerDocument, localName);
      this[IMAGE] = createCanvas(300, 150);
    }
    get width() {
      return this[IMAGE].width;
    }
    set width(value) {
      numericAttribute.set(this, "width", value);
      this[IMAGE].width = value;
    }
    get height() {
      return this[IMAGE].height;
    }
    set height(value) {
      numericAttribute.set(this, "height", value);
      this[IMAGE].height = value;
    }
    getContext(type) {
      return this[IMAGE].getContext(type);
    }
    toDataURL(...args) {
      return this[IMAGE].toDataURL(...args);
    }
  };
  registerHTMLClass(tagName7, HTMLCanvasElement);

  // node_modules/linkedom/esm/html/legend-element.js
  var HTMLLegendElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "legend") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/option-element.js
  var tagName8 = "option";
  var HTMLOptionElement = class extends HTMLElement {
    constructor(ownerDocument, localName = tagName8) {
      super(ownerDocument, localName);
    }
    /* c8 ignore start */
    get value() {
      return stringAttribute.get(this, "value");
    }
    set value(value) {
      stringAttribute.set(this, "value", value);
    }
    /* c8 ignore stop */
    get selected() {
      return booleanAttribute.get(this, "selected");
    }
    set selected(value) {
      const option = this.parentElement?.querySelector("option[selected]");
      if (option && option !== this)
        option.selected = false;
      booleanAttribute.set(this, "selected", value);
    }
  };
  registerHTMLClass(tagName8, HTMLOptionElement);

  // node_modules/linkedom/esm/html/span-element.js
  var HTMLSpanElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "span") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/meter-element.js
  var HTMLMeterElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "meter") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/video-element.js
  var HTMLVideoElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "video") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/table-cell-element.js
  var HTMLTableCellElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "td") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/title-element.js
  var tagName9 = "title";
  var HTMLTitleElement = class extends TextElement {
    constructor(ownerDocument, localName = tagName9) {
      super(ownerDocument, localName);
    }
  };
  registerHTMLClass(tagName9, HTMLTitleElement);

  // node_modules/linkedom/esm/html/output-element.js
  var HTMLOutputElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "output") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/table-row-element.js
  var HTMLTableRowElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "tr") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/data-element.js
  var HTMLDataElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "data") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/menu-element.js
  var HTMLMenuElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "menu") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/select-element.js
  var tagName10 = "select";
  var HTMLSelectElement = class extends HTMLElement {
    constructor(ownerDocument, localName = tagName10) {
      super(ownerDocument, localName);
    }
    get options() {
      let children2 = new NodeList();
      let { firstElementChild } = this;
      while (firstElementChild) {
        if (firstElementChild.tagName === "OPTGROUP")
          children2.push(...firstElementChild.children);
        else
          children2.push(firstElementChild);
        firstElementChild = firstElementChild.nextElementSibling;
      }
      return children2;
    }
    /* c8 ignore start */
    get disabled() {
      return booleanAttribute.get(this, "disabled");
    }
    set disabled(value) {
      booleanAttribute.set(this, "disabled", value);
    }
    get name() {
      return this.getAttribute("name");
    }
    set name(value) {
      this.setAttribute("name", value);
    }
    /* c8 ignore stop */
    get value() {
      return this.querySelector("option[selected]")?.value;
    }
  };
  registerHTMLClass(tagName10, HTMLSelectElement);

  // node_modules/linkedom/esm/html/br-element.js
  var HTMLBRElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "br") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/button-element.js
  var tagName11 = "button";
  var HTMLButtonElement = class extends HTMLElement {
    constructor(ownerDocument, localName = tagName11) {
      super(ownerDocument, localName);
    }
    /* c8 ignore start */
    get disabled() {
      return booleanAttribute.get(this, "disabled");
    }
    set disabled(value) {
      booleanAttribute.set(this, "disabled", value);
    }
    get name() {
      return this.getAttribute("name");
    }
    set name(value) {
      this.setAttribute("name", value);
    }
    get type() {
      return this.getAttribute("type");
    }
    set type(value) {
      this.setAttribute("type", value);
    }
    /* c8 ignore stop */
  };
  registerHTMLClass(tagName11, HTMLButtonElement);

  // node_modules/linkedom/esm/html/map-element.js
  var HTMLMapElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "map") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/opt-group-element.js
  var HTMLOptGroupElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "optgroup") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/d-list-element.js
  var HTMLDListElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "dl") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/text-area-element.js
  var tagName12 = "textarea";
  var HTMLTextAreaElement = class extends TextElement {
    constructor(ownerDocument, localName = tagName12) {
      super(ownerDocument, localName);
    }
    /* c8 ignore start */
    get disabled() {
      return booleanAttribute.get(this, "disabled");
    }
    set disabled(value) {
      booleanAttribute.set(this, "disabled", value);
    }
    get name() {
      return this.getAttribute("name");
    }
    set name(value) {
      this.setAttribute("name", value);
    }
    get placeholder() {
      return this.getAttribute("placeholder");
    }
    set placeholder(value) {
      this.setAttribute("placeholder", value);
    }
    get type() {
      return this.getAttribute("type");
    }
    set type(value) {
      this.setAttribute("type", value);
    }
    get value() {
      return this.textContent;
    }
    set value(content) {
      this.textContent = content;
    }
    /* c8 ignore stop */
  };
  registerHTMLClass(tagName12, HTMLTextAreaElement);

  // node_modules/linkedom/esm/html/font-element.js
  var HTMLFontElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "font") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/div-element.js
  var HTMLDivElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "div") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/link-element.js
  var tagName13 = "link";
  var HTMLLinkElement = class extends HTMLElement {
    constructor(ownerDocument, localName = tagName13) {
      super(ownerDocument, localName);
    }
    /* c8 ignore start */
    // copy paste from img.src, already covered
    get disabled() {
      return booleanAttribute.get(this, "disabled");
    }
    set disabled(value) {
      booleanAttribute.set(this, "disabled", value);
    }
    get href() {
      return stringAttribute.get(this, "href");
    }
    set href(value) {
      stringAttribute.set(this, "href", value);
    }
    get hreflang() {
      return stringAttribute.get(this, "hreflang");
    }
    set hreflang(value) {
      stringAttribute.set(this, "hreflang", value);
    }
    get media() {
      return stringAttribute.get(this, "media");
    }
    set media(value) {
      stringAttribute.set(this, "media", value);
    }
    get rel() {
      return stringAttribute.get(this, "rel");
    }
    set rel(value) {
      stringAttribute.set(this, "rel", value);
    }
    get type() {
      return stringAttribute.get(this, "type");
    }
    set type(value) {
      stringAttribute.set(this, "type", value);
    }
    /* c8 ignore stop */
  };
  registerHTMLClass(tagName13, HTMLLinkElement);

  // node_modules/linkedom/esm/html/slot-element.js
  var HTMLSlotElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "slot") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/form-element.js
  var HTMLFormElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "form") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/image-element.js
  var tagName14 = "img";
  var HTMLImageElement = class extends HTMLElement {
    constructor(ownerDocument, localName = tagName14) {
      super(ownerDocument, localName);
    }
    /* c8 ignore start */
    get alt() {
      return stringAttribute.get(this, "alt");
    }
    set alt(value) {
      stringAttribute.set(this, "alt", value);
    }
    get sizes() {
      return stringAttribute.get(this, "sizes");
    }
    set sizes(value) {
      stringAttribute.set(this, "sizes", value);
    }
    get src() {
      return stringAttribute.get(this, "src");
    }
    set src(value) {
      stringAttribute.set(this, "src", value);
    }
    get srcset() {
      return stringAttribute.get(this, "srcset");
    }
    set srcset(value) {
      stringAttribute.set(this, "srcset", value);
    }
    get title() {
      return stringAttribute.get(this, "title");
    }
    set title(value) {
      stringAttribute.set(this, "title", value);
    }
    get width() {
      return numericAttribute.get(this, "width");
    }
    set width(value) {
      numericAttribute.set(this, "width", value);
    }
    get height() {
      return numericAttribute.get(this, "height");
    }
    set height(value) {
      numericAttribute.set(this, "height", value);
    }
    /* c8 ignore stop */
  };
  registerHTMLClass(tagName14, HTMLImageElement);

  // node_modules/linkedom/esm/html/pre-element.js
  var HTMLPreElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "pre") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/u-list-element.js
  var HTMLUListElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "ul") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/meta-element.js
  var tagName15 = "meta";
  var HTMLMetaElement = class extends HTMLElement {
    constructor(ownerDocument, localName = tagName15) {
      super(ownerDocument, localName);
    }
    /* c8 ignore start */
    get name() {
      return stringAttribute.get(this, "name");
    }
    set name(value) {
      stringAttribute.set(this, "name", value);
    }
    get httpEquiv() {
      return stringAttribute.get(this, "http-equiv");
    }
    set httpEquiv(value) {
      stringAttribute.set(this, "http-equiv", value);
    }
    get content() {
      return stringAttribute.get(this, "content");
    }
    set content(value) {
      stringAttribute.set(this, "content", value);
    }
    get charset() {
      return stringAttribute.get(this, "charset");
    }
    set charset(value) {
      stringAttribute.set(this, "charset", value);
    }
    get media() {
      return stringAttribute.get(this, "media");
    }
    set media(value) {
      stringAttribute.set(this, "media", value);
    }
    /* c8 ignore stop */
  };
  registerHTMLClass(tagName15, HTMLMetaElement);

  // node_modules/linkedom/esm/html/picture-element.js
  var HTMLPictureElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "picture") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/area-element.js
  var HTMLAreaElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "area") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/o-list-element.js
  var HTMLOListElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "ol") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/table-caption-element.js
  var HTMLTableCaptionElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "caption") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/anchor-element.js
  var tagName16 = "a";
  var HTMLAnchorElement = class extends HTMLElement {
    constructor(ownerDocument, localName = tagName16) {
      super(ownerDocument, localName);
    }
    /* c8 ignore start */
    // copy paste from img.src, already covered
    get href() {
      return encodeURI(stringAttribute.get(this, "href"));
    }
    set href(value) {
      stringAttribute.set(this, "href", decodeURI(value));
    }
    get download() {
      return encodeURI(stringAttribute.get(this, "download"));
    }
    set download(value) {
      stringAttribute.set(this, "download", decodeURI(value));
    }
    get target() {
      return stringAttribute.get(this, "target");
    }
    set target(value) {
      stringAttribute.set(this, "target", value);
    }
    get type() {
      return stringAttribute.get(this, "type");
    }
    set type(value) {
      stringAttribute.set(this, "type", value);
    }
    /* c8 ignore stop */
  };
  registerHTMLClass(tagName16, HTMLAnchorElement);

  // node_modules/linkedom/esm/html/label-element.js
  var HTMLLabelElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "label") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/unknown-element.js
  var HTMLUnknownElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "unknown") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/mod-element.js
  var HTMLModElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "mod") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/details-element.js
  var HTMLDetailsElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "details") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/source-element.js
  var tagName17 = "source";
  var HTMLSourceElement = class extends HTMLElement {
    constructor(ownerDocument, localName = tagName17) {
      super(ownerDocument, localName);
    }
    /* c8 ignore start */
    get src() {
      return stringAttribute.get(this, "src");
    }
    set src(value) {
      stringAttribute.set(this, "src", value);
    }
    get srcset() {
      return stringAttribute.get(this, "srcset");
    }
    set srcset(value) {
      stringAttribute.set(this, "srcset", value);
    }
    get sizes() {
      return stringAttribute.get(this, "sizes");
    }
    set sizes(value) {
      stringAttribute.set(this, "sizes", value);
    }
    get type() {
      return stringAttribute.get(this, "type");
    }
    set type(value) {
      stringAttribute.set(this, "type", value);
    }
    /* c8 ignore stop */
  };
  registerHTMLClass(tagName17, HTMLSourceElement);

  // node_modules/linkedom/esm/html/track-element.js
  var HTMLTrackElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "track") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/html/marquee-element.js
  var HTMLMarqueeElement = class extends HTMLElement {
    constructor(ownerDocument, localName = "marquee") {
      super(ownerDocument, localName);
    }
  };

  // node_modules/linkedom/esm/shared/html-classes.js
  var HTMLClasses = {
    HTMLElement,
    HTMLTemplateElement,
    HTMLHtmlElement,
    HTMLScriptElement,
    HTMLFrameElement,
    HTMLIFrameElement,
    HTMLObjectElement,
    HTMLHeadElement,
    HTMLBodyElement,
    HTMLStyleElement,
    HTMLTimeElement,
    HTMLFieldSetElement,
    HTMLEmbedElement,
    HTMLHRElement,
    HTMLProgressElement,
    HTMLParagraphElement,
    HTMLTableElement,
    HTMLFrameSetElement,
    HTMLLIElement,
    HTMLBaseElement,
    HTMLDataListElement,
    HTMLInputElement,
    HTMLParamElement,
    HTMLMediaElement,
    HTMLAudioElement,
    HTMLHeadingElement,
    HTMLDirectoryElement,
    HTMLQuoteElement,
    HTMLCanvasElement,
    HTMLLegendElement,
    HTMLOptionElement,
    HTMLSpanElement,
    HTMLMeterElement,
    HTMLVideoElement,
    HTMLTableCellElement,
    HTMLTitleElement,
    HTMLOutputElement,
    HTMLTableRowElement,
    HTMLDataElement,
    HTMLMenuElement,
    HTMLSelectElement,
    HTMLBRElement,
    HTMLButtonElement,
    HTMLMapElement,
    HTMLOptGroupElement,
    HTMLDListElement,
    HTMLTextAreaElement,
    HTMLFontElement,
    HTMLDivElement,
    HTMLLinkElement,
    HTMLSlotElement,
    HTMLFormElement,
    HTMLImageElement,
    HTMLPreElement,
    HTMLUListElement,
    HTMLMetaElement,
    HTMLPictureElement,
    HTMLAreaElement,
    HTMLOListElement,
    HTMLTableCaptionElement,
    HTMLAnchorElement,
    HTMLLabelElement,
    HTMLUnknownElement,
    HTMLModElement,
    HTMLDetailsElement,
    HTMLSourceElement,
    HTMLTrackElement,
    HTMLMarqueeElement
  };

  // node_modules/linkedom/esm/shared/mime.js
  var voidElements2 = { test: () => true };
  var Mime = {
    "text/html": {
      docType: "<!DOCTYPE html>",
      ignoreCase: true,
      voidElements: /^(?:area|base|br|col|embed|hr|img|input|keygen|link|menuitem|meta|param|source|track|wbr)$/i
    },
    "image/svg+xml": {
      docType: '<?xml version="1.0" encoding="utf-8"?>',
      ignoreCase: false,
      voidElements: voidElements2
    },
    "text/xml": {
      docType: '<?xml version="1.0" encoding="utf-8"?>',
      ignoreCase: false,
      voidElements: voidElements2
    },
    "application/xml": {
      docType: '<?xml version="1.0" encoding="utf-8"?>',
      ignoreCase: false,
      voidElements: voidElements2
    },
    "application/xhtml+xml": {
      docType: '<?xml version="1.0" encoding="utf-8"?>',
      ignoreCase: false,
      voidElements: voidElements2
    }
  };

  // node_modules/linkedom/esm/interface/custom-event.js
  var CustomEvent = class extends GlobalEvent {
    constructor(type, eventInitDict = {}) {
      super(type, eventInitDict);
      this.detail = eventInitDict.detail;
    }
  };

  // node_modules/linkedom/esm/interface/input-event.js
  var InputEvent = class extends GlobalEvent {
    constructor(type, inputEventInit = {}) {
      super(type, inputEventInit);
      this.inputType = inputEventInit.inputType;
      this.data = inputEventInit.data;
      this.dataTransfer = inputEventInit.dataTransfer;
      this.isComposing = inputEventInit.isComposing || false;
      this.ranges = inputEventInit.ranges;
    }
  };

  // node_modules/linkedom/esm/interface/image.js
  var ImageClass = (ownerDocument) => (
    /**
     * @implements globalThis.Image
     */
    class Image extends HTMLImageElement {
      constructor(width, height) {
        super(ownerDocument);
        switch (arguments.length) {
          case 1:
            this.height = width;
            this.width = width;
            break;
          case 2:
            this.height = height;
            this.width = width;
            break;
        }
      }
    }
  );

  // node_modules/linkedom/esm/interface/range.js
  var deleteContents = ({ [START]: start, [END]: end2 }, fragment = null) => {
    setAdjacent(start[PREV], end2[NEXT]);
    do {
      const after3 = getEnd(start);
      const next2 = after3 === end2 ? after3 : after3[NEXT];
      if (fragment)
        fragment.insertBefore(start, fragment[END]);
      else
        start.remove();
      start = next2;
    } while (start !== end2);
  };
  var Range = class {
    constructor() {
      this[START] = null;
      this[END] = null;
      this.commonAncestorContainer = null;
    }
    /* TODO: this is more complicated than it looks
      setStart(node, offset) {
        this[START] = node.childNodes[offset];
      }
    
      setEnd(node, offset) {
        this[END] = getEnd(node.childNodes[offset]);
      }
      //*/
    insertNode(newNode) {
      this[END].parentNode.insertBefore(newNode, this[START]);
    }
    selectNode(node) {
      this[START] = node;
      this[END] = getEnd(node);
    }
    surroundContents(parentNode) {
      parentNode.replaceChildren(this.extractContents());
    }
    setStartBefore(node) {
      this[START] = node;
    }
    setStartAfter(node) {
      this[START] = node.nextSibling;
    }
    setEndBefore(node) {
      this[END] = getEnd(node.previousSibling);
    }
    setEndAfter(node) {
      this[END] = getEnd(node);
    }
    cloneContents() {
      let { [START]: start, [END]: end2 } = this;
      const fragment = start.ownerDocument.createDocumentFragment();
      while (start !== end2) {
        fragment.insertBefore(start.cloneNode(true), fragment[END]);
        start = getEnd(start);
        if (start !== end2)
          start = start[NEXT];
      }
      return fragment;
    }
    deleteContents() {
      deleteContents(this);
    }
    extractContents() {
      const fragment = this[START].ownerDocument.createDocumentFragment();
      deleteContents(this, fragment);
      return fragment;
    }
    createContextualFragment(html3) {
      const template = this.commonAncestorContainer.createElement("template");
      template.innerHTML = html3;
      this.selectNode(template.content);
      return template.content;
    }
    cloneRange() {
      const range = new Range();
      range[START] = this[START];
      range[END] = this[END];
      return range;
    }
  };

  // node_modules/linkedom/esm/interface/tree-walker.js
  var isOK = ({ nodeType }, mask) => {
    switch (nodeType) {
      case ELEMENT_NODE:
        return mask & SHOW_ELEMENT;
      case TEXT_NODE:
        return mask & SHOW_TEXT;
      case COMMENT_NODE:
        return mask & SHOW_COMMENT;
    }
    return 0;
  };
  var TreeWalker = class {
    constructor(root4, whatToShow = SHOW_ALL) {
      this.root = root4;
      this.currentNode = root4;
      this.whatToShow = whatToShow;
      let { [NEXT]: next2, [END]: end2 } = root4;
      if (root4.nodeType === DOCUMENT_NODE) {
        const { documentElement } = root4;
        next2 = documentElement;
        end2 = documentElement[END];
      }
      const nodes = [];
      while (next2 !== end2) {
        if (isOK(next2, whatToShow))
          nodes.push(next2);
        next2 = next2[NEXT];
      }
      this[PRIVATE] = { i: 0, nodes };
    }
    nextNode() {
      const $3 = this[PRIVATE];
      this.currentNode = $3.i < $3.nodes.length ? $3.nodes[$3.i++] : null;
      return this.currentNode;
    }
  };

  // node_modules/linkedom/esm/interface/document.js
  var query = (method, ownerDocument, selectors) => {
    let { [NEXT]: next2, [END]: end2 } = ownerDocument;
    return method.call({ ownerDocument, [NEXT]: next2, [END]: end2 }, selectors);
  };
  var globalExports = assign(
    {},
    Facades,
    HTMLClasses,
    {
      CustomEvent,
      Event: GlobalEvent,
      EventTarget: DOMEventTarget,
      InputEvent,
      NamedNodeMap,
      NodeList
    }
  );
  var window2 = /* @__PURE__ */ new WeakMap();
  var Document2 = class extends NonElementParentNode {
    constructor(type) {
      super(null, "#document", DOCUMENT_NODE);
      this[CUSTOM_ELEMENTS] = { active: false, registry: null };
      this[MUTATION_OBSERVER] = { active: false, class: null };
      this[MIME] = Mime[type];
      this[DOCTYPE] = null;
      this[DOM_PARSER] = null;
      this[GLOBALS] = null;
      this[IMAGE] = null;
      this[UPGRADE] = null;
    }
    /**
     * @type {globalThis.Document['defaultView']}
     */
    get defaultView() {
      if (!window2.has(this))
        window2.set(this, new Proxy(globalThis, {
          set: (target, name, value) => {
            switch (name) {
              case "addEventListener":
              case "removeEventListener":
              case "dispatchEvent":
                this[EVENT_TARGET][name] = value;
                break;
              default:
                target[name] = value;
                break;
            }
            return true;
          },
          get: (globalThis2, name) => {
            switch (name) {
              case "addEventListener":
              case "removeEventListener":
              case "dispatchEvent":
                if (!this[EVENT_TARGET]) {
                  const et = this[EVENT_TARGET] = new DOMEventTarget();
                  et.dispatchEvent = et.dispatchEvent.bind(et);
                  et.addEventListener = et.addEventListener.bind(et);
                  et.removeEventListener = et.removeEventListener.bind(et);
                }
                return this[EVENT_TARGET][name];
              case "document":
                return this;
              case "navigator":
                return {
                  userAgent: "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36"
                };
              case "window":
                return window2.get(this);
              case "customElements":
                if (!this[CUSTOM_ELEMENTS].registry)
                  this[CUSTOM_ELEMENTS] = new CustomElementRegistry(this);
                return this[CUSTOM_ELEMENTS];
              case "performance":
                return import_perf_hooks.performance;
              case "DOMParser":
                return this[DOM_PARSER];
              case "Image":
                if (!this[IMAGE])
                  this[IMAGE] = ImageClass(this);
                return this[IMAGE];
              case "MutationObserver":
                if (!this[MUTATION_OBSERVER].class)
                  this[MUTATION_OBSERVER] = new MutationObserverClass(this);
                return this[MUTATION_OBSERVER].class;
            }
            return this[GLOBALS] && this[GLOBALS][name] || globalExports[name] || globalThis2[name];
          }
        }));
      return window2.get(this);
    }
    get doctype() {
      const docType = this[DOCTYPE];
      if (docType)
        return docType;
      const { firstChild } = this;
      if (firstChild && firstChild.nodeType === DOCUMENT_TYPE_NODE)
        return this[DOCTYPE] = firstChild;
      return null;
    }
    set doctype(value) {
      if (/^([a-z:]+)(\s+system|\s+public(\s+"([^"]+)")?)?(\s+"([^"]+)")?/i.test(value)) {
        const { $1: name, $4: publicId, $6: systemId } = RegExp;
        this[DOCTYPE] = new DocumentType(this, name, publicId, systemId);
        knownSiblings(this, this[DOCTYPE], this[NEXT]);
      }
    }
    get documentElement() {
      return this.firstElementChild;
    }
    get isConnected() {
      return true;
    }
    /**
     * @protected
     */
    _getParent() {
      return this[EVENT_TARGET];
    }
    createAttribute(name) {
      return new Attr(this, name);
    }
    createComment(textContent2) {
      return new Comment3(this, textContent2);
    }
    createDocumentFragment() {
      return new DocumentFragment(this);
    }
    createDocumentType(name, publicId, systemId) {
      return new DocumentType(this, name, publicId, systemId);
    }
    createElement(localName) {
      return new Element2(this, localName);
    }
    createRange() {
      const range = new Range();
      range.commonAncestorContainer = this;
      return range;
    }
    createTextNode(textContent2) {
      return new Text3(this, textContent2);
    }
    createTreeWalker(root4, whatToShow = -1) {
      return new TreeWalker(root4, whatToShow);
    }
    createNodeIterator(root4, whatToShow = -1) {
      return this.createTreeWalker(root4, whatToShow);
    }
    createEvent(name) {
      const event = create(name === "Event" ? new GlobalEvent("") : new CustomEvent(""));
      event.initEvent = event.initCustomEvent = (type, canBubble = false, cancelable = false, detail) => {
        defineProperties(event, {
          type: { value: type },
          canBubble: { value: canBubble },
          cancelable: { value: cancelable },
          detail: { value: detail }
        });
      };
      return event;
    }
    cloneNode(deep = false) {
      const {
        constructor,
        [CUSTOM_ELEMENTS]: customElements2,
        [DOCTYPE]: doctype
      } = this;
      const document2 = new constructor();
      document2[CUSTOM_ELEMENTS] = customElements2;
      if (deep) {
        const end2 = document2[END];
        const { childNodes } = this;
        for (let { length } = childNodes, i3 = 0; i3 < length; i3++)
          document2.insertBefore(childNodes[i3].cloneNode(true), end2);
        if (doctype)
          document2[DOCTYPE] = childNodes[0];
      }
      return document2;
    }
    importNode(externalNode) {
      const deep = 1 < arguments.length && !!arguments[1];
      const node = externalNode.cloneNode(deep);
      const { [CUSTOM_ELEMENTS]: customElements2 } = this;
      const { active } = customElements2;
      const upgrade = (element) => {
        const { ownerDocument, nodeType } = element;
        element.ownerDocument = this;
        if (active && ownerDocument !== this && nodeType === ELEMENT_NODE)
          customElements2.upgrade(element);
      };
      upgrade(node);
      if (deep) {
        switch (node.nodeType) {
          case ELEMENT_NODE:
          case DOCUMENT_FRAGMENT_NODE: {
            let { [NEXT]: next2, [END]: end2 } = node;
            while (next2 !== end2) {
              if (next2.nodeType === ELEMENT_NODE)
                upgrade(next2);
              next2 = next2[NEXT];
            }
            break;
          }
        }
      }
      return node;
    }
    toString() {
      return this.childNodes.join("");
    }
    querySelector(selectors) {
      return query(super.querySelector, this, selectors);
    }
    querySelectorAll(selectors) {
      return query(super.querySelectorAll, this, selectors);
    }
    /* c8 ignore start */
    getElementsByTagNameNS(_2, name) {
      return this.getElementsByTagName(name);
    }
    createAttributeNS(_2, name) {
      return this.createAttribute(name);
    }
    createElementNS(nsp, localName, options2) {
      return nsp === SVG_NAMESPACE ? new SVGElement(this, localName, null) : this.createElement(localName, options2);
    }
    /* c8 ignore stop */
  };
  setPrototypeOf(
    globalExports.Document = function Document3() {
      illegalConstructor();
    },
    Document2
  ).prototype = Document2.prototype;

  // node_modules/linkedom/esm/shared/parse-json.js
  var { parse: parse7 } = JSON;

  // node_modules/linkedom/esm/index.js
  function Document4() {
    illegalConstructor();
  }
  setPrototypeOf(Document4, Document2).prototype = Document2.prototype;

  // src/content-scripts/api.ts
  var import_webextension_polyfill7 = __toESM(require_browser_polyfill());
  async function apiExtractText(url) {
    const response = await import_webextension_polyfill7.default.runtime.sendMessage({
      type: "get_webpage_text",
      url
    });
    return [response];
  }

  // src/content-scripts/mainUI.tsx
  var isProcessing = false;
  var updatingUI = false;
  var rootEl = getRootElement();
  var btnSubmit;
  var textarea;
  var chatGptFooter;
  var toolbar;
  function renderSlashCommandsMenu() {
    let div = document.querySelector("div.wcg-slash-commands-menu");
    if (div)
      div.remove();
    div = document.createElement("div");
    div.className = "wcg-slash-commands-menu";
    const textareaParentParent = textarea?.parentElement?.parentElement;
    textareaParentParent?.insertBefore(div, textareaParentParent.firstChild);
    P(/* @__PURE__ */ h(slashCommandsMenu_default, { textarea }), div);
  }
  async function processQuery(query2, userConfig) {
    const containsWebResults = await promptContainsWebResults();
    if (!containsWebResults) {
      return void 0;
    }
    let results;
    const pageCommandMatch = query2.match(/page:(\S+)/);
    if (pageCommandMatch) {
      const url = pageCommandMatch[1];
      results = await apiExtractText(url);
    } else {
      const searchRequest = {
        query: query2,
        timerange: userConfig.timePeriod,
        region: userConfig.region
      };
      results = await webSearch(searchRequest, userConfig.numWebResults);
    }
    return results;
  }
  async function handleSubmit(query2) {
    if (!textarea)
      return;
    const userConfig = await getUserConfig();
    if (!userConfig.webAccess) {
      textarea.value = query2;
      pressEnter();
      return;
    }
    try {
      const results = await processQuery(query2, userConfig);
      const compiledPrompt = await compilePrompt(results, query2);
      textarea.value = compiledPrompt;
      pressEnter();
    } catch (error) {
      if (error instanceof Error) {
        showErrorMessage(error);
      }
    }
  }
  async function onSubmit(event) {
    if (!textarea)
      return;
    const isKeyEvent = event instanceof KeyboardEvent;
    if (isKeyEvent && event.shiftKey && event.key === "Enter")
      return;
    if (isKeyEvent && event.key === "Enter" && event.isComposing)
      return;
    if (!isProcessing && (event.type === "click" || isKeyEvent && event.key === "Enter")) {
      const query2 = textarea?.value.trim();
      if (!query2)
        return;
      textarea.value = "";
      const isPartialCommand = slashCommands.some((command) => command.name.startsWith(query2) && query2.length <= command.name.length);
      if (isPartialCommand) {
        return;
      }
      isProcessing = true;
      await handleSubmit(query2);
      isProcessing = false;
    }
  }
  function pressEnter() {
    textarea?.focus();
    const enterEvent = new KeyboardEvent("keydown", {
      bubbles: true,
      cancelable: true,
      key: "Enter",
      code: "Enter"
    });
    textarea?.dispatchEvent(enterEvent);
  }
  function showErrorMessage(error) {
    console.info("WebChatGPT error --> API error: ", error);
    const div = document.createElement("div");
    document.body.appendChild(div);
    P(/* @__PURE__ */ h(errorMessage_default, { message: error.message }), div);
  }
  async function updateUI() {
    if (updatingUI)
      return;
    updatingUI = true;
    textarea = getTextArea();
    toolbar = getWebChatGPTToolbar();
    if (!textarea) {
      toolbar?.remove();
      return;
    }
    if (toolbar)
      return;
    console.info("WebChatGPT: Updating UI");
    btnSubmit = getSubmitButton();
    btnSubmit?.addEventListener("click", onSubmit);
    textarea?.addEventListener("keydown", onSubmit);
    await renderToolbar();
    renderSlashCommandsMenu();
    await renderSectionButtons();
    chatGptFooter = getFooter();
    if (chatGptFooter) {
      const lastChild = chatGptFooter.lastElementChild;
      if (lastChild)
        lastChild.style.padding = "0 0 0.5em 0";
    }
    updatingUI = false;
  }
  async function renderToolbar() {
    try {
      const textareaParentParent = textarea?.parentElement?.parentElement;
      const { shadowRootDiv, shadowRoot } = await createShadowRoot_default("content-scripts/mainUI.css");
      shadowRootDiv.classList.add("wcg-toolbar");
      textareaParentParent?.appendChild(shadowRootDiv);
      P(/* @__PURE__ */ h(toolbar_default, { textarea }), shadowRoot);
    } catch (e3) {
      if (e3 instanceof Error) {
        showErrorMessage(Error(`Error loading WebChatGPT toolbar: ${e3.message}. Please reload the page (F5).`));
      }
    }
  }
  var mutationObserver = new MutationObserver((mutations) => {
    if (!mutations.some((mutation) => mutation.removedNodes.length > 0))
      return;
    if (getWebChatGPTToolbar())
      return;
    try {
      updateUI();
    } catch (e3) {
      if (e3 instanceof Error) {
        showErrorMessage(e3);
      }
    }
  });
  window.onload = function() {
    updateUI();
    mutationObserver.observe(rootEl, { childList: true, subtree: true });
  };
  window.onunload = function() {
    mutationObserver.disconnect();
  };
})();
/*! Bundled license information:

lodash-es/lodash.js:
  (**
   * @license
   * Lodash (Custom Build) <https://lodash.com/>
   * Build: `lodash modularize exports="es" -o ./`
   * Copyright OpenJS Foundation and other contributors <https://openjsf.org/>
   * Released under MIT license <https://lodash.com/license>
   * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
   * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
   *)
*/
